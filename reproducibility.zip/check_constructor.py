#!/usr/bin/env python3
"""Optional self-contained constructor audit, including all 4,256 finite kernels."""
import argparse,itertools,json,random,sys,time
from pathlib import Path
from collections import Counter
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'artifact'))
import networkx as nx
from subcubic_bip_core_no_three import color_subcubic_two_marked
from construct import recount

def expand(n,threads,pendants):
    g=nx.Graph();g.add_nodes_from(range(n));count=n
    for u,v,length in threads:
        assert length>=(3 if u==v else 1)
        middle=list(range(count,count+length-1));count+=length-1
        path=[u]+middle+[v]
        for a,b in zip(path,path[1:]):assert not g.has_edge(a,b);g.add_edge(a,b)
    for u,length in pendants:
        extra=list(range(count,count+length));count+=length
        path=[u]+extra;g.add_edges_from(zip(path,path[1:]))
    assert all(g.degree(v)==3 for v in range(n)) and nx.is_connected(g)
    return g

def kernel_core(left,right,length,lift=False,rng=None):
    g=nx.Graph();g.add_nodes_from((0,1));flags={0:[],1:[]};count=2
    def path(u,v,n):
        nonlocal count
        middle=list(range(count,count+n-1));count+=n-1
        for w in middle:flags[w]=[True]
        word=[u]+middle+[v];g.add_edges_from(zip(word,word[1:]))
    path(0,1,length)
    for root,side in enumerate((left,right)):
        for name in side:
            n=int(name[1:]);marked=name[0]=='m'
            if lift and ((marked and n==6) or (not marked and n==3)):n+=rng.randrange(12)
            if n==0:flags[root].append(False)
            else:
                leaf=count;count+=1;flags[leaf]=[False,True];path(root,leaf,n)
    assert set(g)==set(range(len(g)))
    return g,flags

def cloned_network(core,flags,rng):
    n=len(core);threads=[(u,v,1) for u,v in core.edges()]+[(u+n,v+n,1) for u,v in core.edges()]
    for short,length in [(False,3),(True,2)]:
        ports=[v for v in core for flag in flags[v] if flag==short]
        target=[v+n for v in ports];rng.shuffle(target)
        threads.extend((u,v,length) for u,v in zip(ports,target))
    return expand(2*n,threads,[])

def random_graph(n,rng):
    tree=nx.empty_graph(n)
    for v in range(1,n):tree.add_edge(rng.choice([u for u in range(v) if tree.degree(u)<3]),v)
    direct=set();threads=[];choices=(1,1,1,2,2,3,3,4,5,8,13)
    for u,v in tree.edges():
        k=rng.choice(choices);threads.append((u,v,k))
        if k==1:direct.add(frozenset((u,v)))
    stubs=[v for v in tree for _ in range(3-tree.degree(v))];rng.shuffle(stubs);pendants=[]
    while stubs:
        u=stubs.pop()
        if not stubs or rng.randrange(8)==0:pendants.append((u,rng.randrange(1,10)));continue
        v=stubs.pop();k=rng.choice(choices)
        if u==v:k=max(k,3)
        elif k==1 and frozenset((u,v)) in direct:k=2
        if k==1:direct.add(frozenset((u,v)))
        threads.append((u,v,k))
    return expand(n,threads,pendants)

def main():
    if not __debug__:raise SystemExit('Do not run with -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path);parser.add_argument('--random',type=int,default=2200)
    parser.add_argument('--skip-kernels',action='store_true');args=parser.parse_args()
    rng=random.Random(2026102703);start=time.monotonic();counts=Counter();controls=Counter()
    def check(kind,g):
        out=color_subcubic_two_marked(g);recount(g,out);counts[kind]+=1
        for r in out.get('core_reports',[]):
            if r['kind']=='two_intrinsic_controls':controls[','.join(sorted(x[0] for x in r['controls']))]+=1
    for g in nx.graph_atlas_g():
        if len(g)>=3 and nx.is_connected(g) and max(dict(g.degree()).values())<=3:check('atlas',g)
    check('single_vertex',nx.empty_graph(1))
    if not args.skip_kernels:
        data=json.loads((ROOT/'artifact/weak_two_marked_interfaces.json').read_text(encoding='utf-8'))
        for r in data['records']:
            core,flags=kernel_core(r['left'],r['right'],r['length'])
            check('kernel_clone_networks',cloned_network(core,flags,rng))
    for _ in range(args.random):check('random_compressions',random_graph(rng.randrange(1,100),rng))
    for n in range(4,102,2):
        for _ in range(4):
            g=nx.random_regular_graph(3,n,seed=rng.randrange(1<<30))
            if nx.is_connected(g):check('cubic',g)
    out={'constructor_check':'PASS','actual_graph_counts':dict(counts),'total':sum(counts.values()),
         'intrinsic_control_pairs':dict(controls),'python':sys.version.split()[0],
         'networkx':nx.__version__,'seed':2026102703,'seconds':round(time.monotonic()-start,3),
         'scope':'Finite implementation audit, not the universal proof or unrestricted conjecture'}
    text=json.dumps(out,indent=2)+'\n'
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text,encoding='utf-8')
    print(text,end='')

if __name__=='__main__':main()
