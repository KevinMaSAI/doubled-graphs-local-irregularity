# Complete retained-claim coverage ledger

English proof filenames below are relative to `manuscript/`. Code/data basenames are in
`artifact/` unless they name a root entry point such as `verify_a1.py`. Other explicit paths
are relative to the archive root.
A/B/C are inventory groups, not counts of independent or historically first theorems. D groups are completed post-17:00 extensions.
Every original subclaim is retained with its conditions; covered ordinary existence results become corollaries rather than additional main claims.

| ID | English proof | Exact retained scope | Implementation | Certificate or audit |
|---|---|---|---|---|
| A1 | subcubic.tex | Full subcubic theorem and all earlier covered cubic/subcubic families. | subcubic_bip_core_no_three.py; weak_two_marked_tree.py; verify_a1.py | Five A1 interface tables; independent_local_review.py |
| A2(a) | ports_and_branches.tex | Independent branch vertices; arbitrary degrees, short paths, loops and pendants. | independent_branch_coloring.py | independent_branch_validation.json |
| A2(b) | ports_and_branches.tex | No degree-three vertex; retained direct branch edges form a matching. | matching_branch_coloring.py | matching_branch_repair_witnesses.json |
| A2(c) | ports_and_branches.tex | Retained direct matching with ordinary non-direct paths at least four; degree three allowed. | matching_long_branch_coloring.py | matching_long_branch_witnesses.json |
| A3 | ports_and_branches.tex | Homogeneous original degree per three-colourable direct component; no returns; long paths at least three; even signed-form lemma. | even_signed_forms.py; degree_homogeneous_long_core.py | degree_homogeneous_long_core_validation.json |
| A4 | ports_and_branches.tex | Balanced partial subdivisions with selected degree not one and unequal original degrees on retained edges. | balanced_subdivision.py | balanced_subdivision_example.json |
| A5 | ports_and_branches.tex | Given-component colour preservation, componentwise constant new degree 0 or at least four, including explicit K2 handling. | balanced_subdivision.py | balanced_subdivision_validation.json |
| A6 | ports_and_branches.tex | Near-centre realisation of every feasible parity; colouring under the degree-gap bipartite phase condition. | parity_initialization.py | parity_degree_tools_validation.json |
| A7 | cliques_and_gluing.tex | All clique root targets, strong nonroot bounds with two K4 exceptions, outward-capacity clique block trees. | rooted_clique_interface.py; clique_block_tree.py | rooted_clique_interfaces.json: 836 complete bases |
| A8 | cliques_and_gluing.tex | Given-colour bouquets and arbitrary unknown cores with sufficient capacity at each vertex. | clique_bouquet_extension.py | clique_bouquet_extension_validation.json |
| A9 | cliques_and_gluing.tex | Tree gluing of supplied local colours under explicit interval separation. | piece_tree_gluing.py; regular_block_tree.py | piece_tree_gluing_validation.json |
| B1(a) | ports_and_branches.tex | One-bridge tree candidate sets and precise endpoint compatibility; pure and mixed path interfaces. | tree_ports.py; independent_branch_coloring.py | tree_ports_validation.json; extra_checks.py |
| B1(b) | ports_and_branches.tex | Arbitrary decorated-path endpoints at length six; finite 24-state saturation with unbounded-length induction. | decorated_paths.py | decorated_path_certificate.json; decorated_path_certificate_check.py |
| B1(c) | ports_and_branches.tex | Preserved given colouring under the exact 4+epsilon+epsilon subdivision threshold, and the full 60-state cubic diagnosis. | preserve_given_subdivision.py | preserve_given_subdivision_validation.json |
| B1(d) | algebra.tex | Two arbitrary real offsets on odd forests; physical offsets on odd-order connected bipartite graphs. | parity_initialization.py; coefficient_frontier.py | Proof via parity or highest coefficient; not an outside-edge guarantee |
| B2 | targets_and_reductions.tex | Complementary target lists; fixed-target minimum F via matching; capacity/odd-component criterion; even-target integrality; parity intervals; symmetric exchanges; quotient T-join lower bound. | fixed_degree_coloring.py; target_obstructions.py; parity_window_factor.py | extra_checks.py; prior target and factor validation records; classical applications attributed |
| B3 | algebra.tex | Exact edge factors, free-parameter sufficiency, permanent identity, line-graph principal minors, tree examples and list-weighting implication. | coefficient_frontier.py; parity_certificate.py; actual_polynomial.py; central_coefficient.py | verify.py exact interpolation/permanent checks; extra_checks.py exact principal-minor tests |
| B4 | targets_and_reductions.tex | Sparse mixed odd-cactus normal form; energy/degree-one cleanup; exact tree elimination and capacity; universal vertices; minimal-counterexample restrictions. | high_degree_cleanup.py; core_tree_boundary.py; universal_vertex_extension.py | extra_checks.py and original core/tree/universal validation records |
| C1 | obstructions.tex; algebra.tex | All maximum cuts fail zero-exception template on an explicit minimum-degree-three family; H7/O9 and even/odd boundary modules; six-vertex modulo-three obstruction; regular modulo-two certificate failure; added R=degree parity obstruction. | core_parity_obstruction.py; parity_certificate.py | core_parity_obstruction_r3.json; algebraic rank proof; explicit legal witnesses |
| C2 | obstructions.tex | Wheel closed two-state plateau; 13-regular strict two-unit minima over whole target fibres; P5 barrier even after proper 1-2-3 initialisation. | frozen_target_graph.py; fixed_degree_coloring.py | frozen_target_data.json; wheel6_plateau_verified.json; proper_initialization_validation.json; verify.py |
| C3 | obstructions.tex | Bridge locking, pure odd-factor defect with continuous witness, strictness of quotient lower bound, nonconvex F, unbounded fixed-parity repair radius and exception budget; C5 centre-window obstruction. | target_obstructions.py; parity_repair_obstruction.py | actual_target_integrality_obstruction.json; parity_radius_matching_obstruction.json; exact rational checks |
| C4 | ports_and_branches.tex; cliques_and_gluing.tex; obstructions.tex | Five-edge fixed endpoint failure; preserved tree capacity and clique capacity cannot uniformly drop by one, with full recolourings. | core_extension_family.py; clique_bouquet_extension.py; decorated_paths.py | five_edge_boundary_obstruction.json; sharpness-family witnesses and independent checks |
| C5 | cliques_and_gluing.tex; obstructions.tex | All four whole-piece flips fail for two rooted Krr pieces; nonclique root sums 0 and 6 fail; multiple fixed bridges and strong marked ports have narrower domains. | piece_tree_gluing.py; tree_ports.py; verify.py | two_port_path_obstruction.json; multiple_strong_mixed_obstructions.json; 3888-state independent audit |
| D1 | high_degree.tex | delta >= 8c(2c+1)-7, shifted CRT interfaces, one-vertex boundary absorption, bridge minimality, simple-host limitation. | chromatic_degree_factor.py; factor_cut_certificate.py; one_boundary_region.py | chromatic_degree_factor_witnesses.json; one_boundary_region_validation.json |
| D2 | high_degree.tex | Many CRT regions with global proper labels; class-dependent palette budgets; private-leaf low-side preprocessing and K2 exception; matching-supported trees on an ordinarily irregular core, and rigid old-colour leaf example. | region_partition_absorption.py; low_side_ports.py; irregular_core_tree_attachment.py | region_partition_absorption_witness.json; low_side_ports_validation.json; irregular_core_tree_attachment_validation.json |
| D3 | dense_regions.tex | 8 delta >= 7n+6; all red degrees pairwise distinct and all blue degrees pairwise distinct, via antitone targets and Tutte. | dense_antitone_factor.py | dense_antitone_factor_witness.json; independent scalar bounds |
| D4 | complements.tex | Four-vertex complement lift preserving old colours and uniform count increments; complement cycle-chord family; parity-refined defective-partition obstruction; edge-transitive cubic complement families; counterexample restrictions. | complement_path_lift.py; co_cycle_chord_family.py | co_cycle_chord_witness.json; complement_path_lift_validation.json |
| D5 | dense_regions.tex | Forbidden red targets with physical offsets; class-dependent E,W bounds; per-vertex boundary condition n >= 8q+8t(q+t+2)+18; sequential induced regions; additional parity rule obstruction is in C1. | dense_offset_lists.py; sequential_dense_absorption.py | dense_offset_lists_witness.json; sequential_dense_absorption_witnesses.json |

## Consolidated special cases

Cubic matching and arbitrary-edge subdivisions at lengths four and three are included in A1; their original independent constructors remain in the artifact.
Independent branch points include fully subdivided arbitrary mother graphs at lengths at least three. A4 retains its stronger balanced root sums and partial-retention property.
Equal-order clique block trees are special cases of A7; ordinary clique colourability was already known.
The fixed parameter polynomial is a special case of B3; previously known tree and unicyclic existence results are examples, not new family breakthroughs.
O9 is retained for its boundary-interface information but is not counted separately from the stronger C1 family as a template disproof.

## Completed main-task source notes after 17:00

- D1: degree-constrained subgraphs and high minimum degree.
- D2: multi-region boundary absorption and low-side restoration (including irregular-core tree attachments).
- D3/D4: dense antitone targets; complement four-vertex lifts and parity-decomposition barriers.
- D5: dense forbidden targets and sequential absorption.

The frozen scope is documented in `provenance/source_scope.json`. Those probes were unfinished at the earlier 27 October snapshot. The separate
28 October snapshot adds the completed E1--E4 partition results listed below;
subsequent unfinished component-DP work remains excluded.

## Claim limits

A1 is a computer-assisted proof manuscript, internally checked but not independently peer reviewed or formalised. B2 uses classical matching/factor/exchange theory. No exhaustive historical originality claim is made.
The mother conjecture for arbitrary connected simple graphs other than K2 remains unproved. Every C-group obstruction concerns extra strategy restrictions and has no counterexample claim against that conjecture.

## Completed additions of 28 October 2026 (revision 1.1.1)

| Group | English section | Retained content and limits | Code and independent audit |
|---|---|---|---|
| E1 | Signed gaps and paired partitions | Homogeneous forms with at least four terms, each variable in at most two rows; absolute gap at least two. Paired-partition construction with local degree differences at most one, allowing unbounded maximum degree. Fixed-mixed integer repairs and sharp auxiliary limitations. | signed_gap_two.py; integer_matching_cut.py; audit_integer_matching_cut_stage.py |
| E2 | Path and cycle sides in degree three and four | A supplied path/cycle side against an induced matching covering the other side. Exact local relations and a matching of sufficient protection edges. No universal partition claim. | path_cycle_partition.py; audit_path_cycle_partition_stage.py |
| E3 | Isolated vertices of the matching side | Protected parity joins; exact fixed-mixed completion for an independent side; bridge-forced strategy obstruction and repair. | isolate_parity_partitions.py; audit_isolate_parity_partitions_stage.py |
| E4 | Odd-component root ports at arbitrary degrees | Given eligible roots and a qualified port set, an explicit construction without a global degree bound. Component parity is sufficient automatically only within the stated one-or-three port capacity. | odd_component_root_ports.py; audit_odd_component_root_ports_stage.py |

The even-component parity-swapped existence result is a corollary of E4, not a
separate maximal contribution. E2 covers the degree-three/four special case of
E1's graph application, but does not replace E1 at arbitrary degrees. E3 includes
fixed-interface information absent from E4. The biased maximum-cut shape is an
elementary supporting lemma and not a claim of a new general partition theorem.
The four source notes were frozen at 10:25:33 China Standard Time on 28 October.
An unfinished component-DP investigation was screened out at that cutoff.
