#!/usr/bin/env python3
"""Run the released constructor regression checks with pinned optional dependencies.

These sampled graph tests are separate from the complete finite proof certificates.
No test result is interpreted as a proof of the unrestricted conjecture.
"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import uuid

ROOT=Path(__file__).resolve().parent
TESTS=[
 'check_constructor.py',
 'artifact/check_independent_branch_coloring.py',
 'artifact/check_matching_branch_coloring.py',
 'artifact/check_matching_long_branch_coloring.py',
 'artifact/check_degree_homogeneous_long_core.py',
 'artifact/check_balanced_subdivision.py',
 'artifact/check_parity_degree_tools.py',
 'artifact/check_preserve_given_subdivision.py',
 'artifact/check_rooted_clique_interface.py',
 'artifact/check_clique_block_tree.py',
 'artifact/check_clique_bouquet_extension.py',
 'artifact/check_piece_tree_gluing.py',
 'artifact/check_chromatic_degree_factor.py',
 'artifact/check_one_boundary_region.py',
 'artifact/check_low_side_ports.py',
 'artifact/check_region_partition_absorption.py',
 'artifact/check_irregular_core_tree_attachment.py',
 'artifact/check_dense_antitone_factor.py',
 'artifact/check_dense_offset_lists.py',
 'artifact/check_sequential_dense_absorption.py',
 'artifact/check_complement_path_lift.py',
 'extra_checks.py',
 'artifact/check_integer_matching_cut.py',
 'artifact/check_path_cycle_partition.py',
 'artifact/check_isolate_parity_partitions.py',
 'artifact/check_odd_component_root_ports.py',

]


def main():
    if not __debug__:raise SystemExit('Do not run with -O.')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'validation/constructors.json')
    p.add_argument('--timeout',type=int,default=600)
    args=p.parse_args()
    import networkx
    import z3
    started=time.monotonic()
    logdir=ROOT/'validation/constructor_logs'
    logdir.mkdir(parents=True,exist_ok=True)
    # Checkers may emit new witnesses or timing reports. Keep the released data immutable.
    workspace=ROOT/'validation'/('constructor_workspace_'+uuid.uuid4().hex[:8])
    shutil.copytree(ROOT/'artifact',workspace/'artifact')
    for name in ('construct.py','check_constructor.py','extra_checks.py'):
        shutil.copy2(ROOT/name,workspace/name)
    records=[]
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    for script in TESTS:
        t=time.monotonic()
        name=Path(script).stem
        command=[sys.executable,'-X','utf8','-B',str(workspace/script)]
        try:
            r=subprocess.run(command,cwd=workspace,capture_output=True,encoding='utf-8',
                             errors='replace',env=env,timeout=args.timeout)
            output=r.stdout+'\n'+r.stderr
            status='PASS' if r.returncode==0 else 'FAIL'
            code=r.returncode
        except subprocess.TimeoutExpired as ex:
            status='TIMEOUT';code=None
            output=str(ex)
        # Logs are bounded; tests emit finite summaries and witnesses stay in data files.
        if len(output)>1_000_000:
            output=output[:450_000]+'\n[log truncated]\n'+output[-450_000:]
        (logdir/(name+'.log')).write_text(output,encoding='utf-8')
        record={'script':script,'status':status,'exit_code':code,
                'seconds':round(time.monotonic()-t,3),'log':'constructor_logs/'+name+'.log'}
        records.append(record)
        print(json.dumps(record),flush=True)
        report={'records':records,'all_checks_passed':all(x['status']=='PASS' for x in records),
                'completed_checks':len(records),'planned_checks':len(TESTS),
                'python':sys.version.split()[0],'networkx':networkx.__version__,
                'z3':z3.get_version_string(),'seconds':round(time.monotonic()-started,3),
                'scope':'Finite implementation checks; not formalisation or unrestricted proof.',
                'mother_conjecture_proved':False}
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
        if status!='PASS':raise SystemExit('Check '+status+': '+script)


if __name__=='__main__':main()
