# Zenodo metadata — local preparation only

- Title: Locally Irregular Two-Edge-Colourings of Doubled Graphs: Constructions, Extensions, and Obstructions
- Creator: Qiyuan Ma; family name Ma; given name Qiyuan
- Affiliation: Shanghai Jiao Tong University
- Resource: Publication / Preprint
- Version: 1.1.1
- Manuscript date: 2026-10-28
- Publication date: 28 October 2026 (first public availability on GitHub); not yet published on Zenodo.
- Language: English
- Licences: CC-BY-4.0 for manuscript/documentation/certificate JSON; MIT for Python code.
- Existing DOI: none for this work. No DOI has been reserved or registered.
- ORCID: https://orcid.org/0009-0000-9532-0821
- Funding, community and additional authors: not supplied; omitted.
- Author contact email: mqyqwerty@sjtu.edu.cn; author approved public display in the manuscript, record description and README.
- Current repository preparation: the paper and accompanying data were first made public on GitHub; this local update does not publish a Zenodo record.

Use the accompanying submission-preparation folder for the full abstract, record description,
keywords, related references, exact upload-file manifest and step-by-step field guide.
The data are local form preparation, not an API response or a saved server-side draft.
