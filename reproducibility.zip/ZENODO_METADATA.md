# Zenodo metadata — local preparation only

- Title: Locally Irregular Two-Edge-Colourings of Doubled Graphs: Constructions, Extensions, and Obstructions
- Creator: Qiyuan Ma; family name Ma; given name Qiyuan
- Affiliation: Shanghai Jiao Tong University
- Resource: Publication / Preprint
- Version: 1.1.1
- Manuscript date: 2026-10-28
- Publication date: the actual date of first public availability; this local draft is unpublished.
- Language: English
- Licences: CC-BY-4.0 for manuscript/documentation/certificate JSON; MIT for Python code.
- Existing DOI: none for this work. No DOI has been reserved or registered.
- ORCID, funding, community and additional authors: not supplied; omitted.
- Author contact email: mqyqwerty@sjtu.edu.cn; author approved public display in the manuscript, record description and README.
- Current repository preparation: Zenodo only; this local update does not change an account or publish a record.

Use the accompanying submission-preparation folder for the full abstract, record description,
keywords, related references, exact upload-file manifest and step-by-step field guide.
The data are local form preparation, not an API response or a saved server-side draft.
