"""Independent semantic check of the path lemma and release completeness.

This does not import a constructor or treat bounded path checks as its proof.
"""
from pathlib import Path
from itertools import product
import ast, hashlib, json, re, zipfile

ROOT=Path(__file__).resolve().parent

def ordinary_end(a,next_x,r):
    return (a==0 or r!=a+next_x) and (a==2 or 6-r!=4-a-next_x)

def physical(a,r):
    return a<=r<=a+4

ordinary_cases=return_cases=pendant_cases=0
for length in range(2,10):
    relation=set()
    ret=set()
    pend=set()
    for w in product(range(3),repeat=length):
        if any(w[i]==w[i+2] for i in range(length-2)):
            continue
        a,b=w[0],w[-1]
        left=[r for r in range(7) if physical(a,r) and ordinary_end(a,w[1],r)]
        right=[r for r in range(7) if physical(b,r) and ordinary_end(b,w[-2],r)]
        relation.update((a,b,r,s) for r in left for s in right)
        ret.update((a,b,r) for r in set(left)&set(right) if 0<=r-a-b<=2)
        # Last vertex is a leaf, with the last edge contributing all its degree.
        leaf_ok=(b==0 or w[-2]+b!=b) and (b==2 or 4-w[-2]-b!=2-b)
        if leaf_ok:
            pend.update((a,r) for r in left)
    for a,b in product((0,2),repeat=2):
        for r,s in product(range(7),repeat=2):
            if not physical(a,r) or not physical(b,s):
                continue
            if length==2:
                assert ((a,b,r,s) in relation)==(r!=2+b and s!=2+a)
                ordinary_cases+=1
            elif length>=4 or a!=b:
                assert (a,b,r,s) in relation,(length,a,b,r,s)
                ordinary_cases+=1
    if length==3:
        for a,b,r,s in product(range(3),range(3),range(7),range(7)):
            if not physical(a,r) or not physical(b,s):
                continue
            expected=a!=b and not ((a==1 or b==1) and r==s==3)
            assert ((a,b,r,s) in relation)==expected,(a,b,r,s)
            ordinary_cases+=1
    if length>=3:
        for a,b in [(0,2),(0,1),(1,2)]:
            for r in range(7):
                if not 0<=r-a-b<=2 or ((a,b)!=(0,2) and r%3==0):
                    continue
                assert (a,b,r) in ret,(length,a,b,r)
                return_cases+=1
    for a,r in product((0,2),range(7)):
        if not physical(a,r):continue
        expected=(r!=(2 if a==0 else 4)) if length==2 else True
        assert ((a,r) in pend)==expected,(length,a,r)
        pendant_cases+=1
for a,r in product((0,2),range(7)):
    if physical(a,r):
        legal=(a==0 or r!=a) and (a==2 or 6-r!=2-a)
        assert legal==(r!=(4 if a==0 else 2))
        pendant_cases+=1

tex='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'manuscript').glob('*.tex'))
labels=re.findall(r'\\label\{([^}]+)\}',tex)
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex)
assert len(labels)==len(set(labels)) and not set(refs)-set(labels)
cites={x for group in re.findall(r'\\cite\{([^}]+)\}',tex) for x in group.split(',')}
bib=set(re.findall(r'\\bibitem\{([^}]+)\}',tex))
assert cites==bib
literal=[]
for name in set(re.findall(r'\\code\{([^}]+)\}',tex)):
    if ' ' in name or '\\' in name or not re.search(r'\.(?:py|json|md|tex|txt)$',name):continue
    assert any((base/name).is_file() for base in (ROOT,ROOT/'artifact',ROOT/'manuscript')),name
    literal.append(name)
for name in ['LICENSES/CC-BY-4.0.txt','LICENSES/MIT.txt','LICENSES.md','AI_ASSISTANCE.md',
             'COVERAGE.md','PROOF_DEPENDENCIES.md','references.bib','requirements.txt']:
    assert (ROOT/name).is_file(),name
directory_links=[]
for name in re.findall(r'`([^`]+/)`',(ROOT/'README.md').read_text(encoding='utf-8')):
    if '*' in name:continue
    assert (ROOT/name).is_dir(),name
    directory_links.append(name)
source_count=0
for name,subdir in [('provenance/source_manifest.json','provenance/original_source'),
                    ('provenance/updates_20261028/source_manifest.json','provenance/updates_20261028/original_source')]:
    data=json.loads((ROOT/name).read_text(encoding='utf-8'))
    for row in data['files']:
        p=ROOT/subdir/row['name']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p.name
        source_count+=1
for p in list(ROOT.glob('*.py'))+list((ROOT/'artifact').glob('*.py')):
    ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
report={'all_checks_passed':True,'ordinary_path_endpoint_cases':ordinary_cases,
        'return_path_endpoint_cases':return_cases,'pendant_endpoint_cases':pendant_cases,
        'path_lengths_checked':[2,9],'independent_path_enumeration_not_a_universal_proof':True,
        'documented_directories_checked':len(directory_links),'unique_labels':len(labels),'resolved_references':len(refs),
        'cited_and_listed_references':len(cites),'literal_code_file_links_checked':len(literal),
        'frozen_source_files_rehashed':source_count,'licence_files_present':True,
        'mother_conjecture_proved':False,'absolute_error_freedom_certified':False,
        'formalisation_claimed':False}
print(json.dumps(report,indent=2))
