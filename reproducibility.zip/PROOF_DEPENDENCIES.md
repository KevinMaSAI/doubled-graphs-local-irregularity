# Proof dependencies and verification boundary

| Part | External fact | Local proof obligation |
|---|---|---|
| A1 | Degree-list theorem: Cranston–Rabern, Beyond degree choosability, Theorem A (classical characterisation) | Core classification, port budgets, compatible forest/cotree interfaces, full finite kernels and lifting |
| A2–A5 | Elementary Euler orientation and Hall matching; incidence linear algebra over F3 | All stated port choices, exceptional short paths, independent matching repairs, exact root sums |
| A6 | Elementary parity and spanning trees | Alternating forest trails and actual degree-gap separation |
| A7–A8 | None beyond finite verification and elementary induction | 836 complete K4/K5 bases, two-vertex induction with both exceptional bases addressed, capacity counting |
| A9 | Given legal colourings of pieces; regular-block corollary uses GOW26 | Tree sign balancing and all interval-separation hypotheses |
| B1 | Polynomial interpolation for arbitrary real forest offsets; elementary parity for physical bipartite offsets | Tree induction, exact path relations, 24-state decorated kernel, unbounded-length saturation |
| B2 | Classical perfect matching and Tutte factor theorem, jump-system background | Explicit reductions, capacity separation argument, exact costs and defect interpretation |
| B3 | Combinatorial Nullstellensatz/interpolation and Cauchy–Binet | Actual-rule edge factors, coefficient/permanent identity, free-parameter and principal-minor formulas |
| B4 | Elementary graph structure, plus previously proved interfaces | Correct potential function, exact peripheral profiles, universal-vertex K2 exception, minimality assumptions |
| D1–D2 | Addario-Berry–Dalal–Reed, Degree constrained subgraphs, Theorem 5, on a simple host; known bipartite/cactus colourings for low placeholders | All floor/ceiling bounds, disjoint CRT palettes, fixed boundary avoidance, cross-region constraints |
| D3/D5 | Tutte factor theorem on the doubled multigraph | Even sum, physical target bounds, all disjoint S,T inequalities and odd-component cases |
| D4 | Known regular-graph colourability for cubic-complement seeds | Explicit lift, preserved counts, seed word, propagation and complement-class restrictions |
| C1–C5 | No unresolved conjecture is assumed | Finite tables or parameter proofs, exact allowed moves, and legal unrestricted witnesses |

The manuscript bibliography gives stable primary-source links. Historical priority was screened in the original research notes, not certified by a finite search.

Complete finite proof certificates are different from graph-atlas or random regression tests. The release standard-library verifier checks complete domains, supplied witnesses and finite identities. `run_checks.py` tests implementations under their stated scopes. Optional solver discovery is not a proof oracle: timeouts stay unfinished. No Lean or other proof-assistant formalisation is included.

## E1--E4: integer partitions and root ports

These proofs do not use A1. The signed-gap lemma is proved by sign flips,
an explicitly oriented bad-edge graph and a spanning-tree/cycle construction.
The binary-relation argument is proved in full; two-literal satisfiability is a
standard implementation tool, not a claimed invention. Component parity recovery
uses the classical spanning-tree parity-subgraph argument, also supplied in full.
The exact statements keep the mixed set, parity pattern and root capacity explicit.
The unbounded family conclusions depend on those proofs, not atlas coverage.

The four independent `artifact/audit_*_stage.py` programs use only the standard
library and no constructor/solver imports. They rederive finite saved witnesses,
row values, truth tables and strategy obstructions. The four `check_*.py` tests
exercise the constructions and compare bounded local domains to brute force.
The old modulo-four modules are included as comparison dependencies, not as
a claim that a modular obstruction is an obstruction to actual colourability.
