#!/usr/bin/env python3
"""Standard-library release verification. Run without -O; no network is used."""
from pathlib import Path
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'artifact'
sys.path.insert(0, str(DATA))


def load(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def immutable_manifest():
    file=ROOT/'MANIFEST.sha256'
    if not file.exists():return {'status':'not_yet_generated','files_checked':0}
    checked=0
    for line in file.read_text(encoding='utf-8').splitlines():
        digest,relative=line.split('  ',1)
        parts=Path(relative)
        assert len(digest)==64 and not parts.is_absolute() and '..' not in parts.parts
        target=(ROOT/parts).resolve()
        assert target.is_relative_to(ROOT.resolve()) and target.is_file(), relative
        assert hashlib.sha256(target.read_bytes()).hexdigest()==digest, ('digest mismatch',relative)
        checked+=1
    assert checked>300
    return {'status':'PASS','files_checked':checked}


def degrees(edges, values, nodes=None, A=None, B=None):
    nodes = set(nodes or ()) | {v for e in edges for v in e}
    red = {v: Fraction((A or {}).get(v, 0)) for v in nodes}
    blue = {v: Fraction((B or {}).get(v, 0)) for v in nodes}
    assert len(edges) == len(values)
    assert len({frozenset(e) for e in edges}) == len(edges)
    for (u, v), x in zip(edges, values):
        assert u != v and 0 <= x <= 2
        for w in (u, v):
            red[w] += x
            blue[w] += 2-x
    return red, blue


def bad(edges, values):
    r, b = degrees(edges, values)
    return sum(x*(r[u] == r[v])+(2-x)*(b[u] == b[v])
               for (u, v), x in zip(edges, values))


def supplied_witnesses():
    records = []
    def walk(obj, file, trail=''):
        if isinstance(obj, list):
            for i, v in enumerate(obj):
                if isinstance(v, (dict, list)):
                    walk(v, file, trail+'/'+str(i))
            return
        if not isinstance(obj, dict):
            return
        rows = obj.get('edges', obj.get('expanded_edges'))
        if (isinstance(rows, list) and 'red' in obj and 'blue' in obj
            and all(isinstance(e, list) and len(e) == 3
                    and all(isinstance(z, int) for z in e) for e in rows)
            and isinstance(obj['red'], dict) and isinstance(obj['blue'], dict)):
            es = [tuple(e[:2]) for e in rows]
            xs = [e[2] for e in rows]
            assert all(type(x) is int and 0 <= x <= 2 for x in xs)
            A = {int(v): a for v, a in obj.get('A', {}).items()}
            B = {int(v): b for v, b in obj.get('B', {}).items()}
            nodes = set(map(int, obj['red'])) | set(map(int, obj['blue']))
            r, b = degrees(es, xs, nodes, A, B)
            assert r == {int(v): a for v, a in obj['red'].items()}, (file, trail, 'red')
            assert b == {int(v): a for v, a in obj['blue'].items()}, (file, trail, 'blue')
            for (u, v), x in zip(es, xs):
                assert x == 0 or r[u] != r[v], (file, trail, 'red edge', u, v)
                assert x == 2 or b[u] != b[v], (file, trail, 'blue edge', u, v)
            for v, forbidden in obj.get('forbidden', {}).items():
                assert r[int(v)] not in forbidden
            edge_map = {frozenset(e): x for e, x in zip(es, xs)}
            for u, v, x in obj.get('given', []):
                assert edge_map[frozenset((u, v))] == x
            if file.startswith(('dense_antitone', 'dense_offset')):
                assert len(set(r.values())) == len(r)
                assert len(set(b.values())) == len(b)
            records.append({'file': file, 'record': trail, 'vertices': len(nodes), 'edges': len(es)})
            return
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                walk(v, file, trail+'/'+k)
    files = sorted(set(DATA.glob('*witness*.json')))
    for f in files:
        walk(json.loads(f.read_text(encoding='utf-8')), f.name)
    required = {'region_partition_absorption_witness.json', 'dense_antitone_factor_witness.json',
                'dense_offset_lists_witness.json', 'sequential_dense_absorption_witnesses.json',
                'co_cycle_chord_witness.json', 'chromatic_degree_factor_witnesses.json',
                'subcubic_two_marked_witnesses.json'}
    assert required <= {r['file'] for r in records}
    return {'records': len(records), 'original_edges': sum(r['edges'] for r in records),
            'files': sorted({r['file'] for r in records}), 'details': records}


def elementary_obstructions():
    es = [(0,1),(0,2),(0,3),(0,4),(0,5),(1,2),(1,5),(2,3),(3,4),(4,5)]
    x = (1,2,1,1,0,0,2,2,0,0)
    y = (1,2,1,1,0,0,2,2,2,0)
    expected = [((4,1,4),(4,1,4)),((2,4,1),(2,2,1)),((2,1,4),(4,1,4)),
                ((4,1,4),(4,1,2)),((1,2,2),(1,4,2)),((1,3,2),(1,5,2)),
                ((2,5,1),(2,3,1)),((4,3,1),(2,2,1)),((1,4,1),(1,4,1)),
                ((1,2,2),(1,3,4))]
    for j, base in enumerate((x,y)):
        assert bad(es,base) == 1
        neighbours=[]
        for i in range(10):
            row=[]
            for z in range(3):
                w=list(base);w[i]=z
                row.append(bad(es,w))
                if z != base[i] and row[-1] <= 1: neighbours.append(tuple(w))
            assert tuple(row) == expected[i][j]
        assert neighbours == [y if j == 0 else x]
    assert bad(es,(0,2,1,1,0,1,2,2,0,0)) == 0
    es=[(0,1),(1,2),(2,3),(3,4)]
    base=(1,0,0,1)
    r,_=degrees(es,base)
    targets={}
    for xs in product(range(3),repeat=4):
        R,_=degrees(es,xs)
        q=tuple(R[i] for i in range(5))
        assert q not in targets
        targets[q]=bad(es,xs)
    ns=[v for q,v in targets.items() if sum(abs(q[i]-r[i]) for i in range(5))==2]
    assert sorted(ns)==[3]*6+[5]*2
    assert bad(es,(0,0,1,1))==0
    strong=0
    safe={0,1,3,5,6}
    for xs in product(range(3),repeat=5):
        # edges uv, u-a, u-b, v-c, v-d; each leaf has one mixed and one pure port.
        for ps in product((0,2),repeat=4):
            R=[xs[0]+xs[1]+xs[2],xs[0]+xs[3]+xs[4]]
            R += [xs[i+1]+1+ps[i] for i in range(4)]
            if all(z in safe for z in R) and all(z in (1,5) for z in R[2:]):
                if all(R[u]!=R[v] for u,v in [(0,1),(0,2),(0,3),(1,4),(1,5)]):strong+=1
    assert strong==0
    es=[(0,1),(0,2),(1,2),(3,4),(3,5),(4,5),(0,3),(2,6),(5,7),(3,8)]
    x=(0,1,1,0,1,1,1,2,2,0)
    q,_=degrees(es,x)
    continuous=(Fraction(1,2),Fraction(3,2),Fraction(1,2),Fraction(1,2),
                Fraction(3,2),Fraction(1,2),0,2,2,0)
    assert degrees(es,continuous)[0]==q and bad(es,continuous)==0
    assert sum(q[v] for v in (0,1,2,6))==9
    assert sum(q[v] for v in (3,4,5,7,8))==9
    assert bad(es,(0,2,1,0,2,1,0,2,2,0))==0
    return {'wheel_complete_neighbour_values':60,'P5_all_assignments':81,
            'P5_two_unit_neighbours':len(ns),'strong_mark_assignments':3888,
            'strong_mark_solutions':strong,'rational_odd_defect_witness':True}


def frozen_regular_table():
    data=load('frozen_target_data.json')
    a=[[0]*27 for _ in range(27)]
    for i in range(27):
        for j in range(i+1,27):a[i][j]=3 if j-i==1 else 2 if j-i==2 else 0
    for i,j,z in [(0,1,1),(0,2,1),(0,4,2),(0,11,2),(0,24,1),(1,3,2),
                  (1,20,1),(5,14,2),(6,13,1),(7,9,2),(8,10,2)]:
        a[i][j]+=z;a[26-j][26-i]+=z
    nonzero={(3,4):2,(5,7):3,(6,7):4,(8,9):6,(9,11):1,
             (10,11):6,(10,12):4,(11,13):4,(12,14):2}
    b=[[0]*27 for _ in range(27)]
    for i in range(27):
        for j in range(i+1,27):
            b[i][j]=nonzero.get((i,j),0) if i+j<=26 else 2*a[i][j]-nonzero.get((26-j,26-i),0)
            a[j][i]=a[i][j];b[j][i]=b[i][j]
    c=[0,1,0,1,2,2,0,0,2,2,0,0,2,1]+[0]*13
    for i in range(14,27):c[i]=2-c[26-i]
    assert c==data['internal_red']
    expected={(i,j):(a[i][j],b[i][j]) for i in range(27) for j in range(i+1,27) if a[i][j]}
    actual={(r['i'],r['j']):(r['multiplicity'],r['red_sum']) for r in data['cross']}
    assert expected==actual and data['layers']==27 and data['degree']==13
    for i in range(27):
        assert sum(a[i])==12 and c[i]+sum(b[i])==i
        assert all(0<=b[i][j]<=2*a[i][j]<=8 for j in range(27))
        for d,count in [(1,3),(2,2)]:
            for j in (i-d,i+d):
                if 0<=j<27:assert a[i][j]>=count
    expanded=[]
    for N in (4,6,8):
        es=[];xs=[]
        for i in range(27):
            for t in range(0,N,2):es.append((i*N+t,i*N+t+1));xs.append(c[i])
        for (i,j),(aij,bij) in expected.items():
            for s in range(aij):
                w=min(2,max(0,bij-2*s))
                for t in range(N):es.append((i*N+t,j*N+(t+s)%N));xs.append(w)
        r,_=degrees(es,xs)
        deg=Counter(v for e in es for v in e)
        assert all(deg[v]==13 and r[v]==v//N for v in range(27*N))
        assert bad(es,xs)==27*N
        expanded.append({'fiber_size':N,'vertices':27*N,'edges':len(es),'F':27*N})
    return {'cross_layer_records':len(actual),'row_identities':27,'expanded':expanded}


def degree_arithmetic():
    crt=0
    for c in range(2,7):
        M=2*c*(2*c+1)
        for d in range(4*M-7,6*M-3):
            t=d//2
            for residue in range(M):
                r=(t-residue)%M;a=t-r;b=a if r==0 else a+M
                assert 0<=a<=d//2<=b<d
                assert 2*b<=d+a+2 and b<=2*a+3
                crt+=1
        P=[{2*j,2*j+1} for j in range(c)]
        Q=[{2*j%(2*c+1),(2*j-1)%(2*c+1)} for j in range(c)]
        assert all(not(P[i]&P[j]) and not(Q[i]&Q[j]) for i in range(c) for j in range(i))
    dense=0;perturbed=0
    for q in range(13):
        for slack in range(4):
            n=8*q+14+slack;L=(n-1)//2
            for s in range(n+1):
                for t in range(n-s+1):
                    h=s+t
                    if not h:continue
                    D=(s-t)*L+(s*(s-1)+t*(t-1))//2+t*(n-1-2*q-2*s)-1
                    assert D>=2*h-1
                    dense+=1
    for q in range(8):
        for W in range(2,9):
            for slack in range(3):
                n=8*q+4*W+10+slack;L=(n-1)//2
                assert L-W>=0 and L+n-1+W<=2*(n-1-q)
                for s in range(n+1):
                    for t in range(n-s+1):
                        h=s+t
                        if not h:continue
                        D=(s-t)*L+(s*(s-1)+t*(t-1))//2+t*(n-1-2*q-2*s)-W*h
                        assert D>=h
                        perturbed+=1
    return {'CRT_rounding_states':crt,'dense_size_pairs':dense,'offset_dense_size_pairs':perturbed}


def exact_coefficients():
    graphs=[[(0,1),(1,2)],[(0,1),(1,2),(2,3)],[(0,1),(0,2),(1,2)],
            [(0,1),(0,2),(0,3)],[(i,j) for i in range(4) for j in range(i+1,4)]]
    results=[]
    for es in graphs:
        m=len(es);deg=Counter(v for e in es for v in e)
        M=[[int(u in f)-int(v in f) for f in es] for u,v in es]
        delta=[deg[u]-deg[v] for u,v in es]
        # Highest homogeneous product, clipped at exponent two in each variable.
        poly={(0,)*m:1}
        for i in range(m):
            terms=Counter()
            for j in range(m):
                for k in range(m):
                    ex=[0]*m;ex[j]+=1;ex[k]+=1
                    terms[tuple(ex)]+=M[i][j]*M[i][k]
            for j in range(m):
                ex=[0]*m;ex[i]+=1;ex[j]+=1
                terms[tuple(ex)]+=2*delta[i]*M[i][j]
            ex=[0]*m;ex[i]=2;terms[tuple(ex)]+=2*delta[i]**2
            nxt=defaultdict(int)
            for x,c in poly.items():
                for y,d in terms.items():
                    if not d:continue
                    z=tuple(a+b for a,b in zip(x,y))
                    if max(z)<=2:nxt[z]+=c*d
            poly={x:c for x,c in nxt.items() if c}
        coefficient=poly.get((2,)*m,0)
        size=2*m
        A=[[M[i//2][j//2]+(2*delta[i//2] if i==j else 0) for j in range(size)] for i in range(size)]
        dp={0:1}
        for i in range(size):
            nxt=defaultdict(int)
            for mask,val in dp.items():
                for j in range(size):
                    if not(mask>>j&1) and A[i][j]:nxt[mask|(1<<j)]+=val*A[i][j]
            dp=nxt
        permanent=dp.get((1<<size)-1,0)
        assert permanent==2**m*coefficient
        interpolated=0
        for xs in product(range(3),repeat=m):
            value=1;den=1
            for i,(u,v) in enumerate(es):
                d=sum(M[i][j]*xs[j] for j in range(m));dd=delta[i];x=xs[i]
                value*=d*d-2*dd*(2-x)*d+2*dd*dd*(x-1)*(x-2)
                den*=(-1 if x==1 else 2)
            interpolated+=Fraction(value,den)
        assert interpolated==coefficient
        results.append({'vertices':len(deg),'edges':m,'coefficient':coefficient,'permanent':permanent})
    return results


def partition_update_audits():
    reports = {}
    for stem in ('integer_matching_cut','path_cycle_partition',
                 'isolate_parity_partitions','odd_component_root_ports'):
        proc = subprocess.run([sys.executable,'-X','utf8','-I','-B',
                               str(DATA/('audit_'+stem+'_stage.py'))],cwd=ROOT,
                              capture_output=True,text=True,encoding='utf-8',timeout=180)
        assert proc.returncode == 0, (stem,proc.stdout,proc.stderr)
        report = json.loads(proc.stdout)
        assert report['all_checks_passed'] and not report['mother_conjecture_proved']
        reports[stem] = report
    return reports


def final_content_audit():
    proc=subprocess.run([sys.executable,'-X','utf8','-I','-B',str(ROOT/'audit_content.py')],
                        cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=180)
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    data=json.loads(proc.stdout)
    assert data['all_checks_passed'] and not data['mother_conjecture_proved']
    return data


def main():
    if not __debug__:raise SystemExit('Assertions are required: do not run with -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    started=time.monotonic()
    result=subprocess.run([sys.executable,'-X','utf8','-I','-B',str(ROOT/'verify_a1.py')],cwd=ROOT,
                          capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
    assert result.returncode==0, (result.stdout or '')+'\n'+(result.stderr or '')
    from rooted_clique_certificate import verify_certificate
    from decorated_path_certificate_check import verify as decorated_verify
    report={'immutable_manifest':immutable_manifest(),
            'A1_complete_certificates':json.loads(result.stdout),
            'clique_complete_bases':verify_certificate(load('rooted_clique_interfaces.json')),
            'decorated_complete_relations':decorated_verify(),
            'stored_weight_witnesses':supplied_witnesses(),
            'strategy_obstructions':elementary_obstructions(),
            'frozen_regular_table':frozen_regular_table(),
            'rounding_and_factor_arithmetic':degree_arithmetic(),
            'exact_polynomial_identities':exact_coefficients(),
            'E1_E4_independent_audits':partition_update_audits(),
            'final_content_and_path_audit':final_content_audit(),
            'all_checks_passed':True,'mother_conjecture_proved':False,
            'formalisation_claimed':False,'seconds':round(time.monotonic()-started,3)}
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False))


if __name__=='__main__':main()
