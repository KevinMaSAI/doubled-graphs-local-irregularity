# Final content and error audit, revision 1.1.1

The 64-page mathematical scope stays fixed at 28 October 2026, 10:25:33 CST.
The later completed component-DP note was reviewed for scope but is not an
omission from this frozen revision and is not silently added.

Corrections made:
1. README's note-only provenance path is `provenance/original_notes/`.
2. The upload description no longer describes a future public record as
   unpublished local preparation; local server-status flags remain separate.
3. The coverage ledger explicitly resolves English filenames in `manuscript/`
   and code/data in `artifact/`, with root entry points named separately.
4. The overview distinguishes the later completed DP note from work that was
   unfinished at the frozen source cutoff.

Mathematical review revisited A1's physical path relations, the four-port budget,
forest/cotree compatibility, modulo-three targets and independent defect controls;
D1's simple-host hypotheses and CRT residues; all three Tutte cases and physical
targets in D3/D5; and the signed-gap, binary-relation, protected-join and root-port
conditions of E1--E4. No new fatal gap was found in those reviewed arguments.
The other retained proof/code material is unchanged from the preceding internal
review. This is not an independent expert review or an absolute error-free guarantee.

The quoted external tools were rechecked against the primary sources:
[Degree Constrained Subgraphs, Theorem 5](https://problab.ca/louigi/papers/dcsubgraphs.pdf)
and [Beyond Degree Choosability](https://arxiv.org/abs/1511.00350).
The latter records the classical Gallai-tree characterisation used by A1.

A new constructor-independent standard-library audit checks 975 ordinary path
endpoint cases, 49 return-path cases and 90 pendant endpoint cases (1,114 total),
on lengths two through nine plus the one-edge pendant boundaries. These bounded
checks support the displayed general argument and do not replace it. It also
checks all 143 unique labels, 171 references, eight bibliography entries, literal
code links, documented directories and all 300 frozen source-file hashes.

No theorem's mathematical hypothesis or conclusion was enlarged. No upload,
publication, DOI reservation, formalisation or historical-priority certificate
is claimed. Author and licence scopes are unchanged.
