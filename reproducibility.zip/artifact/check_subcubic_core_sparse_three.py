"""Independent density, finite marked kernel, and actual red/blue-copy checks."""
import copy
import itertools
import json
import random
import time
from pathlib import Path
import networkx as nx

from check_matching_long_branch_coloring import verify
from check_safe_all_cactus import verify_auxiliary
from check_subcubic_core_forest_three import change_some_short_to_three, gallai_other_than_K4
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import join_cores
from forest_pseudoforest import partition, independent, orient_pseudoforest
from marked_theta_certificate import verify_certificate
from strong_marked_safe_core import strong_marked_safe_core
from subcubic_bip_core_no_three import color_subcubic_core_sparse_three, color_subcubic_core_forest_three


def density_sparse(vertices, edges):
    """Independent maximum-closure/min-cut test, with a strict subset gap."""
    vertices = list(vertices)
    scale = len(vertices) + 1
    source, sink = object(), object()
    flow = nx.DiGraph()
    profit = scale * len(edges)
    infinite = profit + len(vertices) * (2 * scale - 1) + 1
    for v in vertices:
        flow.add_edge(("v", v), sink, capacity=2 * scale - 1)
    for i, (u, v) in enumerate(edges):
        flow.add_edge(source, ("e", i), capacity=scale)
        for w in {u, v}:
            flow.add_edge(("e", i), ("v", w), capacity=infinite)
    flow.add_nodes_from((source, sink))
    cut, sets = nx.minimum_cut(flow, source, sink)
    if profit - cut <= 0:
        return True, []
    witness = [v for v in vertices if ("v", v) in sets[0]]
    assert len([1 for u, v in edges if u in witness and v in witness]) >= 2 * len(witness)
    return False, witness


def original_scope(graph):
    if max(dict(graph.degree()).values()) > 3:
        return False, {}
    roots = {v for v in graph if graph.degree(v) == 3}
    core = graph.subgraph(roots)
    components = list(nx.connected_components(core))
    member = {v: i for i, c in enumerate(components) for v in c}
    returns, three, promote = set(), [], set()
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        if len(attachments) == 2 and attachments[0] == attachments[1]:
            returns.add(member[attachments[0]])
        elif len(attachments) == 2 and len(vertices) == 2:
            three.append(tuple(map(member.get, attachments)))
            for v in attachments:
                if not nx.is_bipartite(core.subgraph(components[member[v]])):
                    promote.add(member[v])
    safe = {i for i, c in enumerate(components) if i not in returns | promote and
            (gallai_other_than_K4(core.subgraph(c)) or
             (nx.is_bipartite(core.subgraph(c)) and sum(core.degree(v) == 3 for v in c) <= 2))}
    edges = [(u, v) for u, v in three if u in safe and v in safe]
    sparse, witness = density_sparse(safe, edges)
    return sparse, {"vertices": sorted(safe), "edges": edges, "density_witness": witness}


def theta(p, q, a, b):
    graph = nx.Graph()
    graph.add_nodes_from((0, 1))
    count, marked = 2, None
    for j, length in enumerate((p + q, a, b)):
        middle = list(range(count, count + length - 1))
        count += length - 1
        path = [0] + middle + [1]
        graph.add_edges_from(zip(path, path[1:]))
        if j == 0:
            marked = path[p]
    return graph, marked


def claw_modules(long_graph, rng):
    vertices = list(long_graph)
    labels = {v: i for i, v in enumerate(vertices)}
    direct = [(4 * i, 4 * i + j, 1) for i in range(len(vertices)) for j in (1, 2, 3)]
    stubs = {v: [4 * labels[v] + j for j in (1, 2, 3) for _ in range(2)] for v in vertices}
    # Put each first three long incidences at a different leaf.
    for v in stubs:
        stubs[v] = stubs[v][::2] + stubs[v][1::2]
    ordinary = []
    for u, v in long_graph.edges():
        ordinary.append((stubs[u].pop(0), stubs[v].pop(0), 3))
    unused = [v for values in stubs.values() for v in values]
    rng.shuffle(unused)
    while unused:
        u = unused.pop()
        choice = next((i for i, v in enumerate(unused) if v != u), None)
        if choice is None:
            raise AssertionError("Fixture needs an even valid boundary pairing.")
        ordinary.append((u, unused.pop(choice), 2))
    return expand(4 * len(vertices), direct + ordinary, [])


def main():
    start = time.monotonic()
    base = Path(__file__).parent
    rng = random.Random(20261114)
    cert = json.loads((base / "marked_theta_interfaces.json").read_text(encoding="utf-8"))
    certificate = verify_certificate(cert)
    bad = copy.deepcopy(cert); bad["marked_records"].pop()
    try:
        verify_certificate(bad)
    except AssertionError:
        pass
    else:
        raise AssertionError("An incomplete marked domain was accepted.")
    theta_count = 0
    for record in cert["marked_records"]:
        for lift in (False, True):
            lengths = [n + (2 * rng.randrange(1, 8) if lift and n >= 7 else 0) for n in record["lengths"]]
            core, mark = theta(*lengths)
            result = strong_marked_safe_core(core, mark)
            verify_auxiliary(core, result, mark, 1, True)
            theta_count += 1
    core, mark = theta(5001, 5002, 7, 9)
    verify_auxiliary(core, strong_marked_safe_core(core, mark), mark, 1, True)
    theta_count += 1
    decomposition_cases, impossible = 0, 0
    for n in range(1, 5):
        for _ in range(350):
            edges = [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randrange(10))]
            expected = all(sum(u in subset and v in subset for u, v in edges) <= 2 * len(subset) - 1
                           for k in range(1, n + 1) for subset in itertools.combinations(range(n), k))
            sparse, witness = density_sparse(range(n), edges)
            assert sparse == expected
            result = partition(range(n), edges)
            assert (result["status"] == "partitioned") == expected
            if expected:
                assert independent(range(n), edges, result["forest"])
                assert independent(range(n), edges, result["pseudoforest"], True)
                orient_pseudoforest(range(n), edges, result["pseudoforest"])
                decomposition_cases += 1
            else:
                impossible += 1
    actual, eligible, outside, mixed, promoted = 0, 0, 0, 0, 0
    selected, with_cycles, witnesses = 0, 0, {}
    def check(name, graph):
        nonlocal actual, mixed, promoted, selected, with_cycles
        expected, scope = original_scope(graph)
        assert expected, (name, scope)
        result = color_subcubic_core_sparse_three(graph)
        verify(graph, result)
        actual += 1
        selected += len(result.get("mixed_three_threads", []))
        promoted += len(result.get("promoted_nonbip_three_components", []))
        two = sum(len(t["path"]) == 3 for t in result.get("threads", []))
        three = sum(len(t["path"]) == 4 and t["path"][0] != t["path"][-1] for t in result.get("threads", []))
        mixed += bool(two and three)
        with_cycles += bool(result.get("mixed_three_threads"))
        for key in result.get("mixed_three_threads", []):
            item = result["threads"][key]
            end = item["ports"].index(1)
            assert result["red"][item["path"][0 if end == 0 else -1]] in (1, 5)
        if name.startswith("named_"):
            witnesses[name] = {"scope": scope, "partition": result.get("three_edge_partition"),
                              "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                              "red": result["red"], "blue": result["blue"]}
        return result
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected, scope = original_scope(graph)
        result = color_subcubic_core_sparse_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph); eligible += 1
        else:
            outside += 1
    pool = [core for core in nx.graph_atlas_g() if len(core) and nx.is_connected(core)
            and max(dict(core.degree()).values()) <= 3]
    for _ in range(1400):
        graph = join_cores([rng.choice(pool) for j in range(rng.randrange(2, 10))], rng)
        if graph is None:
            continue
        change_some_short_to_three(graph, rng)
        expected, scope = original_scope(graph)
        result = color_subcubic_core_sparse_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("random_mixed_network", graph)
        else:
            outside += 1
    obstruction = expand(6, [(0, 1, 3), (1, 2, 3), (2, 0, 3),
                            (3, 4, 3), (4, 5, 3), (5, 3, 3),
                            (0, 3, 2), (1, 4, 2), (2, 5, 2)], [])
    check("named_old_pure_SAFE_obstruction", obstruction)
    assert color_subcubic_core_forest_three(obstruction)["status"] == "method_not_applicable"
    for n in range(4, 42, 2):
        long_graph = nx.random_regular_graph(3, n, seed=rng.randrange(1 << 30))
        if nx.is_connected(long_graph):
            graph = claw_modules(long_graph, rng)
            check("named_cubic_network_of_claw_cores_" + str(n), graph)
            assert color_subcubic_core_forest_three(graph)["status"] == "method_not_applicable"
    # A long-three cycle inside one SAFE core becomes a self-loop in F.
    graph = expand(2, [(0, 1, 1), (0, 1, 3)], [(0, 1), (1, 1)])
    check("named_SAFE_component_self_loop", graph)
    # The 2,1 density boundary is real for this construction, not a graph
    # counterexample: a 4-regular F has 2|V| edges and is out of scope.
    dense = claw_modules(nx.complete_graph(5), rng)
    assert original_scope(dense)[0] is False
    assert color_subcubic_core_sparse_three(dense)["reason"] == "SAFE_three_multigraph_not_2_1_sparse"
    result = {"marked_theta_certificate": certificate, "actual_marked_theta_cores_verified": theta_count,
              "multigraph_partitions_verified": decomposition_cases, "non_sparse_multigraphs_rejected": impossible,
              "density_min_cut_vs_all_subsets_passed": True, "actual_graph_colorings_verified": actual,
              "atlas_eligible": eligible, "outside_scope_checked": outside,
              "graphs_with_both_two_and_three": mixed, "graphs_using_cycle_breaks": with_cycles,
              "mixed_three_ports_used": selected, "nonbipartite_three_cores_promoted": promoted,
              "former_pure_SAFE_obstruction_colored": True, "density_boundary_rejected": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "general_subcubic_conjecture_proved": False,
              "seconds": round(time.monotonic() - start, 3)}
    (base / "subcubic_core_sparse_three_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (base / "subcubic_core_sparse_three_witnesses.json").write_text(json.dumps(witnesses, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
