"""All P3 direct cores with one short leaf incidence and four long incidences.

An abstract module i has roots a,b,c (direct edges ab,bc), long half-ports
(i,0),(i,1) at a, (i,2) at b, (i,3) at c, and one short port at c.
Every long half-port is paired exactly once, path length >=3; the c short
ports form a perfect matching of length-two paths. Long returns allowed.
No solver, no restriction on the resulting four-regular connection graph.
"""

import networkx as nx
from independent_branch_coloring import _path_word


def color_p3_single_short_network(count, long_connections, short_matching):
    if count < 2 or count % 2:
        raise ValueError("An even positive number of at least two modules is needed.")
    half_ports = {(i, j) for i in range(count) for j in range(4)}
    used = []
    for first, last, length in long_connections:
        if length < 3 or first == last or tuple(first) not in half_ports or tuple(last) not in half_ports:
            raise ValueError("Invalid long connection.")
        used.extend((tuple(first), tuple(last)))
    if len(used) != len(set(used)) or set(used) != half_ports:
        raise ValueError("Every long half-port must occur exactly once.")
    shorts = [i for pair in short_matching for i in pair]
    if sorted(shorts) != list(range(count)) or any(u == v for u, v in short_matching):
        raise ValueError("Short ports must form a perfect matching of modules.")
    def root(half):
        i, j = half
        return 3 * i + (0 if j < 2 else j - 1)
    graph = nx.Graph()
    graph.add_nodes_from(range(3 * count))
    graph.add_edges_from((3 * i + j, 3 * i + j + 1) for i in range(count) for j in (0, 1))
    next_vertex = 3 * count
    def path(u, v, length):
        nonlocal next_vertex
        middle = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        word = [u] + middle + [v]
        graph.add_edges_from(zip(word, word[1:]))
        return word
    long_paths, short_paths = [], []
    offsets = dict.fromkeys(range(3 * count), 0)
    for first, last, length in long_connections:
        u, v = root(first), root(last)
        long_paths.append({"path": path(u, v, length), "ports": [0, 2]})
        offsets[v] += 2
    for u, v in short_matching:
        short_paths.append({"modules": [u, v], "path": path(3 * u + 2, 3 * v + 2, 2)})
    short_port, direct, root_red = {}, {}, {}
    for i in range(count):
        a, b, c = 3 * i, 3 * i + 1, 3 * i + 2
        defect = (offsets[a] + offsets[c] - offsets[b]) % 3
        short_port[i] = 2 if defect == 0 else 0
        defect = (defect + short_port[i]) % 3
        assert defect in (1, 2)
        phi_a = (defect + 1) % 3
        x = (phi_a - offsets[a]) % 3
        y = (-offsets[c] - short_port[i]) % 3
        direct[frozenset((a, b))] = x
        direct[frozenset((b, c))] = y
        root_red.update({a: offsets[a] + x, b: offsets[b] + x + y,
                         c: offsets[c] + short_port[i] + y})
        assert root_red[a] % 3 in (0, 2) and root_red[b] % 3 == 1 and root_red[c] % 3 == 0
    weights = dict(direct)
    for item in long_paths:
        word = item["path"]
        u, v = word[0], word[-1]
        colors = _path_word(len(word) - 1, 0, 2, root_red[u], 6 - root_red[u], root_red[v], 6 - root_red[v])
        assert colors is not None
        for a, b, value in zip(word, word[1:], colors):
            weights[frozenset((a, b))] = value
    for item in short_paths:
        u, v = item["modules"]
        word, colors = item["path"], [short_port[u], short_port[v]]
        for a, b, value in zip(word, word[1:], colors):
            weights[frozenset((a, b))] = value
    edges = list(graph.edges())
    values = [weights[frozenset(edge)] for edge in edges]
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, values):
        red[u] += value
        red[v] += value
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] == root_red[v] and graph.degree(v) == 3 for v in root_red)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, values))
    result = {"status": "colored", "edge_order": edges, "weights": values, "red": red, "blue": blue,
              "root_red": root_red, "short_ports": short_port, "long_paths": long_paths,
              "short_paths": short_paths, "mother_conjecture_proved": False}
    return graph, result
