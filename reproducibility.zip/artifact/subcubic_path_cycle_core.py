"""LIR2 for a path/cycle direct core with no ordinary length-three thread.

Ordinary paths have length 2 or >=4, loops have every length >=3, and
pendants have every positive length. No restriction on compressed parallel
paths. The direct degree-three core must have maximum degree at most two.
"""

import networkx as nx

from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches


def color_subcubic_path_cycle_core(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return {"status": "method_not_applicable", "reason": "degree_above_three",
                "mother_conjecture_proved": False}
    roots = [v for v in graph if degree[v] == 3]
    if not roots:
        return color_independent_branches(graph)
    root_set = set(roots)
    core = graph.subgraph(roots).copy()
    if max(dict(core.degree()).values()) > 2:
        return {"status": "method_not_applicable", "reason": "direct_core_degree_three",
                "mother_conjecture_proved": False}
    edges = list(graph.edges())
    edge_id = {frozenset(edge): i for i, edge in enumerate(edges)}
    threads, pendants, used = [], [], set()
    for root in roots:
        for neighbor in graph[root]:
            index = edge_id[frozenset((root, neighbor))]
            if index in used:
                continue
            used.add(index)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                index = edge_id[frozenset((current, other))]
                assert index not in used
                used.add(index)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": 0})
            else:
                assert current in root_set
                if len(path) == 4 and current != root:
                    return {"status": "method_not_applicable", "reason": "ordinary_three_edge_thread",
                            "path": path, "mother_conjecture_proved": False}
                threads.append({"path": path, "ports": [0, 0]})
    assert len(used) == len(edges)
    loops, free = {v: [] for v in roots}, {v: [] for v in roots}
    for key, item in enumerate(threads):
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            continue
        if u == v:
            assert len(path) >= 4
            loops[u].append(key)
        else:
            free[u].append(("ordinary", key, 0))
            free[v].append(("ordinary", key, 1))
    for key, item in enumerate(pendants):
        free[item["path"][0]].append(("pendant", key, 0))
    assert all(core.degree(v) + 2 * len(loops[v]) + len(free[v]) == 3 for v in roots)
    matching, core_reports = set(), []
    for vertices in nx.connected_components(core):
        component = core.subgraph(vertices)
        start = next((v for v in component if component.degree(v) < 2), next(iter(component)))
        order = [start]
        visited = {start}
        while True:
            following = next((v for v in component[order[-1]] if v not in visited), None)
            if following is None:
                break
            order.append(following)
            visited.add(following)
        assert set(order) == set(component)
        cycle = len(component) >= 3 and all(component.degree(v) == 2 for v in component)
        for i in range(0, len(order) - 1, 2):
            matching.add(frozenset((order[i], order[i + 1])))
        core_reports.append({"kind": "cycle" if cycle else "path", "order": order,
                             "parity": len(order) % 2})
    matched = {v for edge in matching for v in edge}
    flexible_matched = [v for v in roots if v in matched and not loops[v]]
    remaining = core.subgraph(flexible_matched)
    assert nx.is_bipartite(remaining)
    colors = nx.bipartite.color(remaining)
    actions = []
    for root in flexible_matched:
        assert free[root]
        if colors[root] == 0:
            continue
        kind, key, end = free[root][0]
        if kind == "ordinary":
            threads[key]["ports"][end] = 2
        else:
            pendants[key]["port"] = 2
        actions.append({"kind": kind + "_port_two", "root": root, "key": key, "end": end})
    for root in roots:
        if not loops[root]:
            continue
        assert len(loops[root]) == 1 and core.degree(root) <= 1
        if core.degree(root) == 0:
            # One remaining external port stays zero; R(root)=1, B=5.
            threads[loops[root][0]]["ports"] = [0, 1]
            actions.append({"kind": "isolated_loop_red_one", "root": root})
        else:
            # The direct edge has weight 0 or 1. Choose the loop's sum
            # so R(root)=2 in both cases.
            threads[loops[root][0]]["ports"] = [0, 1] if root in matched else [0, 2]
            actions.append({"kind": "endpoint_loop_red_two", "root": root})
    for u, v in core.edges():
        if loops[u] and loops[v]:
            assert frozenset((u, v)) in matching
            threads[loops[v][0]]["ports"] = [1, 2]
            actions.append({"kind": "double_loop_red_four", "root": v})
    for item in threads:
        if len(item["path"]) == 2:
            value = int(frozenset(item["path"]) in matching)
            item["ports"] = [value, value]
    red = dict.fromkeys(roots, 0)
    for item in threads:
        red[item["path"][0]] += item["ports"][0]
        red[item["path"][-1]] += item["ports"][1]
    for item in pendants:
        red[item["path"][0]] += item["port"]
    blue = {v: 6 - red[v] for v in roots}
    assert all(red[u] != red[v] for u, v in core.edges())
    assert all(red[v] in (0, 1, 3) for v in roots if not loops[v])
    assert all(red[v] == 1 for v in roots if loops[v] and core.degree(v) == 0)
    assert all(red[v] in (2, 4) for v in roots if loops[v] and core.degree(v) == 1)
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value
    for item in threads:
        path, ports = item["path"], item["ports"]
        u, v = path[0], path[-1]
        word = [ports[0]] if len(path) == 2 else _path_word(
            len(path) - 1, *ports, red[u], blue[u], red[v], blue[v])
        put(path, word)
    for item in pendants:
        root = item["path"][0]
        put(item["path"], _pendant_word(len(item["path"]) - 1, item["port"], red[root], blue[root]))
    actual_red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        actual_red[u] += value
        actual_red[v] += value
    actual_blue = {v: 2 * degree[v] - actual_red[v] for v in graph}
    assert all(red[v] == actual_red[v] and blue[v] == actual_blue[v] for v in roots)
    assert all((x == 0 or actual_red[u] != actual_red[v])
               and (x == 2 or actual_blue[u] != actual_blue[v])
               for (u, v), x in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": actual_red, "blue": actual_blue, "threads": threads, "pendants": pendants,
            "core_matching": [tuple(edge) for edge in matching], "core_reports": core_reports,
            "matched_nonloop_colors": colors, "actions": actions, "mother_conjecture_proved": False}
