"""Absorb a high-minimum-degree region with one inside boundary vertex.

All edges outside the induced region, including boundary edges, are supplied
and preserved. Internal region colors are recovered from a factor certificate
or by the optional integer search. This is a conditional absorption theorem.
"""

import networkx as nx

from chromatic_degree_factor import color_from_factor, color_with_degree_factor


def absorption_plan(graph, inside, coloring, given_weights):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    inside = set(inside)
    if not inside or not inside <= set(graph):
        raise ValueError("The region must be a nonempty vertex subset.")
    inner = graph.subgraph(inside)
    if not nx.is_connected(inner) or set(coloring) != inside:
        raise ValueError("A connected region and its full vertex coloring are required.")
    if any(coloring[u] == coloring[v] for u, v in inner.edges()):
        raise ValueError("The supplied region coloring must be proper.")
    values = {frozenset(edge): x for edge, x in given_weights.items()}
    needed = {frozenset(e) for e in graph.edges() if not set(e) <= inside}
    if (len(values) != len(given_weights) or set(values) != needed
            or any(type(x) is not int or not 0 <= x <= 2 for x in values.values())):
        raise ValueError("Supply each noninternal edge exactly once with a 0/1/2 weight.")
    outside = set(graph) - inside
    red = dict.fromkeys(outside, 0)
    blue = dict.fromkeys(outside, 0)
    A, B = dict.fromkeys(inside, 0), dict.fromkeys(inside, 0)
    boundary = []
    for u, v in graph.edges():
        if u in inside and v in inside:
            continue
        x = values[frozenset((u, v))]
        for w in (u, v):
            if w in inside:
                A[w] += x
                B[w] += 2 - x
            else:
                red[w] += x
                blue[w] += 2 - x
        if (u in inside) != (v in inside):
            boundary.append((u, v, x) if u in inside else (v, u, x))
    for u, v in graph.edges():
        if u in outside and v in outside:
            x = values[frozenset((u, v))]
            if (x > 0 and red[u] == red[v]) or (x < 2 and blue[u] == blue[v]):
                raise ValueError("The outside internal edges are not already legal.")
    roots = {u for u, v, x in boundary}
    if len(roots) > 1:
        return {"status": "method_not_applicable", "reason": "multiple_inside_boundary_vertices"}
    root = next(iter(roots)) if roots else next(iter(inner))
    classes = {}
    for value in coloring.values():
        if value not in classes:
            classes[value] = len(classes)
    base = {v: classes[coloring[v]] for v in inside}
    mixed = sum(x == 1 for u, v, x in boundary)
    C = max(2, len(classes), len(boundary) + mixed + 1)
    p, q = 2 * C, 2 * C + 1
    minimum = 4 * p * q - 7
    if min(dict(inner.degree()).values()) < minimum:
        return {"status": "method_not_applicable", "reason": "region_minimum_degree_too_small",
                "required": minimum, "palette_size": C}
    good = next(j for j in range(C) if all(
        (x == 0 or red[v] % p not in {2 * j % p, (2 * j + 1) % p})
        and (x == 2 or blue[v] % q not in {2 * j % q, (2 * j - 1) % q})
        for u, v, x in boundary))
    mapping = {base[root]: good}
    available = (j for j in range(C) if j != good)
    for original in range(len(classes)):
        if original not in mapping:
            mapping[original] = next(available)
    return {"status": "planned", "root": root, "boundary_edges": boundary,
            "outside_red": red, "outside_blue": blue,
            "red_offsets": A, "blue_offsets": B, "palette_size": C,
            "coloring": {v: mapping[base[v]] for v in inside},
            "root_color_label": good, "required_minimum_degree": minimum,
            "given_weights": values}


def color_one_boundary_region(graph, inside, coloring, given_weights,
                               factor_edges=None, timeout_ms=10000):
    inside = set(inside)
    plan = absorption_plan(graph, inside, coloring, given_weights)
    if plan["status"] != "planned":
        return plan
    inner = graph.subgraph(inside)
    if factor_edges is None:
        local = color_with_degree_factor(
            inner, plan["coloring"], plan["red_offsets"], plan["blue_offsets"],
            timeout_ms=timeout_ms, palette_size=plan["palette_size"])
    else:
        local = color_from_factor(
            inner, plan["coloring"], factor_edges, plan["red_offsets"], plan["blue_offsets"],
            palette_size=plan["palette_size"])
    if local["status"] != "colored":
        return local
    values = dict(plan["given_weights"])
    values.update(zip(map(frozenset, local["edge_order"]), local["weights"]))
    edges = list(graph.edges())
    red = dict.fromkeys(graph, 0)
    for u, v in edges:
        x = values[frozenset((u, v))]
        red[u] += x
        red[v] += x
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] == plan["outside_red"][v] and blue[v] == plan["outside_blue"][v]
               for v in graph if v not in inside)
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for u, v in edges for x in [values[frozenset((u, v))]])
    return {"status": "colored", "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges],
            "red": red, "blue": blue, "absorption_plan": plan,
            "outside_colors_preserved": True, "mother_conjecture_proved": False}
