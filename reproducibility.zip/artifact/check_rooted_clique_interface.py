"""Independent finite implementation checks of the all-size clique induction."""

from collections import Counter
import copy
import itertools
import json
from pathlib import Path
import random
import time

from rooted_clique_certificate import verify_certificate
from rooted_clique_interface import color_rooted_clique


def verify(graph, result, root, A=0, B=0, target=None):
    assert result["status"] == "colored"
    vertices = list(graph)
    red, blue = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    red[root], blue[root] = A, B
    assert len(result["edge_order"]) == len(result["weights"]) == graph.number_of_edges()
    assert {frozenset(e) for e in result["edge_order"]} == {frozenset(e) for e in graph.edges()}
    for (u, v), value in zip(result["edge_order"], result["weights"]):
        assert type(value) is int and 0 <= value <= 2
        for copy_index in range(2):
            degree = red if copy_index < value else blue
            degree[u] += 1
            degree[v] += 1
    assert red == result["red"] and blue == result["blue"]
    if target is not None:
        assert red[root] == A + target
        assert blue[root] == B + 2 * graph.degree(root) - target
    for (u, v), value in zip(result["edge_order"], result["weights"]):
        for copy_index in range(2):
            degree = red if copy_index < value else blue
            assert degree[u] != degree[v]


def main():
    import networkx as nx
    started = time.monotonic()
    path = Path(__file__).parent
    data = json.loads((path / "rooted_clique_interfaces.json").read_text(encoding="utf-8"))
    certificate = verify_certificate(data)
    mutations = []
    bad = copy.deepcopy(data); bad["records"].pop(); mutations.append(bad)
    bad = copy.deepcopy(data); bad["records"][0]["weights"][0] = 3; mutations.append(bad)
    bad = copy.deepcopy(data); bad["records"][0]["root_red"] += 1; mutations.append(bad)
    bad = copy.deepcopy(data); bad["allowed_noninterior_cases"].pop(); mutations.append(bad)
    for bad in mutations:
        try:
            verify_certificate(bad)
        except AssertionError:
            pass
        else:
            raise AssertionError("A damaged clique base certificate was accepted")
    checked, modes = 0, Counter()
    for n in range(6, 11):
        graph = nx.complete_graph(n)
        r = n - 1
        for A, B in itertools.product(range(2 * r + 3), repeat=2):
            if (A + B) % 2:
                continue
            for target in range(2 * r + 1):
                result = color_rooted_clique(n, A, B, target)
                verify(graph, result, 0, A, B, target)
                assert all(0 < result["red"][v] < 2 * r for v in range(1, n))
                modes.update(result["construction_modes"])
                checked += 1
    rng = random.Random(2026102751)
    for n in list(range(11, 61)) + [100, 151, 200]:
        graph = nx.complete_graph(n)
        targets = {0, 1, 2, n - 1, 2 * n - 4, 2 * n - 3, 2 * n - 2}
        for _ in range(8):
            targets.add(rng.randrange(2 * n - 1))
        for target in targets:
            A, B = rng.randrange(10 ** 9), rng.randrange(10 ** 9)
            B += (A + B) % 2
            result = color_rooted_clique(n, A, B, target)
            verify(graph, result, 0, A, B, target)
            modes.update(result["construction_modes"])
            checked += 1
    assert all(modes[k] for k in ("low", "middle_zero", "middle_one",
                                  "complement", "negative_offset_reinterpretation", "K4_weak_base"))
    output = {"finite_certificate": certificate, "damaged_certificates_rejected": 4,
              "actual_rooted_cliques_verified": checked,
              "maximum_clique_order": 200, "all_construction_modes": dict(modes),
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "scope": "Implementation audit; arbitrary clique orders use the separate two-vertex induction.",
              "seconds": round(time.monotonic() - started, 3)}
    (path / "rooted_clique_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
