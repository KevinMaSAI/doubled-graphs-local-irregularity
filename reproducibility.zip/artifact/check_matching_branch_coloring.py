"""Actual-copy checks of the direct-matching branch construction."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from matching_branch_coloring import color_matching_branches


def verify(graph, result):
    assert result["status"] == "colored"
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for (u, v), value in zip(result["edge_order"], result["weights"]):
        assert value in (0, 1, 2)
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
    assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    assert dict(red.degree()) == result["red"] and dict(blue.degree()) == result["blue"]
    return {record["kind"] for record in result.get("direct_edge_repairs", [])}


def expand(count, threads, pendants):
    graph = nx.Graph()
    graph.add_nodes_from(range(count))
    next_vertex = count
    for u, v, length in threads:
        assert length >= (3 if u == v else 1)
        internal = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + internal + [v]
        for a, b in zip(path, path[1:]):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
    for root, length in pendants:
        internal = list(range(next_vertex, next_vertex + length))
        next_vertex += length
        path = [root] + internal
        graph.add_edges_from(zip(path, path[1:]))
    assert nx.is_connected(graph)
    assert all(graph.degree(v) >= 4 for v in range(count))
    assert all(sum(graph.degree(w) >= 3 for w in graph[v]) <= 1 for v in range(count))
    return graph


def main():
    started = time.monotonic()
    rng = random.Random(20261028)
    atlas_colored, atlas_inapplicable = 0, 0
    kinds = set()
    witnesses = {}
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected = (not any(graph.degree(v) == 3 for v in graph)
                    and all(sum(graph.degree(w) >= 3 for w in graph[v]) <= 1
                            for v in graph if graph.degree(v) >= 3))
        result = color_matching_branches(graph)
        if expected:
            kinds.update(verify(graph, result))
            atlas_colored += 1
        else:
            assert result["status"] == "method_not_applicable"
            atlas_inapplicable += 1

    fixture_specs = [
        ("degree_four_parallel_threads", 2, [(0, 1, 1), (0, 1, 2), (0, 1, 3), (0, 1, 5)], []),
        ("degree_five_loop_pair", 2, [(0, 1, 1), (0, 0, 3), (0, 0, 4), (1, 1, 3), (1, 1, 5)], []),
        ("degree_five_pendant_pair", 2, [(0, 1, 1)], [(v, 2) for v in (0, 1) for _ in range(4)]),
        ("mixed_degree_four_five", 2, [(0, 1, 1), (0, 1, 3), (0, 1, 4), (0, 1, 2)], [(1, 2)]),
        ("loops_and_pendants", 3, [(0, 1, 1), (0, 2, 3), (1, 2, 2), (2, 2, 5)],
         [(0, 1), (0, 2), (1, 3), (1, 2)]),
    ]
    fixture_records = []
    def save_new_witnesses(name, graph, result):
        for record in result["direct_edge_repairs"]:
            kind = record["kind"]
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "vertices": len(graph), "repair": record,
                                   "edges": [[u, v, value] for (u, v), value in zip(result["edge_order"], result["weights"])],
                                   "red": result["red"], "blue": result["blue"],
                                   "initial_root_red": result["initial_root_red"],
                                   "initial_root_blue": result["initial_root_blue"]}
    for name, count, threads, pendants in fixture_specs:
        graph = expand(count, threads, pendants)
        result = color_matching_branches(graph)
        kinds.update(verify(graph, result))
        save_new_witnesses(name, graph, result)
        fixture_records.append({"name": name, "vertices": len(graph), "edges": graph.number_of_edges(),
                                "repairs": result["direct_edge_repairs"], "passed": True})

    random_cases, loop_cases, maximum_degree = 0, 0, 0
    for case in range(900):
        count = rng.randrange(1, 26)
        core = nx.MultiGraph()
        core.add_nodes_from(range(count))
        if count > 1:
            core.add_edges_from((v, rng.randrange(v)) for v in range(1, count))
        for _ in range(rng.randrange(4 * count + 1)):
            core.add_edge(rng.randrange(count), rng.randrange(count))
        records = list(core.edges())
        chosen, covered = set(), set()
        order = list(range(len(records)))
        rng.shuffle(order)
        for edge_id in order:
            u, v = records[edge_id]
            if u != v and u not in covered and v not in covered and rng.random() < .8:
                chosen.add(edge_id)
                covered.update((u, v))
        threads = [(u, v, 1 if i in chosen else rng.randrange(3 if u == v else 2, 11))
                   for i, (u, v) in enumerate(records)]
        pendants = [(v, rng.randrange(1, 10)) for v in core for _ in range(rng.randrange(4))]
        for v in core:
            existing = core.degree(v) + sum(root == v for root, _ in pendants)
            for _ in range(max(0, 4 - existing)):
                pendants.append((v, rng.randrange(1, 10)))
        graph = expand(count, threads, pendants)
        result = color_matching_branches(graph)
        kinds.update(verify(graph, result))
        save_new_witnesses(f"random_{case}", graph, result)
        maximum_degree = max(maximum_degree, max(dict(graph.degree()).values()))
        loop_cases += int(any(u == v for u, v, _ in threads))
        random_cases += 1

    # Retain a matching in K5 and exercise ALL 2/3 patterns on its other edges.
    base = nx.complete_graph(5)
    matching = {(0, 1), (2, 3)}
    expanded_patterns = 0
    for pattern in itertools.product((2, 3), repeat=8):
        variable = iter(pattern)
        threads = [(u, v, 1 if (u, v) in matching else next(variable)) for u, v in base.edges()]
        graph = expand(5, threads, [])
        result = color_matching_branches(graph)
        kinds.update(verify(graph, result))
        expanded_patterns += 1
    # Every direct pair in K6 has odd degree five; all remaining lengths vary.
    for variant in range(36):
        base = nx.complete_graph(6)
        matching = {(0, 1), (2, 3), (4, 5)}
        threads = [(u, v, 1 if (u, v) in matching else 2 + (u + 2 * v + variant) % 7)
                   for u, v in base.edges()]
        graph = expand(6, threads, [])
        result = color_matching_branches(graph)
        kinds.update(verify(graph, result))
        save_new_witnesses(f"K6_variant_{variant}", graph, result)
    # No recursion for long paths and no maximum-degree cap.
    base = nx.complete_graph(30)
    matching = {(i, i + 1) for i in range(0, 30, 2)}
    dense = expand(30, [(u, v, 1 if (u, v) in matching else 2 + (u + v) % 4) for u, v in base.edges()], [])
    result = color_matching_branches(dense)
    kinds.update(verify(dense, result))
    maximum_degree = max(maximum_degree, 29)
    long_graph = expand(2, [(0, 1, 1), (0, 0, 5000), (0, 0, 3), (1, 1, 3), (1, 1, 4)], [])
    result = color_matching_branches(long_graph)
    kinds.update(verify(long_graph, result))
    expected_kinds = {"keep_mixed", "blue_only", "red_only", "increase_nondirect_port", "decrease_pendant_port"}
    constructor_modes = sorted(kinds)
    assert expected_kinds - {"decrease_pendant_port"} <= kinds <= expected_kinds, kinds
    # Check the remaining rule on an EXPLICIT balanced orientation. The default
    # Euler ordering need not produce every allowed orientation in a finite run.
    # Two degree-five roots have a direct edge 0->1 and two outward/two inward
    # pendant paths each. Initial R=3,B=7 at both roots. Decrease one outward
    # pendant port at root 0, then refill that pendant.
    graph = nx.Graph()
    graph.add_edge(0, 1)
    value_map = {frozenset((0, 1)): 1}
    initial_map = dict(value_map)
    next_vertex = 2
    for root in (0, 1):
        for i in range(4):
            middle, leaf = next_vertex, next_vertex + 1
            next_vertex += 2
            graph.add_edges_from(((root, middle), (middle, leaf)))
            first = int(i < 2)
            initial_map[frozenset((root, middle))] = first
            initial_map[frozenset((middle, leaf))] = 0
            value_map[frozenset((root, middle))] = 0 if root == 0 and i == 0 else first
            value_map[frozenset((middle, leaf))] = 0
    edges = list(graph.edges())
    red = {v: sum(value_map[frozenset(e)] for e in edges if v in e) for v in graph}
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    initial_red = {v: sum(initial_map[frozenset(e)] for e in edges if v in e) for v in graph}
    assert initial_red[0] == initial_red[1] == 3 and red[0] == 2 and red[1] == 3
    manual = {"status": "colored", "edge_order": edges,
              "weights": [value_map[frozenset(e)] for e in edges], "red": red, "blue": blue}
    verify(graph, manual)
    kinds.add("decrease_pendant_port")
    witnesses["decrease_pendant_port"] = {
        "name": "explicit_balanced_orientation_pendant_rule", "vertices": len(graph),
        "source": "Independent rule witness, not a claim that the default Euler ordering took this branch.",
        "edges": [[u, v, value_map[frozenset((u, v))]] for u, v in edges],
        "initial_root_red": {0: 3, 1: 3}, "initial_root_blue": {0: 7, 1: 7},
        "red": red, "blue": blue}
    assert kinds == expected_kinds
    Path(__file__).with_name("matching_branch_repair_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    result = {"eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs": atlas_inapplicable,
              "boundary_fixtures": fixture_records, "random_compressed_cases": random_cases,
              "random_cases_with_loops": loop_cases, "K5_all_short_long_patterns": expanded_patterns,
              "K6_variants": 36, "dense_and_long_cases": 2,
              "maximum_tested_branch_degree": maximum_degree,
              "observed_constructor_modes": constructor_modes,
              "independently_checked_rule_modes": sorted(kinds), "checks_passed": True,
              "seconds": time.monotonic() - started,
              "scope": "Independent finite actual-copy checks. The separate proof establishes the infinite family.",
              "mother_conjecture_proved": False}
    Path(__file__).with_name("matching_branch_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "boundary_fixtures"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
