"""Exact local interface classification and actual-copy preservation checks."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from independent_branch_coloring import _path_word
from preserve_given_subdivision import extend_given_doubled_coloring


def actual_path(word, ru, bu, rv, bv):
    red = [ru] + [a + b for a, b in zip(word, word[1:])] + [rv]
    blue = [bu] + [4 - r for r in red[1:-1]] + [bv]
    return all((x == 0 or red[i] != red[i + 1]) and (x == 2 or blue[i] != blue[i + 1])
               for i, x in enumerate(word))


def main():
    started = time.monotonic()
    rng = random.Random(20261110)
    local_states, local_words, rejected, cubic_states, cubic_bad4 = 0, 0, 0, 0, 0
    exceptional_counts = set()
    for du, dv, x in itertools.product(range(1, 7), range(1, 7), range(3)):
        for ru in range(x, x + 2 * (du - 1) + 1):
            for rv in range(x, x + 2 * (dv - 1) + 1):
                bu, bv = 2 * du - ru, 2 * dv - rv
                # The initial edge must itself be legal before replacement.
                if (x and ru == rv) or (x < 2 and bu == bv):
                    continue
                exceptional = sum(r == b and r in (1, 3) for r, b in ((ru, bu), (rv, bv))) if x == 1 else 0
                exceptional_counts.add(exceptional)
                local_states += 1
                if du == dv == 3:
                    cubic_states += 1
                for length in range(4, 9):
                    word = _path_word(length, x, x, ru, bu, rv, bv)
                    expected = length >= 4 + exceptional
                    assert (word is not None) == expected, (du, dv, x, ru, rv, length)
                    if word is None:
                        rejected += 1
                        if du == dv == 3 and length == 4:
                            cubic_bad4 += 1
                    else:
                        assert actual_path(word, ru, bu, rv, bv)
                        local_words += 1
    assert cubic_states == 60 and cubic_bad4 == 8 and exceptional_counts == {0, 1, 2}
    cases, mixed_cases, different_degrees = 0, 0, 0
    required_lengths, witnesses = set(), {}
    def check(name, base, source, lengths):
        nonlocal cases, mixed_cases, different_degrees
        result = extend_given_doubled_coloring(base, source, lengths)
        assert result["status"] == "colored"
        verify(result["graph"], result)
        assert all(result["red"][v] == result["initial_red"][v]
                   and result["blue"][v] == result["initial_blue"][v] for v in base)
        cases += 1
        mixed_cases += any(source[key] == 1 for key in lengths)
        different_degrees += any(base.degree(u) != base.degree(v) for key in lengths for u, v in [tuple(key)])
        for path in result["subdivision_paths"]:
            required_lengths.add(path["required_length"])
            if path["required_length"] not in witnesses:
                witnesses[path["required_length"]] = {"name": name,
                    "base_edges": [[u, v, source[frozenset((u, v))]] for u, v in base.edges()],
                    "path": path, "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    # Regular bipartite bases: a red star with one mixed edge.
    for d in range(4, 13):
        base = nx.complete_bipartite_graph(d, d)
        source = {frozenset((u, v)): (1 if (u, v) == (0, d) else 2 if u == 0 else 0)
                  for u, v in base.edges()}
        for _ in range(30):
            lengths = {key: rng.randrange(4, 10) for key in source if rng.random() < 0.6}
            check("regular_bipartite_base", base, source, lengths)
    # Unequal-degree bases with a pair of mixed star edges.
    for p, q in ((4, 6), (5, 9), (8, 12)):
        for leaf in (False, True):
            base = nx.complete_bipartite_graph(p, q)
            if leaf:
                base.add_edge(0, p + q)
            source = {frozenset((u, v)): int(u == 0 and v in (p, p + 1)) for u, v in base.edges()}
            eligible = [key for key in source if all(base.degree(v) >= 4 for v in key)]
            for _ in range(30):
                lengths = {key: rng.randrange(4, 8) for key in eligible if rng.random() < 0.7}
                check("unequal_degrees_with_existing_leaf", base, source, lengths)
    # Degree-three balanced endpoint: length four is a real fixed-interface
    # obstruction, but length five preserves this supplied legal K4 coloring.
    k4 = nx.complete_graph(4)
    source = dict(zip((frozenset(e) for e in k4.edges()), (1, 2, 0, 0, 0, 2)))
    edge = frozenset((0, 1))
    failed4 = extend_given_doubled_coloring(k4, source, {edge: 4})
    assert failed4["status"] == "method_not_applicable" and failed4["minimum_length_at_least_four"] == 5
    check("one_balanced_cubic_endpoint", k4, source, {edge: 5})
    # Two exceptional endpoints can have degrees one and three.
    star = nx.star_graph(3)
    source = {frozenset(edge): 1 for edge in star.edges()}
    selected = next(iter(source))
    failed5 = extend_given_doubled_coloring(star, source, {selected: 5})
    assert failed5["status"] == "method_not_applicable" and failed5["minimum_length_at_least_four"] == 6
    check("two_exceptional_endpoints", star, source, {selected: 6})
    check("long_preserved_path", k4, dict(zip((frozenset(e) for e in k4.edges()), (1, 2, 0, 0, 0, 2))),
          {frozenset((0, 1)): 5000})
    assert required_lengths == {4, 5, 6}
    report = {"checks_passed": True, "legal_local_endpoint_states": local_states,
        "actual_local_path_words_checked": local_words, "infeasible_fixed_interfaces_checked": rejected,
        "cubic_legal_endpoint_states": cubic_states, "cubic_length_four_obstructions": cubic_bad4,
        "actual_copy_checked_expansions": cases, "expansions_with_selected_mixed_edges": mixed_cases,
        "expansions_with_unequal_degree_selected_edges": different_degrees,
        "required_length_thresholds_observed": sorted(required_lengths), "long_path_length": 5000,
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Exact finite local audit plus finite implementation checks; the universal conditional extension and minimal-counterexample reduction have separate proofs."}
    Path(__file__).with_name("preserve_given_subdivision_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("preserve_given_subdivision_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
