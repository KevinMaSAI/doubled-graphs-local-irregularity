"""Conditional treatments of T-induced isolates; no universal partition claim.

All graph operations act on the original simple degree3/4 graph. The three
coloring routines have different, explicit hypotheses and parity patterns.
"""

from path_cycle_partition import complete_component, selected_break_indices
from signed_gap_two import signed_gap_two


def _layout(vertices, edges, T):
    vertices, edges, T = list(vertices), [tuple(e) for e in edges], set(T)
    V = set(vertices)
    if not vertices or len(V) != len(vertices) or not T <= V:
        raise ValueError("Use distinct vertices and a subset T.")
    adjacency, inventory = {v: [] for v in vertices}, set()
    for i, (u, v) in enumerate(edges):
        key = frozenset((u, v))
        if len(key) != 2 or not key <= V or key in inventory:
            raise ValueError("A simple undirected graph is required.")
        inventory.add(key); adjacency[u].append((v, i)); adjacency[v].append((u, i))
    D = {v: len(adjacency[v]) for v in vertices}
    inside = {v: [u for u, i in adjacency[v] if (u in T) == (v in T)] for v in vertices}
    if any(d not in (3, 4) for d in D.values()) or any(len(inside[v]) > 1 for v in T) or any(
            len(inside[v]) > 2 or len(inside[v]) == 2 and D[v] != 4 for v in V-T):
        return {"status": "not_applicable", "mother_conjecture_proved": False}
    groups, seen = [], set()
    for start in vertices:
        if start in T or start in seen:
            continue
        group, seen = [start], seen | {start}
        for v in group:
            for u in inside[v]:
                if u not in seen:
                    seen.add(u); group.append(u)
        cycle = all(len(inside[v]) == 2 for v in group)
        root = group[0] if cycle else next(v for v in group if len(inside[v]) <= 1)
        order, previous = [root], None
        while True:
            u = next((u for u in inside[order[-1]] if u != previous and u != root), None)
            if u is None:
                break
            previous = order[-1]; order.append(u)
        assert set(order) == set(group) and len(order) == len(group)
        groups.append({"vertices": order, "cycle": cycle})
    return {"vertices": vertices, "edges": edges, "T": T, "S": V-T,
            "degree": D, "inside": inside, "adjacency": adjacency, "groups": groups,
            "cross": [i for i, (u, v) in enumerate(edges) if (u in T) != (v in T)],
            "T_pairs": [(u, v) for u, v in edges if u in T and v in T],
            "I": [v for v in vertices if v in T and not inside[v]]}


def _parity_join(vertices, indexed_edges, targets):
    targets = set(targets)
    adjacency = {v: [] for v in vertices}
    for i, u, v in indexed_edges:
        adjacency[u].append((v, i)); adjacency[v].append((u, i))
    seen, components, chosen = set(), [], set()
    for root in vertices:
        if root in seen:
            continue
        group, parents = [root], {root: (None, None)}; seen.add(root)
        for v in group:
            for u, i in adjacency[v]:
                if u not in seen:
                    seen.add(u); group.append(u); parents[u] = (v, i)
        components.append(group)
        if len(set(group) & targets) % 2:
            return {"status": "infeasible", "odd_component": group,
                    "odd_targets": [v for v in group if v in targets], "components": components}
        parity = {v: int(v in targets) for v in group}
        for v in reversed(group[1:]):
            parent, edge = parents[v]
            if parity[v]:
                chosen.add(edge); parity[parent] ^= 1
        assert parity[root] == 0
    return {"status": "feasible", "indices": sorted(chosen), "components": components}


def _finish(g, values, method, **certificate):
    vertices, edges = g["vertices"], g["edges"]
    assert set(values) == set(range(len(edges)))
    R, B = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    for i, (u, v) in enumerate(edges):
        x = values[i]
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for i, (u, v) in enumerate(edges) for x in [values[i]])
    return {"status": "colored", "method": method, "vertices": vertices,
            "T": [v for v in vertices if v in g["T"]],
            "edges": [[u, v, values[i]] for i, (u, v) in enumerate(edges)],
            "red": R, "blue": B,
            "mixed_edges": [list(edges[i]) for i in range(len(edges)) if values[i] == 1],
            "new_vertices_added": 0, "new_edges_added": 0,
            "mother_conjecture_proved": False, **certificate}


def _complete_S(g, values):
    index = {frozenset(e): i for i, e in enumerate(g["edges"])}
    counts = {v: sum(values[i] for i in g["cross"] if v in g["edges"][i]) for v in g["S"]}
    assert all(r % 2 == 0 for r in counts.values())
    groups = []
    for group in g["groups"]:
        order = group["vertices"]
        extension = complete_component([g["degree"][v] for v in order],
                                       [counts[v]//2 for v in order], group["cycle"])
        assert extension["status"] == "extended", (group, extension)
        for j, bit in enumerate(extension["internal_bits"]):
            values[index[frozenset((order[j], order[(j+1) % len(order)]))]] = 2*bit
        groups.append(dict(group, extension=extension))
    return groups


def color_protected_isolates(vertices, edges, T):
    """T can contain paired vertices and isolates; exact protected-join gate."""
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    selected = []
    for group in g["groups"]:
        order = group["vertices"]
        selected += [(order[i], order[(i+1) % len(order)]) for i in selected_break_indices(
            len(order), group["cycle"], [g["degree"][v] for v in order])]
    protected = {v for edge in selected for v in edge}
    allowed_vertices = [v for v in g["vertices"] if v in g["I"] or v in g["S"]-protected]
    allowed = [(i, u, v) for i in g["cross"] for u, v in [g["edges"][i]]
               if u in allowed_vertices and v in allowed_vertices]
    join = _parity_join(allowed_vertices, allowed, g["I"])
    if join["status"] != "feasible":
        return {"status": "no_protected_parity_join", "vertices": g["vertices"],
                "original_edges": [list(e) for e in g["edges"]],
                "T": [v for v in g["vertices"] if v in g["T"]], "I": g["I"],
                "protected_S_vertices": [v for v in g["vertices"] if v in protected],
                "selected_S_edges": [list(e) for e in selected],
                "allowed_edge_indices": [i for i, u, v in allowed], "parity_certificate": join,
                "scope": "Only this protected mixed-edge strategy is excluded.",
                "mother_conjecture_proved": False}
    mixed = set(join["indices"]); pure = [i for i in g["cross"] if i not in mixed]
    row_pairs = g["T_pairs"]+selected
    rows = [{i: (1 if u in g["edges"][i] else -1) for i in pure if u in g["edges"][i] or v in g["edges"][i]}
            for u, v in row_pairs]
    assert all(len(row) >= 4 for row in rows)
    signed = signed_gap_two(rows)
    values = {i: 1 if i in mixed else 1+signed["signs"].get(i, -1) for i in g["cross"]}
    values.update({i: 1 for i, (u, v) in enumerate(g["edges"]) if u in g["T"] and v in g["T"]})
    groups = _complete_S(g, values)
    answer = _finish(g, values, "protected_isolate_join", I=g["I"],
                     protected_S_vertices=[v for v in g["vertices"] if v in protected],
                     selected_S_edges=[list(e) for e in selected],
                     allowed_edge_indices=[i for i, u, v in allowed],
                     extra_mixed_edges=[list(g["edges"][i]) for i in sorted(mixed)],
                     parity_certificate=join, row_pairs=[list(e) for e in row_pairs],
                     signed_rows=[list(row.items()) for row in rows], signed_solution=signed,
                     S_components=groups)
    assert all(answer["red"][v] % 2 == answer["blue"][v] % 2 == int(v in g["T"]) for v in g["vertices"])
    return answer


def independent_cross_join(vertices, edges, T):
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    if g["T_pairs"]:
        return {"status": "not_applicable", "mother_conjecture_proved": False}
    return _parity_join(g["vertices"], [(i, *g["edges"][i]) for i in g["cross"]], g["T"])


def color_independent_given_join(vertices, edges, T, extra_mixed_edges):
    """Exact extension criterion for fixed cross mixed set, S even/T odd."""
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    if g["T_pairs"]:
        return {"status": "not_applicable", "mother_conjecture_proved": False}
    index = {frozenset(e): i for i, e in enumerate(g["edges"])}
    requested = [frozenset(e) for e in extra_mixed_edges]
    if len(set(requested)) != len(requested) or any(e not in index or index[e] not in g["cross"] for e in requested):
        raise ValueError("The prescribed mixed set must be a set of crossing edges.")
    mixed = {index[e] for e in requested}
    md = {v: sum(v in g["edges"][i] for i in mixed) for v in g["vertices"]}
    if any(md[v] % 2 != int(v in g["T"]) for v in g["vertices"]):
        return {"status": "not_an_appropriate_parity_join", "mother_conjecture_proved": False}
    target = {}
    critical_groups = []
    for group in g["groups"]:
        order, cycle = group["vertices"], group["cycle"]; n = len(order)
        critical = (cycle and n % 4 != 0) or (not cycle and n % 2 == 0 and
                    g["degree"][order[0]] == g["degree"][order[-1]] == 3)
        critical_groups.append({"vertices": order, "critical": critical})
        if critical and all(md[v] == 2 for v in order):
            return {"status": "no_extension_for_this_cross_mixed_set", "vertices": g["vertices"],
                    "original_edges": [list(e) for e in g["edges"]],
                    "T": [v for v in g["vertices"] if v in g["T"]],
                    "mixed_edges": [list(g["edges"][i]) for i in sorted(mixed)],
                    "saturated_critical_component": dict(group, degrees=[g["degree"][v] for v in order]),
                    "scope": "Only this fixed cross mixed set with pure S edges is excluded.",
                    "mother_conjecture_proved": False}
        for v in order:
            c = g["degree"][v]-len(g["inside"][v])
            target[v] = max(md[v]//2, min(1, c-md[v]//2))
        if critical:
            target[next(v for v in order if md[v] == 0)] = 0
        if not cycle and n % 2 == 0 and g["degree"][order[0]] == g["degree"][order[-1]] == 4:
            target[order[0]] = 1
            target[order[-1]] = 2 if n == 2 or ((n-4)//2) % 2 else 1
    values = {i: 1 for i in mixed}
    for v in g["S"]:
        pure = [i for u, i in g["adjacency"][v] if i in g["cross"] and i not in mixed]
        amount = target[v]-md[v]//2
        assert 0 <= amount <= len(pure)
        for j, i in enumerate(pure):
            values[i] = 2*int(j < amount)
    groups = _complete_S(g, values)
    answer = _finish(g, values, "independent_T_fixed_cross_join", critical_groups=critical_groups,
                     crossing_half_red_targets=[[v, target[v]] for v in g["vertices"] if v in target],
                     S_components=groups)
    assert set(map(frozenset, answer["mixed_edges"])) == set(requested)
    assert all(answer["red"][v] % 2 == int(v in g["T"]) for v in g["vertices"])
    return answer


def color_independent_even_components(vertices, edges, T):
    """Reverse parity: T even, every S odd, all S components have even order."""
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    if g["T_pairs"] or any(len(c["vertices"]) % 2 for c in g["groups"]):
        return {"status": "not_applicable", "mother_conjecture_proved": False,
                "reason": "Need independent T and even-order S paths/cycles."}
    index = {frozenset(e): i for i, e in enumerate(g["edges"])}
    values, labels = {}, {}
    for group in g["groups"]:
        order = group["vertices"]; n = len(order)
        for j, v in enumerate(order):
            labels[v] = 1+4*(j % 2)
        for j in range(n if group["cycle"] else n-1):
            values[index[frozenset((order[j], order[(j+1) % n]))]] = int(j % 2 == 0)
    for v in g["S"]:
        cross = [i for u, i in g["adjacency"][v] if i in g["cross"]]
        assert len(cross) >= 2
        for j, i in enumerate(cross):
            values[i] = 2*int(labels[v] == 5 and j < 2)
    answer = _finish(g, values, "independent_T_reverse_parity", S_red_targets=list(labels.items()))
    assert all(answer["red"][v] == labels[v] and answer["blue"][v] % 2 for v in g["S"])
    assert all(answer["red"][v] % 2 == answer["blue"][v] % 2 == 0 for v in g["T"])
    return answer


def protected_path_family(t, r):
    if type(t) is not int or t < 1 or t % 2 == 0 or type(r) is not int or r < 0:
        raise ValueError("Use odd t>=1 and r>=0.")
    base = [(0, 1)]*3 if t == 1 else [(v, (v+1) % (2*t)) for v in range(2*t)]+[(v, v+t) for v in range(t)]
    u, v = base[0]; path = [u]+list(range(2*t, 2*t+2*r))+[v]
    H = list(zip(path, path[1:]))+base[1:]
    NS, NT = len(H), 2*t+2*r
    edges = [(i, NS+v) for i, e in enumerate(H) for v in e]
    edges += [(i, i+1) for i in range(NS-1)]
    edges += [(NS+2*t+2*i, NS+2*t+2*i+1) for i in range(r)]
    answer = color_protected_isolates(list(range(NS+NT)), edges, list(range(NS, NS+NT)))
    assert answer["status"] == "colored"
    return dict(answer, family="protected_path_family", t=t, r=r)


def bridge_parity_barrier_family(t):
    if type(t) is not int or t < 1:
        raise ValueError("Use t>=1.")
    n = 4*t
    R = [(v, (v+1) % n) for v in range(n)]+[(v, v+2*t) for v in range(2*t)]
    R.remove((0, 1)); Q = R+[(0, n), (n, 1)]
    H, branches, bridge_indices = [], [], []
    for j in range(3):
        shift = 1+j*(n+1)
        branches.append(list(range(shift, shift+n+1)))
        H += [(shift+u, shift+v) for u, v in Q]
        bridge_indices.append(len(H)); H.append((0, shift+n))
    NT, NS = 3*(n+1)+1, len(H)
    T = list(range(NT)); S = list(range(NT, NT+NS))
    bridge_S = [NT+i for i in bridge_indices]
    cycle_S = [v for v in S if v not in bridge_S][:6]
    pair = bridge_S[:2]
    remainder = [v for v in S if v not in cycle_S and v not in pair]
    edges = [(v, NT+i) for i, e in enumerate(H) for v in e]
    edges += [tuple(pair)]
    edges += [(cycle_S[i], cycle_S[(i+1) % 6]) for i in range(6)]
    edges += list(zip(remainder[::2], remainder[1::2]))
    answer = color_independent_even_components(T+S, edges, T)
    assert answer["status"] == "colored"
    join = independent_cross_join(T+S, edges, T)
    assert join["status"] == "feasible"
    return dict(answer, family="bridge_parity_barrier_family", parameter=t,
                opposite_pattern_obstruction={"branch_T_sets": branches, "bridge_S_vertices": bridge_S,
                    "conflicting_S_pair": pair, "all_S_even_T_odd_cross_only_mixed_is_impossible": True},
                opposite_pattern_parity_join=join)


def odd_independent_side_family(q):
    if type(q) is not int or q < 3 or q % 2 == 0:
        raise ValueError("Use odd q>=3.")
    H = [(i, (i+1) % q) for i in range(q) for _ in range(2)]
    NS = len(H)
    edges = [(i, NS+v) for i, e in enumerate(H) for v in e]
    edges += [(i, i+1) for i in range(NS-1)]
    answer = color_independent_even_components(list(range(NS+q)), edges, list(range(NS, NS+q)))
    assert answer["status"] == "colored"
    return dict(answer, family="odd_independent_side_family", parameter=q,
                odd_T_precludes_S_even_T_odd=True)
