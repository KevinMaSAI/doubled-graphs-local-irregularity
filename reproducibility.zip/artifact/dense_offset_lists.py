"""Dense internal factor with physical offsets and arbitrary forbidden TOTAL red counts.

Degree-class target intervals avoid all forbidden lists. One reserved even/odd
pair fixes the internal target sum. A stated density/offset-spread bound is vital.
"""

import networkx as nx

from dense_antitone_factor import _directed_flow_recovery


def dense_offset_list_plan(graph, red_offsets, blue_offsets, forbidden):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph)):
        raise ValueError("A nonempty finite simple graph is required.")
    if set(red_offsets) != set(graph) or set(blue_offsets) != set(graph) or set(forbidden) != set(graph):
        raise ValueError("Supply both physical offsets and a forbidden set at every vertex.")
    A, B = dict(red_offsets), dict(blue_offsets)
    if any(type(A[v]) is not int or type(B[v]) is not int or min(A[v], B[v]) < 0
           or (A[v]+B[v]) % 2 for v in graph):
        raise ValueError("External counts must be nonnegative integers of even total.")
    F = {v: set(forbidden[v]) for v in graph}
    if any(type(x) is not int for values in F.values() for x in values):
        raise ValueError("Forbidden TOTAL red counts must be integers.")
    n = len(graph)
    q = n-1-min(dict(graph.degree()).values())
    D = {v: graph.degree(v)+(A[v]+B[v])//2 for v in graph}
    groups = {}
    for v in sorted(graph, key=lambda v: -D[v]):
        groups.setdefault(D[v], []).append(v)
    classes = list(groups.values())
    budgets = [max(len(F[v]) for v in group) for group in classes]
    parity_class = min(range(len(classes)), key=lambda i: budgets[i])
    extra = sum(budgets)+budgets[parity_class]+2
    alpha = min(A.values())
    spread = max(A.values())-alpha
    W = max(spread, extra)
    required = 8*q+4*W+10
    if n < required:
        return {"status": "method_not_applicable", "reason": "dense_offset_bound_not_met",
                "n": n, "q": q, "required_n": required, "extra_target_slots": extra,
                "red_offset_spread": spread, "perturbation_bound": W,
                "degree_classes": len(classes), "class_forbidden_budgets": budgets}
    root = classes[parity_class][-1]
    intervals, next_value = [], alpha+(n-1)//2
    for i, group in enumerate(classes):
        length = len(group)+budgets[i]
        if i == parity_class:
            length += budgets[i]+2
        intervals.append(range(next_value, next_value+length))
        next_value += length
    reserved = [next(x for x in intervals[parity_class] if x % 2 == p and x not in F[root])
                for p in (0, 1)]
    total_red = {}
    for i, group in enumerate(classes):
        used = set(reserved) if i == parity_class else set()
        for v in group:
            if v == root:
                continue
            total_red[v] = next(x for x in intervals[i] if x not in used and x not in F[v])
            used.add(total_red[v])
    other_sum = sum(total_red[v]-A[v] for v in total_red)
    total_red[root] = reserved[(A[root]-other_sum) % 2]
    factor_targets = {v: total_red[v]-A[v] for v in graph}
    total_blue = {v: 2*D[v]-total_red[v] for v in graph}
    order = sorted(graph, key=lambda v: (-D[v], total_red[v]))
    assert sum(factor_targets.values()) % 2 == 0
    assert all(0 <= factor_targets[v] <= 2*graph.degree(v) for v in graph)
    assert all(total_red[v] not in F[v] for v in graph)
    assert all(total_red[u] < total_red[v] and total_blue[u] > total_blue[v]
               for u, v in zip(order, order[1:]))
    return {"status": "planned", "n": n, "q": q, "required_n": required,
            "red_offsets": A, "blue_offsets": B, "forbidden": F,
            "total_degrees": D, "total_red_targets": total_red,
            "total_blue_targets": total_blue, "factor_targets": factor_targets,
            "vertex_order": order, "extra_target_slots": extra,
            "red_offset_spread": spread, "perturbation_bound": W,
            "degree_classes": len(classes), "class_forbidden_budgets": budgets,
            "parity_vertex": root, "parity_candidates": reserved,
            "mother_conjecture_proved": False}


def color_dense_offset_lists(graph, red_offsets, blue_offsets, forbidden,
                             factor_weights=None, timeout_ms=10000):
    plan = dense_offset_list_plan(graph, red_offsets, blue_offsets, forbidden)
    if plan["status"] != "planned":
        return plan
    edges = list(graph.edges())
    factor_plan = {"targets": plan["factor_targets"], "vertex_order": plan["vertex_order"]}
    values = _directed_flow_recovery(graph, factor_plan) if factor_weights is None else None
    recovery = "directed_unit_capacity_flow" if values is not None else "provided_factor"
    if factor_weights is None and values is None:
        import z3
        xs = [z3.Int("dense_offset_"+str(i)) for i in range(len(edges))]
        solver = z3.Solver()
        solver.set(timeout=timeout_ms)
        solver.add(*[z3.And(x >= 0, x <= 2) for x in xs])
        for v in graph:
            solver.add(z3.Sum([x for e, x in zip(edges, xs) if v in e]) == plan["factor_targets"][v])
        answer = solver.check()
        if answer == z3.unknown:
            return {"status": "factor_search_incomplete", "reason": solver.reason_unknown(),
                    "mother_conjecture_proved": False}
        if answer != z3.sat:
            raise RuntimeError("Factor solver reported infeasibility under the proved sufficient hypotheses.")
        model = solver.model()
        values = [model.eval(x).as_long() for x in xs]
        recovery = "integer_factor_search"
    elif factor_weights is not None:
        supplied = {frozenset(e): x for e, x in factor_weights.items()}
        if len(supplied) != len(factor_weights) or set(supplied) != set(map(frozenset, edges)):
            raise ValueError("The certificate must supply exactly the internal edges.")
        values = [supplied[frozenset(e)] for e in edges]
    if any(type(x) is not int or x not in (0, 1, 2) for x in values):
        raise ValueError("Factor weights must be integer red-copy counts 0, 1, or 2.")
    internal = dict.fromkeys(graph, 0)
    for (u, v), x in zip(edges, values):
        internal[u] += x; internal[v] += x
    if internal != plan["factor_targets"]:
        raise ValueError("The supplied factor does not realize the planned target degrees.")
    return {"status": "colored", "edge_order": edges, "weights": values,
            "red": plan["total_red_targets"], "blue": plan["total_blue_targets"],
            "plan": plan, "recovery": recovery, "mother_conjecture_proved": False}
