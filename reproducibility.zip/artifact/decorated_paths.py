"""Finite-state construction for paths with at most one pendant tree per vertex.

Five internal vertices suffice for all prescribed physical endpoint counts and
all first/last edge red counts. The infinite-length argument uses the complete
finite certificate; this does not prove existence of core colors in all graphs.
"""
import json
from numbers import Integral
from pathlib import Path


TYPES = ('bare', 'leaf', 'two', 'large')
STATES = tuple((p, D, r) for D in (2, 3) for p in range(3)
               for r in range(p, p + (3 if D == 2 else 5)))
INDEX = {s: i for i, s in enumerate(STATES)}


def local_options(kind, incoming, outgoing):
    """Pairs (total original degree, pendant-bridge red count or None)."""
    if kind == 'bare':
        return ((2, None),)
    total = incoming + outgoing
    colors = (0, 1, 2)
    if kind == 'leaf':
        colors = (0,) if total == 0 else (2,) if total == 4 else colors
    elif kind == 'two':
        colors = (1,) if total == 2 else colors
    elif kind != 'large':
        raise ValueError('Unknown decoration type.')
    return tuple((3, c) for c in colors)


def edge_ok(weight, R, B, r, b):
    return (weight == 0 or R != r) and (weight == 2 or B != b)


def initial_mask(kind, weight, red, blue):
    result = 0
    for q in range(3):
        for D, c in local_options(kind, weight, q):
            r = weight + q + (0 if c is None else c)
            if edge_ok(weight, red, blue, r, 2 * D - r):
                result |= 1 << INDEX[(q, D, r)]
    return result


ROWS = {kind: tuple(initial_mask(kind, p, r, 2 * D - r)
                    for p, D, r in STATES) for kind in TYPES}


def move(mask, kind):
    result = 0
    while mask:
        lowest = mask & -mask
        result |= ROWS[kind][lowest.bit_length() - 1]
        mask -= lowest
    return result


def full_mask(kind):
    return sum(1 << i for i, (q, D, r) in enumerate(STATES)
               if any(D == d and r == p + q + (0 if c is None else c)
                      for p in range(3) for d, c in local_options(kind, p, q)))


def verify_mixing_certificate(path=None):
    """Check every finite case of the stated five-vertex induction certificate.

    Symbol 7 in an endpoint class represents every integer >=7. Internal
    color counts never exceed 6; a class containing 7 has no parity restriction.
    This is a finite proof certificate for this path lemma, not for all graphs.
    """
    path = Path(path) if path is not None else Path(__file__).with_name('decorated_path_certificate.json')
    certificate = json.loads(path.read_text(encoding='utf-8'))
    assert certificate['states'] == [list(s) for s in STATES]
    levels = certificate['lower_signature_levels']
    assert len(levels) == 4
    ends = [(p, R, B) for p in range(3) for R in range(8) for B in range(8)
            if R >= p and B >= 2 - p and
            (R == 7 or B == 7 or (R + B) % 2 == 0)]
    initial_cases = 0
    for e in ends:
        for kind in TYPES:
            mask = initial_mask(kind, *e)
            assert any(m & mask == m for m in levels[0])
            initial_cases += 1
    transitions = 0
    for before, after in zip(levels, levels[1:]):
        for m in before:
            for kind in TYPES:
                result = move(m, kind)
                assert any(n & result == n for n in after)
                transitions += 1
    saturation = 0
    for m in levels[-1]:
        for kind in TYPES:
            assert move(m, kind) == full_mask(kind)
            saturation += 1
    for kind in TYPES:
        mask = full_mask(kind)
        assert any(m & mask == m for m in levels[-1])
        for p, R, B in ends:
            accepted = any(mask >> i & 1 and q == p and
                           edge_ok(p, R, B, r, 2 * D - r)
                           for i, (q, D, r) in enumerate(STATES))
            assert accepted
    return {'verified': True, 'states': len(STATES), 'endpoint_classes': len(ends),
            'initial_cases': initial_cases, 'coverage_transitions': transitions,
            'saturation_cases': saturation,
            'lower_level_sizes': [len(s) for s in levels]}


def fill_decorated_path(kinds, first_red, last_red, left_red, left_blue,
                         right_red, right_blue):
    """Return path and bridge weights, or exact incompatibility for a short path.

    kinds lists the INTERNAL vertices. bare has no pendant tree, leaf has a
    singleton, two a two-vertex tree, large any rooted tree of >=3 vertices.
    Endpoint counts are FINAL, including the prescribed path-edge copies.
    Pendant-tree internal edges must subsequently be filled with tree_ports.
    With >=5 internal vertices the construction is always successful. If the
    two ends represent the same vertex, the caller must use equal final counts
    and ensure they include BOTH incident path edges.
    """
    kinds = tuple(kinds)
    if not kinds or any(k not in TYPES for k in kinds):
        raise ValueError('Require at least one internal vertex of a known type.')
    numbers = (first_red, last_red, left_red, left_blue, right_red, right_blue)
    if any(not isinstance(a, Integral) for a in numbers) or \
        first_red not in (0, 1, 2) or last_red not in (0, 1, 2):
        raise ValueError('Require integer physical endpoint counts and edge weights.')
    if left_red < first_red or left_blue < 2 - first_red or \
        right_red < last_red or right_blue < 2 - last_red or \
        (left_red + left_blue) % 2 or (right_red + right_blue) % 2:
        raise ValueError('Final endpoint counts must include their incident edge.')
    history = []
    current = {None: None}
    for i, kind in enumerate(kinds):
        following = {}
        for previous in current:
            if previous is None:
                incoming, R, B = first_red, left_red, left_blue
            else:
                incoming, old_D, R = previous
                B = 2 * old_D - R
            for outgoing in range(3):
                for D, c in local_options(kind, incoming, outgoing):
                    r = incoming + outgoing + (0 if c is None else c)
                    if edge_ok(incoming, R, B, r, 2 * D - r):
                        state = (outgoing, D, r)
                        following.setdefault(state, (previous, c))
        current = following
        history.append(following)
    terminal = next((s for s in current if s[0] == last_red and
                     edge_ok(last_red, right_red, right_blue, s[2], 2 * s[1] - s[2])), None)
    if terminal is None:
        assert len(kinds) < 5
        return {'status': 'incompatible'}
    states, bridges = [None] * len(kinds), [None] * len(kinds)
    state = terminal
    for i in range(len(kinds) - 1, -1, -1):
        states[i] = state
        state, bridges[i] = history[i][state]
    weights = [int(first_red)] + [s[0] for s in states]
    assert weights[-1] == last_red
    return {'status': 'filled', 'path_weights': weights, 'bridge_weights': bridges,
            'internal_red': [s[2] for s in states],
            'internal_blue': [2 * s[1] - s[2] for s in states]}
