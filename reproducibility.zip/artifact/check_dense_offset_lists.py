"""Audit forbidden-list assignment, parity reservation, offsets and actual factors."""

import json
from pathlib import Path
import random
import time

import networkx as nx

from dense_offset_lists import color_dense_offset_lists, dense_offset_list_plan


def verify(graph, result, A, B, forbidden):
    assert result["status"] == "colored", result
    R, Z = dict(A), dict(B)
    for (u, v), x in zip(result["edge_order"], result["weights"]):
        assert type(x) is int and x in (0, 1, 2)
        for copy in range(2):
            selected = R if copy < x else Z
            selected[u] += 1; selected[v] += 1
    assert R == result["red"] and Z == result["blue"]
    assert len(set(R.values())) == len(set(Z.values())) == len(graph)
    assert all(R[v] not in forbidden[v] for v in graph)
    assert all(R[v]+Z[v] == A[v]+B[v]+2*graph.degree(v) for v in graph)
    return R, Z


def main():
    started = time.monotonic()
    scalar = 0
    for q in range(8):
        for W in range(2, 11):
            for n in (8*q+4*W+10, 8*q+4*W+11):
                L = (n-1)//2
                for s in range(n+1):
                    for t in range(n-s+1):
                        h, r = s+t, n-s-t
                        if not h:
                            continue
                        lower = (s*L+s*(s-1)//2-W*s+2*t*(n-1-q-s)
                                 -t*(L+n-1)+t*(t-1)//2-W*t)
                        assert lower >= h
                        assert lower >= (1 if r > 2*q else r)
                        scalar += 1
    fixtures = []
    H = nx.complete_graph(42)
    fixtures.append(("three_shared_forbidden_values", H,
                     dict.fromkeys(H, 7), dict.fromkeys(H, 9),
                     {v: {27, 28, 29} for v in H}))
    H = nx.complete_graph(80)
    fixtures.append(("large_uniform_offset_with_three_total_degrees", H,
                     {v: 1000+v % 2 for v in H},
                     {v: 2*(1000+v % 3)-(1000+v % 2) for v in H},
                     {v: {1039+v % 5, 1054+v % 7} for v in H}))
    missing = nx.cycle_graph(60)
    missing.remove_edge(0, 1)
    H = nx.complement(missing)
    fixtures.append(("offset_spread_dominates_empty_lists", H,
                     {v: 500+2*(v % 5) for v in H},
                     {v: 500-2*(v % 5) for v in H}, {v: set() for v in H}))
    H = nx.complete_graph(30)
    fixtures.append(("minimum_budget_class_fixes_parity", H, dict.fromkeys(H, 6),
                     {v: 2*(4+v % 3)-6 for v in H},
                     {v: {20, 21} if v % 3 == 2 else {32} if v % 3 == 1 else set() for v in H}))
    records, witness = [], None
    for name, H, A, B, forbidden in fixtures:
        result = color_dense_offset_lists(H, A, B, forbidden)
        verify(H, result, A, B, forbidden)
        p = result["plan"]
        assert p["parity_candidates"][0] % 2 == 0 and p["parity_candidates"][1] % 2 == 1
        if name == "minimum_budget_class_fixes_parity":
            assert p["required_n"] == 30 and p["extra_target_slots"] == 5
            witness = {"name": name, "edges": [[u, v, x] for (u, v), x in
                       zip(result["edge_order"], result["weights"])],
                       "red": result["red"], "blue": result["blue"], "A": A, "B": B,
                       "forbidden": {v: sorted(f) for v, f in forbidden.items()},
                       "q": p["q"], "extra": p["extra_target_slots"], "W": p["perturbation_bound"]}
            supplied = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
            again = color_dense_offset_lists(H, A, B, forbidden, supplied)
            verify(H, again, A, B, forbidden)
            first = next(iter(supplied))
            supplied[first] = (supplied[first]+1) % 3
            try:
                color_dense_offset_lists(H, A, B, forbidden, supplied)
            except ValueError:
                pass
            else:
                raise AssertionError("Damaged supplied factor was accepted.")
        record = {"name": name, "n": len(H), "required": p["required_n"],
                  "q": p["q"], "degree_classes": p["degree_classes"],
                  "class_budgets": p["class_forbidden_budgets"],
                  "extra_slots": p["extra_target_slots"], "offset_spread": p["red_offset_spread"],
                  "recovery": result["recovery"]}
        records.append(record)
        print(json.dumps(record), flush=True)
    rng = random.Random(2026102783)
    interval_cases = 0
    # Test the list/interval construction with abstract, adversarial-looking exclusions.
    for unused in range(1200):
        H = nx.complete_graph(50)
        alpha = rng.randrange(1000000)
        A = {v: alpha+v % 2 for v in H}
        B = {v: alpha+4-(v % 2) for v in H}
        F = {v: set(rng.sample(range(alpha+23, alpha+90), rng.randrange(4))) for v in H}
        p = dense_offset_list_plan(H, A, B, F)
        assert p["status"] == "planned", p
        assert all(p["total_red_targets"][v] not in F[v] for v in H)
        assert sum(p["factor_targets"].values()) % 2 == 0
        interval_cases += 1
    rejected = dense_offset_list_plan(nx.complete_graph(17), dict.fromkeys(range(17), 0),
                                      dict.fromkeys(range(17), 0), {v: set() for v in range(17)})
    assert rejected["status"] == "method_not_applicable"
    out = Path(__file__).parent
    report = {"actual_offset_factors_verified": len(records), "list_assignment_cases": interval_cases,
              "perturbed_Tutte_scalar_cases": scalar,
              "damaged_certificate_rejected": True, "scope_failure_reported_explicitly": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "records": records, "seconds": round(time.monotonic()-started, 3)}
    (out/"dense_offset_lists_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (out/"dense_offset_lists_witness.json").write_text(json.dumps(witness, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
