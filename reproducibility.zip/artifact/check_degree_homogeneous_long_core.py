"""Even-sign lemma and actual-copy audit for unbounded homogeneous root degrees."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from degree_homogeneous_long_core import color_degree_homogeneous_long_core
from degree_two_pair_orientation import _solve_cycle_coefficients
from even_signed_forms import avoid_zero_even_forms


def expand_threads(count, threads):
    graph = nx.Graph()
    graph.add_nodes_from(range(count))
    next_vertex = count
    for u, v, length in threads:
        assert u != v and length >= 1
        middle = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + middle + [v]
        for a, b in zip(path, path[1:]):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
    assert nx.is_connected(graph) and all(graph.degree(v) >= 3 for v in range(count))
    return graph


def proper_three(core):
    if nx.is_bipartite(core):
        return nx.bipartite.color(core)
    order = sorted(core, key=lambda v: -core.degree(v))
    colors = {}
    def search(index):
        if index == len(order):
            return True
        root = order[index]
        used = {colors[v] for v in core[root] if v in colors}
        for value in range(3):
            if value not in used:
                colors[root] = value
                if search(index + 1):
                    return True
                colors.pop(root)
        return False
    return dict(colors) if search(0) else None


def independent_domain(graph):
    if len(graph) == 1:
        return True, None
    degree = dict(graph.degree())
    if min(degree.values()) < 2:
        return False, None
    roots = {v for v in graph if degree[v] >= 3}
    if not roots:
        return True, None
    h = graph.subgraph(roots)
    if any(degree[u] != degree[v] for u, v in h.edges()):
        return False, None
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        assert len(attachments) == 2
        if attachments[0] == attachments[1] or len(vertices) == 1:
            return False, None
    color = {}
    for vertices in nx.connected_components(h):
        local = proper_three(h.subgraph(vertices))
        if local is None:
            return False, None
        color.update(local)
    return True, color


def main():
    started = time.monotonic()
    rng = random.Random(20261109)
    form_cases, cycle_cases, largest_constant = 0, 0, 0
    form_modes, row_lengths = set(), set()
    def check_forms(rows):
        nonlocal form_cases, largest_constant
        result = avoid_zero_even_forms(rows)
        assert set(result["signs"]) == set().union(*(set(row) for row in rows))
        assert all(value in (-1, 1) for value in result["signs"].values())
        assert all(sum(c * result["signs"][key] for key, c in row.items()) != 0 for row in rows)
        row_lengths.update(map(len, rows))
        form_cases += 1
        for item in result["components"]:
            form_modes.add(item["kind"])
            if item["kind"] == "positive_cycle":
                largest_constant = max(largest_constant, max(map(abs, item["cycle_constants"])))
        return result
    check_forms([{i: 1 for i in range(10)}, {i: 1 for i in range(10)}])
    check_forms([{i: 1 for i in range(6)}])
    for length in (4, 6):
        for coefficients in itertools.product((-1, 1), repeat=2 * length):
            check_forms([{i: coefficients[i] for i in range(length)},
                         {i: coefficients[length + i] for i in range(length)}])
    random_form_cases = 0
    for _ in range(500):
        count = rng.randrange(2, 20)
        records = []
        if count == 2:
            records = [(0, 1)] * 4
        else:
            records = [(u, (u + 1) % count) for u in range(count) for _ in range(2)]
        for _ in range(rng.randrange(0, 25)):
            u, v = rng.sample(range(count), 2)
            records.extend(((u, v), (u, v)))
        split = {i for i in range(len(records)) if rng.random() < 0.15} if rng.random() < 0.5 else set()
        rows = [{} for _ in range(count)]
        for i, (u, v) in enumerate(records):
            for end, root in enumerate((u, v)):
                key = (i, end) if i in split else (i, -1)
                rows[root][key] = rng.choice((-1, 1))
        check_forms(rows)
        random_form_cases += 1
    for a in itertools.product((-1, 1), repeat=2):
        for b in itertools.product((-1, 1), repeat=2):
            if a[0] * a[1] * b[0] * b[1] < 0:
                continue
            for constants in itertools.product((-6, -4, -2, 0, 2, 4, 6), repeat=2):
                result = _solve_cycle_coefficients(a, b, constants)
                brute = any(all(a[i] * y[i] + b[i] * y[i - 1] + constants[i] != 0 for i in range(2))
                            for y in itertools.product((-1, 1), repeat=2))
                assert result is not None and brute
                assert all(a[i] * result[i] + b[i] * result[i - 1] + constants[i] != 0 for i in range(2))
                cycle_cases += 1
    graph_cases, max_degree, variable_degree_graphs, private_rows = 0, 0, 0, 0
    core_modes, graph_form_modes, witnesses = set(), set(), {}
    def check(name, graph, coloring=None):
        nonlocal graph_cases, max_degree, variable_degree_graphs, private_rows
        result = color_degree_homogeneous_long_core(graph, coloring)
        verify(graph, result)
        graph_cases += 1
        degree = dict(graph.degree())
        roots = [v for v in graph if degree[v] >= 3]
        max_degree = max(max_degree, max(degree.values()))
        variable_degree_graphs += len({degree[v] for v in roots}) > 1
        for item in result.get("core_reports", []):
            core_modes.add(item["kind"])
            if item["kind"] not in witnesses:
                witnesses[item["kind"]] = {"name": name, "component": item,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        orientation = result.get("orientation_certificate", {})
        private_rows += len(orientation.get("private_rows", []))
        for item in orientation.get("even_form_certificate", {}).get("components", []):
            graph_form_modes.add(item["kind"])
        return result
    check("single_vertex", nx.empty_graph(1))
    atlas_colored, atlas_excluded = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected, color = independent_domain(graph)
        result = color_degree_homogeneous_long_core(graph, color)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph, color)
            atlas_colored += 1
        else:
            atlas_excluded += 1
    # Every selected subset of K3,3, including the empty selection.
    q = nx.complete_bipartite_graph(3, 3)
    base_edges = list(q.edges())
    bip_base_cases = 0
    for bits in itertools.product((0, 1), repeat=len(base_edges)):
        threads = [(u, v, 3 + (i % 3) if bits[i] else 1) for i, (u, v) in enumerate(base_edges)]
        check("K33_partial_subdivision", expand_threads(6, threads))
        bip_base_cases += 1
    for d in range(4, 13):
        q = nx.complete_bipartite_graph(d, d)
        base_edges = list(q.edges())
        for _ in range(20):
            threads = [(u, v, rng.randrange(3, 8) if rng.random() < 0.55 else 1) for u, v in base_edges]
            check("higher_regular_bipartite_base", expand_threads(2 * d, threads))
            bip_base_cases += 1
    # Supplied proper 3-colorings of dense nonbipartite retained cores.
    supplied_cases = 0
    for sizes in ((2, 1, 1), (3, 2, 1), (3, 3, 3), (5, 5, 5), (10, 10, 10)):
        colors, next_vertex = {}, 0
        for color, size in enumerate(sizes):
            for v in range(next_vertex, next_vertex + size):
                colors[v] = color
            next_vertex += size
        threads = [(u, v, rng.randrange(3, 7) if colors[u] == colors[v] else 1)
                   for u in range(next_vertex) for v in range(u + 1, next_vertex)]
        graph = expand_threads(next_vertex, threads)
        if min(sizes) >= 3:
            assert color_degree_homogeneous_long_core(graph)["reason"] == "supply_proper_three_coloring"
        check("supplied_complete_three_partite_core", graph, colors)
        supplied_cases += 1
    # A boundary row of length six, with an adjacent triangle component.
    check("boundary_degree_four_pair", expand_threads(5,
        [(0, 1, 1), (2, 3, 1), (3, 4, 1), (4, 2, 1)]
        + [(u, v, 3) for u in (0, 1) for v in (2, 3, 4)]))
    check("private_variable_different_component_degrees", expand_threads(4,
        [(0, 1, 1), (2, 3, 1), (0, 2, 3), (0, 3, 4), (1, 2, 3), (1, 3, 5),
         (2, 3, 3), (2, 3, 4)]))
    # Closed row multigraphs with mixed even row lengths; assign half the
    # incidences at each row to each root of its retained K2 component.
    mixed_core_cases = 0
    for _ in range(180):
        pair_count = rng.randrange(3, 20)
        records = [(i, (i + 1) % pair_count) for i in range(pair_count) for _ in range(2)]
        for _ in range(rng.randrange(1, 50)):
            u, v = rng.sample(range(pair_count), 2)
            records.extend(((u, v), (u, v)))
        incidences = {i: [] for i in range(pair_count)}
        for key, (u, v) in enumerate(records):
            incidences[u].append((key, 0))
            incidences[v].append((key, 1))
        endpoints = [[None, None] for _ in records]
        for row, items in incidences.items():
            rng.shuffle(items)
            half = len(items) // 2
            for i, (key, end) in enumerate(items):
                endpoints[key][end] = 2 * row + int(i >= half)
        threads = [(2 * i, 2 * i + 1, 1) for i in range(pair_count)]
        threads += [(u, v, rng.randrange(3, 8)) for u, v in endpoints]
        check("mixed_degree_isolated_pairs", expand_threads(2 * pair_count, threads))
        mixed_core_cases += 1
    check("high_degree_private_pair", expand_threads(2, [(0, 1, 1)] + [(0, 1, 3)] * 100))
    check("long_original_connection", expand_threads(2,
        [(0, 1, 1), (0, 1, 5000), (0, 1, 3), (0, 1, 4)]))
    assert form_modes == {"boundary_tree", "positive_cycle"}
    assert graph_form_modes == {"boundary_tree", "positive_cycle"}
    assert largest_constant >= 4 and max(row_lengths) > 4 and variable_degree_graphs > 0
    report = {"checks_passed": True, "signed_even_form_systems_checked": form_cases,
        "exhaustive_two_row_coefficient_systems": 4352, "random_even_form_systems": random_form_cases,
        "positive_two_state_cycle_systems": cycle_cases, "row_lengths_observed": sorted(row_lengths),
        "largest_cycle_constant_observed": largest_constant, "form_component_modes": sorted(form_modes),
        "eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs": atlas_excluded,
        "regular_bipartite_partial_subdivisions": bip_base_cases, "supplied_three_coloring_cases": supplied_cases,
        "mixed_degree_direct_pair_networks": mixed_core_cases, "actual_copy_checked_colorings": graph_cases,
        "graphs_with_different_root_degrees": variable_degree_graphs, "maximum_original_degree": max_degree,
        "private_pair_rows_repaired": private_rows, "core_modes_observed": sorted(core_modes),
        "graph_form_modes_observed": sorted(graph_form_modes), "seconds": time.monotonic() - started,
        "mother_conjecture_proved": False,
        "scope": "Finite implementation audit. The universal sign and coloring claims use separate proofs with explicit retained-core hypotheses."}
    Path(__file__).with_name("degree_homogeneous_long_core_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("degree_homogeneous_long_core_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
