"""Audit private-leaf transfers on known low classes, independently of absorbers."""

import json
from pathlib import Path
import time

import networkx as nx

from low_side_ports import _is_cactus, prepare_low_side


def verify_partial(graph, high, result):
    assert result["status"] == "prepared", result
    values = result["given_weights"]
    required = {frozenset((u, v)) for u, v in graph.edges()
                if u not in high or v not in high}
    assert set(values) == required
    low = set(graph) - high
    R, B = dict.fromkeys(low, 0), dict.fromkeys(low, 0)
    for u, v in graph.edges():
        if frozenset((u, v)) not in values:
            continue
        x = values[frozenset((u, v))]
        assert type(x) is int and 0 <= x <= 2
        for w in (u, v):
            if w in low:
                R[w] += x
                B[w] += 2-x
    assert all(R[v] + B[v] == 2*graph.degree(v) for v in low)
    for u, v in graph.subgraph(low).edges():
        x = values[frozenset((u, v))]
        for copy in range(2):
            count = R if copy < x else B
            assert count[u] != count[v]
    return R, B


def main():
    started = time.monotonic()
    cases, kinds = 0, {}
    for low in nx.graph_atlas_g():
        if not len(low) or not nx.is_connected(low):
            continue
        if not nx.is_bipartite(low) and not _is_cactus(low):
            continue
        for all_ports in (False, True):
            graph = nx.relabel_nodes(low, lambda v: v+2)
            graph.add_edge(0, 1)
            attached = list(graph.subgraph(set(graph)-{0, 1})) if all_ports else [2]
            graph.add_edges_from((v, i % 2) for i, v in enumerate(attached))
            result = prepare_low_side(graph, [{0, 1}])
            verify_partial(graph, {0, 1}, result)
            for report in result["reports"]:
                method = report["method"]
                kinds[method] = kinds.get(method, 0) + 1
            cases += 1
    # A clique with one private port at every vertex is outside these classes.
    unsupported = nx.complete_graph(range(2, 6))
    unsupported.add_edge(0, 1)
    unsupported.add_edges_from((0, v) for v in range(2, 6))
    failure = prepare_low_side(unsupported, [{0, 1}])
    assert failure["status"] == "method_not_applicable"
    assert failure["reason"] == "low_placeholder_is_neither_bipartite_nor_cactus"
    assert set(kinds) == {"already_locally_irregular", "constructive_tree_port",
                          "known_class_exact_recovery", "partial_K2_bridge"}
    output = {"private_leaf_transfer_cases": cases, "methods": kinds,
              "unsupported_class_reported_explicitly": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "seconds": round(time.monotonic()-started, 3)}
    (Path(__file__).parent / "low_side_ports_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
