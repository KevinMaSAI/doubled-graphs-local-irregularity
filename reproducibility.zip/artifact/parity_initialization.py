"""Sparse, nearly balanced parity initialization for actual original edges.

Initialization alone does NOT guarantee local irregularity. The degree-proximity
corollary below has additional explicit hypotheses. No constraint solver is used.
"""

import networkx as nx


def _simple(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")


def balanced_parity_assignment(graph, parity):
    """Realize prescribed R(v)%2 with |R(v)-d(v)|<=1.

    The prescribed sum must be even on EACH connected component. If its parity
    already agrees with d(v), R(v)=d(v) exactly. Nonmixed edges form a forest.
    Return weights in graph.edges() order, actual red/blue counts, and trails.
    This function makes no promise that same-parity neighbors are irregular.
    """
    _simple(graph)
    if set(parity) != set(graph) or any(p not in (0, 1) for p in parity.values()):
        raise ValueError("Supply one parity bit per vertex.")
    edges = list(graph.edges())
    incident = {v: [] for v in graph}
    for i, (u, v) in enumerate(edges):
        incident[u].append((v, i))
        incident[v].append((u, i))
    required = {v: (parity[v] - graph.degree(v)) % 2 for v in graph}
    seen, selected = set(), set()
    for root in graph:
        if root in seen:
            continue
        order, parent, parent_edge = [root], {root: None}, {}
        seen.add(root)
        for v in order:
            for other, edge_id in incident[v]:
                if other not in seen:
                    seen.add(other)
                    parent[other], parent_edge[other] = v, edge_id
                    order.append(other)
        if sum(parity[v] for v in order) % 2:
            raise ValueError("Each connected component needs even prescribed parity sum.")
        for v in reversed(order[1:]):
            if required[v]:
                selected.add(parent_edge[v])
                required[parent[v]] ^= 1
        assert required[root] == 0

    forest_incident = {v: [] for v in graph}
    for i in sorted(selected):
        u, v = edges[i]
        forest_incident[u].append(i)
        forest_incident[v].append(i)
    continuation, starts = {}, []
    for v, edge_ids in forest_incident.items():
        edge_ids = edge_ids[:]
        if len(edge_ids) % 2:
            starts.append((v, edge_ids.pop()))
        for a, b in zip(edge_ids[::2], edge_ids[1::2]):
            continuation[v, a] = b
            continuation[v, b] = a
    weights = [1] * len(edges)
    used, trails = set(), []
    for start, edge_id in starts:
        if edge_id in used:
            continue
        v, sign, trail = start, 1, []
        while True:
            assert edge_id not in used
            used.add(edge_id)
            weights[edge_id] = 1 + sign
            trail.append((edge_id, sign))
            u, w = edges[edge_id]
            other = w if u == v else u
            next_edge = continuation.get((other, edge_id))
            if next_edge is None:
                break
            v, edge_id, sign = other, next_edge, -sign
        trails.append(trail)
    assert used == selected
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] % 2 == parity[v] and abs(red[v] - graph.degree(v)) <= 1 for v in graph)
    return {"edge_order": edges, "weights": weights, "red": red, "blue": blue,
            "forest_edge_ids": sorted(selected), "alternating_trails": trails,
            "guarantees_local_irregularity": False}


def color_degree_proximity_graph(graph):
    """Construct LIR2 if the degree-proximity graph passes its phase test.

    graph must be nonempty connected and simple. Proximity edges are precisely
    those with |d(u)-d(v)|<=2. They must form a bipartite graph on ALL vertices.
    Its bipartite phases must allow an even total number of parity-one vertices.
    Failure means only that this sufficient method is inapplicable.
    """
    _simple(graph)
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("A nonempty connected graph is required.")
    proximity = nx.Graph()
    proximity.add_nodes_from(graph)
    proximity.add_edges_from((u, v) for u, v in graph.edges()
                             if abs(graph.degree(u) - graph.degree(v)) <= 2)
    if not nx.is_bipartite(proximity):
        return {"status": "method_not_applicable", "reason": "nonbipartite_proximity_graph"}
    parity = nx.algorithms.bipartite.color(proximity)
    components = list(nx.connected_components(proximity))
    if sum(parity.values()) % 2:
        odd_component = next((c for c in components if len(c) % 2), None)
        if odd_component is None:
            return {"status": "method_not_applicable", "reason": "no_even_bipartite_phase"}
        for v in odd_component:
            parity[v] ^= 1
    result = balanced_parity_assignment(graph, parity)
    # The construction now has a stronger guarantee on EVERY original edge.
    assert all(result["red"][u] != result["red"][v]
               and result["blue"][u] != result["blue"][v] for u, v in graph.edges())
    result.update({"status": "colored", "parity": parity,
                   "proximity_edges": list(proximity.edges()),
                   "guarantees_local_irregularity": True,
                   "mother_conjecture_proved": False})
    return result
