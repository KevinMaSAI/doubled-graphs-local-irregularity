"""Construct LIR2 when every degree-three root has one degree-three neighbor.

Ordinary paths of EVERY length >=2, loops of every length >=3 and pendant
paths of every positive length are allowed. This is a restricted family,
not a proof of the mother conjecture.
"""

import networkx as nx

from degree_two_pair_orientation import avoid_zero_four_forms
from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches


def color_subcubic_perfect_direct_matching(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return {"status": "method_not_applicable", "reason": "degree_above_three",
                "mother_conjecture_proved": False}
    roots = [v for v in graph if degree[v] == 3]
    if not roots:
        return color_independent_branches(graph)
    root_set = set(roots)
    if any(sum(w in root_set for w in graph[v]) != 1 for v in roots):
        return {"status": "method_not_applicable", "reason": "direct_core_not_perfect_matching",
                "mother_conjecture_proved": False}
    edges = list(graph.edges())
    edge_id = {frozenset(edge): i for i, edge in enumerate(edges)}
    threads, pendants, used = [], [], set()
    for root in roots:
        for neighbor in graph[root]:
            index = edge_id[frozenset((root, neighbor))]
            if index in used:
                continue
            used.add(index)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                index = edge_id[frozenset((current, other))]
                assert index not in used
                used.add(index)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": 0})
            else:
                assert current in root_set
                threads.append({"path": path, "ports": [0, 0]})
    assert len(used) == len(edges)
    direct, ordinary, short = [], [], []
    loops, pendant_ids, short_inc = ({v: [] for v in roots} for _ in range(3))
    for key, item in enumerate(threads):
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            direct.append(key)
            item["ports"] = [1, 1]
        elif u == v:
            assert len(path) >= 4
            loops[u].append(key)
        elif len(path) == 3:
            short.append(key)
            short_inc[u].append((key, 0))
            short_inc[v].append((key, 1))
        else:
            ordinary.append(key)
    for key, item in enumerate(pendants):
        pendant_ids[item["path"][0]].append(key)
    pairs = [tuple(threads[key]["path"]) for key in direct]
    assert {v for pair in pairs for v in pair} == root_set
    assert len(pairs) * 2 == len(roots)
    rigid_pairs, actions = [], []
    for u, v in pairs:
        if loops[u] or loops[v]:
            loop_roots = [w for w in (u, v) if loops[w]]
            for j, root in enumerate(loop_roots):
                assert len(loops[root]) == 1 and not pendant_ids[root] and not short_inc[root]
                threads[loops[root][0]]["ports"] = [0, 1] if j == 0 else [1, 2]
            actions.append({"kind": "mixed_loop_pair", "pair": [u, v], "loop_roots": loop_roots})
        elif not (pendant_ids[u] or pendant_ids[v] or short_inc[u] or short_inc[v]):
            rigid_pairs.append((u, v))
    membership = {}
    for i, (u, v) in enumerate(rigid_pairs):
        membership[u], membership[v] = (i, 1), (i, -1)
    rows = [{} for _ in rigid_pairs]
    for key in ordinary:
        path = threads[key]["path"]
        for root, delta in ((path[0], -1), (path[-1], 1)):
            if root in membership:
                row, epsilon = membership[root]
                rows[row][key] = rows[row].get(key, 0) + epsilon * delta
    private = {i: next((key for key, value in row.items() if abs(value) == 2), None)
               for i, row in enumerate(rows)}
    private = {i: key for i, key in private.items() if key is not None}
    occurrences = {}
    for row, coefficients in enumerate(rows):
        for key in coefficients:
            occurrences.setdefault(key, []).append(row)
    regular_ids = [i for i in range(len(rows)) if i not in private]
    four_form = avoid_zero_four_forms([rows[i] for i in regular_ids])
    signs = {key: four_form["signs"].get(key, 1) for key in ordinary}
    for row, key in private.items():
        assert occurrences[key] == [row]
        constant = sum(value * signs[other] for other, value in rows[row].items() if other != key)
        signs[key] = next(value for value in (1, -1) if constant + rows[row][key] * value != 0)
    for key in ordinary:
        threads[key]["ports"] = [0, 2] if signs[key] == 1 else [2, 0]
    red = dict.fromkeys(roots, 0)
    for item in threads:
        red[item["path"][0]] += item["ports"][0]
        red[item["path"][-1]] += item["ports"][1]
    for u, v in pairs:
        if red[u] != red[v]:
            continue
        assert not loops[u] and not loops[v]
        assert u not in membership
        root = next(w for w in (u, v) if short_inc[w] or pendant_ids[w])
        if short_inc[root]:
            key, end = short_inc[root][0]
            assert threads[key]["ports"][end] == 0
            threads[key]["ports"][end] = 2
            action = {"kind": "short_port_flip", "pair": [u, v], "root": root,
                      "thread": key, "end": end}
        else:
            key = pendant_ids[root][0]
            assert pendants[key]["port"] == 0
            pendants[key]["port"] = 2
            action = {"kind": "pendant_port_flip", "pair": [u, v], "root": root,
                      "pendant": key}
        red[root] += 2
        actions.append(action)
    blue = {v: 6 - red[v] for v in roots}
    assert all(red[u] != red[v] and blue[u] != blue[v] for u, v in pairs)
    assert all(red[v] in ((2, 4) if loops[v] else (1, 3, 5)) for v in roots)
    for key in short:
        path, ports = threads[key]["path"], threads[key]["ports"]
        assert red[path[0]] % 2 and red[path[-1]] % 2
        assert red[path[0]] != 2 + ports[1] and red[path[-1]] != 2 + ports[0]
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value
    for item in threads:
        path, ports = item["path"], item["ports"]
        u, v = path[0], path[-1]
        word = [1] if len(path) == 2 else _path_word(
            len(path) - 1, *ports, red[u], blue[u], red[v], blue[v])
        put(path, word)
    for item in pendants:
        root = item["path"][0]
        put(item["path"], _pendant_word(len(item["path"]) - 1, item["port"], red[root], blue[root]))
    actual_red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        actual_red[u] += value
        actual_red[v] += value
    actual_blue = {v: 2 * degree[v] - actual_red[v] for v in graph}
    assert all(actual_red[v] == red[v] and actual_blue[v] == blue[v] for v in roots)
    assert all((value == 0 or actual_red[u] != actual_red[v])
               and (value == 2 or actual_blue[u] != actual_blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": actual_red, "blue": actual_blue, "threads": threads, "pendants": pendants,
            "direct_pairs": pairs, "actions": actions, "rigid_pairs": rigid_pairs,
            "orientation_certificate": {"signed_rows": rows, "private_rows": list(private),
                "four_form_rows": regular_ids, "four_form_certificate": four_form, "signs": signs},
            "mother_conjecture_proved": False}
