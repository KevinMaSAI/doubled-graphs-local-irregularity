"""A restricted unbounded-degree family from independently known regular bases.

All blocks must be cycles or cubic graphs. The gluing interval and tree
hypotheses remain explicit; this does not solve arbitrary nonregular blocks.
The local construction uses modular sums and Brooks' three-colorability of
connected cubic graphs other than K4, not the new general-subcubic draft.
"""

import networkx as nx

from mod3_edge_weighting import proper_012_with_offsets
from piece_tree_gluing import color_piece_tree


def _three_vertex_coloring(graph):
    """Finite exact DSATUR search; no polynomial running-time claim."""
    colors = {}

    def search():
        if len(colors) == len(graph):
            return True
        v = max((v for v in graph if v not in colors),
                key=lambda w: (len({colors[z] for z in graph[w] if z in colors}),
                               graph.degree(w)))
        forbidden = {colors[w] for w in graph[v] if w in colors}
        for value in range(3):
            if value in forbidden:
                continue
            colors[v] = value
            if search():
                return True
            del colors[v]
        return False

    return dict(colors) if search() else None


def color_regular_block_tree(graph):
    if (graph.is_directed() or graph.is_multigraph()
            or nx.number_of_selfloops(graph) or not len(graph)
            or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    if not graph.number_of_edges():
        return color_piece_tree(graph, [], [])
    pieces, rows = [], []
    for edges in nx.biconnected_component_edges(graph):
        piece = nx.Graph()
        piece.add_edges_from(edges)
        degrees = set(dict(piece.degree()).values())
        if degrees not in ({2}, {3}):
            return {"status": "method_not_applicable",
                    "reason": "some_block_is_not_a_cycle_or_cubic"}
        if len(piece) == 4 and piece.number_of_edges() == 6:
            a, b, c, d = list(piece)
            order = [(a, b), (a, c), (a, d), (b, c), (b, d), (c, d)]
            row = [1, 2, 0, 0, 0, 2]
        else:
            colors = None if nx.is_bipartite(piece) else _three_vertex_coloring(piece)
            assert nx.is_bipartite(piece) or colors is not None
            local = proper_012_with_offsets(piece, coloring=colors)
            assert local["status"] == "weighted"
            order, row = local["edge_order"], local["weights"]
        pieces.append(order)
        rows.append(row)
    result = color_piece_tree(graph, pieces, rows)
    if result["status"] == "colored":
        result["local_basis"] = "cycles_or_cubic_Brooks_and_mod3_or_explicit_K4"
        result["block_count"] = len(pieces)
        result["subcubic_two_marked_draft_used"] = False
    return result
