"""LIR2 for explicitly scoped families of noncubic subcubic graphs.

Leaves, pendant paths of every length, compressed loops and parallel threads
are allowed. A degree-two vertex adjacent to TWO degree-three vertices is
excluded by the original strict interface. An explicit second interface
allows such threads between nonbipartite direct-core components. Additional
interfaces allow internally contained bipartite short paths and cross paths
incident only to bipartite components with two intrinsic controls or a loop.
Pure cubic graphs are a separate known case, not solved here.
"""

import itertools
import json
from functools import lru_cache
from pathlib import Path

import networkx as nx

from degree_two_pair_orientation import avoid_zero_four_forms
from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches
from mod3_edge_weighting import realize_mod3_sums, two_degenerate_coloring
from subcubic_pendant_certificate import TEMPLATES, state_key, verify_certificate


def pendant_feasible(port, red, kind):
    if port not in (0, 1, 2) or not port <= red <= port + 4:
        return False
    if kind == 1:
        return red != 4 if port == 0 else red != 2 if port == 2 else 2 <= red <= 4
    if kind == 2:
        return red != 2 if port == 0 else red != 4 if port == 2 else True
    assert kind == 3
    return True


@lru_cache(None)
def _certificate_index():
    data = json.loads(Path(__file__).with_name("subcubic_pendant_interfaces.json").read_text(encoding="utf-8"))
    verify_certificate(data)
    return {state_key(record): record for record in data["records"]}


def color_subcubic_no_two_threads(graph):
    """The original strict no-ordinary-length-two public interface."""
    return _color_subcubic_threads(graph, allow_nonbip_short=False)


def color_subcubic_nonbip_short_threads(graph):
    """Allow short ordinary threads only between nonbipartite direct cores.

    Both endpoint components of H=G[degree-three vertices] must be
    nonbipartite. An unsupported input returns method_not_applicable.
    """
    return _color_subcubic_threads(graph, allow_nonbip_short=True)


def color_subcubic_internal_bip_short_threads(graph):
    """A short path touching a bipartite direct component must stay inside it.

    Short paths between distinct nonbipartite components are still allowed.
    This includes every noncubic input whose direct degree-three core is
    connected. Unsupported inputs return method_not_applicable.
    """
    return _color_subcubic_threads(graph, allow_nonbip_short=True, allow_internal_bip_short=True)


def color_subcubic_adjustable_bip_short_threads(graph):
    """Allow cross short paths at intrinsically adjustable bipartite cores.

    Every bipartite core component incident to a cross-component short path
    must have a compressed loop, or one part with two intrinsic controls:
    pendant ports, internal-short endpoint incidences, or vertices with no
    pendant and no short path at all. Other components use previous cases.
    """
    return _color_subcubic_threads(graph, allow_nonbip_short=True,
                                   allow_internal_bip_short=True,
                                   allow_adjustable_bip_cross=True)


def _color_subcubic_threads(graph, allow_nonbip_short, allow_internal_bip_short=False,
                           allow_adjustable_bip_cross=False):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if any(value > 3 for value in degree.values()):
        return {"status": "method_not_applicable", "reason": "degree_above_three",
                "mother_conjecture_proved": False}
    if all(value == 3 for value in degree.values()):
        return {"status": "method_not_applicable", "reason": "separate_known_cubic_case",
                "mother_conjecture_proved": False}
    if not allow_nonbip_short and any(
            degree[v] == 2 and all(degree[w] == 3 for w in graph[v]) for v in graph):
        return {"status": "method_not_applicable", "reason": "ordinary_two_edge_thread",
                "mother_conjecture_proved": False}
    branches = [v for v in graph if degree[v] == 3]
    if not branches:
        return color_independent_branches(graph)
    branch_set = set(branches)
    edges = list(graph.edges())
    edge_id = {frozenset(edge): i for i, edge in enumerate(edges)}
    used, threads, pendants = set(), [], []
    for root in branches:
        for neighbor in graph[root]:
            index = edge_id[frozenset((root, neighbor))]
            if index in used:
                continue
            used.add(index)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                index = edge_id[frozenset((current, other))]
                assert index not in used
                used.add(index)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": 0, "kind": min(3, len(path) - 1)})
            else:
                assert current in branch_set
                threads.append({"path": path, "ports": None})
    assert len(used) == len(edges)
    retained = nx.Graph()
    retained.add_nodes_from(branches)
    loops, ordinary, short, pendant_ids = {v: [] for v in branches}, [], [], {v: [] for v in branches}
    for i, item in enumerate(threads):
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            retained.add_edge(u, v)
        elif u == v:
            assert len(path) >= 4
            item["ports"] = [0, 2]
            loops[u].append(i)
        elif len(path) == 3:
            short.append(i)
        else:
            ordinary.append(i)
    for i, item in enumerate(pendants):
        pendant_ids[item["path"][0]].append(i)
    ordinary_degree = dict.fromkeys(branches, 0)
    for i in ordinary + short:
        ordinary_degree[threads[i]["path"][0]] += 1
        ordinary_degree[threads[i]["path"][-1]] += 1
    assert all(retained.degree(v) + 2 * len(loops[v]) + ordinary_degree[v] + len(pendant_ids[v]) == 3
               for v in branches)
    components = list(nx.connected_components(retained))
    component_id = {v: i for i, vertices in enumerate(components) for v in vertices}
    internal_bip_short = {i: [] for i in range(len(components))}
    short_degree = dict.fromkeys(branches, 0)
    # Targets are chosen BEFORE short-port offsets, since those offsets
    # depend on the target at the opposite endpoint. Never recolor later.
    nonbip_targets = {}
    for vertices in components:
        component = retained.subgraph(vertices)
        if not nx.is_bipartite(component):
            phi = two_degenerate_coloring(component)
            assert phi is not None
            nonbip_targets.update(phi)
    cross_short_components = set()
    for key in short:
        u, v = threads[key]["path"][0], threads[key]["path"][-1]
        short_degree[u] += 1
        short_degree[v] += 1
        if component_id[u] != component_id[v]:
            cross_short_components.update((component_id[u], component_id[v]))
        elif u not in nonbip_targets:
            internal_bip_short[component_id[u]].append(key)
    adjustable_plans = {}
    short_targets = dict(nonbip_targets)
    if allow_adjustable_bip_cross:
        for core_id in sorted(cross_short_components):
            vertices = components[core_id]
            if next(iter(vertices)) in nonbip_targets:
                continue
            component = retained.subgraph(vertices)
            partition = nx.bipartite.color(component)
            parts = ([v for v in component if partition[v] == 0],
                     [v for v in component if partition[v] == 1])
            loop_root = next((v for v in component if loops[v]), None)
            if loop_root is not None:
                B, A = parts[partition[loop_root]], parts[1 - partition[loop_root]]
                plan = {"A": A, "B": B, "loop_root": loop_root}
            else:
                tokens = [[], []]
                for root in component:
                    side = partition[root]
                    tokens[side].extend(("pendant", i) for i in pendant_ids[root])
                    if not pendant_ids[root] and not short_degree[root]:
                        tokens[side].append(("target", root))
                for key in internal_bip_short[core_id]:
                    path = threads[key]["path"]
                    tokens[partition[path[0]]].append(("short", key, 1))
                    tokens[partition[path[-1]]].append(("short", key, 0))
                side = next((i for i in (0, 1) if len(tokens[i]) >= 2), None)
                if side is None:
                    return {"status": "method_not_applicable",
                            "reason": "cross_short_component_not_adjustable",
                            "component": list(component),
                            "intrinsic_control_counts": [len(items) for items in tokens],
                            "mother_conjecture_proved": False}
                A, B = parts[side], parts[1 - side]
                plan = {"A": A, "B": B, "controls": tokens[side][:2],
                        "intrinsic_control_counts": [len(items) for items in tokens]}
            plan["phi"] = {v: 0 for v in plan["A"]} | {v: 1 for v in plan["B"]}
            adjustable_plans[core_id] = plan
            short_targets.update(plan["phi"])
    for key in short:
        u, v = threads[key]["path"][0], threads[key]["path"][-1]
        if u not in short_targets or v not in short_targets:
            if (allow_internal_bip_short and component_id[u] == component_id[v]
                    and u not in nonbip_targets):
                threads[key]["ports"] = [0, 0]
            else:
                return {"status": "method_not_applicable",
                        "reason": "short_thread_touches_bipartite_component",
                        "short_path": threads[key]["path"],
                        "mother_conjecture_proved": False}
        else:
            threads[key]["ports"] = [2 * int(short_targets[v] == 2),
                                      2 * int(short_targets[u] == 2)]
    paired = []
    for vertices in components:
        if len(vertices) == 2:
            u, v = vertices
            if (not loops[u] and not loops[v] and not pendant_ids[u] and not pendant_ids[v]
                    and not short_degree[u] and not short_degree[v]):
                paired.append((u, v))
    membership = {}
    for i, (u, v) in enumerate(paired):
        membership[u], membership[v] = (i, 1), (i, -1)
    rows = [{} for _ in paired]
    for key in ordinary:
        path = threads[key]["path"]
        for root, delta in ((path[0], -1), (path[-1], 1)):
            if root in membership:
                row, epsilon = membership[root]
                rows[row][key] = rows[row].get(key, 0) + epsilon * delta
    private = {i: next((key for key, value in row.items() if abs(value) == 2), None)
               for i, row in enumerate(rows)}
    private = {i: key for i, key in private.items() if key is not None}
    occurrences = {}
    for i, row in enumerate(rows):
        for key in row:
            occurrences.setdefault(key, []).append(i)
    regular_ids = [i for i in range(len(rows)) if i not in private]
    regular_result = avoid_zero_four_forms([rows[i] for i in regular_ids])
    signs = {key: regular_result["signs"].get(key, 1) for key in ordinary}
    for row, key in private.items():
        assert occurrences[key] == [row]
        constant = sum(value * signs[other] for other, value in rows[row].items() if other != key)
        signs[key] = next(value for value in (1, -1) if constant + rows[row][key] * value != 0)
    ordinary_red = dict.fromkeys(branches, 0)
    for key in ordinary:
        item = threads[key]
        item["ports"] = [0, 2] if signs[key] == 1 else [2, 0]
        ordinary_red[item["path"][0]] += item["ports"][0]
        ordinary_red[item["path"][-1]] += item["ports"][1]
    for key in short:
        item = threads[key]
        ordinary_red[item["path"][0]] += item["ports"][0]
        ordinary_red[item["path"][-1]] += item["ports"][1]
    assert all(ordinary_red[u] != ordinary_red[v] for u, v in paired)
    values, reports = {}, []
    def set_short_port(key, end, value):
        item = threads[key]
        root = item["path"][0 if end == 0 else -1]
        ordinary_red[root] += value - item["ports"][end]
        item["ports"][end] = value
    def offsets(vertices):
        return {v: ordinary_red[v] + sum(sum(threads[i]["ports"]) for i in loops[v])
                + sum(pendants[i]["port"] for i in pendant_ids[v]) for v in vertices}
    def set_pendants(vertices, phi):
        for v in vertices:
            for i in pendant_ids[v]:
                kind = pendants[i]["kind"]
                pendants[i]["port"] = (2 if (kind == 1 and phi[v] == 1)
                                      or (kind == 2 and phi[v] == 2) else 0)
    def balanced(phi, A, B):
        c = offsets(list(A) + list(B))
        return (sum(phi[v] - c[v] for v in A) - sum(phi[v] - c[v] for v in B)) % 3 == 0
    def write_modular(component, phi, kind, **extra):
        c = offsets(component)
        result = realize_mod3_sums(component, {v: (phi[v] - c[v]) % 3 for v in component})
        assert result["status"] == "realized"
        for edge, value in zip(result["edge_order"], result["weights"]):
            values[frozenset(edge)] = value
        red = {v: c[v] + result["sums"][v] for v in component}
        assert all(red[v] % 3 == phi[v] and 0 <= red[v] <= 6 for v in component)
        assert all(red[u] != red[v] for u, v in component.edges())
        assert all(pendant_feasible(pendants[i]["port"], red[v], pendants[i]["kind"])
                   for v in component for i in pendant_ids[v])
        for v in component:
            for i in loops[v]:
                if threads[i]["ports"] != [0, 2]:
                    assert red[v] in (1, 4)
        reports.append({"kind": kind, "vertices": list(component), "target_mod3": phi, **extra})
    loop_pairs = {1: [0, 1], 2: [0, 2], 3: [1, 2]}
    for core_id, vertices in enumerate(components):
        component = retained.subgraph(vertices)
        assert any(retained.degree(v) < 3 for v in component)
        ids = [i for v in component for i in pendant_ids[v]]
        local_short = internal_bip_short[core_id]
        if core_id in adjustable_plans:
            plan = adjustable_plans[core_id]
            A, B, phi = plan["A"], plan["B"], dict(plan["phi"])
            set_pendants(component, phi)
            if "loop_root" in plan:
                root = plan["loop_root"]
                for chosen in (1, 2, 3):
                    threads[loops[root][0]]["ports"] = loop_pairs[chosen][:]
                    if balanced(phi, A, B):
                        break
                else:
                    raise AssertionError("The adjustable loop must span all residues.")
                write_modular(component, phi, "adjustable_bipartite_loop",
                              loop_root=root, loop_sum=chosen)
            else:
                controls = plan["controls"]
                for bits in itertools.product((0, 2), repeat=2):
                    phi = dict(plan["phi"])
                    for token, value in zip(controls, bits):
                        if token[0] == "pendant":
                            pendants[token[1]]["port"] = value
                        elif token[0] == "short":
                            set_short_port(token[1], token[2], value)
                        else:
                            assert token[0] == "target" and not short_degree[token[1]]
                            phi[token[1]] = value
                    if balanced(phi, A, B):
                        break
                else:
                    raise AssertionError("Two intrinsic controls must span all residues.")
                assert all(phi[v] == short_targets[v] for v in component if short_degree[v])
                write_modular(component, phi, "adjustable_bipartite_two_controls",
                              controls=controls,
                              intrinsic_control_counts=plan["intrinsic_control_counts"])
        elif len(component) == 1:
            v = next(iter(component))
            fixed = ordinary_red[v] + sum(sum(threads[i]["ports"]) for i in loops[v])
            for ports in itertools.product(range(3), repeat=len(ids)):
                red = fixed + sum(ports)
                if all(pendant_feasible(port, red, pendants[i]["kind"]) for i, port in zip(ids, ports)):
                    for i, port in zip(ids, ports):
                        pendants[i]["port"] = port
                    break
            else:
                raise AssertionError("The isolated-root boundary lemma failed.")
            reports.append({"kind": "isolated_root_boundary", "vertices": [v]})
        elif len(component) == 2:
            u, v = component
            loop_root = next((w for w in component if loops[w]), None)
            if local_short:
                assert loop_root is None
                values[frozenset((u, v))] = 1
                if ordinary_red[u] == ordinary_red[v]:
                    key = local_short[0]
                    end = 0 if threads[key]["path"][0] == u else 1
                    set_short_port(key, end, 2)
                assert ordinary_red[u] != ordinary_red[v]
                reports.append({"kind": "isolated_edge_short_parity", "vertices": [u, v],
                                "short_threads": local_short})
            elif loop_root is not None:
                B = loop_root
                A = v if B == u else u
                phi = {A: 0, B: 1}
                set_pendants(component, phi)
                c_A = offsets([A])[A]
                chosen = next(value for value in (1, 2, 3) if value % 3 == (1 + c_A) % 3)
                threads[loops[B][0]]["ports"] = loop_pairs[chosen][:]
                write_modular(component, phi, "isolated_edge_loop", loop_sum=chosen)
            elif not ids:
                assert ordinary_red[u] != ordinary_red[v]
                values[frozenset((u, v))] = 1
                reports.append({"kind": "isolated_edge_oriented", "vertices": [u, v]})
            else:
                found = False
                for weight in range(3):
                    for ports in itertools.product(range(3), repeat=len(ids)):
                        red = {u: ordinary_red[u] + weight, v: ordinary_red[v] + weight}
                        for i, port in zip(ids, ports):
                            red[pendants[i]["path"][0]] += port
                        if red[u] == red[v] or not all(
                                pendant_feasible(port, red[pendants[i]["path"][0]], pendants[i]["kind"])
                                for i, port in zip(ids, ports)):
                            continue
                        for i, port in zip(ids, ports):
                            pendants[i]["port"] = port
                        values[frozenset((u, v))] = weight
                        found = True
                        break
                    if found:
                        break
                assert found, "The isolated-edge pendant lemma failed."
                reports.append({"kind": "isolated_edge_pendants", "vertices": [u, v]})
        elif not nx.is_bipartite(component):
            phi = {v: nonbip_targets[v] for v in component}
            set_pendants(component, phi)
            write_modular(component, phi, "nonbipartite_offsets")
        else:
            partition = nx.bipartite.color(component)
            parts = ([v for v in component if partition[v] == 0],
                     [v for v in component if partition[v] == 1])
            loop_root = next((v for v in component if loops[v]), None)
            rich_part = next((part for part in parts if sum(len(pendant_ids[v]) for v in part) >= 2), None)
            free_part = next((part for part in parts if sum(not pendant_ids[v] for v in part) >= 2), None)
            if local_short and loop_root is None:
                # A target-zero endpoint makes the OTHER endpoint's pure
                # port free. Two independent binary changes cover F3.
                def free_short_ports(A):
                    result = []
                    for key in local_short:
                        path = threads[key]["path"]
                        if path[0] in A:
                            result.append((key, 1))
                        if path[-1] in A:
                            result.append((key, 0))
                    return result
                rich = next((part for part in parts if len(free_short_ports(set(part))) >= 2), None)
                if rich is not None:
                    A = rich
                    B = parts[1] if A is parts[0] else parts[0]
                    phi = {v: 0 for v in A} | {v: 1 for v in B}
                    set_pendants(component, phi)
                    slots = free_short_ports(set(A))[:2]
                    for bits in itertools.product((0, 2), repeat=2):
                        for (key, end), value in zip(slots, bits):
                            set_short_port(key, end, value)
                        if balanced(phi, A, B):
                            break
                    else:
                        raise AssertionError("Two free short ports must cover all residues.")
                    write_modular(component, phi, "bipartite_two_short_ports", short_slots=slots)
                elif ids:
                    # Exactly one short path, with one end in each part.
                    A = next(part for part in parts if any(pendant_ids[v] for v in part))
                    B = parts[1] if A is parts[0] else parts[0]
                    phi = {v: 0 for v in A} | {v: 1 for v in B}
                    set_pendants(component, phi)
                    key, end = free_short_ports(set(A))[0]
                    pendant = next(i for v in A for i in pendant_ids[v])
                    for a, b in itertools.product((0, 2), repeat=2):
                        set_short_port(key, end, a)
                        pendants[pendant]["port"] = b
                        if balanced(phi, A, B):
                            break
                    else:
                        raise AssertionError("A short port and a pendant port must cover F3.")
                    write_modular(component, phi, "bipartite_short_and_pendant")
                else:
                    assert len(local_short) == 1
                    A = next(part for part in parts if len(part) >= 2)
                    B = parts[1] if A is parts[0] else parts[0]
                    baseline = {v: 0 for v in A} | {v: 1 for v in B}
                    root = next(v for v in A if not short_degree[v])
                    key, end = free_short_ports(set(A))[0]
                    for a, flip in itertools.product((0, 2), repeat=2):
                        phi = dict(baseline)
                        phi[root] = flip
                        set_short_port(key, end, a)
                        if balanced(phi, A, B):
                            break
                    else:
                        raise AssertionError("A short port and an unattached target must cover F3.")
                    write_modular(component, phi, "bipartite_short_and_target", flipped_root=root)
            elif loop_root is not None:
                B = parts[partition[loop_root]]
                A = parts[1 - partition[loop_root]]
                phi = {v: 0 for v in A} | {v: 1 for v in B}
                set_pendants(component, phi)
                for chosen in (1, 2, 3):
                    threads[loops[loop_root][0]]["ports"] = loop_pairs[chosen][:]
                    if balanced(phi, A, B):
                        break
                else:
                    raise AssertionError("The three loop offsets must cover all residues.")
                write_modular(component, phi, "bipartite_loop", loop_sum=chosen)
            elif rich_part is not None:
                A = rich_part
                B = parts[1] if A is parts[0] else parts[0]
                phi = {v: 0 for v in A} | {v: 1 for v in B}
                set_pendants(component, phi)
                free_ids = [i for v in A for i in pendant_ids[v]][:2]
                for count in range(3):
                    for j, i in enumerate(free_ids):
                        pendants[i]["port"] = 2 * int(j < count)
                    if balanced(phi, A, B):
                        break
                else:
                    raise AssertionError("Two free pendant ports must cover all residues.")
                write_modular(component, phi, "bipartite_two_pendant_ports")
            elif free_part is not None:
                A = free_part
                B = parts[1] if A is parts[0] else parts[0]
                baseline = {v: 0 for v in A} | {v: 1 for v in B}
                set_pendants(component, baseline)
                free_vertices = [v for v in A if not pendant_ids[v]][:2]
                for count in range(3):
                    phi = dict(baseline)
                    for v in free_vertices[:count]:
                        phi[v] = 2
                    if balanced(phi, A, B):
                        break
                else:
                    raise AssertionError("Two unattached vertices must cover all residues.")
                write_modular(component, phi, "bipartite_two_unattached_vertices")
            else:
                local_vertices = list(component)
                actual_edges = {frozenset(edge) for edge in component.edges()}
                match = None
                for name, (count, template_edges, _) in TEMPLATES.items():
                    if count != len(component) or len(template_edges) != component.number_of_edges():
                        continue
                    for order in itertools.permutations(local_vertices):
                        if {frozenset((order[a], order[b])) for a, b in template_edges} == actual_edges:
                            match = name, order, template_edges
                            break
                    if match is not None:
                        break
                assert match is not None
                name, order, template_edges = match
                roots = tuple(j for j, v in enumerate(order) if pendant_ids[v])
                assert all(len(pendant_ids[order[j]]) == 1 for j in roots)
                kinds = tuple(pendants[pendant_ids[order[j]][0]]["kind"] for j in roots)
                fixed = tuple(ordinary_red[v] for v in order)
                record = _certificate_index()[(name, roots, kinds, fixed)]
                for (a, b), weight in zip(template_edges, record["core_weights"]):
                    values[frozenset((order[a], order[b]))] = weight
                for j, word in zip(roots, record["pendant_words"]):
                    pendants[pendant_ids[order[j]][0]]["port"] = word[0]
                reports.append({"kind": "small_bipartite_certificate", "vertices": list(component),
                                "template": name, "canonical_order": list(order),
                                "certificate_key": [name, roots, kinds, fixed]})
    root_red = offsets(branches)
    for u, v in retained.edges():
        value = values[frozenset((u, v))]
        root_red[u] += value
        root_red[v] += value
    root_blue = {v: 6 - root_red[v] for v in branches}
    assert all(0 <= root_red[v] <= 6 for v in branches)
    assert all(root_red[u] != root_red[v] for u, v in retained.edges())
    for key in short:
        item = threads[key]
        u, v = item["path"][0], item["path"][-1]
        a, b = item["ports"]
        assert root_red[u] != 2 + b and root_red[v] != 2 + a
    assert all(pendant_feasible(item["port"], root_red[item["path"][0]], item["kind"]) for item in pendants)
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value
    for item in threads:
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            value = values[frozenset((u, v))]
            item["ports"] = [value, value]
            word = [value]
        else:
            word = _path_word(len(path) - 1, *item["ports"], root_red[u], root_blue[u], root_red[v], root_blue[v])
        put(path, word)
    for item in pendants:
        path = item["path"]
        root = path[0]
        put(path, _pendant_word(len(path) - 1, item["port"], root_red[root], root_blue[root]))
    assert all(value in (0, 1, 2) for value in weights)
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in branches)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights, "red": red, "blue": blue,
            "threads": threads, "pendants": pendants, "retained_components": reports,
            "short_threads": short, "prechosen_nonbip_targets": nonbip_targets,
            "prechosen_short_targets": short_targets,
            "adjustable_bipartite_components": list(adjustable_plans),
            "orientation_certificate": {"pairs": paired, "signed_rows": rows,
                                        "private_rows": list(private), "four_form_rows": regular_ids,
                                        "four_form_certificate": regular_result, "ordinary_signs": signs},
            "mother_conjecture_proved": False}
