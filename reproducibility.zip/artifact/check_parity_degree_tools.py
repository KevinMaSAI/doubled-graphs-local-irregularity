"""Independent finite checks; the accompanying note supplies universal proofs."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from parity_initialization import balanced_parity_assignment, color_degree_proximity_graph
from parity_window_factor import parity_degree_window
from parity_repair_obstruction import repair_obstruction


def actual_counts(graph, edges, weights, require_lir=False):
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    if require_lir:
        assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
        assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    return dict(red.degree()), dict(blue.degree())


def verify_odd_component_certificate(graph, lower, upper, parity, certificate):
    """Rebuild the specified gadget and count components, without matching."""
    adjacency, ports = {}, {v: [] for v in graph}
    next_node = 0
    def edge(a, b):
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)
    def pair(u, v):
        nonlocal next_node
        a, b = next_node, next_node + 1
        next_node += 2
        edge(a, b)
        ports[u].append(a)
        ports[v].append(b)
    for u, v in graph.edges():
        pair(u, v)
        pair(u, v)
    maxima = {}
    for v in graph:
        lo, hi = max(0, lower[v]), min(2 * graph.degree(v), upper[v])
        allowed = [value for value in range(lo, hi + 1) if value % 2 == parity[v]]
        assert allowed
        maxima[v] = max(allowed)
        for _ in range((max(allowed) - min(allowed)) // 2):
            pair(v, v)
    for v in graph:
        for _ in range(maxima[v]):
            dummy = next_node
            next_node += 1
            adjacency.setdefault(dummy, set())
            for port in ports[v]:
                edge(dummy, port)
    removed = set(certificate["removed_vertices"])
    assert removed <= set(range(next_node))
    remaining = set(range(next_node)) - removed
    odd = []
    while remaining:
        start = next(iter(remaining))
        component, stack = {start}, [start]
        remaining.remove(start)
        while stack:
            v = stack.pop()
            for w in adjacency.get(v, ()):
                if w in remaining:
                    remaining.remove(w)
                    component.add(w)
                    stack.append(w)
        if len(component) % 2:
            odd.append(frozenset(component))
    assert set(odd) == {frozenset(c) for c in certificate["odd_components"]}
    assert len(odd) > len(removed)
    assert len(odd) - len(removed) == certificate["deficiency"]
    return {"verified_without_matching": True, "removed": len(removed), "odd_components": len(odd)}


def main():
    started = time.monotonic()
    rng = random.Random(20261027)
    parity_cases = 0
    proximity_cases = 0
    proximity_excluded = 0
    for graph in nx.graph_atlas_g():
        if not len(graph) or len(graph) > 6 or not nx.is_connected(graph):
            continue
        nodes = list(graph)
        for bits in itertools.product((0, 1), repeat=len(nodes)):
            if sum(bits) % 2:
                continue
            parity = dict(zip(nodes, bits))
            result = balanced_parity_assignment(graph, parity)
            red, blue = actual_counts(graph, result["edge_order"], result["weights"])
            assert all(red[v] % 2 == blue[v] % 2 == parity[v] for v in graph)
            assert all(abs(red[v] - graph.degree(v)) <= 1 for v in graph)
            assert all(red[v] == graph.degree(v) for v in graph if graph.degree(v) % 2 == parity[v])
            support = nx.Graph()
            support.add_nodes_from(graph)
            support.add_edges_from(edge for edge, value in zip(result["edge_order"], result["weights"]) if value != 1)
            assert nx.is_forest(support)
            parity_cases += 1
        result = color_degree_proximity_graph(graph)
        if result["status"] == "colored":
            red, blue = actual_counts(graph, result["edge_order"], result["weights"], True)
            assert all(red[u] != red[v] and blue[u] != blue[v] for u, v in graph.edges())
            proximity_cases += 1
        else:
            proximity_excluded += 1

    # A fully un-subdivided, minimum-degree-four, nonbipartite family.
    direct_core_cases = []
    for degrees in ((4, 8, 12), (6, 12, 18), (8, 16, 24)):
        graph, roots, offset = nx.Graph(), [], 0
        for degree in degrees:
            module = nx.relabel_nodes(nx.complete_bipartite_graph(degree, degree), lambda v: v + offset)
            graph.update(module)
            roots.append(offset)
            offset += 2 * degree
        graph.add_edges_from((roots[i], roots[(i + 1) % 3]) for i in range(3))
        assert not nx.is_bipartite(graph) and min(dict(graph.degree()).values()) >= 4
        result = color_degree_proximity_graph(graph)
        assert result["status"] == "colored"
        actual_counts(graph, result["edge_order"], result["weights"], True)
        direct_core_cases.append({"module_degrees": degrees, "vertices": len(graph),
                                  "edges": graph.number_of_edges(), "passed": True})

    # Match parity intervals against exhaustive original-edge assignments.
    factor_cases, feasible_cases, infeasible_cases = 0, 0, 0
    for graph in nx.graph_atlas_g():
        if not len(graph) or len(graph) > 5 or graph.number_of_edges() > 6 or not nx.is_connected(graph):
            continue
        nodes, edges = list(graph), list(graph.edges())
        possible = []
        for values in itertools.product(range(3), repeat=len(edges)):
            counts = dict.fromkeys(nodes, 0)
            for (u, v), value in zip(edges, values):
                counts[u] += value
                counts[v] += value
            possible.append(counts)
        for case in range(20):
            lower, upper, parity = {}, {}, {}
            for v in nodes:
                degree = 2 * graph.degree(v)
                a, b = sorted((rng.randrange(-1, degree + 2), rng.randrange(-1, degree + 2)))
                lower[v], upper[v], parity[v] = a, b, rng.randrange(2)
            expected = any(all(lower[v] <= counts[v] <= upper[v] and counts[v] % 2 == parity[v] for v in nodes)
                           for counts in possible)
            result = parity_degree_window(graph, lower, upper, parity)
            assert (result["status"] == "feasible") == expected
            if expected:
                counts, _ = actual_counts(graph, result["edge_order"], result["weights"])
                assert all(lower[v] <= counts[v] <= upper[v] and counts[v] % 2 == parity[v] for v in nodes)
                feasible_cases += 1
            else:
                infeasible_cases += 1
            factor_cases += 1

    obstruction_cases, factor_radius_cases = [], []
    independent_certificate = None
    for cycle_count in (2, 4, 6, 8, 10, 20):
        for k in (1, 2, 3, 5):
            family = repair_obstruction(cycle_count, k)
            graph, parity, target = family["graph"], family["parity"], family["target"]
            edges = list(graph.edges())
            baseline, _ = actual_counts(graph, edges, [family["baseline"][tuple(sorted(e))] for e in edges])
            assert baseline == target
            repaired_red, repaired_blue = actual_counts(
                graph, edges, [family["parity_repaired_coloring"][tuple(sorted(e))] for e in edges], True)
            assert all(repaired_red[v] % 2 == parity[v] for v in graph)
            radius = max(abs(repaired_red[v] - target[v]) for v in graph)
            assert radius == family["minimum_prescribed_parity_radius"]
            for cycle in family["cycles"]:
                assert sum(parity[v] for v in cycle) % 2 == 1
                boundary_red = sum(family["parity_repaired_coloring"][tuple(sorted((hub, v)))]
                                   for hub in (0, 1) for v in cycle)
                assert boundary_red == 1
            assert repaired_red[0] + repaired_red[1] == cycle_count
            free_red, _ = actual_counts(
                graph, edges, [family["free_coloring"][tuple(sorted(e))] for e in edges], True)
            assert free_red[0] == free_red[1] == 0
            assert max(abs(free_red[v] - target[v]) for v in graph) <= 4
            assert min(dict(graph.degree()).values()) == 4
            assert nx.node_connectivity(graph) == 2
            cut_size = sum(parity[u] != parity[v] for u, v in edges)
            assert cut_size == family["maximum_cut_size"]
            # Also verify the displayed designated-color premises directly.
            n = len(graph) - 2
            designated = {v: (n + 1 if v in (0, 1) else 9 if parity[v] == 0 else 11) for v in graph}
            assert all(designated[u] != designated[v] for u, v in edges)
            assert all(abs(target[v] + graph.degree(v) + 2 - designated[v]) == 1 for v in graph)
            obstruction_cases.append({"cycle_count": cycle_count, "k": k, "vertices": len(graph),
                                      "edges": graph.number_of_edges(), "exact_radius": radius,
                                      "passed": True})

    for cycle_count in (2, 6):
        family = repair_obstruction(cycle_count)
        graph, target, parity = family["graph"], family["target"], family["parity"]
        exact = family["minimum_prescribed_parity_radius"]
        for radius in (exact - 1, exact):
            result = parity_degree_window(graph, {v: target[v] - radius for v in graph},
                                         {v: target[v] + radius for v in graph}, parity,
                                         obstruction_certificate=(cycle_count == 2 and radius == 1))
            assert (result["status"] == "feasible") == (radius >= exact)
            if result["status"] == "feasible":
                counts, _ = actual_counts(graph, result["edge_order"], result["weights"])
                assert max(abs(counts[v] - target[v]) for v in graph) <= radius
            else:
                if "tutte_barrier" in result:
                    barrier = result["tutte_barrier"]
                    independent_certificate = verify_odd_component_certificate(
                        graph, {v: target[v] - radius for v in graph},
                        {v: target[v] + radius for v in graph}, parity, barrier)
                    witness = {"cycle_count": cycle_count, "k": 1, "radius": radius,
                               "edges": list(graph.edges()), "target": target, "parity": parity,
                               "matching_obstruction": result}
                    Path(__file__).with_name("parity_radius_matching_obstruction.json").write_text(
                        json.dumps(witness, ensure_ascii=False, indent=2), encoding="utf-8")
            factor_radius_cases.append({"cycle_count": cycle_count, "radius": radius,
                                        "status": result["status"]})
    smallest = repair_obstruction(2)
    graph = smallest["graph"]
    witness = {"cycle_count": 2, "k": 1, "vertices": len(graph),
               "edges": [[u, v, smallest["baseline"][tuple(sorted((u, v)))],
                           smallest["parity_repaired_coloring"][tuple(sorted((u, v)))],
                           smallest["free_coloring"][tuple(sorted((u, v)))]] for u, v in graph.edges()],
               "target": smallest["target"], "parity": smallest["parity"],
               "exact_prescribed_parity_radius": 2,
               "scope": "A strategy obstruction, not a counterexample to the mother conjecture."}
    Path(__file__).with_name("parity_radius_core_example.json").write_text(
        json.dumps(witness, ensure_ascii=False, indent=2), encoding="utf-8")
    result = {"near_balanced_parity_cases": parity_cases,
              "proximity_colored_atlas_graphs": proximity_cases,
              "proximity_excluded_atlas_graphs": proximity_excluded,
              "unsubdivided_core_family_cases": direct_core_cases,
              "parity_window_exhaustive_comparisons": factor_cases,
              "window_feasible": feasible_cases, "window_infeasible": infeasible_cases,
              "repair_obstruction_family_cases": obstruction_cases,
              "repair_radius_matching_comparisons": factor_radius_cases,
              "independent_odd_component_certificate": independent_certificate,
              "checks_passed": True, "seconds": time.monotonic() - started,
              "scope": "Finite implementation checks. Universal statements are justified by the separate proof note.",
              "mother_conjecture_proved": False}
    Path(__file__).with_name("parity_degree_tools_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in ("repair_obstruction_family_cases",)},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
