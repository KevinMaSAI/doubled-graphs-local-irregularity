"""Check target rounding, every scalar cut bound, and actual integral factors."""

import json
from pathlib import Path
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from dense_antitone_factor import color_dense_antitone, dense_antitone_plan


def main():
    started = time.monotonic()
    scalar = 0
    for q in range(20):
        for n in range(8*q+14, 8*q+19):
            values = [(n-1)//2+i for i in range(n)]
            if sum(values) % 2:
                values[-1] += 1
            prefix = [0]
            for f in values:
                prefix.append(prefix[-1]+f)
            for s in range(n+1):
                for t in range(n-s+1):
                    h, r = s+t, n-s-t
                    if not h:
                        continue
                    bound = prefix[s]+2*t*(n-1-q-s)-(prefix[n]-prefix[n-t])
                    assert bound >= 2*h-1
                    assert bound >= (1 if r > 2*q else r)
                    scalar += 1
    records, witness = [], None
    for q, n in ((0, 14), (0, 15), (0, 16), (0, 17),
                 (1, 22), (1, 23), (2, 30), (2, 31),
                 (3, 38), (3, 39), (4, 46), (6, 62)):
        if q == 0:
            missing = nx.empty_graph(n)
        elif q == 1:
            missing = nx.empty_graph(n)
            missing.add_edges_from((i, i+1) for i in range(0, n-1, 2))
        elif q == 2:
            missing = nx.cycle_graph(n)
        elif q == 3 and n == 39:
            missing = nx.cycle_graph(n)
            missing.add_edge(0, 2)
        else:
            missing = nx.random_regular_graph(q, n, seed=2026102781+q)
        if q and n != 39:
            missing.remove_edge(*next(iter(missing.edges())))
        graph = nx.complement(missing)
        result = color_dense_antitone(graph)
        assert result["status"] == "colored", result
        verify(graph, result)
        plan = result["plan"]
        assert plan["missing_degree_bound"] == q
        assert len(set(result["red"].values())) == len(set(result["blue"].values())) == n
        record = {"q": q, "n": n, "edges": graph.number_of_edges(),
                  "recovery": result["recovery"],
                  "nonregular": len(set(dict(graph.degree()).values())) > 1,
                  "at_density_threshold": n == 8*q+14,
                  "last_target_adjusted": n % 4 == 2}
        records.append(record)
        print(json.dumps(record), flush=True)
        if q == 3 and n == 38:
            witness = {"recipe": record, "missing_edges": list(missing.edges()),
                       "edges": [[u, v, x] for (u, v), x in
                                 zip(result["edge_order"], result["weights"])],
                       "red": result["red"], "blue": result["blue"],
                       "order": plan["vertex_order"]}
            supplied = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
            verified = color_dense_antitone(graph, supplied)
            assert verified["red"] == result["red"]
            first = next(iter(supplied))
            supplied[first] = (supplied[first]+1) % 3
            try:
                color_dense_antitone(graph, supplied)
            except ValueError:
                pass
            else:
                raise AssertionError("Damaged factor certificate was accepted.")
    failure = dense_antitone_plan(nx.cycle_graph(5))
    assert failure["status"] == "method_not_applicable" and failure["reason"] == "density_bound_not_met"
    out = Path(__file__).parent
    record = {"scalar_cut_boundary_cases": scalar, "actual_factors_verified": len(records),
              "nonregular_fixtures": sum(r["nonregular"] for r in records),
              "all_vertex_color_counts_distinct": True, "damaged_certificate_rejected": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "records": records, "seconds": round(time.monotonic()-started, 3)}
    (out/"dense_antitone_factor_validation.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    (out/"dense_antitone_factor_witness.json").write_text(json.dumps(witness, indent=2), encoding="utf-8")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
