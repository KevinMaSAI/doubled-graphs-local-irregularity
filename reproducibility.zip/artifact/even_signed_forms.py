"""Avoid zero in signed even rows of size at least four, occurrence at most two.

Row lengths may differ and are unbounded. This is an auxiliary sign lemma,
not a general locally irregular coloring algorithm.
"""

import networkx as nx

from degree_two_pair_orientation import _positive_cycle, _solve_cycle_coefficients


def avoid_zero_even_forms(rows):
    rows = [dict(row) for row in rows]
    occurrences = {}
    for row, coefficients in enumerate(rows):
        if len(coefficients) < 4 or len(coefficients) % 2 or any(c not in (-1, 1) for c in coefficients.values()):
            raise ValueError("Every row needs an even number >=4 of distinct variables, with coefficients +/-1.")
        for key, coefficient in coefficients.items():
            if key is None:
                raise ValueError("Variable identifiers cannot be None.")
            occurrences.setdefault(key, []).append((row, coefficient))
    if any(len(items) > 2 for items in occurrences.values()):
        raise ValueError("Each variable may occur in at most two rows.")
    graph = nx.MultiGraph()
    graph.add_nodes_from(range(len(rows)))
    boundary, tau = {v: [] for v in graph}, {}
    for key, items in occurrences.items():
        if len(items) == 1:
            boundary[items[0][0]].append(key)
        else:
            (u, a), (v, b) = items
            assert u != v
            graph.add_edge(u, v, key=key)
            tau[key] = a * b
    values, reports = dict.fromkeys(occurrences, 1), []
    def finish(row, key):
        constant = sum(c * values[e] for e, c in rows[row].items() if e != key)
        assert values[key] is None
        values[key] = next(sign for sign in (1, -1) if constant + rows[row][key] * sign != 0)
    for vertices in nx.connected_components(graph):
        component = graph.subgraph(vertices)
        root = next((v for v in component if boundary[v]), None)
        if root is not None:
            chosen = boundary[root][0]
            order, parent, parent_edge = [root], {root: None}, {}
            for u in order:
                for v, keyed in component[u].items():
                    if v not in parent:
                        parent[v], parent_edge[v] = u, next(iter(keyed))
                        order.append(v)
            for key in set(parent_edge.values()) | {chosen}:
                values[key] = None
            for v in reversed(order[1:]):
                finish(v, parent_edge[v])
            finish(root, chosen)
            reports.append({"kind": "boundary_tree", "rows": list(component), "root": root})
        else:
            assert all(component.degree(v) == len(rows[v]) >= 4 for v in component)
            # The positive-cycle search uses minimum degree >=4, not regularity.
            cycle_v, cycle_e, search_kind = _positive_cycle(component, tau)
            order, parent, parent_edge = list(cycle_v), {v: None for v in cycle_v}, {}
            for u in order:
                for v, keyed in component[u].items():
                    if v not in parent:
                        parent[v], parent_edge[v] = u, next(iter(keyed))
                        order.append(v)
            for key in set(cycle_e) | set(parent_edge.values()):
                values[key] = None
            for v in reversed(order[len(cycle_v):]):
                finish(v, parent_edge[v])
            selected = set(cycle_e)
            constants = [sum(c * values[e] for e, c in rows[v].items() if e not in selected) for v in cycle_v]
            assert all(c % 2 == 0 for c in constants)
            a = [rows[v][cycle_e[i]] for i, v in enumerate(cycle_v)]
            b = [rows[v][cycle_e[i - 1]] for i, v in enumerate(cycle_v)]
            signs = _solve_cycle_coefficients(a, b, constants)
            assert signs is not None
            for key, sign in zip(cycle_e, signs):
                values[key] = sign
            reports.append({"kind": "positive_cycle", "rows": list(component),
                            "cycle_rows": cycle_v, "cycle_variables": cycle_e,
                            "cycle_constants": constants, "search_kind": search_kind})
    sums = [sum(c * values[key] for key, c in row.items()) for row in rows]
    assert all(value in (-1, 1) for value in values.values()) and all(sums)
    return {"signs": values, "row_sums": sums, "row_lengths": [len(row) for row in rows], "components": reports}
