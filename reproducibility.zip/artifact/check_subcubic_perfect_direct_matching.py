"""Actual-copy checks for the perfect direct-matching subcubic family."""

import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from independent_branch_coloring import _path_word
from subcubic_perfect_direct_matching import color_subcubic_perfect_direct_matching


def domain(graph):
    degree = dict(graph.degree())
    return max(degree.values()) <= 3 and all(
        sum(degree[w] == 3 for w in graph[v]) == 1 for v in graph if degree[v] == 3)


def check_loop(word, red):
    assert word is not None
    r = [red] + [a + b for a, b in zip(word, word[1:])] + [red]
    b = [6 - red] + [4 - value for value in r[1:-1]] + [6 - red]
    return all((x == 0 or r[i] != r[i + 1]) and (x == 2 or b[i] != b[i + 1])
               for i, x in enumerate(word))


def main():
    started = time.monotonic()
    rng = random.Random(20261104)
    loop_interfaces = 0
    for red, ports in ((2, (0, 1)), (4, (1, 2))):
        for length in range(3, 80):
            word = _path_word(length, *ports, red, 6 - red, red, 6 - red)
            assert word is not None and (word[0], word[-1]) == ports
            assert check_loop(word, red)
            loop_interfaces += 1
    cases, with_short, with_loops, maximum_length, private_rows = 0, 0, 0, 0, 0
    actions, form_modes, witnesses = set(), set(), {}
    def check(name, graph):
        nonlocal cases, with_short, with_loops, maximum_length, private_rows
        assert domain(graph)
        result = color_subcubic_perfect_direct_matching(graph)
        verify(graph, result)
        cases += 1
        short, loop = False, False
        for item in result.get("threads", []):
            length = len(item["path"]) - 1
            short |= length == 2
            loop |= item["path"][0] == item["path"][-1]
        with_short += short
        with_loops += loop
        for item in result.get("threads", []) + result.get("pendants", []):
            maximum_length = max(maximum_length, len(item["path"]) - 1)
        certificate = result.get("orientation_certificate", {})
        private_rows += len(certificate.get("private_rows", []))
        for item in certificate.get("four_form_certificate", {}).get("components", []):
            form_modes.add(item["kind"])
        for action in result.get("actions", []):
            kind = action["kind"]
            actions.add(kind)
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "action": action,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    atlas_colored, atlas_excluded = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        result = color_subcubic_perfect_direct_matching(graph)
        expected = domain(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_colored += 1
        else:
            atlas_excluded += 1
    fixtures = [
        ("all_short_parallel", 2, [(0, 1, 1), (0, 1, 2), (0, 1, 2)], []),
        ("all_pendants", 2, [(0, 1, 1)], [(0, 1), (0, 2), (1, 1), (1, 2)]),
        ("two_mixed_loops", 2, [(0, 1, 1), (0, 0, 3), (1, 1, 3)], []),
        ("one_mixed_loop", 2, [(0, 1, 1), (0, 0, 4)], [(1, 1), (1, 2)]),
        ("private_rigid_pair", 2, [(0, 1, 1), (0, 1, 3), (0, 1, 4)], []),
        ("closed_four_forms", 4,
         [(0, 1, 1), (2, 3, 1), (0, 2, 3), (0, 3, 3), (1, 2, 3), (1, 3, 3)], []),
        ("boundary_four_forms", 6,
         [(0, 1, 1), (2, 3, 1), (4, 5, 1), (0, 2, 3), (0, 3, 4), (1, 4, 5), (1, 5, 3)],
         [(2, 2), (3, 1), (4, 4), (5, 3)]),
        ("short_and_loop_neighbor", 4,
         [(0, 1, 1), (2, 3, 1), (0, 0, 3), (1, 2, 2), (1, 3, 3), (2, 3, 2)], []),
    ]
    for name, count, threads, pendants in fixtures:
        check(name, expand(count, threads, pendants))
    random_cases, discarded = 0, 0
    while random_cases < 1400:
        pair_count = rng.randrange(1, 30)
        count = 2 * pair_count
        direct = [(u, u + 1, 1) for u in range(0, count, 2)]
        stubs = list(range(count)) * 2
        rng.shuffle(stubs)
        ordinary = list(zip(stubs[::2], stubs[1::2]))
        compressed = nx.Graph()
        compressed.add_nodes_from(range(count))
        compressed.add_edges_from((u, v) for u, v, _ in direct)
        compressed.add_edges_from(ordinary)
        if not nx.is_connected(compressed):
            discarded += 1
            continue
        # Remove selected non-bridge paths and use the freed incidences as
        # arbitrary pendant paths, preserving all branch degrees.
        removed = []
        for i in rng.sample(range(len(ordinary)), rng.randrange(min(5, len(ordinary)) + 1)):
            candidate = nx.Graph()
            candidate.add_nodes_from(range(count))
            candidate.add_edges_from((u, v) for u, v, _ in direct)
            candidate.add_edges_from(edge for j, edge in enumerate(ordinary) if j not in removed and j != i)
            if nx.is_connected(candidate):
                removed.append(i)
        pendants = [(v, rng.randrange(1, 12)) for i in removed for v in ordinary[i]]
        threads = direct + [(u, v, rng.randrange(3 if u == v else 2, 12))
                            for i, (u, v) in enumerate(ordinary) if i not in removed]
        order = list(range(count))
        rng.shuffle(order)
        check("random_matching_core", expand(count, threads, pendants, order))
        random_cases += 1
    long_cases = [
        ("long_selected_loops", 2, [(0, 1, 1), (0, 0, 5000), (1, 1, 5001)], []),
        ("long_path_with_short_path", 2, [(0, 1, 1), (0, 1, 5000), (0, 1, 2)], []),
        ("long_pendant_with_short", 2, [(0, 1, 1), (0, 1, 2)], [(0, 5000), (1, 5001)]),
    ]
    for name, count, threads, pendants in long_cases:
        check(name, expand(count, threads, pendants))
    pair_count = 1000
    threads = []
    for i in range(pair_count):
        u, v = 2 * i, 2 * i + 1
        threads.extend(((u, v, 1), (u, v, 3), (v, 2 * ((i + 1) % pair_count), 3)))
    large = check("thousand_rigid_private_pairs", expand(2 * pair_count, threads, []))
    assert len(large["orientation_certificate"]["private_rows"]) == pair_count
    assert actions == {"mixed_loop_pair", "short_port_flip", "pendant_port_flip"}
    assert form_modes == {"boundary_tree", "positive_cycle"}
    report = {"checks_passed": True, "selected_loop_interfaces": loop_interfaces,
        "eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs": atlas_excluded,
        "named_fixtures": len(fixtures), "random_cases": random_cases,
        "disconnected_random_draws_skipped": discarded, "long_cases": len(long_cases),
        "large_private_pair_cases": 1, "actual_copy_checked_colorings": cases,
        "colorings_with_short_threads": with_short, "colorings_with_loops": with_loops,
        "private_pair_rows_repaired": private_rows, "actions_observed": sorted(actions),
        "four_form_modes_observed": sorted(form_modes), "maximum_path_length": maximum_length,
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Finite implementation audit; the infinite family needs its separate proof."}
    Path(__file__).with_name("subcubic_perfect_direct_matching_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_perfect_direct_matching_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
