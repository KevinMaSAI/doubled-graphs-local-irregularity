"""Full-copy checks of protected short exits repairing dense SAFE links."""
import json
import random
import time
from pathlib import Path
import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_core_forest_three import change_some_short_to_three
from check_subcubic_core_sparse_three import density_sparse, original_scope
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import join_cores
from subcubic_bip_core_no_three import color_subcubic_core_sparse_three, color_subcubic_core_repaired_sparse_three


def regular_claw_ring(graph):
    assert all(graph.degree(v) == 4 for v in graph)
    order = list(graph)
    label = {v: i for i, v in enumerate(order)}
    threads = [(4 * i, 4 * i + j, 1) for i in range(len(order)) for j in (1, 2, 3)]
    ports = {v: [4 * label[v] + j for j in (1, 2, 3, 1, 2, 3)] for v in graph}
    for u, v in graph.edges():
        threads.append((ports[u].pop(0), ports[v].pop(0), 3))
    for u, v in zip(order, order[1:] + order[:1]):
        threads.append((ports[u][0], ports[v][1], 2))
    return expand(4 * len(order), threads, [])


def main():
    start = time.monotonic()
    rng = random.Random(20261115)
    count, repaired, count_repairs, old_outside = 0, 0, 0, 0
    witnesses, reasons = {}, {}
    def check(name, graph, require_repair=False):
        nonlocal count, repaired, count_repairs, old_outside
        result = color_subcubic_core_repaired_sparse_three(graph)
        verify(graph, result)
        count += 1
        repairs = result.get("density_repairs", [])
        repaired += bool(repairs)
        count_repairs += len(repairs)
        if require_repair:
            assert repairs
            assert color_subcubic_core_sparse_three(graph)["status"] == "method_not_applicable"
            old_outside += 1
        safe = {v for r in result.get("core_reports", []) if r["kind"].startswith("safe_")
                for v in r["vertices"]}
        h = graph.subgraph({v for v in graph if graph.degree(v) == 3})
        components = list(nx.connected_components(h.subgraph(safe)))
        member = {v: i for i, vertices in enumerate(components) for v in vertices}
        edges = []
        for item in result.get("threads", []):
            path = item["path"]
            if len(path) == 4 and path[0] != path[-1] and path[0] in safe and path[-1] in safe:
                edges.append((member[path[0]], member[path[-1]]))
        assert density_sparse(range(len(components)), edges)[0]
        for repair in repairs:
            vertices = set(repair["vertices"])
            assert nx.is_bipartite(h.subgraph(vertices))
            assert len(repair["protected_short_exits"]) == 2
            assert len(set(repair["protected_short_exits"])) == 2
            for key in repair["protected_short_exits"]:
                path = result["threads"][key]["path"]
                assert len(path) == 3
                u, v = path[0], path[-1]
                assert (u in vertices and v in safe) or (v in vertices and u in safe)
            assert any(len(t["path"]) == 4 and t["path"][0] != t["path"][-1]
                       and (t["path"][0] in vertices or t["path"][-1] in vertices)
                       for t in result["threads"])
        if name.startswith("named_"):
            witnesses[name] = {"repairs": repairs,
                "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                "red": result["red"], "blue": result["blue"]}
        return result
    for n in range(5, 42):
        graph = nx.random_regular_graph(4, n, seed=rng.randrange(1 << 30))
        if nx.is_connected(graph):
            result = check("named_connected_four_regular_" + str(n), regular_claw_ring(graph), True)
            assert len(result["density_repairs"]) == 1
    # Multiple dense components with an external SAFE short cycle.
    for k in range(2, 7):
        four = nx.disjoint_union_all([nx.complete_graph(5) for _ in range(k)])
        check("named_many_dense_components_" + str(k), regular_claw_ring(four), True)
    pool = [g for g in nx.graph_atlas_g() if len(g) and nx.is_connected(g)
            and max(dict(g.degree()).values()) <= 3]
    for _ in range(1000):
        graph = join_cores([rng.choice(pool) for j in range(rng.randrange(2, 10))], rng)
        if graph is None:
            continue
        change_some_short_to_three(graph, rng)
        expected, scope = original_scope(graph)
        result = color_subcubic_core_repaired_sparse_three(graph)
        if expected:
            assert result["status"] == "colored"
        if result["status"] == "colored":
            check("random", graph)
        else:
            reasons[result["reason"]] = reasons.get(result["reason"], 0) + 1
    result = {"actual_graph_colorings_verified": count, "graphs_using_density_repair": repaired,
              "protected_promotions_verified": count_repairs,
              "named_cases_outside_unrepaired_density_interface": old_outside,
              "remaining_SAFE_density_independently_verified": True,
              "all_two_exit_certificates_verified": True, "outside_repair_reasons": reasons,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "general_subcubic_conjecture_proved": False,
              "seconds": round(time.monotonic() - start, 3)}
    base = Path(__file__).parent
    (base / "subcubic_core_density_repair_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (base / "subcubic_core_density_repair_witnesses.json").write_text(json.dumps(witnesses, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
