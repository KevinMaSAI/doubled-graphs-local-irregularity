"""Exact feasibility and minimum-conflict optimization for GIVEN red targets.

Targets are TOTAL red degrees. Optional offsets are fixed exterior contributions.
This does not choose targets and does not prove the mother conjecture.
Requires networkx. Each weight is the number of red copies of an original edge.
"""
from numbers import Integral

import networkx as nx


def degree_exchange_toward(graph, current_weights, target_weights, start_vertex):
    """Move two units of degree discrepancy toward another realization.

    The exchange is a signed alternating walk of distinct COPY edges, possibly
    repeating original edges or vertices. It need not preserve local irregularity.
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    edges = list(graph.edges())
    x, y = list(current_weights), list(target_weights)
    if len(x) != len(edges) or len(y) != len(edges):
        raise ValueError('Weights must follow list(graph.edges()).')
    if any(not isinstance(a, Integral) or a not in (0,1,2) for a in x+y):
        raise ValueError('Weights must be integers from 0,1,2.')
    if start_vertex not in graph:
        raise ValueError('The start vertex must belong to the graph.')
    copies = []
    plus = {v:[] for v in graph}
    minus = {v:[] for v in graph}
    q, r = dict.fromkeys(graph,0), dict.fromkeys(graph,0)
    for i, ((u,v), a,b) in enumerate(zip(edges,x,y)):
        q[u] += a
        q[v] += a
        r[u] += b
        r[v] += b
        sign = 1 if b>a else -1
        for _ in range(abs(b-a)):
            k = len(copies)
            copies.append((i,sign,u,v))
            sides = plus if sign>0 else minus
            sides[u].append((k,0))
            sides[v].append((k,1))
    if q[start_vertex] == r[start_vertex]:
        raise ValueError('The start vertex must have a nonzero target discrepancy.')
    paired = {}
    unpaired = {}
    for v in graph:
        length = min(len(plus[v]),len(minus[v]))
        for left,right in zip(plus[v][:length],minus[v][:length]):
            paired[left], paired[right] = right,left
        unpaired[v] = plus[v][length:]+minus[v][length:]
    half = unpaired[start_vertex][0]
    path = []
    used = set()
    while True:
        k,side = half
        assert k not in used
        used.add(k)
        path.append(k)
        other = (k,1-side)
        if other not in paired:
            end_vertex = copies[k][2+(1-side)]
            break
        half = paired[other]
    delta = [0]*len(edges)
    for k in path:
        i,sign,_,_ = copies[k]
        delta[i] += sign
    new_x = [a+d for a,d in zip(x,delta)]
    new_y = [b-d for b,d in zip(y,delta)]
    assert all(0<=a<=2 for a in new_x+new_y)
    new_q = q.copy()
    for (u,v),d in zip(edges,delta):
        new_q[u] += d
        new_q[v] += d
    assert sum(abs(r[v]-new_q[v]) for v in graph) == \
        sum(abs(r[v]-q[v]) for v in graph)-2
    assert sum(abs(new_q[v]-q[v]) for v in graph) == 2
    assert (new_q[start_vertex]-q[start_vertex])*(r[start_vertex]-q[start_vertex]) > 0
    return {'edges':edges, 'weights':new_x, 'opposite_weights':new_y,
            'red_degrees':new_q, 'old_red_degrees':q,
            'target_red_degrees':r, 'edge_changes':delta,
            'endpoints':(start_vertex,end_vertex),
            'copy_walk':[(copies[k][0],copies[k][1]) for k in path]}


def minimum_conflicts_at_red_degrees(graph, targets, red_offsets=None, blue_offsets=None):
    """Minimize bad COLORED COPY count among all realizations of fixed targets.

    Returns the exact optimum and a witness, or reports an unrealizable target.
    A positive optimum is not a counterexample to the mother conjecture: another
    target may have optimum zero. Targets include the fixed red offsets.
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if set(targets) != set(graph):
        raise ValueError('Exactly one target for every vertex is required.')
    a = dict.fromkeys(graph, 0) if red_offsets is None else dict(red_offsets)
    exterior_blue = dict.fromkeys(graph, 0) if blue_offsets is None else dict(blue_offsets)
    if set(a) != set(graph) or set(exterior_blue) != set(graph):
        raise ValueError('Offsets must include exactly the vertices of the graph.')
    if any(not isinstance(x, Integral) or x < 0
           for x in list(a.values())+list(exterior_blue.values())):
        raise ValueError('Exterior contributions must be nonnegative integers.')
    r = dict(targets)
    q = {}
    for v in graph:
        if not isinstance(r[v], Integral) or not a[v] <= r[v] <= a[v]+2*graph.degree(v):
            return {'status': 'infeasible', 'reason': 'target_out_of_range'}
        q[v] = r[v]-a[v]
    if sum(q.values()) % 2:
        return {'status': 'infeasible', 'reason': 'odd_target_sum'}
    b = {v: exterior_blue[v]+2*graph.degree(v)-q[v] for v in graph}
    edges = list(graph.edges())
    costs = [int(r[u] == r[v])-int(b[u] == b[v]) for u,v in edges]
    constant = 2*sum(b[u] == b[v] for u,v in edges)
    gadget = nx.Graph()
    ports = {v: [] for v in graph}
    for i, (u, v) in enumerate(edges):
        for copy in range(2):
            left, right = ('p', i, copy, 0), ('p', i, copy, 1)
            gadget.add_edge(left, right, weight=-costs[i])
            ports[u].append(left)
            ports[v].append(right)
    for v in graph:
        for j in range(len(ports[v])-q[v]):
            dummy = ('d', v, j)
            gadget.add_node(dummy)
            gadget.add_edges_from((dummy, port, {'weight': 0}) for port in ports[v])
    matching = nx.max_weight_matching(gadget, maxcardinality=True, weight='weight')
    if 2*len(matching) != len(gadget):
        return {'status': 'infeasible', 'reason': 'no_perfect_matching',
                'gadget_vertices': len(gadget), 'maximum_matching_size': len(matching)}
    pairs = {frozenset(pair) for pair in matching}
    weights = [sum(frozenset((('p', i, copy, 0), ('p', i, copy, 1))) in pairs
                   for copy in range(2)) for i in range(len(edges))]
    actual_r = a.copy()
    for (u, v), x in zip(edges, weights):
        actual_r[u] += x
        actual_r[v] += x
    assert actual_r == r
    psi = constant + sum(c*x for c,x in zip(costs, weights))
    assert psi >= 0
    assert psi == sum(x*int(r[u] == r[v])+(2-x)*int(b[u] == b[v])
                      for (u,v),x in zip(edges, weights))
    matching_weight = sum(gadget[u][v]['weight'] for u,v in matching)
    assert psi == constant-matching_weight
    return {'status': 'optimal', 'minimum_bad_copies': psi,
            'edges': edges, 'weights': weights, 'red_degrees': r,
            'blue_degrees': b, 'gadget_vertices': len(gadget)}


def coloring_with_red_degrees(graph, targets, red_offsets=None, blue_offsets=None):
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if set(targets) != set(graph):
        raise ValueError('Exactly one target for every vertex is required.')
    a = dict.fromkeys(graph, 0) if red_offsets is None else dict(red_offsets)
    exterior_blue = dict.fromkeys(graph, 0) if blue_offsets is None else dict(blue_offsets)
    if set(a) != set(graph) or set(exterior_blue) != set(graph):
        raise ValueError('Offsets must include exactly the vertices of the graph.')
    if any(not isinstance(x, Integral) or x < 0
           for x in list(a.values())+list(exterior_blue.values())):
        raise ValueError('Exterior contributions must be nonnegative integers.')
    edges = list(graph.edges())
    r = dict(targets)
    internal_r = {}
    for v in graph:
        if not isinstance(r[v], Integral) or not a[v] <= r[v] <= a[v]+2*graph.degree(v):
            return {'status': 'infeasible', 'reason': 'target_out_of_range'}
        internal_r[v] = r[v]-a[v]
    if sum(internal_r.values()) % 2:
        return {'status': 'infeasible', 'reason': 'odd_target_sum'}
    b = {v: exterior_blue[v]+2*graph.degree(v)-internal_r[v] for v in graph}
    forced_red = []
    forced_blue = []
    free = []
    for i, (u, v) in enumerate(edges):
        red_equal, blue_equal = r[u] == r[v], b[u] == b[v]
        if red_equal and blue_equal:
            return {'status': 'infeasible', 'reason': 'both_colors_equal', 'edge': (u, v)}
        if red_equal:
            forced_blue.append(i)
        elif blue_equal:
            forced_red.append(i)
        else:
            free.append(i)
    residual = internal_r.copy()
    for i in forced_red:
        u, v = edges[i]
        residual[u] -= 2
        residual[v] -= 2
    ports = {v: [] for v in graph}
    gadget = nx.Graph()
    for i in free:
        u, v = edges[i]
        for copy in range(2):
            left, right = ('p', i, copy, 0), ('p', i, copy, 1)
            gadget.add_edge(left, right)
            ports[u].append(left)
            ports[v].append(right)
    for v in graph:
        if not 0 <= residual[v] <= len(ports[v]):
            return {'status': 'infeasible', 'reason': 'residual_out_of_range', 'vertex': v}
        for j in range(len(ports[v])-residual[v]):
            dummy = ('d', v, j)
            gadget.add_node(dummy)
            gadget.add_edges_from((dummy, port) for port in ports[v])
    matching = nx.max_weight_matching(gadget, maxcardinality=True)
    if 2*len(matching) != len(gadget):
        return {'status': 'infeasible', 'reason': 'no_perfect_matching',
                'gadget_vertices': len(gadget), 'maximum_matching_size': len(matching)}
    pairs = {frozenset(pair) for pair in matching}
    weights = [0]*len(edges)
    for i in forced_red:
        weights[i] = 2
    for i in free:
        weights[i] = sum(frozenset((('p', i, copy, 0), ('p', i, copy, 1))) in pairs
                         for copy in range(2))
    actual_r = a.copy()
    for (u, v), x in zip(edges, weights):
        actual_r[u] += x
        actual_r[v] += x
    assert actual_r == r
    assert all((x == 0 or r[u] != r[v]) and (x == 2 or b[u] != b[v])
               for (u, v), x in zip(edges, weights))
    return {'status': 'feasible', 'edges': edges, 'weights': weights,
            'red_degrees': r, 'blue_degrees': b, 'gadget_vertices': len(gadget)}
