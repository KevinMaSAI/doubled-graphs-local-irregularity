"""Sharpness family for keeping the core coloring fixed, not mother counterexamples."""
from numbers import Integral

import networkx as nx


def fixed_core_extension_family(h):
    """h>=2; h-1 pendant 3-vertex trees cannot extend the all-mixed core.

    Returns an explicit legal coloring after changing one core edge. The
    graph and the two edge assignments are elementary, with no solver needed.
    """
    if not isinstance(h, Integral) or h < 2:
        raise ValueError('h must be an integer >=2.')
    h = int(h)
    core = nx.Graph()
    v, hub = 0, h + 1
    core.add_nodes_from(range(h + 2))
    next_vertex = h + 2
    neighbor_degrees = {}
    for i in range(1, h + 1):
        core.add_edge(v, i)
        d = 2 * h - 2 + i
        neighbor_degrees[i] = d
        for _ in range(d - 1):
            z = next_vertex
            next_vertex += 1
            core.add_edge(i, z)
            core.add_edge(z, hub)
    graph = core.copy()
    bridges, interiors = [], []
    for _ in range(h - 1):
        r, a, b = next_vertex, next_vertex + 1, next_vertex + 2
        next_vertex += 3
        graph.add_edges_from([(v, r), (r, a), (a, b)])
        bridges.append((v, r))
        interiors.extend([(r, a), (a, b)])
    edges = list(graph.edges())
    blue_only = {frozenset((v, 2))} | {frozenset(e) for e in interiors}
    repaired = [0 if frozenset(e) in blue_only else 1 for e in edges]
    D = graph.degree(v)
    forbidden = sorted({q for d in neighbor_degrees.values() for q in (d, 2 * D - d)})
    assert forbidden == list(range(h, 3 * h - 1))
    assert core.degree(v) == h
    assert all(core.degree(i) == d for i, d in neighbor_degrees.items())
    return {'graph': graph, 'core': core, 'vertex': v, 'hub': hub,
            'h': h, 'pendant_count': h - 1,
            'neighbor_degrees': neighbor_degrees, 'bridges': bridges,
            'base_edges': list(core.edges()), 'base_weights': [1] * core.number_of_edges(),
            'edges': edges, 'repaired_weights': repaired,
            'forbidden_final_red': forbidden}
