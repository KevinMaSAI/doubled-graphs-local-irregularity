"""Check root-label exclusions, whole-graph copies, and outside preservation."""

import json
import math
from pathlib import Path
import random
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from one_boundary_region import absorption_plan, color_one_boundary_region
from factor_cut_certificate import recover_factor_on_cut


def build_case(n, ports, star_sizes, star_weights):
    inner = nx.complete_multipartite_graph(n, n + 1, n + 2)
    coloring = nx.get_node_attributes(inner, "subset")
    inner.remove_edge(0, 2 * n + 1)
    whole, given = inner.copy(), {}
    next_vertex = len(inner)
    for x, leaves, y in zip(ports, star_sizes, star_weights):
        center = next_vertex
        next_vertex += 1
        whole.add_edge(0, center)
        given[frozenset((0, center))] = x
        for _ in range(leaves):
            whole.add_edge(center, next_vertex)
            given[frozenset((center, next_vertex))] = y
            next_vertex += 1
    return inner, coloring, whole, given


def main():
    started = time.monotonic()
    rng = random.Random(2026102762)
    label_cases = 0
    for _ in range(12000):
        count = rng.randrange(1, 9)
        weights = [rng.randrange(3) for _ in range(count)]
        mixed = weights.count(1)
        c = max(rng.randrange(2, 15), count + mixed + 1)
        p, q = 2 * c, 2 * c + 1
        outside = []
        for x in weights:
            R, B = x + rng.randrange(2000), 2 - x + rng.randrange(2000)
            B += (R + B) % 2
            outside.append((R, B, x))
        good = [j for j in range(c) if all(
            (x == 0 or R % p not in {2*j % p, (2*j+1) % p})
            and (x == 2 or B % q not in {2*j % q, (2*j-1) % q})
            for R, B, x in outside)]
        assert good
        label_cases += 1
    fixtures = [
        ([0], [0], [0]),
        ([1], [0], [0]),
        ([2], [0], [0]),
        ([0], [7], [1]),
        ([1], [11], [2]),
        ([2], [4], [0]),
        ([0, 2], [3, 9], [0, 1]),
        ([0, 1], [2, 2], [0, 0]),
    ]
    actual, mixed_cases, two_ports, unused_palette, maximum_degree = 0, 0, 0, 0, 0
    witness = None
    recipes = []
    for ports, sizes, weights in fixtures:
        C = max(3, len(ports) + ports.count(1) + 1)
        bound = 8 * C * (2*C+1) - 7
        first = math.ceil(bound / 2)
        found = None
        for n in range(first, first + 32):
            inner, coloring, whole, given = build_case(n, ports, sizes, weights)
            plan = absorption_plan(whole, inner, coloring, given)
            assert plan["status"] == "planned"
            for i in range(3):
                right = [v for v in inner if coloring[v] == i]
                left = [v for v in inner if coloring[v] != i]
                local = recover_factor_on_cut(
                    inner, plan["coloring"], left, right, plan["red_offsets"],
                    plan["blue_offsets"], palette_size=plan["palette_size"])
                if local["status"] != "colored":
                    continue
                result = color_one_boundary_region(
                    whole, inner, coloring, given, factor_edges=local["factor_edges"])
                verify(whole, result)
                before = dict(given)
                assert all(before[frozenset(edge)] == x for edge, x in
                           zip(result["edge_order"], result["weights"]) if frozenset(edge) in before)
                assert all(result["red"][v] == plan["outside_red"][v]
                           and result["blue"][v] == plan["outside_blue"][v]
                           for v in whole if v not in inner)
                found = result
                recipes.append({"part_sizes": [n, n+1, n+2], "ports": ports,
                                "outside_star_sizes": sizes, "outside_star_weights": weights,
                                "root_label": plan["root_color_label"],
                                "palette_size": C, "cut_part": i})
                actual += 1
                mixed_cases += int(1 in ports)
                two_ports += int(len(ports) == 2)
                unused_palette += int(C > 3)
                maximum_degree = max(maximum_degree, max(dict(whole.degree()).values()))
                if witness is None and C > 3:
                    witness = {"recipe": recipes[-1], "edges": [[u, v, x] for (u, v), x in
                                         zip(result["edge_order"], result["weights"])],
                               "red": result["red"], "blue": result["blue"]}
                break
            if found:
                break
        assert found is not None, ("No flow certificate recovered for fixture", ports, sizes)
    output = {"root_label_exclusion_cases": label_cases,
              "whole_graph_absorptions_verified": actual,
              "with_mixed_boundary_edge": mixed_cases,
              "with_two_boundary_edges": two_ports,
              "with_reserved_unused_palette_label": unused_palette,
              "outside_edges_and_degrees_preserved": True,
              "maximum_original_degree": maximum_degree,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "scope": "One inside boundary vertex, and the stated region minimum degree bound.",
              "recipes": recipes, "seconds": round(time.monotonic() - started, 3)}
    path = Path(__file__).parent
    (path / "one_boundary_region_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    if witness:
        (path / "one_boundary_region_witness.json").write_text(
            json.dumps(witness, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in output.items() if k != "recipes"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
