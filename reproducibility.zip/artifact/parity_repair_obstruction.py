"""An unbounded prescribed-parity repair radius on bare minimum-degree-four cores.

These graphs ARE locally irregular two-colorable. The obstruction concerns
repair around a specified feasible target and a specified maximum-cut parity.
"""

import networkx as nx


def repair_obstruction(cycle_count, k=1):
    if cycle_count < 2 or cycle_count % 2 or k < 1:
        raise ValueError("Use an even cycle count >=2 and integer k>=1.")
    length = 4 * k + 2
    graph = nx.Graph()
    graph.add_nodes_from((0, 1))
    cycles, parity = [], {0: 0, 1: 0}
    baseline, repaired, free = {}, {}, {}
    first_hub_count = 2 * (cycle_count // 4)
    for j in range(cycle_count):
        cycle = list(range(2 + j * length, 2 + (j + 1) * length))
        cycles.append(cycle)
        for i, v in enumerate(cycle):
            parity[v] = i % 2
            for hub in (0, 1):
                edge = tuple(sorted((hub, v)))
                graph.add_edge(*edge)
                baseline[edge] = repaired[edge] = free[edge] = 0
        word = [0, 1, 2, 0, 1, 2] + [0, 1, 1, 0] * (k - 1)
        for i, u in enumerate(cycle):
            edge = tuple(sorted((u, cycle[(i + 1) % length])))
            graph.add_edge(*edge)
            baseline[edge] = repaired[edge] = 2
            free[edge] = word[i]
        # One odd-parity boundary edge per cycle; the other odd vertices are
        # paired by two-edge paths through even vertices.
        hub = 0 if j < first_hub_count else 1
        repaired[tuple(sorted((hub, cycle[1])))] = 1
        for a in range(1, k + 1):
            before, middle, after = cycle[4 * a - 1], cycle[4 * a], cycle[4 * a + 1]
            repaired[tuple(sorted((before, middle)))] = 1
            repaired[tuple(sorted((middle, after)))] = 1
    target = {v: (0 if v in (0, 1) else 4) for v in graph}
    return {"graph": graph, "cycles": cycles, "parity": parity, "target": target,
            "baseline": baseline, "parity_repaired_coloring": repaired,
            "free_coloring": free, "maximum_cut_size": 2 * cycle_count * length,
            "minimum_prescribed_parity_radius": 2 * ((cycle_count + 3) // 4),
            "mother_conjecture_proved": False}
