"""LIR2 with unbounded root degrees constant on each direct core component.

Every non-direct root connection has length >=3, no original compressed
return paths or pendant paths occur, and each direct component is
3-colorable. An optional proper core coloring supplies the witness when
the automatic bipartite/2-degenerate methods do not find it.
"""

import networkx as nx

from even_signed_forms import avoid_zero_even_forms
from independent_branch_coloring import _path_word, color_independent_branches
from mod3_edge_weighting import proper_012_with_offsets


def color_degree_homogeneous_long_core(graph, core_coloring=None):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("A nonempty connected graph is required.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if len(graph) == 1:
        return color_independent_branches(graph)
    if min(degree.values()) < 2:
        return {"status": "method_not_applicable", "reason": "pendant_vertices",
                "mother_conjecture_proved": False}
    roots = [v for v in graph if degree[v] >= 3]
    if not roots:
        return color_independent_branches(graph)
    root_set = set(roots)
    core = graph.subgraph(roots).copy()
    if any(degree[u] != degree[v] for u, v in core.edges()):
        return {"status": "method_not_applicable", "reason": "unequal_root_degrees_on_direct_edge",
                "mother_conjecture_proved": False}
    if core_coloring is not None:
        if (set(core_coloring) != root_set or any(c not in (0, 1, 2) for c in core_coloring.values())
                or any(core_coloring[u] == core_coloring[v] for u, v in core.edges())):
            raise ValueError("The supplied core coloring must properly color ALL roots with 0/1/2.")
    edges = list(graph.edges())
    edge_id = {frozenset(edge): i for i, edge in enumerate(edges)}
    used, threads, ordinary = set(), [], []
    for root in roots:
        for neighbor in graph[root]:
            key = edge_id[frozenset((root, neighbor))]
            if key in used:
                continue
            used.add(key)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                key = edge_id[frozenset((current, other))]
                assert key not in used
                used.add(key)
                path.append(other)
                previous, current = current, other
            assert current in root_set
            if current == root or len(path) == 3:
                return {"status": "method_not_applicable",
                        "reason": "return_path" if current == root else "ordinary_two_edge_thread",
                        "path": path, "mother_conjecture_proved": False}
            threads.append({"path": path, "ports": None})
            if len(path) > 2:
                ordinary.append(len(threads) - 1)
    assert len(used) == len(edges)
    components = list(nx.connected_components(core))
    pairs = [tuple(vertices) for vertices in components if len(vertices) == 2]
    membership = {}
    for i, (u, v) in enumerate(pairs):
        assert degree[u] == degree[v] >= 3
        membership[u], membership[v] = (i, 1), (i, -1)
    rows = [{} for _ in pairs]
    for key in ordinary:
        path = threads[key]["path"]
        for root, delta in ((path[0], -1), (path[-1], 1)):
            if root in membership:
                row, epsilon = membership[root]
                rows[row][key] = rows[row].get(key, 0) + epsilon * delta
    private = {row: next((key for key, value in coefficients.items() if abs(value) == 2), None)
               for row, coefficients in enumerate(rows)}
    private = {row: key for row, key in private.items() if key is not None}
    occurrences = {}
    for row, coefficients in enumerate(rows):
        for key in coefficients:
            occurrences.setdefault(key, []).append(row)
    regular_ids = [row for row in range(len(rows)) if row not in private]
    signs_result = avoid_zero_even_forms([rows[row] for row in regular_ids])
    signs = {key: signs_result["signs"].get(key, 1) for key in ordinary}
    for row, key in private.items():
        assert occurrences[key] == [row]
        constant = sum(c * signs[other] for other, c in rows[row].items() if other != key)
        signs[key] = next(s for s in (1, -1) if constant + rows[row][key] * s != 0)
    offset = dict.fromkeys(roots, 0)
    for key in ordinary:
        item = threads[key]
        item["ports"] = [0, 2] if signs[key] == 1 else [2, 0]
        offset[item["path"][0]] += item["ports"][0]
        offset[item["path"][-1]] += item["ports"][1]
    assert all(offset[u] != offset[v] for u, v in pairs)
    direct_values, root_red, reports = {}, {}, []
    for vertices in components:
        component = core.subgraph(vertices)
        if len(component) == 1:
            root = next(iter(component))
            root_red[root] = offset[root]
            reports.append({"kind": "isolated_root", "vertices": [root], "original_degree": degree[root]})
        elif len(component) == 2:
            u, v = component
            direct_values[frozenset((u, v))] = 1
            root_red.update({u: offset[u] + 1, v: offset[v] + 1})
            reports.append({"kind": "isolated_edge", "vertices": [u, v], "original_degree": degree[u]})
        else:
            coloring = None if core_coloring is None else {v: core_coloring[v] for v in component}
            result = proper_012_with_offsets(component, {v: offset[v] for v in component}, coloring)
            if result["status"] != "weighted":
                return {"status": "method_not_applicable", "reason": "supply_proper_three_coloring",
                        "component": list(component), "mother_conjecture_proved": False}
            for edge, value in zip(result["edge_order"], result["weights"]):
                direct_values[frozenset(edge)] = value
            root_red.update(result["totals"])
            reports.append({"kind": result["method"], "vertices": list(component),
                            "original_degree": degree[next(iter(component))], "target_mod3": result["target"]})
    root_blue = {v: 2 * degree[v] - root_red[v] for v in roots}
    assert all(root_red[u] != root_red[v] and root_blue[u] != root_blue[v] for u, v in core.edges())
    weights = [None] * len(edges)
    for item in threads:
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            value = direct_values[frozenset((u, v))]
            item["ports"] = [value, value]
            word = [value]
        else:
            word = _path_word(len(path) - 1, *item["ports"],
                              root_red[u], root_blue[u], root_red[v], root_blue[v])
        assert word is not None and len(word) == len(path) - 1
        for a, b, value in zip(path, path[1:], word):
            key = edge_id[frozenset((a, b))]
            assert weights[key] is None
            weights[key] = value
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in roots)
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for (u, v), x in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights, "red": red, "blue": blue,
            "threads": threads, "core_reports": reports, "offsets": offset,
            "orientation_certificate": {"pairs": pairs, "rows": rows, "private_rows": list(private),
                "even_row_ids": regular_ids, "even_form_certificate": signs_result, "signs": signs},
            "mother_conjecture_proved": False}
