"""Independent standard-library check of the COMPLETE K4/K5 root bases."""

import itertools
import json
from pathlib import Path


def verify_certificate(data):
    exceptions = {(4, 1, 3, 4), (4, 3, 1, 2)}
    assert {tuple(row) for row in data["allowed_noninterior_cases"]} == exceptions
    expected = set()
    for n in (4, 5):
        r = n - 1
        expected.update((n, a, b, s) for a, b in itertools.product(range(2 * r + 3), repeat=2)
                        if (a + b) % 2 == 0 for s in range(2 * r + 1))
    records = data["records"]
    keys = [(row["n"], row["A"], row["B"], row["root_red"]) for row in records]
    assert len(keys) == len(set(keys)) == data["domain_count"] == len(expected) == 836
    assert set(keys) == expected
    colored_copies = 0
    for key, row in zip(keys, records):
        n, A, B, S = key
        r = n - 1
        edges = list(itertools.combinations(range(n), 2))
        values = row["weights"]
        assert len(values) == len(edges) and all(type(x) is int and 0 <= x <= 2 for x in values)
        red, blue = [0] * n, [0] * n
        red[0], blue[0] = A, B
        for (u, v), x in zip(edges, values):
            for copy in range(2):
                degree = red if copy < x else blue
                degree[u] += 1
                degree[v] += 1
                colored_copies += 1
        assert red[0] - A == S and blue[0] - B == 2 * r - S
        interior = all(0 < red[v] < 2 * r for v in range(1, n))
        assert row["nonroot_interior"] == interior
        assert key in exceptions or interior
        for (u, v), x in zip(edges, values):
            for copy in range(2):
                degree = red if copy < x else blue
                assert degree[u] != degree[v], (key, (u, v), copy)
    # The two permitted weak K4 bases only occur in a later zero-shift
    # extension: their enlarged root red and blue counts both equal 7.
    assert all(a + s + 2 == b + 10 - (s + 2) == 7
               for n, a, b, s in exceptions)
    assert not data["mother_conjecture_proved"]
    return {"complete_finite_root_bases": len(records),
            "colored_edge_copies_checked": colored_copies,
            "K4_weak_base_exceptions": len(exceptions),
            "exceptions_cannot_reach_odd_boundary_nine": True,
            "all_checks_passed": True, "mother_conjecture_proved": False,
            "scope": "Finite base of a separate strong induction for cliques of every order >=4."}


if __name__ == "__main__":
    path = Path(__file__).parent
    result = verify_certificate(json.loads((path / "rooted_clique_interfaces.json").read_text(encoding="utf-8")))
    (path / "rooted_clique_certificate_check.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
