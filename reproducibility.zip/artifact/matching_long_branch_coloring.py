"""LIR2 for a matching of direct branch edges and other branch paths >=4.

All branch degrees >=3 are allowed, including degree three. Compressed loops
need only length three, and pendant paths may have any positive length.
This is a restricted-family constructor, NOT the mother conjecture.
"""

import networkx as nx

from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches


def color_matching_long_branches(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("The input must be simple, loopless and undirected.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    branches = [v for v in graph if degree[v] >= 3]
    if not branches:
        return color_independent_branches(graph)
    branch_set = set(branches)
    if any(sum(w in branch_set for w in graph[v]) > 1 for v in branches):
        return {"status": "method_not_applicable", "reason": "direct_branch_edges_not_a_matching",
                "mother_conjecture_proved": False}
    edges = list(graph.edges())
    edge_id = {frozenset(e): i for i, e in enumerate(edges)}
    used, threads, pendants = set(), [], []
    for root in branches:
        for neighbor in graph[root]:
            index = edge_id[frozenset((root, neighbor))]
            if index in used:
                continue
            used.add(index)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                index = edge_id[frozenset((current, other))]
                assert index not in used
                used.add(index)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": 0})
            else:
                assert current in branch_set
                if current != root and 2 <= len(path) - 1 <= 3:
                    return {"status": "method_not_applicable", "reason": "nondirect_branch_path_shorter_than_four",
                            "mother_conjecture_proved": False}
                threads.append({"path": path, "ports": None})
    assert len(used) == len(edges)
    loops = {v: [] for v in branches}
    free = {v: [] for v in branches}
    paired = set()
    direct = []
    for i, item in enumerate(threads):
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            item["ports"] = [1, 1]
            direct.append(i)
            paired.update((u, v))
        elif u == v:
            item["ports"] = [0, 2]
            loops[u].append(i)
        else:
            item["ports"] = [0, 0]
            free[u].append(("thread", i, 0))
            free[v].append(("thread", i, 1))
    for i, item in enumerate(pendants):
        free[item["path"][0]].append(("pendant", i, 0))
    assert all(degree[v] == int(v in paired) + 2 * len(loops[v]) + len(free[v]) for v in branches)
    twos = dict.fromkeys(branches, 0)
    decisions = []
    for index in direct:
        u, v = threads[index]["path"]
        lu, lv = len(loops[u]), len(loops[v])
        zu, zv = len(free[u]), len(free[v])
        if not zu or not zv:
            root = u if not zu else v
            assert loops[root]
            threads[loops[root][0]]["ports"] = [0, 1]
            decisions.append({"kind": "locked_root_loop_adjustment", "edge": [u, v], "root": root})
        elif zu == zv == 1:
            if degree[u] == degree[v]:
                twos[v] = 1
                kind = "two_choices_equal_degree"
            else:
                kind = "two_choices_different_degrees"
            decisions.append({"kind": kind, "edge": [u, v]})
        else:
            root, partner = (u, v) if zu >= 2 else (v, u)
            partner_red = 1 + 2 * len(loops[partner])
            partner_blue = 2 * degree[partner] - partner_red
            for count in (0, 1, 2):
                red = 1 + 2 * len(loops[root]) + 2 * count
                blue = 2 * degree[root] - red
                if red != partner_red and blue != partner_blue:
                    twos[root] = count
                    break
            else:
                raise AssertionError("Three choices cannot be covered by two forbidden values.")
            decisions.append({"kind": "three_choices_avoid_two", "edge": [u, v],
                              "root": root, "twos": twos[root]})
    def set_free(record, value):
        kind, index, end = record
        if kind == "thread":
            threads[index]["ports"][end] = value
        else:
            pendants[index]["port"] = value
    for v in branches:
        for record in free[v][:twos[v]]:
            set_free(record, 2)
        if v not in paired and len(loops[v]) == len(free[v]) == 1:
            kind, index, end = free[v][0]
            if kind == "pendant" and len(pendants[index]["path"]) == 3:
                set_free((kind, index, end), 1)
                decisions.append({"kind": "unmatched_loop_two_edge_pendant", "root": v})
    root_red = dict.fromkeys(branches, 0)
    for item in threads:
        for root, value in zip((item["path"][0], item["path"][-1]), item["ports"]):
            root_red[root] += value
    for item in pendants:
        root_red[item["path"][0]] += item["port"]
    root_blue = {v: 2 * degree[v] - root_red[v] for v in branches}
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value
    for item in threads:
        path, pair = item["path"], item["ports"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            assert pair == [1, 1]
            assert root_red[u] != root_red[v] and root_blue[u] != root_blue[v]
            word = [1]
        else:
            word = _path_word(len(path) - 1, *pair, root_red[u], root_blue[u], root_red[v], root_blue[v])
        put(path, word)
    for item in pendants:
        path, first = item["path"], item["port"]
        root = path[0]
        word = _pendant_word(len(path) - 1, first, root_red[root], root_blue[root])
        put(path, word)
    assert all(value in (0, 1, 2) for value in weights)
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in branches)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights, "red": red, "blue": blue,
            "threads": threads, "pendants": pendants, "direct_edge_decisions": decisions,
            "mother_conjecture_proved": False}
