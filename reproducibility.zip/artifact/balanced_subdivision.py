"""Balanced half-edge ports and a conditional subdivision construction.

This is NOT a solver for arbitrary graphs or a proof of the mother conjecture.
The accompanying note proves the infinite family handled by this module.
NetworkX is the only dependency; no constraint solver is used.
"""

import networkx as nx


def _edges(graph):
    if graph.is_directed():
        raise ValueError("An undirected graph is required.")
    if graph.is_multigraph():
        return list(graph.edges(keys=True))
    return [(u, v, None) for u, v in graph.edges()]


def balanced_halfedge_ports(graph, separated_pairs=()):
    """Balance port totals, optionally separating disjoint vertex pairs.

    Each edge has TWO independent port weights in {0,1,2}, one at each
    incidence. Its two port weights are different, including on a loop.
    Isolates are permitted; every nonisolated vertex must have degree >= 2.
    Loops count twice in the degree. Returned ports follow edge_order.
    Optional disjoint pairs must have positive degrees of the same parity.
    For each such pair exactly ONE vertex has port sum degree+/-1, while
    its partner and every unpaired vertex remain balanced.
    These port weights need NOT be colors of a single un-subdivided edge.
    """
    edges = _edges(graph)
    degree = dict(graph.degree())
    if any(d == 1 for d in degree.values()):
        raise ValueError("Nonisolated vertices must have degree at least two.")
    pairs = list(separated_pairs)
    paired = set()
    skipped = set()
    even_pairs = []
    for index, (u, v) in enumerate(pairs):
        if u == v or u not in degree or v not in degree or u in paired or v in paired:
            raise ValueError("Pairs must consist of disjoint distinct vertices.")
        if degree[u] == 0 or degree[v] == 0 or degree[u] % 2 != degree[v] % 2:
            raise ValueError("Paired vertices need positive degrees of the same parity.")
        paired.update((u, v))
        if degree[u] % 2:
            skipped.add(u)
        else:
            even_pairs.append((index, u, v))
    odd = [v for v, d in degree.items() if d % 2]
    augmented = nx.MultiGraph()
    augmented.add_nodes_from(graph)
    for i, (u, v, _) in enumerate(edges):
        augmented.add_edge(u, v, key=("original", i))
    dummy = object()
    if odd:
        for i, v in enumerate(odd):
            augmented.add_edge(v, dummy, key=("auxiliary", i))

    ports = [None] * len(edges)
    for component in nx.connected_components(augmented):
        subgraph = augmented.subgraph(component)
        if subgraph.number_of_edges() == 0:
            continue
        for tail, head, key in nx.eulerian_circuit(subgraph, keys=True):
            if key[0] != "original":
                continue
            i = key[1]
            u, v, _ = edges[i]
            ports[i] = [0, 2] if (tail, head) == (u, v) else [2, 0]

    initial = dict.fromkeys(graph, 0)
    incidences = {v: [] for v in graph}
    for i, (u, v, _) in enumerate(edges):
        for end, vertex in enumerate((u, v)):
            initial[vertex] += ports[i][end]
            incidences[vertex].append((i, end))
    assert all(abs(initial[v] - degree[v]) <= 1 for v in graph)

    # An odd vertex changes one majority port to 1.  Every such vertex has
    # at least two eligible edge IDs, and an edge ID has at most two owners.
    # Hall's theorem therefore gives distinct choices.
    matching_graph = nx.Graph()
    left_nodes = [("vertex", v) for v in odd if v not in skipped]
    left_nodes.extend(("pair", index) for index, _, _ in even_pairs)
    matching_graph.add_nodes_from(left_nodes, bipartite=0)
    majority = {v: (0 if initial[v] < degree[v] else 2) for v in odd}
    eligible = {}
    for v in odd:
        if v in skipped:
            continue
        eligible[v] = [(i, end) for i, end in incidences[v]
                       if ports[i][end] == majority[v]]
        assert len({i for i, _ in eligible[v]}) >= 2
        for i, _ in eligible[v]:
            matching_graph.add_edge(("vertex", v), ("edge", i))
    pair_eligible = {}
    for index, u, v in even_pairs:
        pair_eligible[index] = sorted({i for vertex in (u, v) for i, _ in incidences[vertex]})
        assert len(pair_eligible[index]) >= 2
        for i in pair_eligible[index]:
            matching_graph.add_edge(("pair", index), ("edge", i))
    matching = nx.algorithms.bipartite.maximum_matching(
        matching_graph, top_nodes=left_nodes
    )
    choices = {}
    for v in odd:
        if v in skipped:
            continue
        if ("vertex", v) not in matching:
            raise AssertionError("Hall matching was not found.")
        i = matching[("vertex", v)][1]
        end = next(end for candidate, end in eligible[v] if candidate == i)
        ports[i][end] = 1
        choices[v] = (i, end)
    for index, u, v in even_pairs:
        if ("pair", index) not in matching:
            raise AssertionError("Paired Hall matching was not found.")
        i = matching[("pair", index)][1]
        end = next(end for end, vertex in enumerate(edges[i][:2]) if vertex in (u, v))
        vertex = edges[i][end]
        assert ports[i][end] in (0, 2)
        ports[i][end] = 1
        choices[vertex] = (i, end)

    totals = dict.fromkeys(graph, 0)
    for i, (u, v, _) in enumerate(edges):
        assert ports[i][0] != ports[i][1]
        totals[u] += ports[i][0]
        totals[v] += ports[i][1]
    assert all(totals[v] == degree[v] for v in graph if v not in paired)
    for u, v in pairs:
        assert sorted((abs(totals[u] - degree[u]), abs(totals[v] - degree[v]))) == [0, 1]
    return {"edge_order": edges, "ports": [tuple(p) for p in ports],
            "degree": degree, "port_totals": totals, "changed_ports": choices}


def fill_balanced_path(length, first_red, last_red, left_degree, right_degree):
    """Fill a path with different end ports and endpoint R=B=degree>=4.

    End degrees are FINAL degrees in the expanded simple graph. The endpoints
    may coincide, provided their shared totals include both incidences.
    """
    return fill_buffered_path(length, first_red, last_red, left_degree,
                              left_degree, right_degree, right_degree)


def fill_buffered_path(length, first_red, last_red, left_red, left_blue, right_red, right_blue):
    """Fill different end ports when all four FINAL color degrees are >=4."""
    if length < 2 or min(left_red, left_blue, right_red, right_blue) < 4:
        raise ValueError("Length >=2 and endpoint color degrees >=4 are required.")
    if first_red not in (0, 1, 2) or last_red not in (0, 1, 2):
        raise ValueError("Port weights must lie in {0,1,2}.")
    if first_red == last_red:
        raise ValueError("This lemma requires different end port weights.")
    allowed = [set(range(3)) for _ in range(length)]
    allowed[0] = {first_red}
    allowed[-1] = {last_red}
    if first_red > 0:
        allowed[1].discard(left_red - first_red)
    if first_red < 2:
        allowed[1].discard(4 - first_red - left_blue)
    if last_red > 0:
        allowed[-2].discard(right_red - last_red)
    if last_red < 2:
        allowed[-2].discard(4 - last_red - right_blue)

    word = [None] * length
    for parity in (0, 1):
        positions = list(range(parity, length, 2))
        histories = []
        previous = {None}
        for position in positions:
            current = {}
            for value in sorted(allowed[position]):
                candidates = [old for old in previous if old != value]
                if candidates:
                    current[value] = candidates[0]
            if not current:
                raise AssertionError("The proven path interface failed.")
            histories.append(current)
            previous = set(current)
        value = min(previous)
        for position, history in zip(reversed(positions), reversed(histories)):
            word[position] = value
            value = history[value]
    return word


def color_partial_subdivision(base, lengths):
    """Construct a coloring for the precisely stated conditional family.

    base is a connected undirected (multi)graph of minimum degree >=4.
    lengths follows list(base.edges(keys=True)), or list(base.edges()).
    Edges of length 1 must join vertices of DIFFERENT base degrees and must
    form a simple loopless graph. Edges of length >=2 form J; J has no
    degree-one vertices (isolates are allowed). Loops have length >=3.
    All new path interiors are disjoint. Returns (G, weights, certificate).
    """
    records = _edges(base)
    nodes = list(base)
    if not nodes or not nx.is_connected(base):
        raise ValueError("The base must be nonempty and connected.")
    degrees = dict(base.degree())
    if min(degrees.values()) < 4:
        raise ValueError("The base minimum degree must be at least four.")
    lengths = list(lengths)
    if len(lengths) != len(records) or any(
        not isinstance(t, int) or isinstance(t, bool) or t < 1 for t in lengths
    ):
        raise ValueError("Supply one positive integer length per base edge.")
    labels = {v: i for i, v in enumerate(nodes)}
    root_degree = {labels[v]: degrees[v] for v in nodes}
    selected = nx.MultiGraph()
    selected.add_nodes_from(range(len(nodes)))
    for i, ((u, v, _), length) in enumerate(zip(records, lengths)):
        if u == v and length < 3:
            raise ValueError("A loop needs length >=3 for a simple expansion.")
        if length == 1:
            if degrees[u] == degrees[v]:
                raise ValueError("Retained edges must join different degrees.")
        else:
            selected.add_edge(labels[u], labels[v], key=i)
    halfedge = balanced_halfedge_ports(selected)
    selected_ports = {}
    for (u, v, edge_id), pair in zip(halfedge["edge_order"], halfedge["ports"]):
        original_u, original_v, _ = records[edge_id]
        original_ends = (labels[original_u], labels[original_v])
        selected_ports[edge_id] = pair if (u, v) == original_ends else pair[::-1]

    expanded = nx.Graph()
    expanded.add_nodes_from(range(len(nodes)))
    weights = {}
    threads = []
    next_vertex = len(nodes)
    for i, ((original_u, original_v, _), length) in enumerate(zip(records, lengths)):
        u, v = labels[original_u], labels[original_v]
        if length == 1:
            path, word, pair = [u, v], [1], (1, 1)
        else:
            pair = selected_ports[i]
            internal = list(range(next_vertex, next_vertex + length - 1))
            next_vertex += length - 1
            path = [u] + internal + [v]
            word = fill_balanced_path(length, *pair, root_degree[u], root_degree[v])
        for a, b, red_count in zip(path, path[1:], word):
            if a == b or expanded.has_edge(a, b):
                raise ValueError("The prescribed expansion is not simple.")
            expanded.add_edge(a, b)
            weights[tuple(sorted((a, b)))] = red_count
        threads.append({"edge_id": i, "ends": [u, v], "length": length,
                        "ports": list(pair)})
    certificate = {"root_labels": nodes, "root_degrees": root_degree,
                   "threads": threads, "mother_conjecture_proved": False}
    return expanded, weights, certificate


def extend_by_subdivision_paths(base, base_weights, connector, lengths):
    """Preserve supplied base colors while adding the conditional path system.

    base is simple loopless. connector is an undirected (multi)graph on the
    SAME vertices; it has no degrees 1,2,3, and its degree is constant along
    each base edge. Every connector edge becomes a path of length >=2, or
    >=3 on a loop. The resulting graph must be connected.

    base_weights follows base.edges(). Supply None exactly for isolated K2
    components; other supplied weights must already be legal in the base.
    Those non-None weights are all preserved. K2 edges are filled with 1.
    """
    if base.is_directed() or base.is_multigraph() or nx.number_of_selfloops(base):
        raise ValueError("The base must be simple, loopless and undirected.")
    connector_records = _edges(connector)
    if set(base) != set(connector):
        raise ValueError("Base and connector must have the same vertex set.")
    nodes = list(base)
    labels = {v: i for i, v in enumerate(nodes)}
    connector_degree = dict(connector.degree())
    if any(0 < d < 4 for d in connector_degree.values()):
        raise ValueError("Positive connector degrees must be at least four.")
    old_edges = list(base.edges())
    old_weights = list(base_weights)
    if len(old_edges) != len(old_weights):
        raise ValueError("Supply one base weight per base edge.")
    if any(connector_degree[u] != connector_degree[v] for u, v in old_edges):
        raise ValueError("Connector degrees must be constant along base edges.")
    pairs = []
    pair_edges = set()
    for component in nx.connected_components(base):
        if len(component) == 2:
            u, v = tuple(component)
            if base.has_edge(u, v):
                if connector_degree[u] < 4:
                    raise ValueError("K2 components need connector degree at least four.")
                pairs.append((u, v))
                pair_edges.add(frozenset((u, v)))
    old_red = dict.fromkeys(base, 0)
    for (u, v), value in zip(old_edges, old_weights):
        if frozenset((u, v)) in pair_edges:
            if value is not None:
                raise ValueError("The sole edge of each K2 component needs None.")
            continue
        if value not in (0, 1, 2):
            raise ValueError("Other base weights must be 0,1,2.")
        old_red[u] += value
        old_red[v] += value
    old_blue = {v: 2 * base.degree(v) - old_red[v] for v in base}
    for (u, v), value in zip(old_edges, old_weights):
        if value is None:
            continue
        if (value > 0 and old_red[u] == old_red[v]) or (value < 2 and old_blue[u] == old_blue[v]):
            raise ValueError("Supplied base coloring is not locally irregular.")
    for u, v in pairs:
        old_red[u] = old_red[v] = old_blue[u] = old_blue[v] = 1
    halfedge = balanced_halfedge_ports(connector, pairs)
    final_red = {v: old_red[v] + halfedge["port_totals"][v] for v in base}
    final_blue = {v: old_blue[v] + 2 * connector_degree[v] - halfedge["port_totals"][v]
                  for v in base}
    lengths = list(lengths)
    if len(lengths) != len(connector_records) or any(
        not isinstance(t, int) or isinstance(t, bool) or t < 2
        for t in lengths
    ):
        raise ValueError("Supply one integer length >=2 per connector edge.")

    expanded = nx.Graph()
    expanded.add_nodes_from(range(len(nodes)))
    weights = {}
    for (u, v), value in zip(old_edges, old_weights):
        a, b = labels[u], labels[v]
        expanded.add_edge(a, b)
        weights[tuple(sorted((a, b)))] = 1 if value is None else value
    next_vertex = len(nodes)
    for (u, v, _), pair, length in zip(halfedge["edge_order"], halfedge["ports"], lengths):
        if u == v and length < 3:
            raise ValueError("A loop needs length at least three.")
        word = fill_buffered_path(length, *pair, final_red[u], final_blue[u], final_red[v], final_blue[v])
        internal = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [labels[u]] + internal + [labels[v]]
        for a, b, value in zip(path, path[1:], word):
            assert a != b and not expanded.has_edge(a, b)
            expanded.add_edge(a, b)
            weights[tuple(sorted((a, b)))] = value
    if not nx.is_connected(expanded):
        raise ValueError("The expanded graph must be connected.")
    certificate = {"root_labels": nodes,
                   "root_red": {labels[v]: final_red[v] for v in base},
                   "root_blue": {labels[v]: final_blue[v] for v in base},
                   "filled_K2_components": len(pairs),
                   "mother_conjecture_proved": False}
    return expanded, weights, certificate
