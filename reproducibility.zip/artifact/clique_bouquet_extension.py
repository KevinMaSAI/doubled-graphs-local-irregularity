"""Explicit capacity conditions for clique bouquets on arbitrary graph cores.

The interface supplies every root contribution, but does not solve an unknown
core with no bouquets. Every newly attached clique has order at least four.
"""

import networkx as nx

from rooted_clique_interface import color_rooted_clique


def _validate_graph(graph):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")


def _orders(graph, order_lists):
    if any(v not in graph for v in order_lists):
        raise ValueError("Every attachment vertex must be in the core.")
    result = {v: list(order_lists.get(v, [])) for v in graph}
    if any(type(n) is not int or n < 4 for row in result.values() for n in row):
        raise ValueError("All new cliques must have integer order >=4.")
    return result


def _assemble(core, old_values, order_lists, targets):
    graph = core.copy()
    values = dict(old_values)
    red = dict.fromkeys(core, 0)
    for u, v in core.edges():
        x = values[frozenset((u, v))]
        red[u] += x
        red[v] += x
    next_label, reports = 0, []
    core_blue = {}
    for v in core:
        L = sum(n - 1 for n in order_lists[v])
        total_red = targets[v]
        total_blue = 2 * (core.degree(v) + L) - total_red
        amount = total_red - red[v]
        assert 0 <= amount <= 2 * L
        core_blue[v] = total_blue
        remaining = amount
        for n in order_lists[v]:
            r = n - 1
            s = min(remaining, 2 * r)
            remaining -= s
            local = color_rooted_clique(n, total_red - s,
                                       total_blue - (2 * r - s), s)
            vertices = [v]
            for _ in range(r):
                while next_label in graph:
                    next_label += 1
                vertices.append(next_label)
                graph.add_node(next_label)
                next_label += 1
            for (i, j), x in zip(local["edge_order"], local["weights"]):
                u, w = vertices[i], vertices[j]
                graph.add_edge(u, w)
                values[frozenset((u, w))] = x
        assert remaining == 0
        reports.append({"vertex": v, "new_degree": L, "new_red_contribution": amount})
    edges = list(graph.edges())
    weights = [values[frozenset(edge)] for edge in edges]
    actual_red = dict.fromkeys(graph, 0)
    for (u, v), x in zip(edges, weights):
        actual_red[u] += x
        actual_red[v] += x
    actual_blue = {v: 2 * graph.degree(v) - actual_red[v] for v in graph}
    assert all(actual_red[v] == targets[v] and actual_blue[v] == core_blue[v] for v in core)
    assert all((x == 0 or actual_red[u] != actual_red[v])
               and (x == 2 or actual_blue[u] != actual_blue[v])
               for (u, v), x in zip(edges, weights))
    return graph, {"status": "colored", "edge_order": edges, "weights": weights,
                   "red": actual_red, "blue": actual_blue, "attachments": reports,
                   "mother_conjecture_proved": False}


def extend_by_clique_bouquet(graph, given, root, clique_orders):
    """Preserve every old edge color when sum(order-1)>=old root degree."""
    _validate_graph(graph)
    if root not in graph:
        raise ValueError("The attachment root must be an old vertex.")
    orders = _orders(graph, {root: clique_orders})
    L, h = sum(n - 1 for n in orders[root]), graph.degree(root)
    if L < h:
        return None, {"status": "method_not_applicable",
                      "reason": "added_clique_capacity_smaller_than_old_degree",
                      "old_degree": h, "added_capacity": L}
    if (given["status"] != "colored" or len(given["edge_order"]) != graph.number_of_edges()
            or len(given["weights"]) != graph.number_of_edges()
            or {frozenset(e) for e in given["edge_order"]} != {frozenset(e) for e in graph.edges()}):
        raise ValueError("A complete legal coloring of the old graph is required.")
    values = dict(zip(map(frozenset, given["edge_order"]), given["weights"]))
    red = dict.fromkeys(graph, 0)
    for u, v in graph.edges():
        x = values[frozenset((u, v))]
        if type(x) is not int or not 0 <= x <= 2:
            raise ValueError("Old weights must be 0/1/2.")
        red[u] += x
        red[v] += x
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    if any((x > 0 and red[u] == red[v]) or (x < 2 and blue[u] == blue[v])
           for u, v in graph.edges() for x in [values[frozenset((u, v))]]):
        raise ValueError("The old coloring is not legal.")
    forbidden = set()
    for v in graph[root]:
        x = values[frozenset((root, v))]
        if x > 0:
            forbidden.add(red[v] - red[root])
        if x < 2:
            forbidden.add(blue[root] + 2 * L - blue[v])
    amount = next(s for s in range(2 * h + 1) if s not in forbidden)
    targets = dict(red)
    targets[root] += amount
    colored_graph, result = _assemble(graph, values, orders, targets)
    assert all(values[frozenset(e)] == x for e, x in zip(result["edge_order"], result["weights"])
               if graph.has_edge(*e))
    result["old_colors_preserved"] = True
    result["forbidden_root_contributions"] = sorted(forbidden)
    return colored_graph, result


def color_core_with_clique_bouquets(core, order_lists):
    """Color an UNKNOWN arbitrary core if every vertex has capacity >=core degree."""
    _validate_graph(core)
    orders = _orders(core, order_lists)
    L = {v: sum(n - 1 for n in orders[v]) for v in core}
    if any(L[v] < core.degree(v) for v in core):
        return None, {"status": "method_not_applicable",
                      "reason": "some_core_vertex_has_insufficient_clique_capacity"}
    D = {v: core.degree(v) + L[v] for v in core}
    targets, blue = {}, {}
    for v in core:
        h = core.degree(v)
        forbidden = {targets[w] for w in core[v] if w in targets}
        forbidden.update(2 * D[v] - blue[w] for w in core[v] if w in blue)
        targets[v] = next(q for q in range(h, h + 2 * h + 1) if q not in forbidden)
        blue[v] = 2 * D[v] - targets[v]
    values = {frozenset(edge): 1 for edge in core.edges()}
    graph, result = _assemble(core, values, orders, targets)
    result["core_edges_all_mixed"] = True
    return graph, result
