"""Optional factor recovery by a balanced internal subgraph and cut flow.

Failure of these selected margins means only that this recovery attempt failed.
The general degree-factor theorem does not require its factor to lie in this cut.
"""

import networkx as nx

from chromatic_degree_factor import make_plan, color_from_factor


def _balanced_internal_edges(graph, left_set):
    internal = nx.Graph()
    internal.add_nodes_from(graph)
    internal.add_edges_from((u, v) for u, v in graph.edges()
                            if (u in left_set) == (v in left_set))
    chosen = []
    for vertices in nx.connected_components(internal):
        component = internal.subgraph(vertices).copy()
        if not component.number_of_edges():
            continue
        odd = [v for v, degree in component.degree() if degree % 2]
        dummy = object()
        if odd:
            component.add_edges_from((dummy, v) for v in odd)
            start = dummy
        else:
            start = next(iter(component))
        for index, (u, v) in enumerate(nx.eulerian_circuit(component, source=start)):
            if index % 2 == 0 and u is not dummy and v is not dummy:
                chosen.append((u, v))
    selected_degree = dict.fromkeys(graph, 0)
    for u, v in chosen:
        selected_degree[u] += 1
        selected_degree[v] += 1
    assert all(internal.degree(v) // 2 <= selected_degree[v] <= internal.degree(v) // 2 + 1
               for v in graph)
    return chosen, selected_degree


def recover_factor_on_cut(graph, coloring, left, right, red_offsets=None,
                          blue_offsets=None, palette_size=None, balance_internal=True):
    left, right = list(left), list(right)
    if (set(left) & set(right) or set(left) | set(right) != set(graph)
            or len(left) != len(set(left)) or len(right) != len(set(right))):
        raise ValueError("The supplied cut must partition the input vertices.")
    plan = make_plan(graph, coloring, red_offsets, blue_offsets, palette_size)
    if plan["status"] != "planned":
        return plan
    left_set = set(left)
    M = plan["modulus"]
    if balance_internal:
        fixed, fixed_degree = _balanced_internal_edges(graph, left_set)
    else:
        fixed, fixed_degree = [], dict.fromkeys(graph, 0)
    cross_degree = {v: sum(graph.has_edge(v, w) for w in
                          (right if v in left_set else left)) for v in graph}
    choices = {}
    def incomplete(reason):
        return {"status": "factor_search_incomplete", "reason": reason}
    for v in graph:
        pairs = [plan["options"][v]["lower"] - fixed_degree[v],
                 plan["options"][v]["upper"] - fixed_degree[v]]
        pairs = [a for a in pairs if 0 <= a and a + 1 <= cross_degree[v]]
        if not pairs:
            return incomplete("no_complete_allowed_pair_in_cut")
        choices[v] = min(pairs), max(pairs)
    lower = [sum(choices[v][0] for v in part) for part in (left, right)]
    upper = [sum(choices[v][1] + 1 for v in part) for part in (left, right)]
    lo, hi = max(lower), min(upper)
    if lo > hi:
        return incomplete("aggregate_intervals_disjoint")
    total = (lo + hi) // 2
    targets = {}
    for part, base in zip((left, right), lower):
        flex = [v for v in part if choices[v][0] != choices[v][1]]
        remaining = total - base
        high_count = min(len(flex), remaining // M)
        epsilon = remaining - M * high_count
        if epsilon > len(part):
            return incomplete("aggregate_gap")
        selected_high = set(flex[:high_count])
        for i, v in enumerate(part):
            targets[v] = choices[v][int(v in selected_high)] + int(i < epsilon)
            assert targets[v] + fixed_degree[v] in plan["options"][v]["allowed"]
        assert sum(targets[v] for v in part) == total
    flow_graph = nx.DiGraph()
    source, sink = (object(),), (object(),)
    flow_graph.add_edges_from((source, v, {"capacity": targets[v]}) for v in left)
    flow_graph.add_edges_from((v, sink, {"capacity": targets[v]}) for v in right)
    flow_graph.add_edges_from((u, v, {"capacity": 1})
                             for u in left for v in right if graph.has_edge(u, v))
    value, flow = nx.maximum_flow(flow_graph, source, sink)
    if value != total:
        return incomplete("selected_margins_not_graphical")
    factor = fixed + [(u, v) for u in left for v in right if flow.get(u, {}).get(v, 0)]
    result = color_from_factor(graph, coloring, factor, red_offsets, blue_offsets, palette_size)
    result["recovery"] = "balanced_internal_edges_and_unit_capacity_cut_flow"
    result["factor_edges"] = factor
    return result
