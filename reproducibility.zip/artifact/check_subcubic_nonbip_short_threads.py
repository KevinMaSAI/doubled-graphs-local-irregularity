"""Independent domain, exact two-edge interface, and actual-copy checks.

These finite checks audit the implementation. The infinite-family assertion
is justified separately by the constructive proof, not by these samples.
"""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from subcubic_no_two_threads import (
    color_subcubic_no_two_threads,
    color_subcubic_nonbip_short_threads,
)


def independent_domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3 or all(d == 3 for d in degree.values()):
        return False
    roots = [v for v in graph if degree[v] == 3]
    direct = graph.subgraph(roots)
    is_bip = {}
    for vertices in nx.connected_components(direct):
        value = nx.is_bipartite(direct.subgraph(vertices))
        is_bip.update({v: value for v in vertices})
    for middle in graph:
        if degree[middle] == 2:
            u, v = graph[middle]
            if degree[u] == degree[v] == 3 and (is_bip[u] or is_bip[v]):
                return False
    return True


def verify_short_word(a, b, ru, rv):
    red = [ru, a + b, rv]
    blue = [6 - ru, 4 - a - b, 6 - rv]
    return all((value == 0 or red[i] != red[i + 1])
               and (value == 2 or blue[i] != blue[i + 1])
               for i, value in enumerate((a, b)))


def main():
    started = time.monotonic()
    rng = random.Random(20261103)
    exact_states, residue_states = 0, 0
    for a, b in itertools.product((0, 2), repeat=2):
        for ru in range(a, a + 5):
            for rv in range(b, b + 5):
                assert verify_short_word(a, b, ru, rv) == (ru != 2 + b and rv != 2 + a)
                exact_states += 1
    for pu, pv in itertools.product(range(3), repeat=2):
        a, b = 2 * int(pv == 2), 2 * int(pu == 2)
        for ru in range(a, a + 5):
            for rv in range(b, b + 5):
                if ru % 3 == pu and rv % 3 == pv:
                    assert verify_short_word(a, b, ru, rv)
                    residue_states += 1
    cases, with_short, maximum_length = 0, 0, 0
    short_target_pairs, short_port_pairs, core_modes = set(), set(), set()
    witnesses = {}
    def check(name, graph):
        nonlocal cases, with_short, maximum_length
        assert independent_domain(graph)
        result = color_subcubic_nonbip_short_threads(graph)
        verify(graph, result)
        cases += 1
        with_short += bool(result.get("short_threads"))
        for record in result.get("retained_components", []):
            core_modes.add(record["kind"])
        phi = result.get("prechosen_nonbip_targets", {})
        for key in result.get("short_threads", []):
            thread = result["threads"][key]
            path, ports = thread["path"], tuple(thread["ports"])
            u, v = path[0], path[-1]
            target = (phi[u], phi[v])
            short_target_pairs.add(target)
            short_port_pairs.add(ports)
            # Check the actual middle-vertex degrees as well as the stated
            # interface formula, independently of the constructor's assert.
            assert result["red"][path[1]] == sum(ports)
            assert verify_short_word(*ports, result["red"][u], result["red"][v])
            if ports not in witnesses:
                witnesses[ports] = {"name": name, "path": path, "ports": ports,
                    "targets": target,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        for item in result.get("threads", []) + result.get("pendants", []):
            maximum_length = max(maximum_length, len(item["path"]) - 1)
        return result
    atlas_colored, atlas_with_short, atlas_excluded = 0, 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        result = color_subcubic_nonbip_short_threads(graph)
        expected = independent_domain(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            result = check("atlas", graph)
            atlas_colored += 1
            atlas_with_short += bool(result.get("short_threads"))
        else:
            atlas_excluded += 1
    triangle = [(0, 1, 1), (1, 2, 1), (2, 0, 1)]
    other_triangle = [(u + 3, v + 3, length) for u, v, length in triangle]
    fixtures = [
        ("same_component_parallel_short", 3, triangle + [(0, 1, 2)], [(2, 1)]),
        ("three_cross_component_short", 6, triangle + other_triangle
         + [(0, 3, 2), (1, 4, 2), (2, 5, 2)], []),
        ("direct_bridge_in_nonbip_core", 6, triangle + other_triangle
         + [(0, 3, 1), (1, 4, 2), (2, 5, 2)], []),
        ("short_with_isolated_root_pendants", 4, triangle
         + [(0, 1, 2), (2, 3, 6)], [(3, 1), (3, 2)]),
        ("short_with_isolated_edge_pendant", 6, triangle + [(0, 1, 2),
         (2, 3, 3), (3, 4, 1), (3, 5, 4), (4, 5, 5)], [(4, 2), (5, 1)]),
    ]
    for name, count, threads, pendants in fixtures:
        graph = expand(count, threads, pendants)
        assert color_subcubic_no_two_threads(graph)["status"] == "method_not_applicable"
        check(name, graph)
    # Nonbipartite direct cores may be connected by a global network of
    # short paths, so choices cannot be made after solving individual cores.
    random_cases, rejected = 0, 0
    for _ in range(1200):
        count_components = rng.randrange(1, 9)
        blocks, count, threads = [], 0, []
        for _ in range(count_components):
            size = rng.choice((3, 5, 7, 9))
            block = list(range(count, count + size))
            count += size
            blocks.append(block)
            threads.extend((u, v, 1) for u, v in zip(block, block[1:] + block[:1]))
        free = set(range(count))
        # Connect the odd-core components before pairing the remaining
        # ports. Every root initially has exactly one available incidence.
        for previous, current in zip(blocks, blocks[1:]):
            u = rng.choice([v for v in previous if v in free])
            v = rng.choice([v for v in current if v in free])
            free.remove(u)
            free.remove(v)
            threads.append((u, v, rng.choice((1, 2, 2, 3, 7))))
        free = list(free)
        rng.shuffle(free)
        pendants = []
        while len(free) >= 2 and rng.random() < 0.9:
            u, v = free.pop(), free.pop()
            threads.append((u, v, rng.choice((2, 2, 3, 4, 8))))
        pendants.extend((v, rng.randrange(1, 11)) for v in free)
        if not any(length == 2 for u, v, length in threads):
            candidate = next((i for i, (u, v, length) in enumerate(threads) if length > 1), None)
            if candidate is None:
                rejected += 1
                continue
            u, v, _ = threads[candidate]
            threads[candidate] = (u, v, 2)
        order = list(range(count))
        rng.shuffle(order)
        check("random_odd_core_network", expand(count, threads, pendants, order))
        random_cases += 1
    check("five_thousand_edge_pendant", expand(3, triangle + [(0, 1, 2)], [(2, 5000)]))
    assert short_target_pairs == set(itertools.product(range(3), repeat=2)), short_target_pairs
    assert short_port_pairs == set(itertools.product((0, 2), repeat=2)), short_port_pairs
    report = {"checks_passed": True, "exact_two_edge_interface_states": exact_states,
        "physical_residue_interface_states": residue_states, "eligible_atlas_graphs": atlas_colored,
        "atlas_graphs_with_short_threads": atlas_with_short, "inapplicable_atlas_graphs": atlas_excluded,
        "named_fixtures": len(fixtures), "random_odd_core_networks": random_cases,
        "random_draws_without_short_thread_skipped": rejected,
        "long_cases": 1, "actual_copy_checked_colorings": cases,
        "colorings_with_short_threads": with_short,
        "short_target_pairs_observed": sorted(short_target_pairs),
        "short_port_pairs_observed": sorted(short_port_pairs),
        "core_modes_observed": sorted(core_modes), "maximum_path_length": maximum_length,
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Finite implementation audit; the universal claim needs the separate proof."}
    Path(__file__).with_name("subcubic_nonbip_short_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_nonbip_short_witnesses.json").write_text(
        json.dumps({str(key): value for key, value in witnesses.items()}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
