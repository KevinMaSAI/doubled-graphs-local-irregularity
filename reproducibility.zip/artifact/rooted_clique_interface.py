"""All root red sums of K_n (n>=4), with arbitrary physical root offsets.

The universal scope uses the separate two-new-vertices induction. JSON supplies
only the COMPLETE finite K4/K5 base, checked by an independent stdlib program.
No arbitrary-graph mother theorem is claimed.
"""

from collections import Counter
from functools import lru_cache
import itertools
import json
from pathlib import Path

from rooted_clique_certificate import verify_certificate


@lru_cache(maxsize=1)
def _bases():
    data = json.loads((Path(__file__).parent / "rooted_clique_interfaces.json").read_text(encoding="utf-8"))
    verify_certificate(data)
    return {(row["n"], row["A"], row["B"], row["root_red"]): row for row in data["records"]}


def color_rooted_clique(n, red_offset=0, blue_offset=0, root_red=None):
    """Root=0, other vertices 1..n-1; only INTERNAL edges are required valid.

    Offsets are fixed nonnegative integers with even sum. root_red specifies
    the internal root red degree, in [0,2(n-1)], and defaults to n-1.
    Returned red/blue counts at 0 include the fixed external contributions.
    """
    if type(n) is not int or n < 4:
        raise ValueError("The clique order must be an integer >=4.")
    A, B = red_offset, blue_offset
    S = n - 1 if root_red is None else root_red
    if (type(A) is not int or type(B) is not int or A < 0 or B < 0
            or (A + B) % 2 or type(S) is not int or not 0 <= S <= 2 * (n - 1)):
        raise ValueError("Offsets must be physical and the internal root degree feasible.")
    original = n, A, B, S
    frames, modes = [], Counter()
    while n > 5:
        if S >= 2 * n - 3:
            frames.append(("complement", n))
            modes["complement"] += 1
            A, B, S = B, A, 2 * (n - 1) - S
            continue
        if S <= 1:
            frames.append(("low", n))
            modes["low"] += 1
            if A < 2:
                modes["negative_offset_reinterpretation"] += 1
            A = A - 2 if A >= 2 else A % 2
            B += 2
            n -= 2
        else:
            high = 2 * n - 3
            needs_shift = A + S == high or B + 2 * (n - 1) - S == high
            mode = "middle_one" if needs_shift else "middle_zero"
            frames.append((mode, n))
            modes[mode] += 1
            n, S = n - 2, S - 2
    r = n - 1
    def cap(value):
        return value if value <= 2 * r else 2 * r + 1 + int(value % 2 == 0)
    record = _bases()[n, cap(A), cap(B), S]
    modes["K4_weak_base"] += int(not record["nonroot_interior"])
    values = dict(zip(itertools.combinations(range(n), 2), record["weights"]))
    for mode, size in reversed(frames):
        if mode == "complement":
            for edge in values:
                values[edge] = 2 - values[edge]
            continue
        u, v = size - 2, size - 1
        for old in range(size - 2):
            if mode == "low":
                values[old, u] = 0
                values[old, v] = 0 if old == 0 else 2
            elif mode == "middle_one" and old == 1:
                values[old, u] = values[old, v] = 1
            else:
                assert mode in ("middle_zero", "middle_one")
                values[old, u], values[old, v] = 0, 2
        values[u, v] = 2 if mode == "low" else 1
    n, A, B, S = original
    edges = list(itertools.combinations(range(n), 2))
    weights = [values[edge] for edge in edges]
    red = dict.fromkeys(range(n), 0)
    for (u, v), x in zip(edges, weights):
        red[u] += x
        red[v] += x
    assert red[0] == S
    red[0] += A
    blue = {v: 2 * (n - 1) - red[v] for v in range(1, n)}
    blue[0] = B + 2 * (n - 1) - S
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for (u, v), x in zip(edges, weights))
    interior = all(0 < red[v] < 2 * (n - 1) for v in range(1, n))
    assert n == 4 or interior
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "root_internal_red": S,
            "nonroot_interior": interior, "construction_modes": dict(modes),
            "mother_conjecture_proved": False}
