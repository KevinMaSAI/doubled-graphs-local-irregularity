"""Safe pure-port weighting on bipartite cores with at most two forks.

At every vertex v the auxiliary core has 3-degree_H(v) PRIVATE pure ports.
This is not an arbitrary boundary-list lemma or a mother-conjecture solver.
"""

import itertools
import json
from functools import lru_cache
from pathlib import Path

import networkx as nx

from sparse_bip_core_certificate import verify_certificate


SAFE = (0, 1, 3, 5, 6)


@lru_cache(None)
def _interfaces():
    data = json.loads(Path(__file__).with_name("sparse_bip_core_interfaces.json").read_text(encoding="utf-8"))
    verify_certificate(data)
    return {(item["shape"], tuple(item["lengths"])): item["witness"] for item in data["finite_records"]}


def _representative(length):
    return length if length <= 6 else 7 + int(length % 2 == 0)


def _chain_word(length, left_red, first, right_red=None, last=None, leaf=False):
    """Core-chain lifting: its internal vertices have ACTUAL total degree 3."""
    assert length >= 1 and left_red in SAFE and first in (0, 1, 2)
    assert first <= left_red <= first + 4
    current, histories = {(first, left_red)}, []
    for _ in range(length - 1):
        following = {}
        for previous in sorted(current):
            edge, old_red = previous
            for new_edge, port in itertools.product(range(3), (0, 2)):
                red = edge + new_edge + port
                if red in SAFE and red != old_red:
                    following.setdefault((new_edge, red), (previous, port))
        if not following:
            return None
        histories.append(following)
        current = set(following)
    if leaf:
        candidates = [(state, count) for state in sorted(current) for count in range(3)
                      if state[0] + 2 * count in SAFE and state[0] + 2 * count != state[1]]
        if not candidates:
            return None
        state, count = candidates[0]
        right_red = state[0] + 2 * count
        leaf_ports = [2] * count + [0] * (2 - count)
    else:
        candidates = [state for state in sorted(current) if state[0] == last and state[1] != right_red]
        if not candidates:
            return None
        state, leaf_ports = candidates[0], None
    trace, ports = [state], []
    for layer in reversed(histories):
        state, port = layer[state]
        trace.append(state)
        ports.append(port)
    trace.reverse()
    ports.reverse()
    word = [state[0] for state in trace]
    reds = [left_red] + [state[1] for state in trace[1:]] + [right_red]
    assert len(word) == length and len(ports) == length - 1
    assert all(a != b for a, b in zip(reds, reds[1:]))
    assert all(reds[i + 1] == word[i] + word[i + 1] + ports[i] for i in range(length - 1))
    assert all(port in (0, 2) for port in ports)
    return {"weights": word, "internal_ports": ports, "reds": reds, "leaf_ports": leaf_ports}


def safe_sparse_bipartite_core(core):
    """Return H-weights and free private ports for the precisely stated scope."""
    if core.is_directed() or core.is_multigraph() or nx.number_of_selfloops(core):
        raise ValueError("The auxiliary core must be simple, undirected and loopless.")
    if not len(core) or not nx.is_connected(core):
        raise ValueError("The auxiliary core must be nonempty and connected.")
    degree = dict(core.degree())
    if max(degree.values()) > 3 or not nx.is_bipartite(core):
        return {"status": "method_not_applicable", "reason": "core_not_bipartite_subcubic",
                "mother_conjecture_proved": False}
    forks = [v for v in core if degree[v] == 3]
    if len(forks) > 2:
        return {"status": "method_not_applicable", "reason": "more_than_two_core_forks",
                "mother_conjecture_proved": False}
    edges = list(core.edges())
    index = {frozenset(edge): i for i, edge in enumerate(edges)}
    weights, boundary = [None] * len(edges), {v: [0] * (3 - degree[v]) for v in core}
    chain_reports, planned_red = [], {}
    def put(path, word):
        assert len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            key = index[frozenset((u, v))]
            assert weights[key] is None
            weights[key] = value
    if not forks:
        start = next((v for v in core if degree[v] < 2), next(iter(core)))
        order, visited = [start], {start}
        while True:
            other = next((v for v in core[order[-1]] if v not in visited), None)
            if other is None:
                break
            order.append(other)
            visited.add(other)
        assert len(order) == len(core)
        matching = {frozenset((order[i], order[i + 1])) for i in range(0, len(order) - 1, 2)}
        covered = {v for edge in matching for v in edge}
        colors = nx.bipartite.color(core.subgraph(covered))
        for i, edge in enumerate(edges):
            weights[i] = int(frozenset(edge) in matching)
        for root in covered:
            if colors[root]:
                boundary[root][0] = 2
        shape, representatives = ("even_cycle" if all(degree[v] == 2 for v in core) else "path"), []
    else:
        used, chains = set(), []
        terminals = [v for v in core if degree[v] != 2]
        for root in terminals:
            for neighbor in core[root]:
                key = index[frozenset((root, neighbor))]
                if key in used:
                    continue
                used.add(key)
                path, previous, current = [root, neighbor], root, neighbor
                while degree[current] == 2:
                    other = next(v for v in core[current] if v != previous)
                    key = index[frozenset((current, other))]
                    assert key not in used
                    used.add(key)
                    path.append(other)
                    previous, current = current, other
                chains.append({"path": path, "ports": [None, None]})
        assert len(used) == len(edges)
        loop_ids = {v: [] for v in forks}
        connector_ids, arm_ids = [], {v: [] for v in forks}
        for key, item in enumerate(chains):
            path = item["path"]
            if path[0] == path[-1]:
                loop_ids[path[0]].append(key)
            elif degree[path[0]] == degree[path[-1]] == 3:
                connector_ids.append(key)
            else:
                if degree[path[0]] == 1:
                    path.reverse()
                assert degree[path[0]] == 3 and degree[path[-1]] == 1
                arm_ids[path[0]].append(key)
        if len(forks) == 2 and sum(map(len, loop_ids.values())) == 1:
            first = next(v for v in forks if loop_ids[v])
            forks = [first, next(v for v in forks if v != first)]
        for key in connector_ids:
            if chains[key]["path"][0] != forks[0]:
                chains[key]["path"].reverse()
        connector_ids.sort(key=lambda key: (_representative(len(chains[key]["path"]) - 1), key))
        def rep(key):
            return _representative(len(chains[key]["path"]) - 1)
        assignments = []
        if len(forks) == 1:
            u = forks[0]
            if not loop_ids[u]:
                assert len(arm_ids[u]) == 3
                shape, representatives = "claw", []
                assignments = [(key, 0, 0, slot) for slot, key in enumerate(arm_ids[u])]
            else:
                assert len(loop_ids[u]) == len(arm_ids[u]) == 1
                loop, arm = loop_ids[u][0], arm_ids[u][0]
                shape, representatives = "lollipop", [rep(loop)]
                assignments = [(loop, 0, 0, 0), (loop, 1, 0, 1), (arm, 0, 0, 2)]
        else:
            u, v = forks
            if len(connector_ids) == 3:
                assert not any(loop_ids.values()) and not any(arm_ids.values())
                shape, representatives = "theta", [rep(key) for key in connector_ids]
                assignments = [(key, end, end, slot) for slot, key in enumerate(connector_ids) for end in (0, 1)]
            elif len(connector_ids) == 2:
                assert not any(loop_ids.values()) and all(len(arm_ids[w]) == 1 for w in forks)
                shape, representatives = "cycle_two_arms", [rep(key) for key in connector_ids]
                assignments = [(key, end, end, slot) for slot, key in enumerate(connector_ids) for end in (0, 1)]
                assignments += [(arm_ids[w][0], 0, i, 2) for i, w in enumerate(forks)]
            else:
                assert len(connector_ids) == 1
                connector = connector_ids[0]
                assignments = [(connector, 0, 0, 2), (connector, 1, 1, 2)]
                if not any(loop_ids.values()):
                    assert all(len(arm_ids[w]) == 2 for w in forks)
                    shape, representatives = "double_star", [rep(connector)]
                    assignments += [(key, 0, i, slot) for i, w in enumerate(forks)
                                    for slot, key in enumerate(arm_ids[w])]
                elif all(len(loop_ids[w]) == 1 for w in forks):
                    assert not any(arm_ids.values())
                    shape, representatives = "barbell", [rep(loop_ids[u][0]), rep(loop_ids[v][0]), rep(connector)]
                    assignments += [(loop_ids[w][0], end, i, end) for i, w in enumerate(forks) for end in (0, 1)]
                else:
                    assert len(loop_ids[u]) == 1 and not loop_ids[v]
                    assert not arm_ids[u] and len(arm_ids[v]) == 2
                    shape, representatives = "lollipop_fork", [rep(loop_ids[u][0]), rep(connector)]
                    assignments += [(loop_ids[u][0], 0, 0, 0), (loop_ids[u][0], 1, 0, 1)]
                    assignments += [(key, 0, 1, slot) for slot, key in enumerate(arm_ids[v])]
        witness = _interfaces()[(shape, tuple(representatives))]
        planned_red = dict(zip(forks, witness["root_red"]))
        for key, end, root_index, slot in assignments:
            assert chains[key]["ports"][end] is None
            chains[key]["ports"][end] = witness["root_ports"][root_index][slot]
        for item in chains:
            path, ports = item["path"], item["ports"]
            u, v = path[0], path[-1]
            leaf = degree[v] == 1
            result = _chain_word(len(path) - 1, planned_red[u], ports[0],
                                 None if leaf else planned_red[v], ports[1], leaf=leaf)
            assert result is not None
            put(path, result["weights"])
            for root, port in zip(path[1:-1], result["internal_ports"]):
                assert degree[root] == 2
                boundary[root] = [port]
            if leaf:
                boundary[v] = result["leaf_ports"]
            chain_reports.append({"path": path, "ports": ports, "reds": result["reds"],
                                  "internal_ports": result["internal_ports"]})
    assert all(value in (0, 1, 2) for value in weights)
    red = {v: sum(boundary[v]) for v in core}
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    assert all(len(boundary[v]) == 3 - degree[v] and all(p in (0, 2) for p in boundary[v]) for v in core)
    assert all(value in SAFE for value in red.values())
    assert all(red[u] != red[v] for u, v in edges)
    assert all(red[v] == value for v, value in planned_red.items())
    return {"status": "weighted", "edge_order": edges, "weights": weights,
            "boundary_ports": boundary, "red": red, "skeleton": shape,
            "representative_lengths": representatives, "chain_reports": chain_reports,
            "mother_conjecture_proved": False}
