"""Constructive one-port flexibility for rooted doubled TREES.

The external port contributes c red and 2-c blue copies at the root. Only
internal tree edges are checked here. This does not solve arbitrary core graphs.
"""
from numbers import Integral

import networkx as nx


def tree_port_witnesses(graph, root):
    """Return bounded-size witness sets, not necessarily the full port domains.

    For n>=2, port 1 has three distinct internal root red counts. For n>=3,
    ports 0 and 2 each have at least two. Counts follow list(graph.edges()).
    The construction uses a constant number of states per rooted subtree.
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A simple undirected tree is required.')
    if root not in graph or not nx.is_tree(graph):
        raise ValueError('A nonempty tree and a root in it are required.')
    parent={root:None};order=[root];children={v:[] for v in graph}
    for v in order:
        for w in graph[v]:
            if w==parent[v]:continue
            parent[w]=v;children[v].append(w);order.append(w)
    size={};states={}

    def compatible(child, port, red, A, B):
        degree=len(children[child])
        return (port==0 or A!=red+port) and \
            (port==2 or B!=2*degree-red+2-port)

    def available(child,port,A,B):
        return next((p for p in states[child][port]
                     if compatible(child,port,p,A,B)),None)

    def direct(v,port,edge_values):
        k=len(children[v]);red=sum(edge_values)
        A=red+port;B=2*k-red+2-port
        choices=[]
        for child,a in zip(children[v],edge_values):
            p=available(child,a,A,B)
            assert p is not None
            choices.append((child,a,p))
        states[v][port][red]={'choices':choices}
        return red

    for v in reversed(order):
        k=len(children[v]);size[v]=1+sum(size[w] for w in children[v])
        states[v]={0:{},1:{},2:{}}
        if k==0:
            for c in range(3):states[v][c][0]={'choices':[]}
            continue
        if size[v]==2:
            direct(v,0,[0])
            states[v][2][2]={'reflect':(0,0)}
            for a in range(3):direct(v,1,[a])
            continue
        direct(v,0,[1]*k)
        distinguished=next((i for i,w in enumerate(children[v])
                            if available(w,2,k+1,k+1) is not None),None)
        if distinguished is not None:
            values=[1]*k;values[distinguished]=2
        else:
            assert k==3 and all(size[w]==2 for w in children[v])
            values=[0,1,1]
        direct(v,0,values)
        for p in list(states[v][0]):
            states[v][2][2*k-p]={'reflect':(0,p)}
        direct(v,1,[1]*k)
        distinguished=next((i for i,w in enumerate(children[v])
                            if available(w,0,k,k+2) is not None),None)
        if distinguished is not None:
            values=[1]*k;values[distinguished]=0
        else:
            assert k==2 and all(size[w]==2 for w in children[v])
            values=[0,0]
        off=direct(v,1,values)
        states[v][1][2*k-off]={'reflect':(1,off)}
        assert len(states[v][0])>=2 and len(states[v][1])>=3

    edges=list(graph.edges())
    index={frozenset(e):i for i,e in enumerate(edges)}
    ports={0:{},1:{},2:{}}
    for c in range(3):
        for p in states[root][c]:
            weights=[None]*len(edges);stack=[(root,c,p,False)]
            while stack:
                v,port,red,flip=stack.pop();plan=states[v][port][red]
                if 'reflect' in plan:
                    old_port,old_red=plan['reflect']
                    stack.append((v,old_port,old_red,not flip))
                    continue
                for child,a,child_red in plan['choices']:
                    weights[index[frozenset((v,child))]]=2-a if flip else a
                    stack.append((child,a,child_red,flip))
            assert all(x in (0,1,2) for x in weights)
            ports[c][p]=weights
    return {'edges':edges,'root':root,'root_degree':graph.degree(root),'ports':ports}


def extend_tree_bridge(graph, root, parent_red, parent_blue, bridge_red=1):
    """Color the tree against FINAL parent counts that already include the bridge.

    The existing core must already be legal with those final counts. This call
    does not justify changing the parent's counts after coloring its core.
    """
    if not isinstance(bridge_red,Integral) or bridge_red not in (0,1,2):
        raise ValueError('bridge_red must be 0,1,2.')
    if any(not isinstance(a,Integral) for a in (parent_red,parent_blue)) or \
        parent_red<bridge_red or parent_blue<2-bridge_red or \
        (parent_red+parent_blue)%2:
        raise ValueError('Final parent counts must include the bridge copies.')
    result=tree_port_witnesses(graph,root);d=result['root_degree'];c=bridge_red
    for r,weights in result['ports'][c].items():
        child_red=r+c;child_blue=2*d-r+2-c
        if (c==0 or parent_red!=child_red) and (c==2 or parent_blue!=child_blue):
            return {'status':'extended','edges':result['edges'],'weights':weights,
                    'bridge_red':c,'root_internal_red':r,
                    'root_total_red':child_red,'root_total_blue':child_blue}
    return {'status':'incompatible'}
