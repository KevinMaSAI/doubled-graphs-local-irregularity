"""Explicit LIR2 for subdividing a cubic graph's perfect matching to >=4."""

import networkx as nx

from independent_branch_coloring import _path_word


def color_cubic_perfect_matching_subdivision(base, matching, lengths=4):
    """Return the expanded graph and actual weights; no existence oracle.

    The input matching must be a supplied perfect matching of the connected
    simple cubic base. lengths is an integer or a frozenset(edge)-keyed mapping.
    """
    if (base.is_directed() or base.is_multigraph() or nx.number_of_selfloops(base)
            or not len(base) or not nx.is_connected(base)
            or any(degree != 3 for v, degree in base.degree())):
        raise ValueError("The base must be a connected simple cubic graph.")
    pairs = [tuple(edge) for edge in matching]
    covered = set()
    for pair in pairs:
        if len(pair) != 2 or not base.has_edge(*pair) or any(v in covered for v in pair):
            raise ValueError("The supplied edges must form a perfect matching.")
        covered.update(pair)
    if covered != set(base):
        raise ValueError("The supplied matching is not perfect.")
    path_lengths = [lengths if isinstance(lengths, int) else lengths[frozenset(pair)] for pair in pairs]
    if any(not isinstance(value, int) or value < 4 for value in path_lengths):
        raise ValueError("Every replacement path must have at least four edges.")
    graph = base.copy()
    graph.remove_edges_from(pairs)
    assert all(degree == 2 for v, degree in graph.degree())
    value_map, cycles = {}, []
    for component in nx.connected_components(graph):
        start = next(iter(component))
        cycle, previous, current = [start], None, start
        while True:
            other = next(v for v in graph[current] if v != previous)
            if other == start:
                break
            cycle.append(other)
            previous, current = current, other
        assert len(cycle) == len(component)
        count = len(cycle)
        position_graph = nx.Graph()
        position_graph.add_nodes_from(range(count))
        position_graph.add_edges_from((i, (i + 2) % count) for i in range(count))
        colors = {}
        for i in range(count):
            unavailable = {colors[j] for j in position_graph[i] if j in colors}
            colors[i] = next(value for value in range(3) if value not in unavailable)
        for i, u in enumerate(cycle):
            v = cycle[(i + 1) % count]
            value_map[frozenset((u, v))] = colors[i]
        cycles.append(cycle)
    root_red = {v: sum(value_map[frozenset((u, v))] for u in graph[v]) for v in base}
    root_blue = {v: 6 - root_red[v] for v in base}
    assert all(root_red[u] != root_red[v] for u, v in graph.edges())
    next_vertex, paths = 0, []
    for (u, v), length in zip(pairs, path_lengths):
        path = [u]
        for _ in range(length - 1):
            while next_vertex in graph:
                next_vertex += 1
            graph.add_node(next_vertex)
            path.append(next_vertex)
            next_vertex += 1
        path.append(v)
        graph.add_edges_from(zip(path, path[1:]))
        word = _path_word(length, 0, 0, root_red[u], root_blue[u], root_red[v], root_blue[v])
        assert word is not None and word[0] == word[-1] == 0
        for a, b, value in zip(path, path[1:], word):
            value_map[frozenset((a, b))] = value
        paths.append(path)
    edges = list(graph.edges())
    weights = [value_map[frozenset(e)] for e in edges]
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in base)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "graph": graph, "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "cycles": cycles, "replacement_paths": paths,
            "mother_conjecture_proved": False}
