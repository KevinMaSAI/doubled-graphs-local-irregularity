"""Precolor a bipartite/cactus low side using a PRIVATE leaf for every port.

Only the low-low edges must be legal at this stage; port comparisons will be
completed by the high-region absorption theorem. Trees use a direct constructor.
Non-tree bipartite/cactus components use finite exact recovery, with timeout
reported explicitly; their existence is an established separate theorem.
"""

import networkx as nx

from tree_ports import extend_tree_bridge


def _is_cactus(graph):
    for vertices in nx.biconnected_components(graph):
        block = graph.subgraph(vertices)
        if len(block) > 2 and (block.number_of_edges() != len(block)
                               or any(d != 2 for v, d in block.degree())):
            return False
    return True


def _color_placeholder(graph, timeout_ms):
    if len(graph) == 2:
        return {"status": "partial_K2", "values": {frozenset(next(iter(graph.edges()))): 1}}
    if all(graph.degree(u) != graph.degree(v) for u, v in graph.edges()):
        return {"status": "colored", "method": "already_locally_irregular",
                "values": {frozenset(e): 0 for e in graph.edges()}}
    if nx.is_tree(graph):
        leaf = next(v for v, degree in graph.degree() if degree == 1)
        root = next(iter(graph[leaf]))
        smaller = graph.subgraph([v for v in graph if v != leaf])
        colored = extend_tree_bridge(smaller, root, 1, 1, bridge_red=1)
        assert colored["status"] == "extended"
        values = dict(zip(map(frozenset, colored["edges"]), colored["weights"]))
        values[frozenset((root, leaf))] = 1
        return {"status": "colored", "method": "constructive_tree_port", "values": values}
    if not nx.is_bipartite(graph) and not _is_cactus(graph):
        return {"status": "method_not_applicable",
                "reason": "low_placeholder_is_neither_bipartite_nor_cactus"}
    import z3
    edges = list(graph.edges())
    variables = [z3.Int("low_" + str(i)) for i in range(len(edges))]
    incident = {v: [] for v in graph}
    for (u, v), x in zip(edges, variables):
        incident[u].append(x)
        incident[v].append(x)
    red = {v: z3.Sum(incident[v]) for v in graph}
    solver = z3.Solver()
    solver.set(timeout=timeout_ms)
    solver.add(*[z3.And(x >= 0, x <= 2) for x in variables])
    for (u, v), x in zip(edges, variables):
        solver.add(z3.Implies(x > 0, red[u] != red[v]),
                   z3.Implies(x < 2, 2 * graph.degree(u) - red[u] != 2 * graph.degree(v) - red[v]))
    answer = solver.check()
    if answer == z3.unknown:
        return {"status": "low_search_incomplete", "reason": solver.reason_unknown()}
    assert answer == z3.sat, "A known bipartite/cactus placeholder was reported infeasible."
    model = solver.model()
    return {"status": "colored", "method": "known_class_exact_recovery",
            "values": {frozenset(e): model.eval(x).as_long() for e, x in zip(edges, variables)}}


def prepare_low_side(graph, regions, timeout_ms=10000):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    regions = [set(part) for part in regions]
    if not regions or any(not part for part in regions):
        raise ValueError("Nonempty high regions are required.")
    high = set()
    owner = {}
    for i, part in enumerate(regions):
        for v in part:
            if v in owner:
                raise ValueError("High regions must be disjoint.")
            high.add(v)
            owner[v] = i
    if not high or not high <= set(graph):
        raise ValueError("A nonempty high side is required.")
    low = set(graph) - high
    values = {frozenset((u, v)): 0 for u, v in graph.edges()
              if u in high and v in high and owner[u] != owner[v]}
    reports = []
    for vertices in nx.connected_components(graph.subgraph(low)):
        placeholder = graph.subgraph(vertices).copy()
        port_map = {}
        for u in vertices:
            for v in graph[u]:
                if v not in high:
                    continue
                leaf = object()
                placeholder.add_edge(u, leaf)
                port_map[frozenset((u, leaf))] = frozenset((u, v))
        if len(placeholder) < 2:
            raise ValueError("A low component has no connection to the high side.")
        colored = _color_placeholder(placeholder, timeout_ms)
        if colored["status"] not in ("colored", "partial_K2"):
            return colored
        # Verify internal edges of every actual placeholder coloring separately.
        R, B = dict.fromkeys(placeholder, 0), dict.fromkeys(placeholder, 0)
        for u, v in placeholder.edges():
            x = colored["values"][frozenset((u, v))]
            R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
        if colored["status"] == "colored":
            assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
                       for u, v in placeholder.edges()
                       for x in [colored["values"][frozenset((u, v))]])
        else:
            assert len(vertices) == len(port_map) == 1
        for edge, x in colored["values"].items():
            values[port_map.get(edge, edge)] = x
        reports.append({"low_vertices": list(vertices), "ports": len(port_map),
                        "method": colored.get("method", "partial_K2_bridge")})
    return {"status": "prepared", "given_weights": values, "reports": reports,
            "mother_conjecture_proved": False}
