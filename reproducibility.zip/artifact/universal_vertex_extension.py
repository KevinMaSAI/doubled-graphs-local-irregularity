"""Conditional extension over a universal vertex, with explicit K2 components.

This does NOT find legal colorings of arbitrary base components. Given those
colorings, it preserves all supplied edge colors and fills the cone in linear
time. The mother conjecture for arbitrary graphs remains unproved.
"""
from numbers import Integral

import networkx as nx


def extend_universal_vertex(graph, root, base_weights):
    """Color 2G, given the legal colorings of components of H=G-root.

    root must be adjacent to every other vertex. base_weights follows
    list(H.edges()). Every edge in a component exactly K2 must have value None;
    it is filled separately. All other entries must be 0,1,2, and each supplied
    component coloring must already be legal. All those colors are preserved.
    The excluded graph K2 raises ValueError; the singleton graph is trivial.
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if root not in graph or graph.degree(root) != len(graph) - 1:
        raise ValueError('The specified root must be adjacent to every other vertex.')
    if len(graph) == 2:
        raise ValueError('K2 is excluded from the mother conjecture.')
    base = graph.subgraph(set(graph) - {root}).copy()
    base_edges = list(base.edges())
    base_weights = list(base_weights)
    if len(base_edges) != len(base_weights):
        raise ValueError('base_weights must follow list((G-root).edges()).')
    components = list(nx.connected_components(base))
    pairs = [C for C in components if len(C) == 2]
    pair_edges = {frozenset(C) for C in pairs}
    values = {}
    red_old = {v: 0 for v in base}
    for e, x in zip(base_edges, base_weights):
        key = frozenset(e)
        if key in pair_edges:
            if x is not None:
                raise ValueError('An isolated K2 component must be supplied as uncolored (None).')
            continue
        if not isinstance(x, Integral) or x not in (0, 1, 2):
            raise ValueError('Every other base edge needs a weight 0,1,2.')
        values[key] = int(x)
        for v in e:
            red_old[v] += x
    blue_old = {v: 2 * base.degree(v) - red_old[v] for v in base}
    for e, x in zip(base_edges, base_weights):
        if frozenset(e) in pair_edges:
            continue
        u, v = e
        if (x > 0 and red_old[u] == red_old[v]) or \
           (x < 2 and blue_old[u] == blue_old[v]):
            raise ValueError('Every supplied base component coloring must be legal.')
    if len(graph) == 1:
        return {'status': 'extended', 'edges': [], 'weights': [],
                'red_degrees': {root: 0}, 'blue_degrees': {root: 0},
                'base_edges': [], 'root_mode': 'trivial'}
    bulk_red = 0
    if len(components) == 1 and len(components[0]) >= 3:
        n = len(base)
        has_blue_universal = any(base.degree(v) == n - 1 and red_old[v] == 0 for v in base)
        if has_blue_universal:
            assert not any(base.degree(v) == n - 1 and blue_old[v] == 0 for v in base)
            bulk_red = 2
    for v in base:
        values[frozenset((root, v))] = bulk_red
    for pair in pairs:
        u, v = tuple(pair)
        values[frozenset((u, v))] = 1
        values[frozenset((root, u))] = 0
        values[frozenset((root, v))] = 2
    edges = list(graph.edges())
    weights = [values[frozenset(e)] for e in edges]
    red = {v: 0 for v in graph}
    for (u, v), x in zip(edges, weights):
        red[u] += x
        red[v] += x
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    return {'status': 'extended', 'edges': edges, 'weights': weights,
            'red_degrees': red, 'blue_degrees': blue, 'base_edges': base_edges,
            'root_mode': 'red' if bulk_red == 2 else 'blue_with_triangle_components',
            'two_vertex_components': len(pairs)}
