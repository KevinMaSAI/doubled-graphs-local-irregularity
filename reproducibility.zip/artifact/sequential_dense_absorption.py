"""Fill several dense regions, protecting low neighbors and already filled regions.

All noninternal-region edges are given and preserved. Future-region comparisons
are deferred, but every fixed external contribution is included from the start.
"""

import networkx as nx

from dense_offset_lists import color_dense_offset_lists


def complete_dense_regions(graph, regions, given_weights, factors=None, timeout_ms=10000):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    parts = [set(part) for part in regions]
    owner = {}
    for i, part in enumerate(parts):
        if (not part or not part <= set(graph) or set(owner) & part
                or not nx.is_connected(graph.subgraph(part))):
            raise ValueError("Disjoint nonempty connected induced regions are required.")
        owner.update({v: i for v in part})
    if not parts or (factors is not None and len(factors) != len(parts)):
        raise ValueError("Provide at least one region, and one certificate per region when supplied.")
    values = {frozenset(e): x for e, x in given_weights.items()}
    required = {frozenset((u, v)) for u, v in graph.edges()
                if u not in owner or v not in owner or owner[u] != owner[v]}
    if (len(values) != len(given_weights) or set(values) != required
            or any(type(x) is not int or x not in (0, 1, 2) for x in values.values())):
        raise ValueError("Supply exactly all noninternal-region edges with fixed weights 0, 1, or 2.")
    R, B = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    for e, x in values.items():
        for v in e:
            R[v] += x; B[v] += 2-x
    A, Z = dict(R), dict(B)
    low = set(graph)-set(owner)
    for u, v in graph.subgraph(low).edges():
        x = values[frozenset((u, v))]
        if (x > 0 and R[u] == R[v]) or (x < 2 and B[u] == B[v]):
            raise ValueError("The low-low edges must already be legal with the fixed ports included.")
    plans = []
    for i, part in enumerate(parts):
        H = graph.subgraph(part)
        forbidden = {v: set() for v in H}
        for v in H:
            for u in graph[v]:
                if u in part or (u in owner and owner[u] > i):
                    continue
                x = values[frozenset((u, v))]
                if x > 0:
                    forbidden[v].add(R[u])
                if x < 2:
                    forbidden[v].add(2*graph.degree(v)-B[u])
        local = color_dense_offset_lists(H, {v: A[v] for v in H}, {v: Z[v] for v in H},
                                        forbidden, None if factors is None else factors[i], timeout_ms)
        if local["status"] != "colored":
            return {"status": local["status"], "region": i, "details": local,
                    "mother_conjecture_proved": False}
        for e, x in zip(local["edge_order"], local["weights"]):
            key = frozenset(e)
            values[key] = x
            for v in key:
                R[v] += x; B[v] += 2-x
        assert all(R[v] == local["red"][v] and B[v] == local["blue"][v] for v in H)
        plans.append(local["plan"])
    assert all(R[v] == A[v] and B[v] == Z[v] for v in low)
    edges = list(graph.edges())
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for u, v in edges for x in [values[frozenset((u, v))]])
    return {"status": "colored", "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges], "red": R, "blue": B,
            "plans": plans, "all_given_colors_preserved": True,
            "all_low_counters_preserved": True, "mother_conjecture_proved": False}
