"""Independent copy counts and all residue boundary identities for the proof."""

import itertools
import json
from pathlib import Path
import random
import time

import networkx as nx

from chromatic_degree_factor import degree_options, make_plan, color_from_factor
from factor_cut_certificate import recover_factor_on_cut, _balanced_internal_edges


def verify(graph, result, A=None, B=None):
    assert result["status"] == "colored"
    assert len(result["edge_order"]) == len(result["weights"]) == graph.number_of_edges()
    assert {frozenset(e) for e in result["edge_order"]} == {frozenset(e) for e in graph.edges()}
    red = {v: 0 if A is None else A[v] for v in graph}
    blue = {v: 0 if B is None else B[v] for v in graph}
    for (u, v), x in zip(result["edge_order"], result["weights"]):
        assert type(x) is int and x in (0, 1)
        for copy in range(2):
            degree = red if copy < x else blue
            degree[u] += 1
            degree[v] += 1
    assert red == result["red"] and blue == result["blue"]
    assert all(red[u] != red[v] and blue[u] != blue[v] for u, v in graph.edges())


def main():
    started = time.monotonic()
    scalar, one_less, palettes, offsets = 0, 0, 0, 0
    for modulus in range(3, 502):
        for d in (4 * modulus - 7, 4 * modulus - 6):
            for residue in range(modulus):
                row = degree_options(d, residue, modulus)
                a, b = row["lower"], row["upper"]
                assert 0 <= a <= d // 2 <= b < d
                assert 2 * b <= d + a + 2 and b <= 2 * a + 3
                assert a % modulus == b % modulus == residue
                assert all(0 <= t <= d for t in row["allowed"])
                scalar += 1
        d = 4 * modulus - 8
        row = degree_options(d, (d // 2 - 1) % modulus, modulus)
        assert 2 * row["upper"] > d + row["lower"] + 2
        assert not row["conditions_hold"]
        one_less += 1
    for c in range(2, 51):
        p, q = 2 * c, 2 * c + 1
        for i, j in itertools.combinations(range(c), 2):
            assert not {2 * i % p, (2 * i + 1) % p} & {2 * j % p, (2 * j + 1) % p}
            assert not {2 * i % q, (2 * i - 1) % q} & {2 * j % q, (2 * j - 1) % q}
            palettes += 1
        M = p * q
        for d in (4 * M - 7, 4 * M - 6, 5 * M + 7):
            for i in range(c):
                for A, B in ((0, 0), (1, 1), (0, 2), (2, 0), (10**9, 10**9 + 2)):
                    a, b = (2 * i - A) % p, (2 * d + B - 2 * i) % q
                    phi = a + p * ((b - a) * pow(p, -1, q) % q)
                    row = degree_options(d, phi, M)
                    assert row["conditions_hold"]
                    for target in row["allowed"]:
                        assert (A + target) % p in {2 * i % p, (2 * i + 1) % p}
                        assert (B + 2 * d - target) % q in {2 * i % q, (2 * i - 1) % q}
                        offsets += 1
    balanced_graphs = 0
    for auxiliary in nx.graph_atlas_g():
        selected, degree = _balanced_internal_edges(auxiliary, set(auxiliary))
        assert len(selected) == len({frozenset(e) for e in selected})
        actual_degree = dict.fromkeys(auxiliary, 0)
        for u, v in selected:
            assert auxiliary.has_edge(u, v)
            actual_degree[u] += 1
            actual_degree[v] += 1
        assert actual_degree == degree
        assert all(auxiliary.degree(v) // 2 <= degree[v] <= auxiliary.degree(v) // 2 + 1
                   for v in auxiliary)
        balanced_graphs += 1
    actual, noncomplete_nonbip, with_offsets = 0, 0, 0
    witnesses = {}
    for n, m in ((73, 74), (150, 151), (181, 182)):
        graph = nx.complete_bipartite_graph(n, m)
        left, right = list(range(n)), list(range(n, n + m))
        coloring = {v: int(v >= n) for v in graph}
        result = recover_factor_on_cut(graph, coloring, left, right)
        verify(graph, result)
        assert result["plan"]["global_minimum_degree_bound_holds"]
        actual += 1
    rng = random.Random(2026102761)
    for trial in range(6):
        graph = nx.complete_bipartite_graph(150, 151)
        coloring = {v: int(v >= 150) for v in graph}
        A, B = {}, {}
        for v in graph:
            A[v], B[v] = rng.randrange(200), rng.randrange(200)
            B[v] += (A[v] + B[v]) % 2
        result = recover_factor_on_cut(graph, coloring, range(150), range(150, 301), A, B)
        verify(graph, result, A, B)
        actual += 1
        with_offsets += 1
    for missing in (0, 1, 10, 50):
        graph = nx.complete_multipartite_graph(123, 124, 125)
        coloring = nx.get_node_attributes(graph, "subset")
        for i in range(missing):
            graph.remove_edge(i, 247 + i)
        for cut_part in range(3):
            right = [v for v in graph if coloring[v] == cut_part]
            left = [v for v in graph if coloring[v] != cut_part]
            result = recover_factor_on_cut(graph, coloring, left, right)
            if result["status"] == "colored":
                break
        verify(graph, result)
        assert min(dict(graph.degree()).values()) >= 161
        actual += 1
        noncomplete_nonbip += int(missing > 0)
        if missing == 50:
            witnesses["nonregular_noncomplete_three_color_core"] = {
                "recipe": "K_123,124,125 minus edges (i,247+i), i=0..49",
                "edges": [[u, v, x] for (u, v), x in
                          zip(result["edge_order"], result["weights"])],
                "red": result["red"], "blue": result["blue"]}
    graph = nx.complete_multipartite_graph(133, 134, 135, 136)
    coloring = nx.get_node_attributes(graph, "subset")
    left = [v for v in graph if coloring[v] < 2]
    right = [v for v in graph if coloring[v] >= 2]
    for i in range(30):
        graph.remove_edge(i, 133 + i)
    result = recover_factor_on_cut(graph, coloring, left, right)
    verify(graph, result)
    assert min(dict(graph.degree()).values()) >= 281
    actual += 1
    noncomplete_nonbip += 1
    # A damaged factor is rejected by recomputing exact allowed degrees.
    try:
        color_from_factor(graph, coloring, [])
    except AssertionError:
        pass
    else:
        raise AssertionError("An invalid empty factor was accepted.")
    assert make_plan(nx.cycle_graph(3), {0: 0, 1: 1, 2: 2})["status"] == "method_not_applicable"
    output = {"all_residue_boundary_identities": scalar,
              "one_less_rounding_threshold_failures": one_less,
              "disjoint_color_palette_pairs": palettes,
              "physical_offset_modular_identities": offsets,
              "balanced_internal_graphs_verified": balanced_graphs,
              "actual_factor_colorings_verified": actual,
              "noncomplete_nonbipartite_cores_verified": noncomplete_nonbip,
              "arbitrary_offset_factor_colorings_verified": with_offsets,
              "damaged_factor_rejected": True, "all_checks_passed": True,
              "mother_conjecture_proved": False,
              "scope": "Global sufficient degree/chromatic condition and internal offset variant only.",
              "seconds": round(time.monotonic() - started, 3)}
    path = Path(__file__).parent
    (path / "chromatic_degree_factor_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    (path / "chromatic_degree_factor_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
