"""Independent actual-copy and hypothesis checks for conditional tree gluing."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from piece_tree_gluing import color_piece_tree
from regular_block_tree import color_regular_block_tree


def append_piece(graph, root, template):
    mapping = {next(iter(template)): root}
    next_vertex = max(graph, default=-1) + 1
    for v in template:
        if v not in mapping:
            mapping[v] = next_vertex
            next_vertex += 1
    edges = [(mapping[u], mapping[v]) for u, v in template.edges()]
    graph.add_edges_from(edges)
    return edges


def centered_regular_network(counts, rng, mixed=False):
    """Central K4 may share all four vertices with attached regular blocks."""
    graph = nx.complete_graph(4)
    templates = [nx.complete_graph(4)]
    if mixed:
        templates += [nx.cycle_graph(3), nx.cycle_graph(4),
                      nx.complete_bipartite_graph(3, 3), nx.circular_ladder_graph(5)]
    for v, count in enumerate(counts):
        for _ in range(count):
            append_piece(graph, v, rng.choice(templates))
    return graph


def main():
    started = time.monotonic()
    rng = random.Random(2026102749)
    checked, rejected, complements, adjacent_boundary = 0, 0, 0, 0
    maximum_degree, maximum_blocks = 0, 0
    witnesses = {}

    def check(name, graph):
        nonlocal checked, rejected, complements, adjacent_boundary
        nonlocal maximum_degree, maximum_blocks
        result = color_regular_block_tree(graph)
        if result["status"] != "colored":
            assert result["status"] == "method_not_applicable"
            rejected += 1
            return result
        verify(graph, result)
        checked += 1
        assert not result.get("subcubic_two_marked_draft_used", False)
        boundary = set(result["boundary_vertices"])
        high_edges = sum(u in boundary and v in boundary for u, v in graph.edges())
        adjacent_boundary += int(high_edges > 0)
        complements += sum(result["piece_complements"])
        maximum_degree = max(maximum_degree, max(dict(graph.degree()).values()))
        maximum_blocks = max(maximum_blocks, result.get("block_count", 0))
        for v in boundary:
            lower, upper = result["intervals"][v]
            assert lower <= result["red"][v] <= upper
            assert lower <= result["blue"][v] <= upper
        if high_edges and "adjacent_shared_vertices" not in witnesses:
            witnesses["adjacent_shared_vertices"] = {
                "name": name, "edges": [[u, v, x] for (u, v), x in
                                      zip(result["edge_order"], result["weights"])],
                "red": result["red"], "blue": result["blue"],
                "intervals": result["intervals"],
                "piece_complements": result["piece_complements"]}
        return result

    check("singleton", nx.empty_graph(1))
    for length in range(3, 36):
        check("single_cycle", nx.cycle_graph(length))
    for graph in [nx.complete_graph(4), nx.complete_bipartite_graph(3, 3),
                  nx.petersen_graph(), nx.circular_ladder_graph(8)]:
        check("single_cubic", graph)
    # Exhaust all canonical cubic-center degree choices in the selected range.
    for ranks in itertools.permutations(range(4), 4):
        counts = [3 + 3 * rank for rank in ranks]
        result = check("four_adjacent_shared", centered_regular_network(counts, rng))
        assert result["status"] == "colored"
    for count in range(3, 105):
        graph = nx.Graph()
        graph.add_node(0)
        for _ in range(count):
            append_piece(graph, 0, nx.complete_graph(4))
        assert check("unbounded_K4_windmill", graph)["status"] == "colored"
    for trial in range(180):
        counts = [4 + 6 * rank + rng.randrange(2) for rank in rng.sample(range(6), 4)]
        result = check("mixed_regular_blocks", centered_regular_network(counts, rng, mixed=True))
        # The adaptive interval check can reject a randomly small degree gap.
        if result["status"] != "colored":
            assert result["reason"] in {"boundary_intervals_not_separated",
                                        "boundary_low_interval_not_separated"}
    # A deeper incidence tree: each eligible new K4 vertex becomes a shared cut.
    graph = nx.complete_graph(4)
    frontier = [(0, 12), (1, 21), (2, 30), (3, 39)]
    for depth in range(3):
        following = []
        for v, desired in frontier:
            while graph.degree(v) < desired:
                fresh = append_piece(graph, v, nx.complete_graph(4))
                if depth < 2 and len(following) < 6:
                    children = sorted({w for edge in fresh for w in edge} - {v})
                    for j, w in enumerate(children):
                        following.append((w, 60 + 9 * j + 27 * depth))
            assert graph.degree(v) == desired
        frontier = following
    assert check("depth_three_block_tree", graph)["status"] == "colored"
    # Arbitrary tuple labels and edge insertion order must not change scope.
    for trial in range(25):
        original = centered_regular_network([3, 6, 9, 12], rng)
        edges = list(original.edges())
        rng.shuffle(edges)
        graph = nx.Graph()
        graph.add_edges_from(((("v", u), ("v", v)) for u, v in edges))
        assert check("tuple_labels_reordered", graph)["status"] == "colored"
    # Cyclic incidence and overlapping intervals must be rejected explicitly.
    cyclic = nx.cycle_graph(3)
    bad = color_piece_tree(cyclic, [[(0, 1)], [(1, 2)], [(2, 0)]], [[0], [0], [0]])
    assert bad["reason"] == "piece_boundary_incidence_is_not_a_tree"
    equal = centered_regular_network([3, 3, 3, 3], rng)
    bad = color_regular_block_tree(equal)
    assert bad["status"] == "method_not_applicable"
    assert bad["reason"] == "boundary_intervals_not_separated"
    # Broken nonboundary local input is an error, even though K2 is excluded.
    try:
        color_piece_tree(nx.path_graph(3), [[(0, 1), (1, 2)]], [[0, 2]])
    except ValueError as error:
        assert "invalid local coloring" in str(error)
    else:
        raise AssertionError("Invalid local coloring was accepted")
    # The elementary minimax sign identity used in every induction step.
    sign_identities = 0
    for bound in range(8):
        for s in range(-bound, bound + 1):
            for a in range(-bound, bound + 1):
                assert min(abs(s + a), abs(s - a)) <= max(abs(s), abs(a)) <= bound
                sign_identities += 1
    # For every r>=2, two individually colored K_{r,r} blocks can make
    # every whole-piece flip fail. A closed formula also gives a repair.
    fixed_flip_failures, repaired_block_pairs = 0, 0
    for r in range(2, 36):
        graph = nx.Graph()
        graph.add_node(0)
        parts, rows = [], []
        for block in range(2):
            left = [0] + list(range(1 + block * (2 * r - 1),
                                    r + block * (2 * r - 1)))
            right = list(range(r + block * (2 * r - 1),
                               2 * r + block * (2 * r - 1)))
            part, row = [], []
            for j, u in enumerate(left):
                for k, v in enumerate(right):
                    part.append((u, v))
                    row.append(2 if k == 0 else (1 if j == 0 and k >= 2 else 0))
            parts.append(part)
            rows.append(row)
            graph.add_edges_from(part)
            local = nx.Graph(part)
            rr = dict.fromkeys(local, 0)
            for (u, v), x in zip(part, row):
                rr[u] += x
                rr[v] += x
            verify(local, {"status": "colored", "edge_order": part, "weights": row,
                           "red": rr, "blue": {v: 2 * r - rr[v] for v in local}})
        for bits in itertools.product((0, 1), repeat=2):
            combined = [2 - x if bit else x for bit, row in zip(bits, rows) for x in row]
            edges = parts[0] + parts[1]
            rr = dict.fromkeys(graph, 0)
            for (u, v), x in zip(edges, combined):
                rr[u] += x
                rr[v] += x
            bb = {v: 2 * graph.degree(v) - rr[v] for v in graph}
            assert any((x > 0 and rr[u] == rr[v]) or (x < 2 and bb[u] == bb[v])
                       for (u, v), x in zip(edges, combined))
            fixed_flip_failures += 1
        if r >= 3:
            rows[0][2] = 0
        else:
            rows[0] = [0, 0, 2, 2]
        rr = dict.fromkeys(graph, 0)
        for (u, v), x in zip(parts[0] + parts[1], rows[0] + rows[1]):
            rr[u] += x
            rr[v] += x
        verify(graph, {"status": "colored", "edge_order": parts[0] + parts[1],
                       "weights": rows[0] + rows[1], "red": rr,
                       "blue": {v: 2 * graph.degree(v) - rr[v] for v in graph}})
        repaired_block_pairs += 1
    output = {
        "actual_graph_colorings_verified": checked,
        "explicit_hypothesis_rejections": rejected + 2,
        "graphs_with_adjacent_shared_vertices": adjacent_boundary,
        "piece_complements_used": complements, "maximum_original_degree": maximum_degree,
        "maximum_piece_count": maximum_blocks, "finite_sign_identities": sign_identities,
        "fixed_whole_piece_flip_failures_verified": fixed_flip_failures,
        "explicit_regular_block_pair_repairs_verified": repaired_block_pairs,
        "damaged_local_coloring_rejected": True, "all_checks_passed": True,
        "general_subcubic_draft_assumed": False,
        "mother_conjecture_proved": False,
        "scope": "Given locally colored pieces, tree incidence and strict interval separation; cycles/cubic block corollary.",
        "seconds": round(time.monotonic() - started, 3)}
    path = Path(__file__).parent
    (path / "piece_tree_gluing_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    (path / "piece_tree_gluing_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
