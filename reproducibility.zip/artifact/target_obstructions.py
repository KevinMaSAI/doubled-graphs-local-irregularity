"""Exact cut/parity certificates for small fixed-target factor problems.

Enumerates 3^n disjoint S,T pairs and is intended for research-sized examples.
It does not choose red-degree targets or solve the mother conjecture in general.
"""
import itertools
from numbers import Integral

import networkx as nx


def parity_defect_lower_bound(graph, red_targets):
    """Polynomial-time T-join lower bound for the number of bad colored copies.

    Contract the free-edge components. Every realization's bad copies have odd
    quotient degree exactly at components with odd target sum. The bound does
    not enforce capacities or component factors, and need not be attained.
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if set(red_targets)!=set(graph) or any(
        not isinstance(t,Integral) or not 0<=t<=2*graph.degree(v)
        for v,t in red_targets.items()):
        raise ValueError('Integer red targets in the degree ranges are required.')
    blue={v:2*graph.degree(v)-red_targets[v] for v in graph}
    free=nx.Graph();free.add_nodes_from(graph)
    forced=[]
    for u,v in graph.edges():
        same_red=red_targets[u]==red_targets[v]
        same_blue=blue[u]==blue[v]
        if same_red and same_blue:
            return {'status':'both_colors_equal','edge':(u,v)}
        if same_red or same_blue:forced.append((u,v))
        else:free.add_edge(u,v)
    components=[list(c) for c in nx.connected_components(free)]
    owner={v:i for i,c in enumerate(components) for v in c}
    quotient=nx.Graph();quotient.add_nodes_from(range(len(components)))
    for u,v in forced:
        if owner[u]!=owner[v]:quotient.add_edge(owner[u],owner[v])
    odd={i for i,c in enumerate(components) if sum(red_targets[v] for v in c)%2}
    metric=nx.Graph();metric.add_nodes_from(odd)
    for source in odd:
        distances=nx.single_source_shortest_path_length(quotient,source)
        for target in odd:
            if source<target and target in distances:
                metric.add_edge(source,target,weight=distances[target])
    pairing=nx.min_weight_matching(metric,weight='weight')
    if 2*len(pairing)!=len(odd):
        return {'status':'no_parity_join','components':components,'odd_components':sorted(odd)}
    lower=sum(metric[u][v]['weight'] for u,v in pairing)
    paths=[nx.shortest_path(quotient,u,v) for u,v in pairing]
    return {'status':'lower_bound','lower_bound':lower,'components':components,
            'odd_components':sorted(odd),'quotient_edges':list(quotient.edges()),
            'paired_component_paths':paths}


def factor_cut_certificate(graph, targets, max_states=1000000):
    """Classify an f-factor of 2*graph as feasible, capacity, or parity blocked.

    targets are residual degrees, with no exterior offsets. For every disjoint
    S,T, tests g=t(S)+2*d_{K-S}(T)-t(T) and g>=odd_t(K-S-T).
    """
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if set(targets)!=set(graph):
        raise ValueError('Exactly one target for each vertex is required.')
    if any(not isinstance(t,Integral) for t in targets.values()):
        raise ValueError('Targets must be integers.')
    nodes=list(graph)
    if 3**len(nodes)>max_states:
        raise ValueError('The explicit 3^n certificate search exceeds max_states.')
    best_capacity=None;best_integer=None
    for parts in itertools.product(range(3),repeat=len(nodes)):
        s={v for v,p in zip(nodes,parts) if p==1}
        t={v for v,p in zip(nodes,parts) if p==2}
        rest=set(nodes)-s-t
        capacity=sum(targets[v] for v in s)-sum(targets[v] for v in t)
        capacity+=2*sum(sum(w not in s for w in graph[v]) for v in t)
        odd=[list(c) for c in nx.connected_components(graph.subgraph(rest))
             if sum(targets[v] for v in c)%2]
        slack=capacity-len(odd)
        certificate={'S':list(s),'T':list(t),'capacity_slack':int(capacity),
                     'odd_components':odd,'integer_slack':int(slack)}
        if best_capacity is None or capacity<best_capacity['capacity_slack']:
            best_capacity=certificate
        if best_integer is None or slack<best_integer['integer_slack']:
            best_integer=certificate
    if best_capacity['capacity_slack']<0:
        status='capacity_obstruction';chosen=best_capacity
    elif best_integer['integer_slack']<0:
        status='parity_obstruction';chosen=best_integer
    else:
        status='integer_feasible';chosen=None
    return {'status':status,'minimum_capacity_slack':best_capacity['capacity_slack'],
            'minimum_integer_slack':best_integer['integer_slack'],
            'certificate':chosen,'states_checked':3**len(nodes)}


def coloring_target_certificate(graph, red_targets, max_states=1000000):
    """Reduce actual red/blue legality to a doubled-free-graph certificate."""
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A finite simple undirected graph is required.')
    if set(red_targets)!=set(graph):
        raise ValueError('Exactly one target for each vertex is required.')
    if any(not isinstance(t,Integral) or not 0<=t<=2*graph.degree(v)
           for v,t in red_targets.items()):
        return {'status':'target_out_of_range'}
    blue={v:2*graph.degree(v)-red_targets[v] for v in graph}
    forced_red=[];forced_blue=[];free=nx.Graph()
    free.add_nodes_from(graph)
    residual=dict(red_targets)
    for u,v in graph.edges():
        same_red=red_targets[u]==red_targets[v]
        same_blue=blue[u]==blue[v]
        if same_red and same_blue:
            return {'status':'both_colors_equal','edge':(u,v)}
        if same_red:
            forced_blue.append((u,v))
        elif same_blue:
            forced_red.append((u,v));residual[u]-=2;residual[v]-=2
        else:
            free.add_edge(u,v)
    result=factor_cut_certificate(free,residual,max_states=max_states)
    return {**result,'free_edges':list(free.edges()),'residual_targets':residual,
            'forced_red':forced_red,'forced_blue':forced_blue,'blue_degrees':blue}
