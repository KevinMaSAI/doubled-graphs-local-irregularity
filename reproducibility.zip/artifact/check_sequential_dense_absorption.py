"""Check entire graphs with many inside boundary vertices and several dense regions."""

import json
from pathlib import Path
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from low_side_ports import prepare_low_side
from sequential_dense_absorption import complete_dense_regions


def star_case():
    H = nx.complete_graph(34)
    G = H.copy()
    given = {frozenset((v, 34)): 1 for v in H}
    given.update({frozenset((34, v)): 2 for v in range(35, 43)})
    G.add_edges_from(tuple(e) for e in given)
    return G, [set(H)], given


def partial_case():
    H = nx.complete_graph(26)
    G, given = H.copy(), {}
    next_node = 26
    for v in range(12):
        center = next_node
        next_node += 1
        given[frozenset((v, center))] = v % 3
        for unused in range(6):
            given[frozenset((center, next_node))] = 2
            next_node += 1
    G.add_edges_from(tuple(e) for e in given)
    return G, [set(H)], given


def pair_case(noncomplete=False, low=False):
    n, m = (90, 91) if noncomplete else (42, 43)
    if noncomplete:
        F = nx.random_regular_graph(3, n, seed=2026102784)
        F.remove_edge(*next(iter(F.edges())))
        first = nx.complement(F)
        F = nx.cycle_graph(m)
        F.add_edge(0, 2)
        second = nx.relabel_nodes(nx.complement(F), lambda v: v+n)
    else:
        first = nx.complete_graph(n)
        second = nx.complete_graph(range(n, n+m))
    G = nx.compose(first, second)
    cross_count = 20 if low else n
    G.add_edges_from((v, n+v) for v in range(cross_count))
    if low:
        high_ends = [20, n+20, 21, n+21, 22, n+22, 23, n+23, 24, n+24, 25, n+25]
        next_node = n+m
        for template in (nx.cycle_graph(3), nx.complete_bipartite_graph(3, 3), nx.path_graph(3)):
            mapping = {v: next_node+i for i, v in enumerate(template)}
            component = nx.relabel_nodes(template, mapping)
            G.update(component)
            for u in component:
                G.add_edge(u, high_ends.pop(0))
            next_node += len(component)
        prepared = prepare_low_side(G, [set(first), set(second)])
        assert prepared["status"] == "prepared", prepared
        given = prepared["given_weights"]
    else:
        given = {}
    given.update({frozenset((v, n+v)): v % 3 for v in range(cross_count)})
    return G, [set(first), set(second)], given


def main():
    started = time.monotonic()
    records, witnesses = [], {}
    for name, fixture in (("shared_forbidden_counts", star_case),
                          ("partial_mixed_ports", partial_case),
                          ("two_cliques", pair_case),
                          ("two_noncomplete_cores", lambda: pair_case(noncomplete=True)),
                          ("bipartite_cactus_low_side", lambda: pair_case(low=True))):
        G, regions, given = fixture()
        low = set(G)-set().union(*regions)
        old_R, old_B = dict.fromkeys(low, 0), dict.fromkeys(low, 0)
        for edge, x in given.items():
            for v in edge:
                if v in low:
                    old_R[v] += x; old_B[v] += 2-x
        result = complete_dense_regions(G, regions, given)
        assert result["status"] == "colored", result
        verify(G, result)
        values = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
        assert all(values[e] == x for e, x in given.items())
        assert all(result["red"][v] == old_R[v] and result["blue"][v] == old_B[v] for v in low)
        if name == "shared_forbidden_counts":
            assert result["plans"][0]["required_n"] == 34
            assert result["red"][34] == 50 and result["blue"][34] == 34
            assert all(result["red"][v] not in {34, 50} for v in regions[0])
        if name == "partial_mixed_ports":
            assert result["plans"][0]["required_n"] == 26
        record = {"name": name, "vertices": len(G), "edges": G.number_of_edges(),
                  "minimum_degree": min(dict(G.degree()).values()), "regions": len(regions),
                  "region_orders": list(map(len, regions)),
                  "region_requirements": [p["required_n"] for p in result["plans"]],
                  "extra_slots": [p["extra_target_slots"] for p in result["plans"]],
                  "nonregular": len(set(dict(G.degree()).values())) > 1,
                  "global_dense_bound_met": 8*min(dict(G.degree()).values()) >= 7*len(G)+6}
        records.append(record)
        print(json.dumps(record), flush=True)
        if name in ("two_cliques", "two_noncomplete_cores", "bipartite_cactus_low_side"):
            witnesses[name] = {"recipe": record, "regions": [sorted(s) for s in regions],
                               "given": [[*tuple(e), x] for e, x in given.items()],
                               "edges": [[u, v, x] for (u, v), x in
                                         zip(result["edge_order"], result["weights"])],
                               "red": result["red"], "blue": result["blue"]}
        if name == "two_cliques":
            factors = [{e: values[e] for e in map(frozenset, G.subgraph(part).edges())} for part in regions]
            again = complete_dense_regions(G, regions, given, factors)
            verify(G, again)
            assert again["red"] == result["red"] and again["blue"] == result["blue"]
    report = {"whole_graph_absorptions_verified": len(records),
              "all_fixed_colors_and_low_counts_preserved": True,
              "multiple_regions_without_global_vertex_coloring": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "records": records, "seconds": round(time.monotonic()-started, 3)}
    out = Path(__file__).parent
    (out/"sequential_dense_absorption_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (out/"sequential_dense_absorption_witnesses.json").write_text(json.dumps(witnesses, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
