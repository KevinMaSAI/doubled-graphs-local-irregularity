"""Check simultaneous absorbers, all boundary colors, and actual doubled copies."""

import json
from pathlib import Path
import random
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from factor_cut_certificate import recover_factor_on_cut
from low_side_ports import prepare_low_side
from region_partition_absorption import complete_region_partition, partition_absorption_plan


def fixture(kind):
    inner = nx.complete_bipartite_graph(282, 283)
    graph = inner.copy()
    regions = [set(inner)]
    base = {v: int(v >= 282) for v in inner}
    if kind == "two_regions":
        second = nx.relabel_nodes(inner, lambda v: v+565)
        graph.update(second)
        regions.append(set(second))
        base.update({v+565: int(v >= 282) for v in inner})
        cross = [(0, 847), (1, 848), (282, 565)]
        graph.add_edges_from(cross)
        graph.add_edges_from((1130, v) for v in (2, 283, 567, 849))
    elif kind in ("two_ports", "four_ports"):
        ends = (0, 282) if kind == "two_ports" else (0, 1, 282, 283)
        graph.add_edges_from((565, v) for v in ends)
    elif kind == "path_low":
        graph.add_edges_from([(565, 566), (566, 567)])
        graph.add_edges_from((565+i, i) for i in range(3))
    else:
        low = {"triangle_low": nx.cycle_graph(3),
               "bipartite_low": nx.complete_bipartite_graph(3, 3),
               "partial_K2": nx.empty_graph(1)}[kind]
        graph.update(nx.relabel_nodes(low, lambda v: v+565))
        graph.add_edges_from((565+i, i) for i in low)
    return graph, regions, base


def boundary_avoiding_explicit_labels(graph, regions, base, given):
    high = set().union(*regions)
    low = set(graph)-high
    R, B = dict.fromkeys(low, 0), dict.fromkeys(low, 0)
    for (u, v), x in ((tuple(edge), x) for edge, x in given.items()):
        for w in (u, v):
            if w in low:
                R[w] += x
                B[w] += 2-x
    labels = dict(base)
    for v in high:
        ports = [u for u in graph[v] if u in low]
        if not ports:
            continue
        # These fixtures have disjoint left-side boundary vertices, one port each.
        assert base[v] == 0 and len(ports) == 1
        u = ports[0]
        x = given[frozenset((u, v))]
        labels[v] = next(j for j in (0, 2, 3) if
            (x == 0 or R[u] % 8 not in {2*j % 8, (2*j+1) % 8}) and
            (x == 2 or B[u] % 9 not in {2*j % 9, (2*j-1) % 9}))
    assert all(labels[u] != labels[v] for u, v in graph.subgraph(high).edges())
    return labels


def label_copy_audit():
    rng = random.Random(2026102773)
    for _ in range(12000):
        c, port_count = rng.randrange(2, 15), rng.randrange(12)
        j = rng.randrange(c)
        ports = []
        for unused in range(port_count):
            x, R, B = rng.randrange(3), rng.randrange(10000), rng.randrange(10000)
            B += (R+B) % 2
            ports.append((x, R, B))
        L = 1+sum(1+int(x == 1) for x, R, B in ports)
        C = c*L
        p, q = 2*C, 2*C+1
        good = [label for label in range(j, C, c) if all(
            (x == 0 or R % p not in {2*label % p, (2*label+1) % p}) and
            (x == 2 or B % q not in {2*label % q, (2*label-1) % q})
            for x, R, B in ports)]
        assert good
        assert all(label % c == j for label in good)
    return 12000


def main():
    started = time.monotonic()
    labels_checked = label_copy_audit()
    records = []
    witness = None
    for kind in ("two_ports", "four_ports", "path_low", "triangle_low",
                 "bipartite_low", "partial_K2", "two_regions"):
        graph, regions, base = fixture(kind)
        partial = prepare_low_side(graph, regions)
        assert partial["status"] == "prepared", partial
        given = partial["given_weights"]
        palette = None
        if kind == "partial_K2":
            base = boundary_avoiding_explicit_labels(graph, regions, base, given)
            palette = 4
        if kind == "two_regions":
            given.update({frozenset(e): x for e, x in
                          [((0, 847), 0), ((1, 848), 1), ((282, 565), 2)]})
        plan = partition_absorption_plan(graph, regions, base, given, palette)
        assert plan["status"] == "planned", plan
        assert 2 <= plan["palette_size"] <= 4
        factors = []
        for part in regions:
            inner = graph.subgraph(part)
            local_labels = {v: plan["coloring"][v] for v in part}
            A = {v: plan["red_offsets"][v] for v in part}
            B = {v: plan["blue_offsets"][v] for v in part}
            left = [v for v in part if (v % 565) < 282]
            right = [v for v in part if (v % 565) >= 282]
            local = recover_factor_on_cut(inner, local_labels, left, right, A, B,
                                          palette_size=plan["palette_size"])
            assert local["status"] == "colored", (kind, local)
            factors.append(local["factor_edges"])
        result = complete_region_partition(graph, regions, base, given, factors, palette)
        assert result["status"] == "colored"
        verify(graph, result)
        actual = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
        assert all(actual[e] == x for e, x in given.items())
        assert all(result["red"][v] == plan["outside_red"][v] and
                   result["blue"][v] == plan["outside_blue"][v]
                   for v in plan["outside_red"])
        record = {"kind": kind, "vertices": len(graph), "edges": graph.number_of_edges(),
                  "region_count": len(regions), "palette_size": plan["palette_size"],
                  "class_copy_counts": plan["class_copy_counts"],
                  "original_minimum_degree": min(dict(graph.degree()).values()),
                  "region_minimum_degrees": [min(dict(graph.subgraph(s).degree()).values())
                                             for s in regions],
                  "boundary_vertex_count": sum(any(u in plan["outside_red"] for u in graph[v])
                                               for v in plan["coloring"]),
                  "low_methods": [r["method"] for r in partial["reports"]],
                  "explicit_labels": palette is not None,
                  "nonbipartite": not nx.is_bipartite(graph),
                  "biconnected": nx.is_biconnected(graph)}
        records.append(record)
        print(json.dumps(record, ensure_ascii=False), flush=True)
        if kind == "two_regions":
            witness = {"recipe": record, "edges": [[u, v, x] for (u, v), x in
                zip(result["edge_order"], result["weights"])],
                "regions": [sorted(s) for s in regions], "labels": plan["coloring"],
                "given": [[*tuple(e), x] for e, x in given.items()],
                "red": result["red"], "blue": result["blue"]}
    # Failing a method's hypotheses is never a counterexample to the conjecture.
    graph = nx.cycle_graph(4)
    fail = partition_absorption_plan(graph, [set(graph)], {v: v % 2 for v in graph}, {})
    assert fail["status"] == "method_not_applicable"
    assert fail["reason"] == "region_minimum_degree_too_small"
    graph, regions, base = fixture("two_regions")
    partial = prepare_low_side(graph, regions)
    bad = dict(base)
    bad[847] = bad[0]
    try:
        partition_absorption_plan(graph, regions, bad, partial["given_weights"])
    except ValueError as error:
        assert "entire high-vertex" in str(error)
    else:
        raise AssertionError("Cross-region improper labels were accepted.")
    output = {"whole_graph_absorptions_verified": len(records),
              "class_copy_label_states_checked": labels_checked,
              "all_given_edge_colors_and_low_counters_preserved": True,
              "multiple_regions_with_all_three_cross_weights": True,
              "method_hypothesis_failures_rejected": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "records": records, "seconds": round(time.monotonic()-started, 3)}
    path = Path(__file__).parent
    (path / "region_partition_absorption_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    (path / "region_partition_absorption_witness.json").write_text(
        json.dumps(witness, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(json.dumps({k: v for k, v in output.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
