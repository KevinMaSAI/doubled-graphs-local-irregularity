"""Two mixed long ports; only SHORT-incident roots must stay in SAFE."""
import itertools
import json
from functools import lru_cache
from pathlib import Path
import networkx as nx
from weak_two_marked_certificate import verify_certificate

SAFE={0,1,3,5,6}
@lru_cache(None)
def _records():
    data=json.loads(Path(__file__).with_name("weak_two_marked_interfaces.json").read_text(encoding="utf-8"))
    verify_certificate(data)
    return {(tuple(r["left"]),tuple(r["right"]),r["length"]):r["witness"] for r in data["records"]}


def chain_word(length,L,first,R,last):
    current={(first,L)}; histories=[]
    for _ in range(length-1):
        following={}
        for old in sorted(current):
            x,r=old
            for y,p in itertools.product(range(3),(0,2)):
                red=x+y+p
                if red in SAFE and red!=r:following.setdefault((y,red),(old,p))
        histories.append(following);current=set(following)
    ending=next((s for s in sorted(current) if s[0]==last and s[1]!=R),None)
    assert ending is not None
    state=ending;trace=[state];ports=[]
    for history in reversed(histories):
        state,p=history[state];trace.append(state);ports.append(p)
    trace.reverse();ports.reverse()
    return [s[0] for s in trace],[L]+[s[1] for s in trace[1:]]+[R],ports


def arm_layers(length,marked):
    base={}
    for x in range(3):
        for long in ((1,) if marked else (0,2)):
            for short in (0,2):
                r=x+long+short
                if r in SAFE and (not marked or r!=3):base.setdefault((x,r),(long,short))
    layers=[base]
    for _ in range(length-1):
        following={}
        for x in range(3):
            for child in sorted(layers[-1]):
                y,s=child
                for p in (0,2):
                    r=x+y+p
                    if r in SAFE and r!=s:following.setdefault((x,r),(child,p))
        layers.append(following)
    return layers


def weak_two_marked_tree(core,short_flags,marks):
    """short_flags[v] matches the private port order; marks are (v,index)."""
    assert nx.is_tree(core) and nx.is_bipartite(core)
    assert all(len(short_flags[v])==3-core.degree(v) for v in core)
    assert len(marks)==len(set(marks))==2
    assert all(not short_flags[v][j] for v,j in marks)
    assert sum(not flag for flags in short_flags.values() for flag in flags)==4
    special=[v for v in core if not any(short_flags[v])]
    assert len(special)==2
    connector=nx.shortest_path(core,*special)
    assert (len(connector)-1)%2==1
    def branches(root,next_vertex):
        result=[]
        for j,flag in enumerate(short_flags[root]):
            assert not flag
            result.append({"path":[root],"slot":(root,j),"marked":(root,j) in marks})
        for neighbor in core[root]:
            if neighbor==next_vertex:continue
            path=[root,neighbor];previous,current=root,neighbor
            while core.degree(current)==2:
                assert current not in special and short_flags[current]==[True]
                other=next(v for v in core[current] if v!=previous)
                path.append(other);previous,current=current,other
            assert core.degree(current)==1 and sorted(short_flags[current])==[False,True]
            j=short_flags[current].index(False)
            result.append({"path":path,"slot":(current,j),"marked":(current,j) in marks})
        assert len(result)==2
        return result
    sides=[branches(connector[0],connector[1]),branches(connector[-1],connector[-2])]
    if sum(b["marked"] for b in sides[0])==0:
        sides.reverse();connector.reverse()
    def type_of(branch):
        n=len(branch["path"])-1
        return ("m"+str(min(n,6))) if branch["marked"] else "u"+str(min(n,3))
    both_left=all(b["marked"] for b in sides[0])
    for side in sides:
        side.sort(key=(lambda b:type_of(b)) if both_left else (lambda b:(not b["marked"],type_of(b))))
    key=(tuple(map(type_of,sides[0])),tuple(map(type_of,sides[1])),min(len(connector)-1,7))
    witness=_records()[key]
    boundary={v:[None]*len(short_flags[v]) for v in core};red={};values={}
    def put(path,word):
        for u,v,x in zip(path,path[1:],word):
            e=frozenset((u,v));assert e not in values;values[e]=x
    x,L=witness["left_state"];y,R=witness["right_state"]
    word,reds,ports=chain_word(len(connector)-1,L,x,R,y)
    put(connector,word);red.update(zip(connector,reds))
    for v,p in zip(connector[1:-1],ports):
        assert short_flags[v]==[True];boundary[v][0]=p
    for side_index,side in enumerate(sides):
        entries=witness["left_branches" if side_index==0 else "right_branches"]
        for branch,(first,s) in zip(side,entries):
            path=branch["path"];v,j=branch["slot"]
            if len(path)==1:
                boundary[v][j]=first;continue
            layers=arm_layers(len(path)-1,branch["marked"])
            state=(first,s);incoming=first
            for k,current in enumerate(path[1:]):
                put([path[k],current],[incoming]);red[current]=state[1]
                remaining=len(path)-2-k
                info=layers[remaining][state]
                if remaining==0:
                    long,short=info
                    boundary[current][j]=long
                    boundary[current][short_flags[current].index(True)]=short
                else:
                    state,p=info
                    assert short_flags[current]==[True]
                    boundary[current][0]=p;incoming=state[0]
    for v in core:
        assert all(p in (0,1,2) for p in boundary[v])
        assert red[v]==sum(boundary[v])+sum(values[frozenset((v,w))] for w in core[v])
        if any(short_flags[v]):assert red[v] in SAFE
    assert all(red[u]!=red[v] for u,v in core.edges())
    assert all(boundary[v][j]==1 and red[v]!=3 for v,j in marks)
    assert all(p in (0,2) for v in core for j,p in enumerate(boundary[v]) if (v,j) not in marks)
    edges=list(core.edges())
    return {"status":"weighted","edge_order":edges,"weights":[values[frozenset(e)] for e in edges],
            "boundary_ports":boundary,"red":red,"marked_ports":marks,"kernel_key":key,
            "mother_conjecture_proved":False}
