"""Independent checks of mod-3 sums and arbitrary cubic 4-subdivisions."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from cubic_four_subdivision import color_cubic_partial_subdivision
from mod3_edge_weighting import proper_012_with_offsets, realize_mod3_sums


def verify_total_weighting(graph, result, offsets):
    assert result["status"] == "weighted"
    edges = result["edge_order"]
    assert len(edges) == graph.number_of_edges() == len(result["weights"])
    sums = {v: offsets[v] for v in graph}
    for (u, v), value in zip(edges, result["weights"]):
        assert value in (0, 1, 2)
        sums[u] += value
        sums[v] += value
    assert sums == result["totals"]
    assert all(sums[v] % 3 == result["target"][v] for v in graph)
    assert all(sums[u] % 3 != sums[v] % 3 for u, v in graph.edges())


def main():
    started = time.monotonic()
    rng = random.Random(20261030)
    # Enumerate actual edge assignments independently, then compare every
    # prescribed target with the bipartite alternating-sum obstruction.
    image_graphs, target_checks = 0, 0
    for graph in nx.graph_atlas_g():
        if not 2 <= len(graph) <= 5 or not nx.is_connected(graph) or graph.number_of_edges() > 7:
            continue
        vertices, edges = list(graph), list(graph.edges())
        image = set()
        for values in itertools.product(range(3), repeat=len(edges)):
            sums = dict.fromkeys(graph, 0)
            for (u, v), value in zip(edges, values):
                sums[u] += value
                sums[v] += value
            image.add(tuple(sums[v] % 3 for v in vertices))
        partition = nx.bipartite.color(graph) if nx.is_bipartite(graph) else None
        for vector in itertools.product(range(3), repeat=len(vertices)):
            expected = (partition is None or
                        sum((1 if partition[v] else -1) * value for v, value in zip(vertices, vector)) % 3 == 0)
            assert (vector in image) == expected
            result = realize_mod3_sums(graph, dict(zip(vertices, vector)))
            assert (result["status"] == "realized") == expected
            if expected:
                actual = dict.fromkeys(graph, 0)
                for (u, v), value in zip(result["edge_order"], result["weights"]):
                    actual[u] += value
                    actual[v] += value
                assert tuple(actual[v] % 3 for v in vertices) == vector
            target_checks += 1
        image_graphs += 1
    offset_cases, unsupported = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        eligible = nx.is_bipartite(graph) or max(nx.core_number(graph).values()) <= 2
        for variant in range(3):
            offsets = {v: 0 if variant == 0 else rng.randrange(-8, 9) for v in graph}
            result = proper_012_with_offsets(graph, offsets)
            if eligible:
                verify_total_weighting(graph, result, offsets)
                offset_cases += 1
            else:
                assert result["status"] == "method_not_applicable"
                unsupported += 1
    component_modes, pure_pairs, target_adjustment_counts = set(), set(), set()
    witnesses, full_cases, subdivided_matching_cases, adjacent_subdivided_cases = {}, 0, 0, 0
    def check(name, base, selected, lengths=4):
        nonlocal full_cases, subdivided_matching_cases, adjacent_subdivided_cases
        result = color_cubic_partial_subdivision(base, selected, lengths)
        verify(result["graph"], result)
        full_cases += 1
        covered = [v for edge in selected for v in edge]
        if len(set(covered)) == len(covered):
            subdivided_matching_cases += 1
        else:
            adjacent_subdivided_cases += 1
        for pair in result["ports"]:
            pure_pairs.add(tuple(sorted(pair)))
        for component in result["retained_components"]:
            kind = component["kind"]
            component_modes.add(kind)
            if kind == "balanced_bipartite_target":
                target_adjustment_counts.add(len(component["adjusted_bipartite_vertices"]))
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "component": component,
                    "subdivided_edges": result["subdivided_edges"], "ports": result["ports"],
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    subset_records = []
    for name, base in [
        ("K4", nx.complete_graph(4)),
        ("triangular_prism", nx.circular_ladder_graph(3)),
        ("K33", nx.complete_bipartite_graph(3, 3)),
    ]:
        edges = list(base.edges())
        count = 0
        for mask in range(1, 1 << len(edges)):
            selected = [edge for i, edge in enumerate(edges) if mask & (1 << i)]
            check(f"{name}_subset_{mask}_all_four", base, selected)
            lengths = {frozenset(edge): 4 + (i + mask) % 4 for i, edge in enumerate(selected)}
            check(f"{name}_subset_{mask}_vary_lengths", base, selected, lengths)
            count += 1
        subset_records.append({"base": name, "all_nonempty_edge_subsets": count,
                               "length_configurations_per_subset": 2})
    bridged = nx.disjoint_union(nx.complete_graph(4), nx.complete_graph(4))
    bridged.remove_edges_from(((0, 1), (4, 5)))
    bridged.add_edges_from(((0, 8), (8, 1), (4, 9), (9, 5), (8, 9)))
    special_records = []
    for name, base in [
        ("Petersen", nx.petersen_graph()), ("Heawood", nx.heawood_graph()),
        ("dodecahedral", nx.dodecahedral_graph()), ("Desargues", nx.desargues_graph()),
        ("Moebius_Kantor", nx.moebius_kantor_graph()), ("with_bridge", bridged),
    ]:
        edges = list(base.edges())
        count = 0
        for index, edge in enumerate(edges):
            check(f"{name}_single_{index}", base, [edge])
            check(f"{name}_retain_single_{index}", base, [other for other in edges if other != edge])
            count += 2
        check(f"{name}_all", base, edges)
        count += 1
        for variant in range(100):
            selected = [edge for edge in edges if rng.random() < rng.uniform(.1, .9)]
            if not selected:
                selected = edges[:1]
            lengths = {frozenset(edge): rng.randrange(4, 10) for edge in selected}
            check(f"{name}_random_subset_{variant}", base, selected, lengths)
            count += 1
        special_records.append({"base": name, "cases": count})
    random_cases, disconnected_bases = 0, 0
    for size in (8, 12, 18, 30, 50, 80):
        for variant in range(24):
            base = nx.random_regular_graph(3, size, seed=20261030 + 100 * size + variant)
            if not nx.is_connected(base):
                disconnected_bases += 1
                continue
            edges = list(base.edges())
            selected = [edge for edge in edges if rng.random() < .5]
            if not selected:
                selected = edges[:1]
            lengths = {frozenset(edge): rng.randrange(4, 12) for edge in selected}
            check(f"random_cubic_{size}_{variant}", base, selected, lengths)
            random_cases += 1
    base = nx.complete_graph(4)
    check("long_single_edge", base, [(0, 1)], 5000)
    check("long_all_edges", base, list(base.edges()), 5000)
    # A proper RED sum modulo 3 alone does not solve the original variable-
    # degree problem: P6 weights 0,1,2,2,1 have a blue conflict at the last edge.
    path = nx.path_graph(6)
    weights = (0, 1, 2, 2, 1)
    red = dict.fromkeys(path, 0)
    for (u, v), value in zip(path.edges(), weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * path.degree(v) - red[v] for v in path}
    assert all(red[u] % 3 != red[v] % 3 for u, v in path.edges())
    assert blue[4] == blue[5] == 1 and weights[-1] == 1
    expected = {"isolated_vertex", "isolated_edge_port_repair",
                "balanced_bipartite_target", "nonbipartite_three_color_target"}
    assert component_modes == expected
    assert pure_pairs == {(0, 0), (0, 2), (2, 2)}
    assert target_adjustment_counts == {0, 1, 2}
    summary = {"mod3_image_graphs": image_graphs, "all_prescribed_targets_checked": target_checks,
               "integer_offset_weightings_checked": offset_cases,
               "unsupported_offset_cases": unsupported, "all_subset_bases": subset_records,
               "other_named_bases": special_records, "random_connected_cubic_cases": random_cases,
               "random_disconnected_bases_skipped": disconnected_bases,
               "full_actual_copy_checked_colorings": full_cases,
               "cases_subdividing_a_matching": subdivided_matching_cases,
               "cases_with_adjacent_subdivided_edges": adjacent_subdivided_cases,
               "retained_component_modes": sorted(component_modes),
               "observed_pure_port_pairs": [list(pair) for pair in sorted(pure_pairs)],
               "bipartite_target_adjustment_counts": sorted(target_adjustment_counts),
               "maximum_tested_path_length": 5000, "checks_passed": True,
               "one_sum_not_mother_P6_boundary_checked": True,
               "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
               "scope": "Finite independent checks of the implementation; the infinite theorem has a separate proof."}
    Path(__file__).with_name("cubic_four_subdivision_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("cubic_four_subdivision_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
