"""Root-port coloring on a supplied independent-side path/cycle partition.

The graph degrees are not globally bounded. Non-isolated S vertices need at
least two T-neighbors, and S-edge endpoint degrees differ by at most one.
No universal existence of this layout or of admissible root ports is claimed.
"""


def _layout(vertices, edges, T):
    vertices, edges, T = list(vertices), [tuple(e) for e in edges], set(T)
    V = set(vertices)
    if not vertices or len(V) != len(vertices) or not T <= V:
        raise ValueError("Use distinct vertices and a subset T.")
    adjacency, inventory = {v: [] for v in vertices}, set()
    for i, (u, v) in enumerate(edges):
        key = frozenset((u, v))
        if len(key) != 2 or not key <= V or key in inventory:
            raise ValueError("Use a simple undirected graph.")
        inventory.add(key); adjacency[u].append((v, i)); adjacency[v].append((u, i))
    D = {v: len(adjacency[v]) for v in vertices}; S = V-T
    inside = {v: [u for u, i in adjacency[v] if u in S] for v in S}
    cross = {v: [(u, i) for u, i in adjacency[v] if u in T] for v in S}
    if any(u in T and v in T for u, v in edges) or any(len(inside[v]) > 2 for v in S):
        return {"status": "not_applicable", "reason": "T must be independent; S internal degree at most two.",
                "mother_conjecture_proved": False}
    if any(inside[v] and len(cross[v]) < 2 for v in S) or any(
            abs(D[u]-D[v]) > 1 for u, v in edges if u in S and v in S):
        return {"status": "not_applicable", "reason": "Need at least two cross neighbors at non-isolated S vertices and S-edge degree gaps at most one.",
                "mother_conjecture_proved": False}
    groups, seen, component_of = [], set(), {}
    for start in vertices:
        if start not in S or start in seen:
            continue
        group, seen = [start], seen | {start}
        for v in group:
            for u in inside[v]:
                if u not in seen:
                    seen.add(u); group.append(u)
        cycle = all(len(inside[v]) == 2 for v in group)
        root = group[0] if cycle else next(v for v in group if len(inside[v]) <= 1)
        order, previous = [root], None
        while True:
            u = next((u for u in inside[order[-1]] if u != previous and u != root), None)
            if u is None:
                break
            previous = order[-1]; order.append(u)
        assert set(order) == set(group) and len(order) == len(group)
        admissible = []
        if len(order) % 2:
            if not cycle:
                admissible = order[::2]
            else:
                for j, v in enumerate(order):
                    left, right = order[(j-1) % len(order)], order[(j+1) % len(order)]
                    if not (D[left] == D[right] and abs(D[left]-D[v]) == 1):
                        admissible.append(v)
                assert admissible  # All strict extrema would alternate on an odd circle.
        number = len(groups)
        for v in order:
            component_of[v] = number
        groups.append({"vertices": order, "cycle": cycle, "admissible_roots": admissible})
    return {"vertices": vertices, "edges": edges, "T": T, "S": S, "D": D,
            "inside": inside, "cross": cross, "groups": groups, "component_of": component_of}


def inspect_root_layout(vertices, edges, T):
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    return {"status": "applicable", "S_components": g["groups"],
            "odd_component_indices": [i for i, c in enumerate(g["groups"]) if len(c["vertices"]) % 2],
            "mother_conjecture_proved": False}


def _validate_roots(g, roots):
    roots = list(roots)
    if len(set(roots)) != len(roots):
        raise ValueError("Use one distinct admissible root per odd S component.")
    odd = {i for i, c in enumerate(g["groups"]) if len(c["vertices"]) % 2}
    if any(v not in g["S"] or v not in g["groups"][g["component_of"][v]]["admissible_roots"] for v in roots):
        raise ValueError("A proposed root is inadmissible for its component.")
    selected = [g["component_of"][v] for v in roots]
    if set(selected) != odd or len(selected) != len(odd):
        raise ValueError("Cover exactly the odd components, once each.")
    return set(roots)


def color_root_ports(vertices, edges, T, roots, mixed_port_edges):
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    roots = _validate_roots(g, roots)
    index = {frozenset(e): i for i, e in enumerate(g["edges"])}
    requested = [frozenset(e) for e in mixed_port_edges]
    if len(set(requested)) != len(requested) or any(e not in index for e in requested):
        raise ValueError("Use a set of existing root-to-T mixed ports.")
    mixed_ports = {index[e] for e in requested}; md = dict.fromkeys(g["vertices"], 0)
    for i in mixed_ports:
        u, v = g["edges"][i]
        if not ((u in roots and v in g["T"]) or (v in roots and u in g["T"])):
            raise ValueError("Mixed cross ports may only join chosen roots to T.")
        md[u] += 1; md[v] += 1
    if any(md[v] % 2 != 0 for v in g["T"]) or any(md[v] % 2 != 1 for v in roots):
        raise ValueError("Root mixed degrees must be odd, and T mixed degrees even.")
    if any(g["inside"][v] and md[v] not in (1, 3) for v in roots):
        return {"status": "root_capacity_not_supported", "mother_conjecture_proved": False,
                "reason": "Non-isolated roots need one or three mixed cross ports for this palette."}
    values = {i: 0 for i in range(len(g["edges"]))}; targets = {}; details = []
    for i in mixed_ports:
        values[i] = 1

    def fill_even_segment(order, phase=0, cycle=False):
        assert len(order) % 2 == 0
        for j, v in enumerate(order):
            targets[v] = 1+4*((j+phase) % 2)
        for j in range(0, len(order), 2):
            values[index[frozenset((order[j], order[j+1]))]] = 1

    for component in g["groups"]:
        order = component["vertices"]; n = len(order)
        if n % 2 == 0:
            fill_even_segment(order, cycle=component["cycle"])
            details.append(dict(component, chosen_root=None, phase=0))
            continue
        root = next(v for v in order if v in roots); j = order.index(root)
        if n == 1:
            targets[root] = md[root]
            details.append(dict(component, chosen_root=root, segments=[]))
            continue
        targets[root] = 3
        if component["cycle"]:
            rest = order[j+1:]+order[:j]
            phase = next(p for p in (0, 1) if
                         2*g["D"][rest[0]]-(1+4*p) != 2*g["D"][root]-3 and
                         2*g["D"][rest[-1]]-(1+4*((len(rest)-1+p) % 2)) != 2*g["D"][root]-3)
            fill_even_segment(rest, phase)
            details.append(dict(component, chosen_root=root, segments=[rest], phases=[phase]))
        else:
            segments, phases = [], []
            for segment in (order[:j], order[j+1:]):
                if not segment:
                    continue
                neighbor = segment[-1] if segment[-1] in g["inside"][root] else segment[0]
                desired = 5 if g["D"][root]-g["D"][neighbor] == 1 else 1
                phase = ((desired-1)//4) ^ (segment.index(neighbor) % 2)
                fill_even_segment(segment, phase)
                segments.append(segment); phases.append(phase)
            details.append(dict(component, chosen_root=root, segments=segments, phases=phases))
    assert set(targets) == g["S"]
    for v in g["S"]:
        cross = [i for u, i in g["cross"][v] if i not in mixed_ports]
        existing = sum(values[i] for i, e in enumerate(g["edges"]) if v in e)
        extra = targets[v]-existing
        assert extra >= 0 and extra % 2 == 0 and extra//2 <= len(cross)
        for i in cross[:extra//2]:
            values[i] = 2
    R, B = dict.fromkeys(g["vertices"], 0), dict.fromkeys(g["vertices"], 0)
    for i, (u, v) in enumerate(g["edges"]):
        for copy in range(2):
            counts = R if copy < values[i] else B
            counts[u] += 1; counts[v] += 1
    assert all(R[v] == targets[v] and R[v] % 2 == B[v] % 2 == 1 for v in g["S"])
    assert all(R[v] % 2 == B[v] % 2 == 0 for v in g["T"])
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for i, (u, v) in enumerate(g["edges"]) for x in [values[i]])
    return {"status": "colored", "vertices": g["vertices"],
            "T": [v for v in g["vertices"] if v in g["T"]],
            "edges": [[u, v, values[i]] for i, (u, v) in enumerate(g["edges"])],
            "red": R, "blue": B, "roots": [v for v in g["vertices"] if v in roots],
            "mixed_port_edges": [list(g["edges"][i]) for i in sorted(mixed_ports)],
            "mixed_edges": [list(g["edges"][i]) for i in range(len(g["edges"])) if values[i] == 1],
            "S_red_targets": list(targets.items()), "S_components": details,
            "new_vertices_added": 0, "new_edges_added": 0, "mother_conjecture_proved": False}


def color_fixed_roots_by_parity(vertices, edges, T, roots):
    """Exact parity gate; guaranteed coloring when nonisolated root cross degree<=4."""
    g = _layout(vertices, edges, T)
    if "status" in g:
        return g
    roots = _validate_roots(g, roots)
    allowed = [(i, u, v) for i, (u, v) in enumerate(g["edges"])
               if (u in roots and v in g["T"]) or (v in roots and u in g["T"])]
    nodes = [v for v in g["vertices"] if v in roots or v in g["T"]]
    adjacency = {v: [] for v in nodes}
    for i, u, v in allowed:
        adjacency[u].append((v, i)); adjacency[v].append((u, i))
    seen, groups, mixed = set(), [], set()
    for root in nodes:
        if root in seen:
            continue
        order, parent = [root], {root: (None, None)}; seen.add(root)
        for v in order:
            for u, i in adjacency[v]:
                if u not in seen:
                    seen.add(u); order.append(u); parent[u] = (v, i)
        groups.append(order)
        if len(set(order) & roots) % 2:
            return {"status": "no_parity_join_for_these_roots", "vertices": g["vertices"],
                    "original_edges": [list(e) for e in g["edges"]],
                    "T": [v for v in g["vertices"] if v in g["T"]],
                    "roots": [v for v in g["vertices"] if v in roots],
                    "allowed_edge_indices": [i for i, u, v in allowed], "odd_root_component": order,
                    "mother_conjecture_proved": False}
        bits = {v: int(v in roots) for v in order}
        for v in reversed(order[1:]):
            u, i = parent[v]
            if bits[v]:
                mixed.add(i); bits[u] ^= 1
        assert bits[root] == 0
    answer = color_root_ports(g["vertices"], g["edges"], g["T"], roots, [g["edges"][i] for i in sorted(mixed)])
    if answer["status"] == "root_capacity_not_supported":
        return dict(answer, scope="Only this recovered tree join exceeds the supported nonisolated-root palette.")
    return dict(answer, parity_components=groups,
                allowed_edge_indices=[i for i, u, v in allowed])


def color_common_neighbor_pairs(vertices, edges, T, pairs):
    """Each triple (left_root, T_center, right_root) pairs two odd components."""
    roots, ports = [], []
    for u, center, v in pairs:
        roots += [u, v]; ports += [(u, center), (v, center)]
    return color_root_ports(vertices, edges, T, roots, ports)


def root_paired_bridge_triangles(t):
    if type(t) is not int or t < 1:
        raise ValueError("Use t>=1.")
    n = 4*t
    base = [(i, (i+1) % n) for i in range(n)]+[(i, i+2*t) for i in range(2*t)]
    base.remove((0, 1)); branch = base+[(0, n), (n, 1)]
    H, bridge_indices, branch_T = [], [], []
    for j in range(3):
        shift = 1+j*(n+1); branch_T.append(list(range(shift, shift+n+1)))
        H += [(u+shift, v+shift) for u, v in branch]
        bridge_indices.append(len(H)); H.append((0, shift+n))
    NT = 3*(n+1)+1; S = list(range(NT, NT+len(H))); T = list(range(NT))
    bridge_S = [NT+i for i in bridge_indices]
    six = [v for v in S if v not in bridge_S][:6]
    triangles = [[six[0], six[2], six[3]], [six[1], six[4], six[5]]]
    forced_pair = bridge_S[:2]
    remainder = [v for v in S if v not in six and v not in forced_pair]
    edges = [(v, NT+i) for i, e in enumerate(H) for v in e]
    edges += [tuple(forced_pair)]+list(zip(remainder[::2], remainder[1::2]))
    edges += [(a[j], a[(j+1) % 3]) for a in triangles for j in range(3)]
    center = next(iter(set(H[0]) & set(H[1])))
    answer = color_common_neighbor_pairs(T+S, edges, T, [(six[0], center, six[1])])
    assert answer["status"] == "colored"
    return dict(answer, family="root_paired_bridge_triangles", parameter=t,
                bridge_S_vertices=bridge_S, branch_T_sets=branch_T,
                forced_S_pair=forced_pair, root_pair=[six[0], center, six[1]])


def two_odd_cycles_with_leaves(n, q, leaf_pairs=0):
    if type(n) is not int or n < 3 or n % 2 == 0 or type(q) is not int or q < 2 or type(leaf_pairs) is not int or leaf_pairs < 0:
        raise ValueError("Use odd cycle length n>=3, q>=2, and leaf_pairs>=0.")
    S_cycle = list(range(2*n)); S_leaf = list(range(2*n, 2*n+2*leaf_pairs))
    T = list(range(2*n+2*leaf_pairs, 2*n+2*leaf_pairs+q))
    edges = [(start+i, start+(i+1) % n) for start in (0, n) for i in range(n)]
    edges += [(v, center) for v in S_cycle for center in T]
    edges += [(v, T[0]) for v in S_leaf]
    pairs = [(0, T[0], n)]+[(S_leaf[2*j], T[0], S_leaf[2*j+1]) for j in range(leaf_pairs)]
    answer = color_common_neighbor_pairs(S_cycle+S_leaf+T, edges, T, pairs)
    assert answer["status"] == "colored"
    return dict(answer, family="two_odd_cycles_with_leaves", cycle_length=n,
                independent_side_size=q, leaf_pairs=leaf_pairs)


def branching_isolated_roots(b=3):
    if type(b) is not int or b < 3 or b % 2 == 0:
        raise ValueError("Use an odd number b>=3 of branches.")
    NS = 1+3*b
    S, T, edges, odd_groups = list(range(NS)), list(range(NS, NS+3*b)), [], []
    for j in range(b):
        leaves = list(range(1+3*j, 4+3*j)); odd_groups.append(leaves)
        port, a, c = NS+3*j, NS+3*j+1, NS+3*j+2
        edges += [(0, port)]+[(v, center) for v in leaves for center in (port, a, c)]
    answer = color_fixed_roots_by_parity(S+T, edges, T, S)
    assert answer["status"] == "colored"
    return dict(answer, family="branching_isolated_roots", branches=b,
                root_pairing_tutte_barrier={"deleted_roots": [0], "odd_components": odd_groups})
