"""Stand-alone certificate audit: stdlib only, no constructor/solver imports."""

import ast
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT
SCRIPTS = ["isolate_parity_partitions.py", "check_isolate_parity_partitions.py",
           "path_cycle_partition.py", "signed_gap_two.py"]
DOCS = ["孤立点侧的奇偶接合与桥障碍修复_20261028.md", "UPDATE_20261028.md"]
RECORDS = ["isolate_parity_partitions_validation.json", "isolate_parity_partitions_witnesses.json"]
links = 0
for name in SCRIPTS:
    ast.parse((OUT/name).read_text(encoding="utf-8"), filename=name)
for name in DOCS:
    content = (OUT/name).read_text(encoding="utf-8")
    assert not any(ord(c) < 32 and c not in "\n\r\t" for c in content)
    assert len(re.findall(r"(?<!\\)\$", content)) % 2 == 0
    for target in re.findall(r"\]\(([^)]+)\)", content):
        if target.startswith(("http:", "https:", "#")):
            continue
        assert (OUT/target).is_file(), (name, target)
        links += 1
report = json.loads((OUT/RECORDS[0]).read_text(encoding="utf-8"))
assert report["all_checks_passed"] and report["mother_conjecture_proved"] is False
assert report["eligible_atlas_partition_outcomes"] == {"colored": 57, "colored_with_T_isolates": 12,
                                                        "no_protected_parity_join": 120}
assert report["exact_fixed_join_outcomes"] == {"colored": 47, "no_extension_for_this_cross_mixed_set": 5}
assert report["fixed_join_domains_compared_to_full_binary_assignments"] == 52
w = json.loads((OUT/RECORDS[1]).read_text(encoding="utf-8"))
assert len(w) == report["saved_groups"] == 5


def raw(data):
    V = set(data["vertices"]); T = set(data["T"]); E = {}; D, R, B = Counter(), Counter(), Counter()
    for u, v, x in data["edges"]:
        key = frozenset((u, v))
        assert len(key) == 2 and key <= V and key not in E and type(x) is int and x in (0, 1, 2)
        E[key] = x; D[u] += 1; D[v] += 1
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert all(d in (3, 4) for d in D.values())
    assert {int(v): r for v, r in data["red"].items()} == {v: R[v] for v in V}
    assert {int(v): b for v, b in data["blue"].items()} == {v: B[v] for v in V}
    for u, v, x in data["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    M = {e for e, x in E.items() if x == 1}
    assert M == set(map(frozenset, data["mixed_edges"]))
    inside = Counter(v for e in E if e <= T or e <= V-T for v in e)
    assert all(inside[v] <= 1 for v in T)
    assert all(inside[v] <= 2 and (inside[v] != 2 or D[v] == 4) for v in V-T)
    reverse = data["method"] == "independent_T_reverse_parity"
    assert all(R[v] % 2 == B[v] % 2 == int(v not in T if reverse else v in T) for v in V)
    if reverse:
        targets = dict(data["S_red_targets"])
        assert set(targets) == V-T and all(targets[v] == R[v] in (1, 5) for v in V-T)
        assert not any(e <= T for e in E) and all(e <= V-T for e in M)
        assert Counter(v for e in M for v in e) == Counter({v: 1 for v in V-T})
        assert all(abs(R[u]-R[v]) == 4 for e in E if e <= V-T for u, v in [tuple(e)])
    assert data["new_vertices_added"] == data["new_edges_added"] == 0
    assert data["mother_conjecture_proved"] is False
    return V, E, D, R, B, M


def component(vertices, edges, root):
    adj = {v: set() for v in vertices}
    for u, v in edges:
        adj[u].add(v); adj[v].add(u)
    order = [root]; seen = {root}
    for v in order:
        for u in adj[v]-seen:
            seen.add(u); order.append(u)
    return seen


protected = w["both_T_pairs_and_isolates"]
V, E, D, R, B, M = raw(protected); T = set(protected["T"]); S = V-T
assert len(V) == 23 and len(E) == 40
I = {v for v in T if not any(e <= T and v in e for e in E)}
assert len(I) == 6 and I == set(protected["I"])
P = set(protected["protected_S_vertices"])
assert not P and not protected["selected_S_edges"]
indexed = [tuple(e[:2]) for e in protected["edges"]]
allowed = [i for i, (u, v) in enumerate(indexed) if (u in I and v in S-P) or (v in I and u in S-P)]
assert allowed == protected["allowed_edge_indices"]
join = protected["parity_certificate"]; N = set(map(frozenset, protected["extra_mixed_edges"]))
assert N == {frozenset(indexed[i]) for i in join["indices"]} and all(i in allowed for i in join["indices"])
nd = Counter(v for e in N for v in e)
assert all(nd[v] % 2 == int(v in I) for v in V)
assert M == N | {e for e in E if e <= T}
for group in join["components"]:
    U = set(group)
    assert len(U & I) % 2 == 0
    assert all((u in U) == (v in U) for i in allowed for u, v in [indexed[i]])
rows = [dict(row) for row in protected["signed_rows"]]
signs = {int(i): y for i, y in protected["signed_solution"]["signs"].items()}
pairs = [tuple(e) for e in protected["row_pairs"]]
pure_cross = [i for i, (u, v) in enumerate(indexed) if (u in T) != (v in T) and frozenset((u, v)) not in N]
expected_rows = [{i: (1 if u in indexed[i] else -1) for i in pure_cross if u in indexed[i] or v in indexed[i]} for u, v in pairs]
assert rows == expected_rows and all(len(row) >= 4 for row in rows)
assert max(Counter(i for row in rows for i in row).values()) <= 2
assert all(protected["edges"][i][2] == 1+signs[i] for i in signs)
assert [sum(c*signs[i] for i, c in row.items()) for row in rows] == protected["signed_solution"]["row_sums"]
assert all(abs(a) >= 2 for a in protected["signed_solution"]["row_sums"])
truth_assignments = 0


def component_tables(data):
    global truth_assignments
    V, T = set(data["vertices"]), set(data["T"]); S = V-T
    E = {frozenset((u, v)): x for u, v, x in data["edges"]}
    for group in data["S_components"]:
        order = group["vertices"]; ext = group["extension"]; n = len(order); m = n if group["cycle"] else n-1
        cross_s = [sum(x for e, x in E.items() if v in e and not(e <= S or e <= T))//2 for v in order]
        assert cross_s == ext["crossing_red_counts"]
        assert [E[frozenset((order[i], order[(i+1) % n]))]//2 for i in range(m)] == ext["internal_bits"]
        for bits in itertools.product((0, 1), repeat=m):
            red = [2*s for s in cross_s]
            for i, bit in enumerate(bits):
                red[i] += 2*bit; red[(i+1) % n] += 2*bit
            blue = [2*d-r for d, r in zip(ext["degrees"], red)]
            actual = all(red[i] != red[(i+1) % n] if bit else blue[i] != blue[(i+1) % n] for i, bit in enumerate(bits))
            encoded = all(any(bits[i] == value for i, value in clause) for clause in ext["clauses"])
            assert actual == encoded
            truth_assignments += 1


component_tables(protected)
barrier = w["even_T_bridge_barrier_repaired_by_reverse_parity"]
Vb, Eb, Db, Rb, Bb, Mb = raw(barrier); Tb = set(barrier["T"]); Sb = Vb-Tb
assert len(Vb) == 40 and len(Eb) == 63 and Counter(Db.values()) == Counter({3: 34, 4: 6})
C = {e for e in Eb for u, v in [tuple(e)] if (u in Tb) != (v in Tb)}
assert component(Vb, [tuple(e) for e in C], 0) == Vb
ob = barrier["opposite_pattern_obstruction"]
assert [len(a) for a in ob["branch_T_sets"]] == [5, 5, 5]
assert set().union(*map(set, ob["branch_T_sets"])) == Tb-{0}
forced_cuts = 0
for v in ob["bridge_S_vertices"]:
    incident = [e for e in C if v in e]
    assert len(incident) == 2
    for edge in incident:
        u = next(iter(edge-{v}))
        U = component(Vb, [tuple(e) for e in C-{edge}], u)
        assert v not in U and len(U & Tb) % 2 == 1
        boundary = {e for e in C for a, b in [tuple(e)] if (a in U) != (b in U)}
        assert boundary == {edge}
        forced_cuts += 1
u, v = ob["conflicting_S_pair"]
assert frozenset((u, v)) in Eb and Db[u] == Db[v] == 3
assert {e for e in set(Eb)-C if u in e or v in e} == {frozenset((u, v))}
for x in (0, 2):
    left_red = sum(1 for e in C if u in e)+x
    right_red = sum(1 for e in C if v in e)+x
    left_blue, right_blue = 2*Db[u]-left_red, 2*Db[v]-right_red
    assert left_red == right_red == 2+x and left_blue == right_blue == 4-x
    assert left_blue == right_blue if x == 0 else left_red == right_red
opposite_N = {frozenset(barrier["edges"][i][:2]) for i in barrier["opposite_pattern_parity_join"]["indices"]}
nd = Counter(v for e in opposite_N for v in e)
assert opposite_N <= C and all(nd[v] % 2 == int(v in Tb) for v in Vb)
assert nd[u] == nd[v] == 2
odd = w["odd_T_reverse_parity"]; Vo, Eo, Do, Ro, Bo, Mo = raw(odd)
assert len(Vo) == 9 and len(Eo) == 17 and len(odd["T"]) == 3
fixed = w["same_graph_fixed_join_obstruction_and_repair"]
good, bad = fixed["good"], fixed["bad"]
Vg, Eg, Dg, Rg, Bg, Mg = raw(good); component_tables(good)
assert set(Eg) == set(map(frozenset, bad["original_edges"])) and len(Eg) == 9
badM = set(map(frozenset, bad["mixed_edges"])); T = set(bad["T"])
assert badM == {e for e in Eg if not(e <= T or e <= Vg-T)}
assert len(badM) == 6 and len(Mg) == 2 and Mg < badM
saturated = set(bad["saturated_critical_component"]["vertices"])
assert saturated == Vg-T and len(saturated) == 3
assert all(sum(v in e for e in badM) == 2 for v in saturated)
bad_assignments = 0
pure = list(set(Eg)-badM)
for bits in itertools.product((0, 1), repeat=len(pure)):
    values = {e: 1 for e in badM}; values.update({e: 2*b for e, b in zip(pure, bits)})
    R, B = Counter(), Counter()
    for e, x in values.items():
        for v in e:
            R[v] += x; B[v] += 2-x
    assert not all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v]) for e, x in values.items() for u, v in [tuple(e)])
    bad_assignments += 1
negative = w["odd_protected_component"]
T = set(negative["T"]); I = set(negative["I"]); P = set(negative["protected_S_vertices"])
E = [tuple(e) for e in negative["original_edges"]]
allowed = [i for i, (u, v) in enumerate(E) if (u in I and v not in T and v not in P) or (
    v in I and u not in T and u not in P)]
assert allowed == negative["allowed_edge_indices"]
U = set(negative["parity_certificate"]["odd_component"])
assert len(U & I) % 2 and all((u in U) == (v in U) for i in allowed for u, v in [E[i]])
inventory = {}
for name in SCRIPTS+DOCS+RECORDS:
    path = OUT/name
    inventory[name] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
edge_count = len(Eb)+len(Eo)+len(Eg)+len(protected["edges"])
audit = {"syntax_checks_including_two_unchanged_dependencies": len(SCRIPTS),
         "documents_checked": len(DOCS), "local_links_checked": links,
         "raw_whole_graphs_checked": 4, "raw_original_edges_checked": edge_count,
         "raw_actual_copies_checked": 2*edge_count,
         "protected_signed_rows_rederived": len(rows), "component_truth_table_assignments_rederived": truth_assignments,
         "bridge_half_odd_cut_certificates_rederived": forced_cuts,
         "fixed_saturated_join_all_pure_completions_rejected": bad_assignments,
         "odd_protected_component_certificate_rederived": True,
         "both_parity_patterns_and_changed_mixed_sets_checked": True,
         "portable_release_paths_checked": True, "all_checks_passed": True,
         "mother_conjecture_proved": False, "external_peer_review": False, "lean_formalization": False,
         "independent_auditor": {"relative_to_project": "artifact/audit_isolate_parity_partitions_stage.py",
                                "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, "files": inventory}
# Report on stdout; preserve all archived input bytes.
print(json.dumps({k: v for k, v in audit.items() if k not in ("files", "independent_auditor")}, ensure_ascii=False, indent=2))
