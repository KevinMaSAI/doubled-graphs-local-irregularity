"""Independent standard-library verifier of all finite pendant interfaces.

This verifies a COMPLETE finite lemma after the structural reduction.
It is not a finite-graph substitute for the separate infinite-family proof.
"""

import itertools
import json
from collections import Counter
from pathlib import Path


TEMPLATES = {
    "P3": (3, ((0, 1), (1, 2)), ((0, 2), (1,))),
    "P4": (4, ((0, 1), (1, 2), (2, 3)), ((0, 2), (1, 3))),
    "C4": (4, ((0, 1), (1, 2), (2, 3), (3, 0)), ((0, 2), (1, 3))),
}


def state_key(record):
    return (record["core"], tuple(record["pendant_roots"]),
            tuple(record["kinds"]), tuple(record["fixed_ordinary_red"]))


def domain_keys():
    for name, (count, edges, parts) in TEMPLATES.items():
        degree = [sum(v in edge for edge in edges) for v in range(count)]
        for marks in itertools.product((0, 1), repeat=count):
            if not 1 <= sum(marks) <= 2:
                continue
            if any(sum(marks[v] for v in part) > 1 for part in parts):
                continue
            if any(sum(1 - marks[v] for v in part) > 1 for part in parts):
                continue
            roots = tuple(v for v in range(count) if marks[v])
            ordinary_degrees = [3 - degree[v] - marks[v] for v in range(count)]
            assert min(ordinary_degrees) >= 0
            possible_red = [tuple(2 * i for i in range(degree + 1)) for degree in ordinary_degrees]
            for red in itertools.product(*possible_red):
                for kinds in itertools.product((1, 2, 3), repeat=len(roots)):
                    yield name, roots, kinds, red


def verify_certificate(data):
    records = data["records"]
    expected = set(domain_keys())
    actual, counts, mixed_ports = set(), Counter(), 0
    for record in records:
        key = state_key(record)
        assert key in expected and key not in actual
        actual.add(key)
        name, roots, kinds, fixed = key
        count, edges, _ = TEMPLATES[name]
        weights, words = record["core_weights"], record["pendant_words"]
        assert len(weights) == len(edges) and len(words) == len(roots)
        assert all(value in (0, 1, 2) for value in weights)
        red = list(fixed)
        for (u, v), value in zip(edges, weights):
            red[u] += value
            red[v] += value
        for root, kind, word in zip(roots, kinds, words):
            assert len(word) == kind and all(value in (0, 1, 2) for value in word)
            red[root] += word[0]
        blue = [6 - value for value in red]
        assert red == record["red"] and blue == record["blue"]
        assert all(0 <= value <= 6 for value in red)
        assert all(red[u] != red[v] for u, v in edges)
        for root, kind, word in zip(roots, kinds, words):
            assert word[0] <= red[root] <= word[0] + 4
            path_red = [red[root]] + [word[i - 1] + word[i] for i in range(1, kind)] + [word[-1]]
            path_blue = [blue[root]] + [4 - value for value in path_red[1:-1]] + [2 - word[-1]]
            for i, value in enumerate(word):
                if value:
                    assert path_red[i] != path_red[i + 1]
                if value < 2:
                    assert path_blue[i] != path_blue[i + 1]
            mixed_ports += int(word[0] == 1)
        counts[name] += 1
    assert actual == expected and len(actual) == 765
    return {"records_verified": len(actual), "core_counts": dict(counts),
            "mixed_pendant_port_occurrences": mixed_ports, "complete_domain_verified": True,
            "scope": "Complete finite residual-interface lemma, not the full mother conjecture."}


if __name__ == "__main__":
    data = json.loads(Path(__file__).with_name("subcubic_pendant_interfaces.json").read_text(encoding="utf-8"))
    print(json.dumps(verify_certificate(data), ensure_ascii=False, indent=2))
