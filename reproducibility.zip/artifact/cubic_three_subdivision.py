"""LIR2 for any nonempty subset of cubic edges replaced by paths >=3.

Pure opposite ports use a coordinated orientation on selected edges.
Integer-offset modular sums color the retained graph. The full mother
conjecture, arbitrary short two-edge paths and leaves are not covered.
"""

import networkx as nx

from degree_two_pair_orientation import orient_distinct_degree_two_pairs
from independent_branch_coloring import _path_word
from mod3_edge_weighting import proper_012_with_offsets


def color_cubic_three_subdivision(base, subdivided_edges, lengths=3):
    if (base.is_directed() or base.is_multigraph() or nx.number_of_selfloops(base)
            or not len(base) or not nx.is_connected(base)
            or any(degree != 3 for v, degree in base.degree())):
        raise ValueError("The base must be a connected simple cubic graph.")
    pairs = [tuple(edge) for edge in subdivided_edges]
    if not pairs:
        raise ValueError("A nonempty subset is required; the unchanged cubic case is a separate known theorem.")
    identities = [frozenset(edge) for edge in pairs]
    if (len(set(identities)) != len(pairs)
            or any(len(edge) != 2 or not base.has_edge(*edge) for edge in pairs)):
        raise ValueError("The supplied edges must be a subset without repetitions.")
    path_lengths = [lengths if isinstance(lengths, int) else lengths[frozenset(edge)] for edge in pairs]
    if any(not isinstance(value, int) or value < 3 for value in path_lengths):
        raise ValueError("Every replacement path must have at least three edges.")
    retained = base.copy()
    retained.remove_edges_from(pairs)
    component_vertices = list(nx.connected_components(retained))
    isolated_pairs = [tuple(vertices) for vertices in component_vertices if len(vertices) == 2]
    selected = nx.Graph()
    selected.add_nodes_from(base)
    selected.add_edges_from(pairs)
    orientation = orient_distinct_degree_two_pairs(selected, isolated_pairs)
    port_map = {frozenset((tail, head)): {tail: 0, head: 2}
                for tail, head in orientation["directions"]}
    ports = [[port_map[frozenset(edge)][v] for v in edge] for edge in pairs]
    assert all(sorted(pair) == [0, 2] for pair in ports)
    offsets = {v: 2 * orientation["indegree"][v] for v in base}
    values, components = {}, []
    for vertices in component_vertices:
        component = retained.subgraph(vertices)
        assert any(selected.degree(v) for v in vertices)
        if len(component) == 1:
            components.append({"kind": "isolated_vertex", "vertices": list(vertices)})
        elif len(component) == 2:
            u, v = component
            assert offsets[u] != offsets[v]
            values[frozenset((u, v))] = 1
            components.append({"kind": "isolated_edge_distinct_offsets", "vertices": [u, v],
                               "offsets": [offsets[u], offsets[v]]})
        else:
            result = proper_012_with_offsets(component, {v: offsets[v] for v in component})
            assert result["status"] == "weighted"
            for edge, value in zip(result["edge_order"], result["weights"]):
                values[frozenset(edge)] = value
            components.append({"kind": result["method"], "vertices": list(vertices),
                               "target_mod3": result["target"],
                               "adjusted_bipartite_vertices": result["adjusted_bipartite_vertices"],
                               "closing_edge": result["closing_edge"],
                               "closing_weight": result["closing_weight"]})
    root_red = dict(offsets)
    for u, v in retained.edges():
        value = values[frozenset((u, v))]
        root_red[u] += value
        root_red[v] += value
    root_blue = {v: 6 - root_red[v] for v in base}
    assert all(0 <= root_red[v] <= 6 for v in base)
    assert all(root_red[u] != root_red[v] and root_blue[u] != root_blue[v]
               for u, v in retained.edges())
    graph = retained.copy()
    next_vertex, paths = 0, []
    for (u, v), length, pair in zip(pairs, path_lengths, ports):
        path = [u]
        for _ in range(length - 1):
            while next_vertex in graph:
                next_vertex += 1
            graph.add_node(next_vertex)
            path.append(next_vertex)
            next_vertex += 1
        path.append(v)
        graph.add_edges_from(zip(path, path[1:]))
        word = _path_word(length, *pair, root_red[u], root_blue[u], root_red[v], root_blue[v])
        assert word is not None
        for a, b, value in zip(path, path[1:], word):
            values[frozenset((a, b))] = value
        paths.append(path)
    edges = list(graph.edges())
    weights = [values[frozenset(edge)] for edge in edges]
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in base)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "graph": graph, "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "root_red": root_red, "root_blue": root_blue,
            "retained_components": components, "subdivided_edges": pairs, "ports": ports,
            "offsets": offsets, "orientation_certificate": orientation,
            "replacement_paths": paths, "mother_conjecture_proved": False}
