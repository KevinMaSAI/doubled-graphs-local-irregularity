"""Complete kernel recovery and actual-copy checks for the two-mark lemma."""
import itertools
import json
import random
import time
from pathlib import Path
import networkx as nx
from independent_branch_coloring import _pendant_word
from check_matching_long_branch_coloring import verify
from weak_two_marked_certificate import verify_certificate
from weak_two_marked_tree import weak_two_marked_tree


def build(left,right,central,rng=None):
    graph=nx.Graph();graph.add_nodes_from((0,1))
    flags={0:[],1:[]};marks=[];count=2
    def path(u,v,length):
        nonlocal count
        mid=list(range(count,count+length-1));count+=length-1
        for w in mid:flags[w]=[True]
        word=[u]+mid+[v];graph.add_edges_from(zip(word,word[1:]));return word
    path(0,1,central)
    for root,side in enumerate((left,right)):
        for name in side:
            marked=name[0]=="m";length=int(name[1:])
            if rng is not None and ((marked and length==6) or (not marked and length==3)):
                length+=rng.randrange(12)
            if length==0:
                j=len(flags[root]);flags[root].append(False)
                if marked:marks.append((root,j))
            else:
                leaf=count;count+=1;flags[leaf]=[False,True]
                path(root,leaf,length)
                if marked:marks.append((leaf,0))
    assert nx.is_tree(graph) and all(len(flags[v])==3-graph.degree(v) for v in graph)
    return graph,flags,marks


def actual_check(core,flags,marks,result):
    assert result["status"]=="weighted"
    graph=core.copy();edges=list(result["edge_order"]);values=list(result["weights"])
    for v in core:
        for j,p in enumerate(result["boundary_ports"][v]):
            assert p==1 if (v,j) in marks else p in (0,2)
            length=1 if flags[v][j] else 3
            word=_pendant_word(length,p,result["red"][v],6-result["red"][v])
            assert word is not None
            path=[v]+[object() for _ in range(length)]
            graph.add_edges_from(zip(path,path[1:]))
            edges.extend(zip(path,path[1:]));values.extend(word)
    red=dict.fromkeys(graph,0)
    for (u,v),x in zip(edges,values):red[u]+=x;red[v]+=x
    assert all(red[v]==result["red"][v] for v in core)
    assert all(red[v] in (0,1,3,5,6) for v in core if any(flags[v]))
    assert all(red[v]!=3 for v,j in marks)
    verify(graph,{"status":"colored","edge_order":edges,"weights":values,"red":red,
                  "blue":{v:2*graph.degree(v)-red[v] for v in graph}})


def main():
    start=time.monotonic();base=Path(__file__).parent
    data=json.loads((base/"weak_two_marked_interfaces.json").read_text(encoding="utf-8"))
    cert=verify_certificate(data);rng=random.Random(20261117)
    count=0;reds=set();kinds=set()
    for record in data["records"]:
        for lift in range(1+int(rng.randrange(8)==0)):
            central=record["length"]+(2*rng.randrange(10) if lift and record["length"]==7 else 0)
            g,flags,marks=build(record["left"],record["right"],central,rng if lift else None)
            out=weak_two_marked_tree(g,flags,marks)
            actual_check(g,flags,marks,out);count+=1
            reds.update(out["red"][v] for v,j in marks)
            kinds.add(tuple(g.degree(v) for v in g if not any(flags[v])))
    g,flags,marks=build(["m6","m6"],["u3","u3"],1001,rng)
    out=weak_two_marked_tree(g,flags,marks);actual_check(g,flags,marks,out);count+=1
    result={"complete_certificate":cert,"actual_auxiliary_cores_verified":count,
            "marked_root_reds_observed":sorted(reds),"special_degree_pairs_observed":sorted(kinds),
            "long_odd_connector":1001,"all_checks_passed":True,"mother_conjecture_proved":False,
            "seconds":round(time.monotonic()-start,3)}
    (base/"weak_two_marked_validation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result))


if __name__=="__main__":main()
