"""Independent finite checks of the structural proof's boundary assertions."""
import copy
import itertools
import json
import time
from pathlib import Path
import networkx as nx
from forest_pseudoforest import spanning_forest_balanced_cotree
from weak_two_marked_certificate import verify_certificate
from weak_two_marked_tree import weak_two_marked_tree


def main():
    start=time.monotonic();base=Path(__file__).parent
    data=json.loads((base/"weak_two_marked_interfaces.json").read_text(encoding="utf-8"))
    cert=verify_certificate(data)
    mutations=[]
    bad=copy.deepcopy(data);bad["records"].pop();mutations.append(bad)
    bad=copy.deepcopy(data);bad["branch_types"]["m1"]=[[0,3]];mutations.append(bad)
    bad=copy.deepcopy(data);bad["records"][0]["witness"]["left_state"][1]+=1;mutations.append(bad)
    bad=copy.deepcopy(data);bad["failures"]=[["omitted"]];mutations.append(bad)
    for bad in mutations:
        try:verify_certificate(bad)
        except AssertionError:pass
        else:raise AssertionError("A damaged finite proof certificate was accepted.")
    local=0
    for h in (1,2,3):
        for p in range(4-h):
            for s in range(4-h-p):
                L=3-h-p-s;t=int(p==s==0)
                assert L<=(1+t if h==1 else t if h==2 else 0)
                local+=1
    binary=0
    for c,a,b in itertools.product(range(3),(1,2),(1,2)):
        assert any((c+a*x+b*y)%3==0 for x,y in itertools.product((0,1),repeat=2));binary+=1
    lists=0
    for h in range(4):
        for f in range(4-h):
            for ports in itertools.product((0,2),repeat=f):
                choices={0,1,2}-{(2+a)%3 for a in ports}
                assert 0 in choices and len(choices)>=h
                if f<3-h:assert len(choices)>h
                lists+=1
    structures=0;marked_cases=0
    for core in nx.graph_atlas_g():
        if len(core)<2 or not nx.is_connected(core) or not nx.is_bipartite(core):continue
        if max(dict(core.degree()).values())>3:continue
        slots=[(v,j) for v in core for j in range(3-core.degree(v))]
        partition=nx.bipartite.color(core)
        for long in itertools.combinations(slots,4):
            chosen=set(long)
            flags={v:[(v,j) not in chosen for j in range(3-core.degree(v))] for v in core}
            no_short=[v for v in core if not any(flags[v])]
            counts=[sum(partition[v]==side for v in no_short) for side in (0,1)]
            if max(counts)>1:continue
            assert nx.is_tree(core) and len(no_short)==2
            assert partition[no_short[0]]!=partition[no_short[1]]
            assert all(any(v==root for root,j in long) for v in core if core.degree(v)==1)
            structures+=1
            for marks in itertools.combinations(long,2):
                # Reverse insertion order to exercise both choices of
                # the canonical special-root order and all branch swaps.
                reversed_core=nx.Graph()
                reversed_core.add_nodes_from(reversed(list(core)))
                reversed_core.add_edges_from(core.edges())
                out=weak_two_marked_tree(reversed_core,flags,list(marks))
                assert all(out["red"][v]!=3 for v,j in marks)
                assert all(out["red"][v] in (0,1,3,5,6) for v in core if any(flags[v]))
                marked_cases+=1
    oriented=0
    for n in range(1,4):
        kinds=[(u,v) for u in range(n) for v in range(u,n)]
        for multiplicities in itertools.product(range(5),repeat=len(kinds)):
            degree=[0]*n
            for (u,v),k in zip(kinds,multiplicities):degree[u]+=k;degree[v]+=k
            if max(degree,default=0)>4:continue
            edges=[edge for edge,k in zip(kinds,multiplicities) for _ in range(k)]
            out=spanning_forest_balanced_cotree(range(n),edges)
            assert all(d<=2 for d in out["outdegrees"].values())
            assert all(d<2 or degree[v]==4 for v,d in out["outdegrees"].items())
            forest=nx.MultiGraph();forest.add_nodes_from(range(n))
            forest.add_edges_from(edges[j] for j in out["forest"])
            entire=nx.MultiGraph();entire.add_nodes_from(range(n));entire.add_edges_from(edges)
            assert nx.number_connected_components(forest)==nx.number_connected_components(entire)
            assert forest.number_of_edges()==n-nx.number_connected_components(entire)
            oriented+=1
    result={"finite_certificate":cert,"damaged_certificates_rejected":len(mutations),
            "all_local_degree_splits":local,"all_two_binary_defects":binary,
            "all_local_boundary_list_cases":lists,
            "independent_four_port_structures_from_graph_atlas":structures,
            "all_mark_pairs_with_reversed_root_order":marked_cases,
            "all_small_degree_four_multigraph_orientations":oriented,
            "all_checks_passed":True,"external_peer_review":False,"lean_formalization":False,
            "mother_conjecture_proved":False,
            "scope":"Finite identities and implementation invariants. The universal subcubic argument is in the separate draft; arbitrary degree remains outside it.",
            "seconds":round(time.monotonic()-start,3)}
    (base/"subcubic_two_marked_proof_audit.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result))


if __name__=="__main__":main()
