"""A conditional all-degree LIR2 construction from an established factor theorem.

Sufficient global bound: delta >=8c(2c+1)-7 for a proper c-coloring.
The exact local inequalities can also be used below that sufficient bound.
No general mother proof or polynomial factor-search time is claimed.
"""

import time

import networkx as nx


def degree_options(degree, residue, modulus):
    """Choose same-residue lower/upper consecutive pairs around degree/2."""
    half = degree // 2
    lower = half - (half - residue) % modulus
    upper = lower if lower == half else lower + modulus
    valid = (0 <= lower <= half <= upper < degree
             and 2 * upper <= degree + lower + 2 and upper <= 2 * lower + 3)
    return {"lower": lower, "upper": upper,
            "allowed": sorted({lower, lower + 1, upper, upper + 1}),
            "conditions_hold": valid}


def make_plan(graph, coloring, red_offsets=None, blue_offsets=None, palette_size=None):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    if set(coloring) != set(graph) or any(coloring[u] == coloring[v] for u, v in graph.edges()):
        raise ValueError("A proper vertex coloring of every vertex is required.")
    if palette_size is None:
        labels = {}
        for value in coloring.values():
            if value not in labels:
                labels[value] = len(labels)
        colors = {v: labels[coloring[v]] for v in graph}
        c = max(2, len(labels))
    else:
        c = palette_size
        if (type(c) is not int or c < 2
                or any(type(x) is not int or not 0 <= x < c for x in coloring.values())):
            raise ValueError("An explicit palette must contain all integer color labels.")
        colors = dict(coloring)
    p, q = 2 * c, 2 * c + 1
    modulus = p * q
    red_offsets = {v: 0 if red_offsets is None else red_offsets[v] for v in graph}
    blue_offsets = {v: 0 if blue_offsets is None else blue_offsets[v] for v in graph}
    if any(type(red_offsets[v]) is not int or type(blue_offsets[v]) is not int
           or red_offsets[v] < 0 or blue_offsets[v] < 0
           or (red_offsets[v] + blue_offsets[v]) % 2 for v in graph):
        raise ValueError("External color contributions must be physical nonnegative integers.")
    options, residues = {}, {}
    for v in graph:
        a = (2 * colors[v] - red_offsets[v]) % p
        b = (2 * graph.degree(v) + blue_offsets[v] - 2 * colors[v]) % q
        residue = a + p * ((b - a) * pow(p, -1, q) % q)
        residues[v] = residue
        options[v] = degree_options(graph.degree(v), residue, modulus)
    if any(not row["conditions_hold"] for row in options.values()):
        return {"status": "method_not_applicable",
                "reason": "degree_factor_local_inequalities_fail",
                "sufficient_minimum_degree": 4 * modulus - 7,
                "failing_vertices": [v for v in graph if not options[v]["conditions_hold"]]}
    return {"status": "planned", "colors": colors, "color_count": c,
            "red_modulus": p, "blue_modulus": q, "modulus": modulus,
            "sufficient_minimum_degree": 4 * modulus - 7,
            "global_minimum_degree_bound_holds":
                min(dict(graph.degree()).values()) >= 4 * modulus - 7,
            "residues": residues, "options": options,
            "red_offsets": red_offsets, "blue_offsets": blue_offsets}


def _finish(graph, plan, edges, weights):
    internal = dict.fromkeys(graph, 0)
    for (u, v), x in zip(edges, weights):
        assert x in (0, 1)
        internal[u] += x
        internal[v] += x
    red = {v: plan["red_offsets"][v] + internal[v] for v in graph}
    blue = {v: plan["blue_offsets"][v] + 2 * graph.degree(v) - internal[v] for v in graph}
    for v in graph:
        assert internal[v] in plan["options"][v]["allowed"]
        assert red[v] % plan["red_modulus"] in {
            2 * plan["colors"][v], (2 * plan["colors"][v] + 1) % plan["red_modulus"]}
        assert blue[v] % plan["blue_modulus"] in {
            2 * plan["colors"][v], (2 * plan["colors"][v] - 1) % plan["blue_modulus"]}
    assert all(red[u] != red[v] and blue[u] != blue[v] for u, v in graph.edges())
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "plan": plan, "mother_conjecture_proved": False}


def color_from_factor(graph, coloring, factor_edges, red_offsets=None, blue_offsets=None,
                      palette_size=None):
    """Check a supplied factor certificate; does not invoke a search solver."""
    plan = make_plan(graph, coloring, red_offsets, blue_offsets, palette_size)
    if plan["status"] != "planned":
        return plan
    selected = {frozenset(edge) for edge in factor_edges}
    if any(len(edge) != 2 or not graph.has_edge(*tuple(edge)) for edge in selected):
        raise ValueError("The supplied factor must use input edges.")
    edges = list(graph.edges())
    return _finish(graph, plan, edges, [int(frozenset(edge) in selected) for edge in edges])


def color_with_degree_factor(graph, coloring, red_offsets=None, blue_offsets=None,
                             timeout_ms=10000, palette_size=None):
    """Exact integer factor search. Timeout is incomplete, not UNSAT.

    A supplied independent factor via color_from_factor avoids solver cost.
    The previous large pseudo-Boolean encoding was replaced by linear equations.
    """
    plan = make_plan(graph, coloring, red_offsets, blue_offsets, palette_size)
    if plan["status"] != "planned":
        return plan
    import z3
    started = time.monotonic()
    edges = list(graph.edges())
    variables = [z3.Int("factor_" + str(i)) for i in range(len(edges))]
    incident = {v: [] for v in graph}
    for (u, v), variable in zip(edges, variables):
        incident[u].append(variable)
        incident[v].append(variable)
    solver = z3.Solver()
    if timeout_ms is not None:
        solver.set(timeout=timeout_ms)
    solver.add(*[z3.And(0 <= x, x <= 1) for x in variables])
    for i, v in enumerate(graph):
        high, unit = z3.Int("high_" + str(i)), z3.Int("unit_" + str(i))
        low, upper = plan["options"][v]["lower"], plan["options"][v]["upper"]
        solver.add(z3.And(0 <= high, high <= 1, 0 <= unit, unit <= 1),
                   z3.Sum(incident[v]) == low + (upper - low) * high + unit)
    answer = solver.check()
    if answer == z3.unknown:
        return {"status": "factor_search_incomplete", "reason": solver.reason_unknown(),
                "seconds": time.monotonic() - started, "plan": plan}
    if answer != z3.sat:
        raise AssertionError("A factor theorem instance was reported infeasible.")
    model = solver.model()
    weights = [model.eval(x).as_long() for x in variables]
    result = _finish(graph, plan, edges, weights)
    result["seconds"] = time.monotonic() - started
    return result
