"""Complete finite certificate, lifted auxiliary cores and actual-copy checks."""

import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from sparse_bip_core_certificate import verify_certificate
from sparse_bipartite_core import SAFE, safe_sparse_bipartite_core
from subcubic_sparse_bip_core_coloring import color_subcubic_sparse_bip_core
from subcubic_no_two_threads import color_subcubic_adjustable_bip_short_threads


def build_core(record, lengths=None, arms=None):
    shape = record["shape"]
    lengths = list(record["lengths"] if lengths is None else lengths)
    count = 1 if shape in ("claw", "lollipop") else 2
    graph = nx.Graph()
    graph.add_nodes_from(range(count))
    next_vertex = count
    arm_iterator = iter(arms if arms is not None else [1] * 6)
    def chain(u, v, length):
        nonlocal next_vertex
        middle = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + middle + [v]
        for a, b in zip(path, path[1:]):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
    def arm(root):
        nonlocal next_vertex
        leaf = next_vertex
        next_vertex += 1
        chain(root, leaf, next(arm_iterator))
    if shape == "claw":
        for _ in range(3):
            arm(0)
    elif shape == "lollipop":
        chain(0, 0, lengths[0])
        arm(0)
    elif shape == "double_star":
        chain(0, 1, lengths[0])
        for root in (0, 1):
            arm(root)
            arm(root)
    elif shape == "lollipop_fork":
        chain(0, 0, lengths[0])
        chain(0, 1, lengths[1])
        arm(1)
        arm(1)
    elif shape == "cycle_two_arms":
        for length in lengths:
            chain(0, 1, length)
        arm(0)
        arm(1)
    elif shape == "theta":
        for length in lengths:
            chain(0, 1, length)
    else:
        assert shape == "barbell"
        chain(0, 0, lengths[0])
        chain(1, 1, lengths[1])
        chain(0, 1, lengths[2])
    assert len(graph) == next_vertex and nx.is_connected(graph) and nx.is_bipartite(graph)
    assert sum(d == 3 for _, d in graph.degree()) == count
    return graph


def verify_core(core, result):
    assert result["status"] == "weighted"
    assert len(result["edge_order"]) == len(result["weights"]) == core.number_of_edges()
    assert {frozenset(e) for e in result["edge_order"]} == {frozenset(e) for e in core.edges()}
    graph = core.copy()
    edges, weights = list(result["edge_order"]), list(result["weights"])
    red = dict.fromkeys(core, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        red[u] += value
        red[v] += value
    for v in core:
        ports = result["boundary_ports"][v]
        assert len(ports) == 3 - core.degree(v)
        for value in ports:
            assert value in (0, 2)
            red[v] += value
            leaf = object()
            graph.add_edge(v, leaf)
            edges.append((v, leaf))
            weights.append(value)
            red[leaf] = value
        assert red[v] == result["red"][v] and red[v] in SAFE
    assert all(red[u] != red[v] for u, v in core.edges())
    # Complete every private port by an ACTUAL leaf, then count both copies.
    colored = {"status": "colored", "edge_order": edges, "weights": weights,
               "red": red, "blue": {v: 2 * graph.degree(v) - red[v] for v in graph}}
    verify(graph, colored)


def embed_core(core, rng):
    core = nx.convert_node_labels_to_integers(core)
    threads = [(u, v, 1) for u, v in core.edges()]
    pendants, count = [], len(core)
    for root in core:
        for _ in range(3 - core.degree(root)):
            helper = count
            count += 1
            threads.append((root, helper, 2))
            pendants.extend(((helper, rng.randrange(1, 8)), (helper, rng.randrange(1, 8))))
    return expand(count, threads, pendants)


def join_cores(cores, rng, all_short=False):
    """Connect all boundary ports by short/long paths or pendant paths."""
    direct, stubs, count = [], [], 0
    for core in cores:
        core = nx.convert_node_labels_to_integers(core)
        direct.extend((count + u, count + v, 1) for u, v in core.edges())
        stubs.extend(count + v for v in core for _ in range(3 - core.degree(v)))
        count += len(core)
    rng.shuffle(stubs)
    ordinary, pendants = [], []
    while stubs:
        u = stubs.pop()
        # Never create an ORIGINAL compressed return path, even though the
        # direct H cores themselves may have topological loop chains.
        choice = next((j for j in range(len(stubs) - 1, -1, -1) if stubs[j] != u), None)
        if choice is None:
            pendants.append((u, rng.randrange(1, 8)))
            continue
        v = stubs.pop(choice)
        length = 2 if all_short else rng.choice((2, 2, 2, 4, 5, 6, 9))
        ordinary.append((u, v, length))
    quotient = nx.Graph()
    quotient.add_nodes_from(range(count))
    quotient.add_edges_from((u, v) for u, v, _ in direct + ordinary)
    if not nx.is_connected(quotient):
        return None
    return expand(count, direct + ordinary, pendants)


def cross_clones(core, rng, long_first=False):
    core = nx.convert_node_labels_to_integers(core)
    count = len(core)
    threads = [(u, v, 1) for u, v in core.edges()]
    threads += [(count + u, count + v, 1) for u, v in core.edges()]
    left = [v for v in core for _ in range(3 - core.degree(v))]
    right = [count + v for v in left]
    rng.shuffle(right)
    assert left
    threads += [(u, v, 5000 if long_first and i == 0 else 2)
                for i, (u, v) in enumerate(zip(left, right))]
    return expand(2 * count, threads, [])


def independent_domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return False
    roots = {v for v in graph if degree[v] == 3}
    if not roots:
        return True
    core = graph.subgraph(roots)
    for vertices in nx.connected_components(core):
        component = core.subgraph(vertices)
        if not nx.is_bipartite(component) or sum(core.degree(v) == 3 for v in vertices) > 2:
            return False
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        if len(attachments) == 2 and (attachments[0] == attachments[1] or len(vertices) == 2):
            return False
    return True


def main():
    started = time.monotonic()
    rng = random.Random(20261108)
    data = json.loads(Path(__file__).with_name("sparse_bip_core_interfaces.json").read_text(encoding="utf-8"))
    certificate = verify_certificate(data)
    core_cases, graph_cases, with_core_forks, with_cross, max_core_chain = 0, 0, 0, 0, 0
    shapes, roots_seen, witnesses = set(), set(), {}
    def check_core(name, core):
        nonlocal core_cases, max_core_chain
        result = safe_sparse_bipartite_core(core)
        verify_core(core, result)
        core_cases += 1
        shapes.add(result["skeleton"])
        roots_seen.update(result["red"].values())
        for item in result["chain_reports"]:
            max_core_chain = max(max_core_chain, len(item["path"]) - 1)
        return result
    def check_graph(name, graph):
        nonlocal graph_cases, with_core_forks, with_cross
        assert independent_domain(graph)
        result = color_subcubic_sparse_bip_core(graph)
        verify(graph, result)
        graph_cases += 1
        h = graph.subgraph([v for v in graph if graph.degree(v) == 3])
        with_core_forks += any(h.degree(v) == 3 for v in h)
        membership = {v: i for i, vertices in enumerate(nx.connected_components(h)) for v in vertices}
        with_cross += any(len(item["path"]) == 3 and membership[item["path"][0]] != membership[item["path"][-1]]
                          for item in result.get("threads", []))
        roots_seen.update(result.get("root_red", {}).values())
        for item in result.get("core_reports", []):
            shape = item["skeleton"]
            if shape not in witnesses:
                witnesses[shape] = {"name": name, "core": item,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    check_graph("single_vertex", nx.empty_graph(1))
    for length in range(1, 25):
        core = nx.path_graph(length)
        check_core("path_core", core)
        if length >= 4 and length % 2 == 0:
            check_core("cycle_core", nx.cycle_graph(length))
    finite_kernels, lifted_kernels = 0, 0
    for record in data["finite_records"]:
        core = build_core(record)
        result = check_core("finite_kernel", core)
        assert result["skeleton"] == record["shape"]
        assert result["representative_lengths"] == record["lengths"]
        check_graph("embedded_finite_kernel", embed_core(core, rng))
        finite_kernels += 1
        lengths = [length + (2 * rng.randrange(1, 15) if length >= 7 else 0) for length in record["lengths"]]
        core = build_core(record, lengths, [rng.randrange(1, 20) for _ in range(6)])
        result = check_core("lifted_kernel", core)
        assert result["representative_lengths"] == record["lengths"]
        check_graph("embedded_lifted_kernel", embed_core(core, rng))
        lifted_kernels += 1
    atlas_colored, atlas_excluded, aux_atlas = 0, 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) and nx.is_connected(graph) and max(dict(graph.degree()).values()) <= 3:
            if nx.is_bipartite(graph) and sum(d == 3 for _, d in graph.degree()) <= 2:
                check_core("atlas_auxiliary", graph)
                aux_atlas += 1
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected = independent_domain(graph)
        result = color_subcubic_sparse_bip_core(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check_graph("atlas_original", graph)
            atlas_colored += 1
        else:
            atlas_excluded += 1
    # All boundary incidences are CROSS short paths here. Each bipartition
    # class contains at most one fork control, so theorem E is inapplicable.
    sparse_records = [record for record in data["finite_records"]
                      if (record["shape"], record["lengths"]) in [
                          ("claw", []), ("double_star", [1]), ("theta", [1, 3, 3]),
                          ("lollipop_fork", [4, 1]), ("barbell", [4, 4, 1])]]
    named_cross_networks = 0
    for record in sparse_records:
        graph = cross_clones(build_core(record), rng)
        excluded = color_subcubic_adjustable_bip_short_threads(graph)
        assert excluded["status"] == "method_not_applicable"
        assert excluded["reason"] == "cross_short_component_not_adjustable"
        check_graph("sparse_cross_" + record["shape"], graph)
        named_cross_networks += 1
    random_cases, disconnected = 0, 0
    while random_cases < 800:
        cores = []
        for _ in range(rng.randrange(2, 7)):
            if rng.random() < 0.15:
                core = nx.path_graph(rng.randrange(1, 12))
            else:
                record = rng.choice(data["finite_records"])
                lengths = [length + 2 * rng.randrange(0, 7) for length in record["lengths"]]
                core = build_core(record, lengths, [rng.randrange(1, 8) for _ in range(6)])
            cores.append(core)
        graph = join_cores(cores, rng)
        if graph is None:
            disconnected += 1
            continue
        check_graph("random_sparse_module_network", graph)
        random_cases += 1
    long_specs = [
        ("double_star", [5001]), ("lollipop", [5000]),
        ("theta", [1, 3, 5001]), ("barbell", [5000, 4, 1])]
    for shape, lengths in long_specs:
        record = next(r for r in data["finite_records"] if r["shape"] == shape)
        core = build_core(record, lengths, [1] * 6)
        check_core("long_core_chain", core)
    check_graph("long_original_connection", cross_clones(build_core(sparse_records[-1]), rng, long_first=True))
    label_graph = nx.relabel_nodes(build_core(sparse_records[-1]), lambda v: ("root", v))
    check_core("tuple_labels", label_graph)
    assert shapes == {"path", "even_cycle", "claw", "lollipop", "double_star",
                      "lollipop_fork", "cycle_two_arms", "theta", "barbell"}
    assert roots_seen == set(SAFE)
    report = {"checks_passed": True, "certificate": certificate,
        "auxiliary_core_colorings_checked": core_cases, "auxiliary_atlas_cores": aux_atlas,
        "complete_finite_kernels_embedded": finite_kernels, "lifted_finite_kernels": lifted_kernels,
        "eligible_original_atlas_graphs": atlas_colored, "inapplicable_original_atlas_graphs": atlas_excluded,
        "named_sparse_cross_networks": named_cross_networks, "random_sparse_module_networks": random_cases,
        "disconnected_random_draws_skipped": disconnected, "long_core_chain_cases": len(long_specs),
        "long_original_connection_cases": 1,
        "actual_original_graph_colorings_checked": graph_cases, "original_graphs_with_core_forks": with_core_forks,
        "original_graphs_with_cross_short_paths": with_cross, "safe_root_values_observed": sorted(roots_seen),
        "auxiliary_skeletons_observed": sorted(shapes), "maximum_lifted_core_chain_length": max_core_chain,
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Complete finite auxiliary certificate plus finite implementation audit. Infinite scope needs the separate structural classification and lifting proof."}
    Path(__file__).with_name("subcubic_sparse_bip_core_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_sparse_bip_core_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
