"""One mixed private port with red one/five on any eligible bipartite SAFE core."""

import json
from functools import lru_cache
from pathlib import Path

import networkx as nx

from marked_theta_certificate import verify_certificate
from safe_odd_cactus_core import cactus_cycles, safe_cactus_core
from sparse_bipartite_core import SAFE, _chain_word


@lru_cache(None)
def _records():
    data = json.loads(Path(__file__).with_name("marked_theta_interfaces.json").read_text(encoding="utf-8"))
    verify_certificate(data)
    return {tuple(record["lengths"]): record for record in data["marked_records"]}


def _rep(n):
    return n if n <= 6 else 7 + int(n % 2 == 0)


def strong_marked_safe_core(core, marked_vertex):
    if marked_vertex not in core or core.degree(marked_vertex) > 2:
        raise ValueError("The marked vertex must have a free incidence.")
    if not nx.is_connected(core) or not nx.is_bipartite(core) or max(dict(core.degree()).values()) > 3:
        return {"status": "method_not_applicable", "reason": "not_bipartite_subcubic_core",
                "mother_conjecture_proved": False}
    if cactus_cycles(core) is not None:
        return safe_cactus_core(core, marked_vertex, 1, forbid_balanced=True)
    forks = [v for v in core if core.degree(v) == 3]
    if len(forks) > 2:
        return {"status": "method_not_applicable", "reason": "noncactus_with_more_than_two_forks",
                "mother_conjecture_proved": False}
    # The connected noncactus subcubic core with <=2 forks is a theta.
    assert len(forks) == 2 and core.degree(marked_vertex) == 2
    left, right = forks
    paths, used = [], set()
    for neighbor in core[left]:
        path, previous, current = [left, neighbor], left, neighbor
        while core.degree(current) == 2:
            other = next(v for v in core[current] if v != previous)
            path.append(other)
            previous, current = current, other
        assert current == right
        paths.append(path)
        used.update(frozenset(edge) for edge in zip(path, path[1:]))
    assert len(paths) == 3 and len(used) == core.number_of_edges()
    marked_path = next(path for path in paths if marked_vertex in path[1:-1])
    others = [path for path in paths if path is not marked_path]
    others.sort(key=len)
    k = marked_path.index(marked_vertex)
    p, q = k, len(marked_path) - 1 - k
    lengths = [_rep(p), _rep(q), *[_rep(len(path) - 1) for path in others]]
    # A nondecreasing actual pair stays nondecreasing after parity-preserving
    # truncation because both ordinary lengths have equal parity.
    assert lengths[2] <= lengths[3]
    record = _records()[tuple(lengths)]
    a, b = record["left_ports"], record["right_ports"]
    red_left, red_right = sum(a), sum(b)
    chains = [(marked_path[:k + 1], red_left, a[0], 1, 0),
              (marked_path[k:], 1, 0, red_right, b[0]),
              (others[0], red_left, a[1], red_right, b[1]),
              (others[1], red_left, a[2], red_right, b[2])]
    boundary = {v: [] for v in core}
    boundary[marked_vertex] = [1]
    red, values = {}, {}
    for path, L, x, R, y in chains:
        word = _chain_word(len(path) - 1, L, x, R, y)
        assert word is not None
        for u, v, weight in zip(path, path[1:], word["weights"]):
            key = frozenset((u, v))
            assert key not in values
            values[key] = weight
        for v, port in zip(path[1:-1], word["internal_ports"]):
            assert not boundary[v]
            boundary[v] = [port]
        for v, r in zip(path, word["reds"]):
            assert v not in red or red[v] == r
            red[v] = r
    assert red[marked_vertex] == 1
    assert all(len(boundary[v]) == 3 - core.degree(v) for v in core)
    assert all(red[v] in SAFE for v in core) and all(red[u] != red[v] for u, v in core.edges())
    edges = list(core.edges())
    return {"status": "weighted", "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges], "boundary_ports": boundary,
            "red": red, "marked_vertex": marked_vertex, "marked_value": 1, "marked_red": 1,
            "skeleton": "marked_theta", "representative_lengths": lengths,
            "mother_conjecture_proved": False}
