"""Conditional tree gluing of GIVEN local doubled-edge colorings.

The hypotheses are checked explicitly. This is not a general graph solver:
the piece--boundary incidence graph must be a tree and the color-degree
intervals must be separated. No subcubic draft is assumed by this module.
"""

from collections import deque

import networkx as nx


def color_piece_tree(graph, pieces, weights):
    """Each piece is an iterable of original edges, with parallel weight list.

    Piece vertices are the endpoints of those edges. Pieces partition E(G).
    Edges with two nonshared ends must already have a valid local coloring;
    edges at a shared end will instead use the strict interval hypotheses.
    K1 is allowed without pieces. Unsupported structures return an explicit
    method_not_applicable result, never a claim of uncolorability.
    """
    if (graph.is_directed() or graph.is_multigraph()
            or nx.number_of_selfloops(graph) or not len(graph)
            or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    parts = [list(part) for part in pieces]
    values = [list(row) for row in weights]
    if len(parts) != len(values):
        raise ValueError("The piece and weight lists must have the same size.")
    if not graph.number_of_edges():
        if parts:
            raise ValueError("K1 has no nonempty edge pieces.")
        return {"status": "colored", "edge_order": [], "weights": [],
                "red": dict.fromkeys(graph, 0), "blue": dict.fromkeys(graph, 0),
                "piece_complements": [], "boundary_vertices": [],
                "intervals": {}, "mother_conjecture_proved": False}
    membership = {v: [] for v in graph}
    owner, local_red, local_blue, local_degree = {}, [], [], []
    for i, (part, row) in enumerate(zip(parts, values)):
        if not part or len(part) != len(row):
            raise ValueError("Every piece must be nonempty with one weight per edge.")
        piece = nx.Graph()
        for edge, value in zip(part, row):
            if len(edge) != 2 or value not in (0, 1, 2):
                raise ValueError("Each piece edge needs a 0/1/2 weight.")
            u, v = edge
            identity = frozenset((u, v))
            if u == v or not graph.has_edge(u, v) or identity in owner:
                raise ValueError("Piece edges must partition the input edges.")
            owner[identity] = i
            piece.add_edge(u, v)
        if not nx.is_connected(piece):
            raise ValueError("Each piece must be connected.")
        degree = dict(piece.degree())
        red = dict.fromkeys(piece, 0)
        for (u, v), value in zip(part, row):
            red[u] += value
            red[v] += value
        blue = {v: 2 * degree[v] - red[v] for v in piece}
        local_red.append(red)
        local_blue.append(blue)
        local_degree.append(degree)
        for v in piece:
            membership[v].append(i)
    if len(owner) != graph.number_of_edges():
        raise ValueError("Some input edges have no piece.")
    boundary = {v for v in graph if len(membership[v]) > 1}
    # Tagged node identities support arbitrary hashable original vertex labels.
    incidence = nx.Graph()
    incidence.add_nodes_from((0, i) for i in range(len(parts)))
    for v in graph:
        if v in boundary:
            incidence.add_node((1, v))
            incidence.add_edges_from(((1, v), (0, i)) for i in membership[v])
    if not nx.is_tree(incidence):
        return {"status": "method_not_applicable",
                "reason": "piece_boundary_incidence_is_not_a_tree"}
    radii = {v: max(abs(local_red[i][v] - local_degree[i][v])
                    for i in membership[v]) for v in boundary}
    intervals = {v: (graph.degree(v) - radii[v],
                     graph.degree(v) + radii[v]) for v in boundary}
    for i, (part, row) in enumerate(zip(parts, values)):
        for (u, v), value in zip(part, row):
            high = [w for w in (u, v) if w in boundary]
            if len(high) == 2:
                if abs(graph.degree(u) - graph.degree(v)) <= radii[u] + radii[v]:
                    return {"status": "method_not_applicable",
                            "reason": "boundary_intervals_not_separated",
                            "edge": (u, v)}
            elif len(high) == 1:
                h = high[0]
                low = v if h == u else u
                if intervals[h][0] <= max(local_red[i][low], local_blue[i][low]):
                    return {"status": "method_not_applicable",
                            "reason": "boundary_low_interval_not_separated",
                            "edge": (u, v)}
            elif ((value > 0 and local_red[i][u] == local_red[i][v])
                    or (value < 2 and local_blue[i][u] == local_blue[i][v])):
                raise ValueError("An edge with no shared endpoint has an invalid local coloring.")
    # Root at a piece. Every boundary has one already oriented parent piece.
    complements = [None] * len(parts)
    complements[0] = 0
    parent = {(0, 0): None}
    order, queue = [], deque([(0, 0)])
    while queue:
        node = queue.popleft()
        order.append(node)
        for nxt in incidence[node]:
            if nxt not in parent:
                parent[nxt] = node
                queue.append(nxt)
    signed_totals = {}
    for kind, key in order:
        if kind == 0:
            continue
        v = key
        parent_piece = parent[(kind, key)][1]
        initial = local_red[parent_piece][v] - local_degree[parent_piece][v]
        total = initial * (1 if complements[parent_piece] == 0 else -1)
        for node in incidence[(kind, key)]:
            i = node[1]
            if i == parent_piece:
                continue
            assert complements[i] is None
            increment = local_red[i][v] - local_degree[i][v]
            complement = int(abs(total - increment) < abs(total + increment))
            complements[i] = complement
            total += increment * (1 if complement == 0 else -1)
            assert abs(total) <= radii[v]
        signed_totals[v] = total
    assert all(bit in (0, 1) for bit in complements)
    edge_values = {}
    for bit, part, row in zip(complements, parts, values):
        for edge, value in zip(part, row):
            edge_values[frozenset(edge)] = 2 - value if bit else value
    edge_order = list(graph.edges())
    result_weights = [edge_values[frozenset(edge)] for edge in edge_order]
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edge_order, result_weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert all(red[v] - graph.degree(v) == signed_totals[v] for v in boundary)
    assert all(intervals[v][0] <= red[v] <= intervals[v][1]
               and intervals[v][0] <= blue[v] <= intervals[v][1] for v in boundary)
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for (u, v), x in zip(edge_order, result_weights))
    return {"status": "colored", "edge_order": edge_order, "weights": result_weights,
            "red": red, "blue": blue, "piece_complements": complements,
            "boundary_vertices": [v for v in graph if v in boundary],
            "intervals": intervals, "signed_totals": signed_totals,
            "mother_conjecture_proved": False}
