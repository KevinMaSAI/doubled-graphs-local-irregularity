"""Integer LIR construction for a supplied paired vertex partition.

Both induced sides have maximum degree one, and T must have no induced
isolates. Each internal pair has endpoint degrees at least three differing
by at most one. Other degrees are unrestricted. No expansion is performed.
"""

from signed_gap_two import signed_gap_two


def color_integer_matching_cut(vertices, edges, T):
    vertices, edges, T = list(vertices), [tuple(e) for e in edges], set(T)
    V = set(vertices)
    if not vertices or len(V) != len(vertices) or not T <= V:
        raise ValueError("Use distinct vertices and an existing vertex subset T.")
    adjacency, inventory = {v: set() for v in vertices}, set()
    for u, v in edges:
        key = frozenset((u, v))
        if u not in V or v not in V or len(key) != 2 or key in inventory:
            raise ValueError("A simple undirected graph is required.")
        inventory.add(key); adjacency[u].add(v); adjacency[v].add(u)
    degrees = {v: len(adjacency[v]) for v in vertices}

    def reject(reason):
        return {"status": "not_applicable", "reason": reason, "mother_conjecture_proved": False}

    inside = {v: sum((u in T) == (v in T) for u in adjacency[v]) for v in vertices}
    if any(inside[v] > 1 for v in V) or any(inside[v] != 1 for v in T):
        return reject("Both induced sides must be matchings, and T must have no induced isolated vertex.")
    pairs = [(u, v) for u, v in edges if (u in T) == (v in T)]
    if any(min(degrees[u], degrees[v]) < 3 or abs(degrees[u]-degrees[v]) > 1 for u, v in pairs):
        return reject("Each internal pair needs endpoint degrees at least three differing by at most one.")
    cross = [i for i, (u, v) in enumerate(edges) if (u in T) != (v in T)]
    rows = [{i: (1 if u in edges[i] else -1) for i in cross if u in edges[i] or v in edges[i]}
            for u, v in pairs]
    assert all(len(row) >= 4 for row in rows)
    result = signed_gap_two(rows)
    values = [1+result["signs"][i] if i in result["signs"] else 1 if u in T else 0
              for i, (u, v) in enumerate(edges)]
    R, B = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    for (u, v), x in zip(edges, values):
        for copy in range(2):
            target = R if copy < x else B
            target[u] += 1; target[v] += 1
    assert all(R[v] % 2 == int(v in T) and B[v] % 2 == int(v in T) for v in vertices)
    for (u, v), total in zip(pairs, result["row_sums"]):
        assert R[u]-R[v] == degrees[u]-degrees[v]+total
        assert B[u]-B[v] == degrees[u]-degrees[v]-total
        assert R[u] != R[v] and B[u] != B[v]
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for (u, v), x in zip(edges, values))
    mod4 = all((x == 0 or (R[u]-R[v]) % 4) and (x == 2 or (B[u]-B[v]) % 4)
               for (u, v), x in zip(edges, values))
    return {"status": "colored", "vertices": vertices, "T": [v for v in vertices if v in T],
            "edges": [[u, v, x] for (u, v), x in zip(edges, values)], "red": R, "blue": B,
            "paired_edges": [list(e) for e in pairs],
            "mixed_edges": [[u, v] for (u, v), x in zip(edges, values) if x == 1],
            "signed_rows": [[[i, c] for i, c in row.items()] for row in rows],
            "signed_solution": result, "satisfies_stronger_mod4_condition": bool(mod4),
            "new_vertices_added": 0, "new_edges_added": 0, "mother_conjecture_proved": False}


def phase_barrier_core(k):
    if type(k) is not int or k < 1:
        raise ValueError("A positive integer k is required.")
    n = 4*k
    base = [(v, (v+1) % n) for v in range(n)]+[(v, v+2*k) for v in range(2*k)]
    T = list(range(n, n+len(base)))
    edges = [(v, T[i]) for i, e in enumerate(base) for v in e]
    edges += [(2*i, 2*i+1) for i in range(2*k)]
    edges += [(T[2*i], T[2*i+1]) for i in range(3*k)]
    answer = color_integer_matching_cut(list(range(10*k)), edges, T)
    assert answer["status"] == "colored"
    answer.update({"family": "genuine_3_4_phase_barrier_core", "parameter": k,
                   "fixed_mixed_mod4_feasible_exactly_when_k_even": True})
    return answer


def cube_extra_cross_edge():
    vertices = list(range(8))
    edges = [(u, v) for u in vertices for v in vertices if u < v and u ^ v in (1, 2, 4)]
    edges.append((0, 3))
    answer = color_integer_matching_cut(vertices, edges, [2, 3, 4, 5])
    assert answer["status"] == "colored"
    answer["family"] = "cube_plus_cross_edge"
    return answer
