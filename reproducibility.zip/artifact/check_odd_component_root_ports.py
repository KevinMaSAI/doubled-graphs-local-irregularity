"""Check root-port constructions on variable degree profiles and whole graphs."""

from collections import Counter
import itertools
import json
from pathlib import Path
import time

import networkx as nx

from odd_component_root_ports import (inspect_root_layout, color_root_ports,
    color_fixed_roots_by_parity, color_common_neighbor_pairs,
    root_paired_bridge_triangles, two_odd_cycles_with_leaves, branching_isolated_roots)

OUT = Path(__file__).resolve().parent


def raw(answer):
    V = answer["vertices"]; T = set(answer["T"]); R, B, D = Counter(), Counter(), Counter(); E = set()
    for u, v, x in answer["edges"]:
        key = frozenset((u, v)); assert len(key) == 2 and key not in E and x in (0, 1, 2); E.add(key)
        D[u] += 1; D[v] += 1
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert {v: R[v] for v in V} == answer["red"] and {v: B[v] for v in V} == answer["blue"]
    for u, v, x in answer["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    assert all(R[v] % 2 == B[v] % 2 == int(v not in T) for v in V)
    assert dict(answer["S_red_targets"]) == {v: R[v] for v in V if v not in T}
    assert answer["new_vertices_added"] == answer["new_edges_added"] == 0
    assert answer["mother_conjecture_proved"] is False
    return D


def doubled_profile(degrees, cycle):
    n = len(degrees)
    internal = [2 if cycle or 0 < i < n-1 else int(n > 1) for i in range(n)]
    capacities = [d-a for d, a in zip(degrees, internal)]
    T = list(range(2*n, 2*n+max(capacities)))
    E = [(start+i, start+(i+1) % n) for start in (0, n) for i in range(n if cycle else n-1)]
    E += [(start+i, T[j]) for start in (0, n) for i, c in enumerate(capacities) for j in range(c)]
    return list(range(2*n+len(T))), E, T


def main():
    started = time.monotonic(); saved = {}; profile_counts = Counter()
    for cycle in (False, True):
        for n in (3, 5, 7):
            options = [range(4, 7)]*n if cycle else [range(3, 6)]+[range(4, 7)]*(n-2)+[range(3, 6)]
            for degrees in itertools.product(*options):
                if any(abs(degrees[i]-degrees[(i+1) % n]) > 1 for i in range(n if cycle else n-1)):
                    continue
                V, E, T = doubled_profile(degrees, cycle)
                info = inspect_root_layout(V, E, T); assert info["status"] == "applicable"
                roots = info["S_components"][0]["admissible_roots"]
                for r in roots:
                    answer = color_common_neighbor_pairs(V, E, T, [(r, T[0], n+r)]); raw(answer)
                    profile_counts["cycle_colorings" if cycle else "path_colorings"] += 1
                if cycle:
                    for r in range(n):
                        phase = any(2*degrees[(r+1) % n]-(1+4*p) != 2*degrees[r]-3 and
                                    2*degrees[(r-1) % n]-(1+4*(1-p)) != 2*degrees[r]-3 for p in (0, 1))
                        assert phase == (r in roots)
                        profile_counts["cycle_root_phase_checks"] += 1
                    bad = next((r for r in range(n) if r not in roots), None)
                    if bad is not None:
                        try:
                            color_common_neighbor_pairs(V, E, T, [(bad, T[0], n+bad)])
                        except ValueError:
                            profile_counts["inadmissible_root_rejections"] += 1
                        else:
                            raise AssertionError("A strict degree extremum was admitted as a cycle root.")
                profile_counts["degree_profiles"] += 1
    for d in [1, 2, 3, 5, 9]:
        V, E, T = doubled_profile([d], False)
        raw(color_common_neighbor_pairs(V, E, T, [(0, T[0], 1)]))
        profile_counts["isolated_root_colorings"] += 1
    atlas = Counter()
    for G in nx.graph_atlas_g():
        if not len(G) or not nx.is_connected(G):
            continue
        V, E = list(G), list(G.edges())
        for mask in range(1, 1 << len(V)):
            T = {v for v in V if mask >> v & 1}
            if any(u in T and v in T for u, v in E):
                continue
            info = inspect_root_layout(V, E, T)
            if info["status"] != "applicable":
                continue
            odd = [c for c in info["S_components"] if len(c["vertices"]) % 2]
            for roots in itertools.product(*(c["admissible_roots"] for c in odd)):
                A = nx.Graph(); A.add_nodes_from(set(roots) | T)
                A.add_edges_from((u, v) for u, v in E if (u in roots and v in T) or (v in roots and u in T))
                gate = all(len(set(C) & set(roots)) % 2 == 0 for C in nx.connected_components(A))
                answer = color_fixed_roots_by_parity(V, E, T, roots)
                assert (answer["status"] == "colored") == gate
                atlas[answer["status"]] += 1
                if gate:
                    raw(answer)
                else:
                    U = set(answer["odd_root_component"])
                    assert len(U & set(roots)) % 2 and all((u in U) == (v in U) for u, v in A.edges())
    bridge_records = []
    for t in [1, 2, 3, 5, 10]:
        answer = root_paired_bridge_triangles(t); D = raw(answer)
        assert len(D) == 30*t+10 and len(answer["edges"]) == 45*t+18
        assert Counter(D.values()) == Counter({3: 30*t+4, 4: 6})
        assert sum(len(c["vertices"]) % 2 for c in answer["S_components"]) == 2
        bridge_records.append({"t": t, "vertices": len(D), "edges": len(answer["edges"])})
        if t == 1:
            saved["bridge_family_with_two_odd_triangles"] = answer
    high_records = []
    for n, q, leaves in [(3, 2, 0), (5, 7, 1), (7, 17, 3), (11, 29, 0), (15, 41, 2)]:
        answer = two_odd_cycles_with_leaves(n, q, leaves); D = raw(answer)
        assert len(D) == 2*n+q+2*leaves and len(answer["edges"]) == 2*n*(q+1)+2*leaves
        high_records.append({"cycle_length": n, "T_size": q, "leaf_pairs": leaves,
                             "minimum_degree": min(D.values()), "maximum_degree": max(D.values())})
        if n == 5:
            saved["unbounded_degrees_and_leaves"] = answer
    V, E, T = doubled_profile([3, 4, 5, 4, 3], False)
    roots = [2, 7]; ports = [(v, t) for v in roots for t in T]
    answer = color_root_ports(V, E, T, roots, ports); raw(answer)
    assert all(sum(v in e for e in answer["mixed_port_edges"]) == 3 for v in roots)
    assert all(answer["red"][v] == 5 for v in [1, 3, 6, 8])
    saved["three_ports_at_nonisolated_path_roots"] = answer
    branch_records = []
    for b in [3, 5, 7, 11]:
        branch_answer = branching_isolated_roots(b); raw(branch_answer)
        assert len(branch_answer["vertices"]) == 1+6*b and len(branch_answer["edges"]) == 10*b
        assert sum(0 in e for e in branch_answer["mixed_port_edges"]) == b
        branch_records.append({"branches": b, "vertices": 1+6*b, "edges": 10*b})
    branch = branching_isolated_roots(); raw(branch)
    roots = branch["roots"]; T = set(branch["T"]); neighbors = {v: set() for v in roots}
    for t in T:
        adjacent = [v for v in roots if any(set(e[:2]) == {v, t} for e in branch["edges"])]
        for u, v in itertools.combinations(adjacent, 2):
            neighbors[u].add(v); neighbors[v].add(u)
    Q = nx.Graph(); Q.add_nodes_from(roots); Q.add_edges_from((u, v) for u in roots for v in neighbors[u])
    Q.remove_node(0)
    odd_groups = [set(c) for c in nx.connected_components(Q)]
    assert len(odd_groups) == 3 and all(len(c) == 3 for c in odd_groups)
    assert {frozenset(c) for c in odd_groups} == set(map(frozenset, branch["root_pairing_tutte_barrier"]["odd_components"]))
    assert sum(0 in e for e in branch["mixed_port_edges"]) == 3
    saved["pairing_fails_but_branching_ports_work"] = branch
    # A connected full cross graph whose fixed-root port graph has odd components.
    V, T = list(range(7)), [4, 5, 6]
    E = [(0, 4), (1, 5), (2, 4), (2, 6), (3, 5), (3, 6), (2, 3)]
    no_join = color_fixed_roots_by_parity(V, E, T, [0, 1])
    assert no_join["status"] == "no_parity_join_for_these_roots"
    C = nx.Graph(E[:-1]); assert nx.is_connected(C)
    # Explicit legal coloring uses ports on the even S component as well.
    weights = [1, 1, 1, 2, 1, 0, 0]
    R, B = Counter(), Counter()
    for (u, v), x in zip(E, weights):
        R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v]) for (u, v), x in zip(E, weights))
    saved["even_component_transport_gap"] = {"root_only_negative": no_join,
        "actual_coloring": {"vertices": V, "T": T, "edges": [[u, v, x] for (u, v), x in zip(E, weights)],
                            "red": dict(R), "blue": dict(B), "mother_conjecture_proved": False}}
    # More than three ports is unsupported at a non-isolated root, not an UNSAT proof.
    V, E, T = doubled_profile([6, 7, 6], False)
    too_many = color_root_ports(V, E, T, [0, 3], [(r, t) for r in [0, 3] for t in T])
    assert too_many["status"] == "root_capacity_not_supported"
    report = {"degree_profile_checks": dict(profile_counts), "fixed_root_atlas_outcomes": dict(atlas),
              "root_paired_bridge_family": bridge_records, "unbounded_degree_family": high_records,
              "branching_isolated_root_family": branch_records,
              "nonisolated_three_port_roots_checked": 2,
              "auxiliary_pairing_tutte_barrier_odd_components": 3,
              "even_component_transport_gap_verified": True, "saved_groups": len(saved),
              "all_checks_passed": True, "elapsed_seconds": round(time.monotonic()-started, 3),
              "mother_conjecture_proved": False, "finite_tests_are_not_universal_proofs": True}
    (OUT/"odd_component_root_ports_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (OUT/"odd_component_root_ports_witnesses.json").write_text(json.dumps(saved, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
