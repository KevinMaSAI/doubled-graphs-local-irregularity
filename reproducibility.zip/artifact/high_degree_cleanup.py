"""Remove bad colored edges whose color-degree exceeds both original degrees.

This is a terminating partial reduction, NOT a full coloring algorithm.
In particular, an all-mixed triangle remains bad after this reduction.
"""


def counts(graph, edges, weights):
    red = dict.fromkeys(graph, 0)
    blue = dict.fromkeys(graph, 0)
    for (u, v), x in zip(edges, weights):
        red[u] += x
        red[v] += x
        blue[u] += 2-x
        blue[v] += 2-x
    return red, blue


def histogram(graph, edges, weights, red, blue):
    maximum = max(dict(graph.degree()).values(), default=0)
    values = [0]*(2*maximum+1)
    for (u, v), x in zip(edges, weights):
        if red[u] == red[v]:
            values[red[u]] += x
        if blue[u] == blue[v]:
            values[blue[u]] += 2-x
    return values


def remove_high_bad_colors(graph, weights):
    return _reduce_extremes(graph, weights, include_degree_one=False)


def remove_extreme_bad_colors(graph, weights):
    """Also eliminate color-degree-one conflicts; exclude isolated K2 components."""
    return _reduce_extremes(graph, weights, include_degree_one=True)


def _reduce_extremes(graph, weights, include_degree_one):
    edges = list(graph.edges())
    x = list(weights)
    if len(x) != len(edges) or any(a not in (0, 1, 2) for a in x):
        raise ValueError('One weight in {0,1,2} per graph edge is required.')
    if graph.is_multigraph() or graph.is_directed() or any(u == v for u, v in edges):
        raise ValueError('A simple undirected graph is required.')
    if include_degree_one and any(graph.degree(u) == graph.degree(v) == 1 for u, v in edges):
        raise ValueError('Isolated K2 components are excluded from the combined reduction.')
    red, blue = counts(graph, edges, x)
    initial_energy = sum((red[v]-graph.degree(v))**2 for v in graph)
    trace = []
    while True:
        move = None
        for i, (u, v) in enumerate(edges):
            bound = max(graph.degree(u), graph.degree(v))
            if x[i] > 0 and red[u] == red[v] and red[u] > bound:
                move = (i, -1, 'red', red[u], 'high')
                break
            if x[i] < 2 and blue[u] == blue[v] and blue[u] > bound:
                move = (i, 1, 'blue', blue[u], 'high')
                break
        if move is None and include_degree_one:
            for i, (u, v) in enumerate(edges):
                if x[i] > 0 and red[u] == red[v] == 1:
                    assert x[i] == 1
                    move = (i, 1, 'red', 1, 'one')
                    break
                if x[i] < 2 and blue[u] == blue[v] == 1:
                    assert x[i] == 1
                    move = (i, -1, 'blue', 1, 'one')
                    break
        if move is None:
            break
        i, delta, color, level, rule = move
        u, v = edges[i]
        before_energy = sum((red[z]-graph.degree(z))**2 for z in graph)
        before_hist = histogram(graph, edges, x, red, blue)
        x[i] += delta
        red[u] += delta
        red[v] += delta
        blue[u] -= delta
        blue[v] -= delta
        after_energy = sum((red[z]-graph.degree(z))**2 for z in graph)
        after_hist = histogram(graph, edges, x, red, blue)
        before_one = before_hist[1] if len(before_hist) > 1 else 0
        after_one = after_hist[1] if len(after_hist) > 1 else 0
        if rule == 'high':
            assert after_energy-before_energy == -4*level+2*(graph.degree(u)+graph.degree(v))+2
            assert after_energy <= before_energy-2
            assert tuple(reversed(after_hist)) < tuple(reversed(before_hist))
        else:
            assert after_energy-before_energy == 6-2*(graph.degree(u)+graph.degree(v))
            assert after_energy <= before_energy
            assert after_one < before_one
        assert (after_energy, after_one) < (before_energy, before_one)
        trace.append({'edge': (u, v), 'old_bad_color': color, 'old_color_degree': level,
                      'rule': rule,
                      'delta_red': delta, 'energy_before': before_energy,
                      'energy_after': after_energy,
                      'degree_one_bad_before': before_one, 'degree_one_bad_after': after_one,
                      'bad_copies_before': sum(before_hist),
                      'bad_copies_after': sum(after_hist)})
    final_hist = histogram(graph, edges, x, red, blue)
    step_bound = ((initial_energy//2+1)*(2*len(edges)+1)-1
                  if include_degree_one else initial_energy//2)
    assert len(trace) <= step_bound
    return {'edges': edges, 'weights': x, 'red_degrees': red, 'blue_degrees': blue,
            'initial_energy': initial_energy,
            'step_bound': step_bound,
            'final_energy': sum((red[v]-graph.degree(v))**2 for v in graph),
            'remaining_bad_copies': sum(final_hist),
            'valid': not any(final_hist), 'trace': trace}
