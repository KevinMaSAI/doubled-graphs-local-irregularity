"""Independent scope, rooted types, list interfaces and actual-copy checks."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import build_core, join_cores, verify_core
from safe_tree_core import TYPES, safe_tree_core
from subcubic_bip_core_no_three import bipartite_degree_list_coloring, color_subcubic_bip_core_no_three


def independent_domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return False
    roots = {v for v in graph if degree[v] == 3}
    if not nx.is_bipartite(graph.subgraph(roots)):
        return False
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        if len(attachments) == 2 and attachments[0] != attachments[1] and len(vertices) == 2:
            return False
    return True


def main():
    start = time.monotonic()
    rng = random.Random(20261110)
    finite_cases = 0
    # Independent enumeration of local incoming/children/private choices.
    local = {name: {x: {r for y, r in states if y == x} for x in range(3)}
             for name, states in TYPES.items()}
    for count in range(3):
        for names in itertools.product(TYPES, repeat=count):
            obtained = set()
            for incoming in range(3):
                for weights in itertools.product(range(3), repeat=count):
                    for bits in itertools.product((0, 2), repeat=2 - count):
                        red = incoming + sum(weights) + sum(bits)
                        if red not in (0, 1, 3, 5, 6):
                            continue
                        if all(local[name][weight] - {red} for name, weight in zip(names, weights)):
                            obtained.add((incoming, red))
            expected = "L" if count == 0 else "O" if "L" in names else "A"
            assert obtained == TYPES[expected], names
            finite_cases += 1
    tree_count, tree_modes = 0, set()
    for n in range(2, 14):
        for tree in nx.nonisomorphic_trees(n):
            if max(dict(tree.degree()).values()) <= 3:
                result = safe_tree_core(tree)
                verify_core(tree, result)
                tree_modes.update(result["interface_types"].values())
                tree_count += 1
    for n in (31, 255, 2047):
        tree = nx.balanced_tree(2, n.bit_length() - 1)
        verify_core(tree, safe_tree_core(tree))
        tree_count += 1
    cycle_list_cases, list_modes = 0, set()
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph) or max(dict(graph.degree()).values()) > 3:
            continue
        if not nx.is_bipartite(graph) or nx.is_tree(graph):
            continue
        nodes = list(graph)
        domains = []
        for v in nodes:
            domains.append([set(subset) for k in range(graph.degree(v), 4)
                            for subset in itertools.combinations(range(3), k)])
        for selection in itertools.product(*domains):
            lists = dict(zip(nodes, selection))
            phi, mode = bipartite_degree_list_coloring(graph, lists)
            assert all(phi[v] in lists[v] for v in graph)
            assert all(phi[u] != phi[v] for u, v in graph.edges())
            list_modes.add(mode)
            cycle_list_cases += 1
    cases, atlas_eligible, atlas_outside, root_forks = 0, 0, 0, 0
    modes, adjustments, boundary_counts, witnesses = {}, {}, set(), {}
    two_control_signs, target_nonzero, long_max, loop_pairs = set(), set(), 0, set()
    def check(name, graph):
        nonlocal cases, root_forks, long_max
        assert independent_domain(graph), name
        result = color_subcubic_bip_core_no_three(graph)
        verify(graph, result)
        cases += 1
        for report in result.get("core_reports", []):
            kind = report["kind"]
            modes[kind] = modes.get(kind, 0) + 1
            root_forks = max(root_forks, report["fork_count"])
            if "safe_short_boundary_count" in report:
                boundary_counts.add(report["safe_short_boundary_count"])
            if kind == "two_safe_boundary_ports":
                key = str(report["selected"])
                adjustments[key] = adjustments.get(key, 0) + 1
            if kind == "two_full_core_targets":
                target_nonzero.update(value for value in report["target_mod3"].values() if value)
            witness_key = kind + ":" + str(report.get("selected"))
            if witness_key not in witnesses:
                witnesses[witness_key] = {
                    "name": name, "component": report,
                    "edges": [[u, v, w] for (u, v), w in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        for item in result.get("threads", []):
            length = len(item["path"]) - 1
            long_max = max(long_max, length)
            if item["path"][0] == item["path"][-1]:
                loop_pairs.add(tuple(item["ports"]))
        return result
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected = independent_domain(graph)
        result = color_subcubic_bip_core_no_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_eligible += 1
        else:
            atlas_outside += 1
    check("isolated_vertex", nx.empty_graph(1))
    k33 = nx.complete_bipartite_graph(3, 3)
    cores = [nx.path_graph(n) for n in range(1, 10)]
    cores.extend(nx.cycle_graph(n) for n in (4, 6, 8, 10))
    for n in range(4, 13):
        cores.extend(tree for tree in nx.nonisomorphic_trees(n)
                     if max(dict(tree.degree()).values()) <= 3)
    for removed in [[(0, 3)], [(0, 3), (1, 4)], [(0, 3), (1, 4), (2, 5)]]:
        core = k33.copy()
        core.remove_edges_from(removed)
        cores.append(core)
    prism = nx.circular_ladder_graph(8)
    for removed in [[(0, 1)], [(0, 1), (4, 5)], [(0, 1), (4, 5), (8, 9), (12, 13)]]:
        core = prism.copy()
        core.remove_edges_from(removed)
        cores.append(core)
    certificate = json.loads(Path(__file__).with_name("sparse_bip_core_interfaces.json").read_text(encoding="utf-8"))
    cores.extend(build_core(record) for record in certificate["finite_records"])
    for i in range(1500):
        core_list = [rng.choice(cores) for _ in range(rng.randrange(2, 11))]
        graph = join_cores(core_list, rng, all_short=(i % 2 == 0))
        if graph is not None:
            check("random_module_network", graph)
    # Force every boundary incidence of a large MOD core to a SAFE tree.
    for n in (4, 8, 16):
        core = nx.circular_ladder_graph(n)
        core.remove_edges_from([(0, 1), (n // 2, n // 2 + 1)])
        core = nx.convert_node_labels_to_integers(core)
        count, ordinary = len(core), [(u, v, 1) for u, v in core.edges()]
        pendants = []
        for v in core:
            for _ in range(3 - core.degree(v)):
                ordinary.append((v, count, 2))
                pendants.extend(((count, 1), (count, 2)))
                count += 1
        check("all_MOD_boundary_to_SAFE", expand(count, ordinary, pendants))
    # Return paths of every parity, with list controls or the single-loop control.
    for length in range(3, 13):
        for safe_count in range(5):
            threads = [(v, v + 1, 1) for v in range(5)] + [(0, 0, length)]
            stubs = [v for v in range(1, 6) for _ in range(3 - (2 if v < 5 else 1))]
            count, pendants = 6, []
            for i, v in enumerate(stubs):
                if i < safe_count:
                    # The SAFE edge core has both zero and two private ports.
                    threads.extend(((v, count, 2), (count, count + 1, 1)))
                    pendants.extend(((count, 1), (count + 1, 1), (count + 1, 2)))
                    count += 2
                else:
                    pendants.append((v, 1 + i % 5))
            check("loop_and_SAFE_boundary", expand(count, threads, pendants))
    check("long_5000_with_loop", expand(3, [(0, 1, 1), (1, 2, 1), (0, 0, 5000)],
                                        [(1, 7), (2, 1), (2, 5000)]))
    # Many forks in a SAFE tree, paired across two copies by short paths.
    tree = nx.balanced_tree(2, 8)
    count = len(tree)
    threads = [(u, v, 1) for u, v in tree.edges()]
    threads += [(count + u, count + v, 1) for u, v in tree.edges()]
    left = [v for v in tree for _ in range(3 - tree.degree(v))]
    right = [count + v for v in left]
    rng.shuffle(right)
    threads += [(u, v, 2) for u, v in zip(left, right)]
    check("unbounded_SAFE_tree_forks", expand(2 * count, threads, []))
    result = {
        "rooted_tree_complete_local_cases": finite_cases, "auxiliary_trees_checked": tree_count,
        "rooted_interface_types_observed": sorted(tree_modes),
        "all_small_bipartite_cycle_degree_lists_checked": cycle_list_cases,
        "list_coloring_modes": sorted(list_modes),
        "actual_graph_colorings_verified": cases, "atlas_eligible": atlas_eligible,
        "atlas_outside_scope": atlas_outside, "component_modes": modes,
        "two_boundary_adjustments": adjustments, "safe_boundary_counts": sorted(boundary_counts),
        "largest_direct_core_fork_count": root_forks, "target_nonzero_values": sorted(target_nonzero),
        "return_port_pairs": sorted(loop_pairs), "largest_thread_length": long_max,
        "all_checks_passed": True, "mother_conjecture_proved": False,
        "seconds": round(time.monotonic() - start, 3),
        "scope": "All direct degree-three cores bipartite; ordinary connections length 2 or >=4. Universal proof is separate; these finite checks audit implementation."}
    base = Path(__file__).parent
    (base / "subcubic_bip_core_no_three_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (base / "subcubic_bip_core_no_three_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
