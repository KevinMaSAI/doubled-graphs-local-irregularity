"""A connected 13-regular family with a strict positive two-unit target barrier.

This is NOT a counterexample to the mother conjecture. It refutes a proposed
nonincreasing local optimization rule for red-degree targets.
"""
import json
from numbers import Integral
from pathlib import Path

import networkx as nx


def graph_and_weights(fiber_size=4):
    """Return (G, red_copy_counts) for any even fiber_size >= 4.

    Counts follow list(G.edges()). Reading the accompanying integer table
    requires no SAT solver. The theorem is proved in the accompanying note.
    """
    if not isinstance(fiber_size, Integral) or fiber_size < 4 or fiber_size % 2:
        raise ValueError('fiber_size must be an even integer at least four.')
    data = json.loads(Path(__file__).with_name('frozen_target_data.json').read_text(encoding='utf-8'))
    g = nx.Graph()
    red = {}
    g.add_nodes_from((i,t) for i in range(data['layers']) for t in range(fiber_size))
    for i,c in enumerate(data['internal_red']):
        for t in range(0,fiber_size,2):
            edge=((i,t),(i,t+1))
            g.add_edge(*edge)
            red[frozenset(edge)]=c
    for item in data['cross']:
        i,j,a,b=(item[k] for k in ('i','j','multiplicity','red_sum'))
        for shift in range(a):
            weight=min(2,max(0,b-2*shift))
            for t in range(fiber_size):
                edge=((i,t),(j,(t+shift)%fiber_size))
                g.add_edge(*edge)
                red[frozenset(edge)]=weight
    return g,[red[frozenset(e)] for e in g.edges()]
