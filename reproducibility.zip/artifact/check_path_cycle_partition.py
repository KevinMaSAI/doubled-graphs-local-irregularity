"""Check local extension domains exhaustively and raw whole graph colorings."""

from collections import Counter
import itertools
import json
from pathlib import Path
import random
import time

import networkx as nx

from path_cycle_partition import (color_path_cycle_partition, complete_component,
                                  triangle_block_family, path_incidence_family, cycle_incidence_family)

OUT = Path(__file__).resolve().parent


def brute_component(degrees, cross_red, cycle):
    n = len(degrees); m = n if cycle else n-1
    for bits in itertools.product((0, 1), repeat=m):
        R = [2*s for s in cross_red]
        for i, bit in enumerate(bits):
            R[i] += 2*bit; R[(i+1) % n] += 2*bit
        B = [2*d-r for d, r in zip(degrees, R)]
        if all(R[i] != R[(i+1) % n] if bit else B[i] != B[(i+1) % n]
               for i, bit in enumerate(bits)):
            return bits
    return None


def profile_check(degrees, cross_red, cycle):
    n = len(degrees)
    a = [2 if cycle or 0 < i < n-1 else int(n > 1) for i in range(n)]
    c = [d-v for d, v in zip(degrees, a)]
    answer = complete_component(degrees, cross_red, cycle)
    brute = brute_component(degrees, cross_red, cycle)
    assert (answer["status"] == "extended") == (brute is not None)
    guard = all(abs(2*(cross_red[i]-cross_red[(i+1) % n])-c[i]+c[(i+1) % n]) >= 2
                for i in answer["selected_break_indices"])
    if guard:
        assert brute is not None, (degrees, cross_red, cycle)
    return guard, brute is None


def raw_check(answer):
    vertices = answer["vertices"]; T = set(answer["T"])
    R, B, D = Counter(), Counter(), Counter(); E = set(); M = set()
    for u, v, x in answer["edges"]:
        key = frozenset((u, v)); assert len(key) == 2 and key not in E; E.add(key)
        assert x in (0, 1, 2); D[u] += 1; D[v] += 1
        if x == 1:
            M.add(key)
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert {v: R[v] for v in vertices} == answer["red"] and {v: B[v] for v in vertices} == answer["blue"]
    for u, v, x in answer["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    assert M == set(map(frozenset, answer["mixed_edges"]))
    assert M == {frozenset((u, v)) for u, v, x in answer["edges"] if u in T and v in T}
    assert all(R[v] % 2 == B[v] % 2 == int(v in T) for v in vertices)
    selected = answer["selected_S_edges"]
    assert len({v for e in selected for v in e}) == 2*len(selected)
    solution = answer["signed_solution"]
    rows = [dict(row) for row in answer["signed_rows"]]
    assert [sum(c*solution["signs"][i] for i, c in row.items()) for row in rows] == solution["row_sums"]
    assert all(abs(a) >= 2 for a in solution["row_sums"])
    assert answer["mother_conjecture_proved"] is False
    return D


def main():
    started = time.monotonic(); profiles = guards = failures = 0; examples = {}
    for n in range(2, 7):
        for left, right in itertools.product((3, 4), repeat=2):
            degrees = [left]+[4]*(n-2)+[right]
            capacities = [left-1]+[2]*(n-2)+[right-1]
            for red in itertools.product(*(range(c+1) for c in capacities)):
                guard, failure = profile_check(degrees, red, False)
                profiles += 1; guards += guard; failures += failure
    path_profiles = profiles
    for n in range(3, 9):
        for red in itertools.product(range(3), repeat=n):
            guard, failure = profile_check([4]*n, red, True)
            profiles += 1; guards += guard; failures += failure
    examples["local_obstruction_profiles"] = [complete_component([4]*3, [0]*3, True),
                                                complete_component([4]*4, [0, 0, 0, 1], False)]
    assert all(p["status"] == "no_extension_for_this_profile" for p in examples["local_obstruction_profiles"])
    atlas = 0
    for G in nx.graph_atlas_g():
        if not len(G) or not nx.is_connected(G) or any(d not in (3, 4) for v, d in G.degree()):
            continue
        V, E = list(G), list(G.edges())
        for mask in range(1, 1 << len(V)):
            if mask.bit_count() % 2:
                continue
            T = {v for v in V if mask >> v & 1}
            inside = {v: sum((u in T) == (v in T) for u in G[v]) for v in G}
            if any(inside[v] != 1 for v in T) or any(
                    inside[v] > 2 or inside[v] == 2 and G.degree(v) != 4 for v in set(V)-T):
                continue
            answer = color_path_cycle_partition(V, E, T)
            assert answer["status"] == "colored"; raw_check(answer); atlas += 1
    K5minus = [(u, v) for u in range(5) for v in range(u+1, 5) if (u, v) != (0, 1)]
    examples["K5_minus_edge_with_path_S"] = color_path_cycle_partition(list(range(5)), K5minus, [3, 4])
    triangle_records, path_records = [], []
    for t in [1, 2, 3, 5, 10]:
        answer = triangle_block_family(t); D = raw_check(answer)
        assert len(answer["vertices"]) == 12*t and len(answer["edges"]) == 21*t
        assert Counter(D.values()) == Counter({3: 6*t, 4: 6*t})
        G = nx.Graph((u, v) for u, v, x in answer["edges"])
        assert nx.is_connected(G) and not nx.is_bipartite(G)
        assert any(x == 2 for u, v, x in answer["edges"] if u not in answer["T"] and v not in answer["T"])
        triangle_records.append({"t": t, "n": 12*t, "m": 21*t})
        if t == 1:
            examples["triangle_blocks_actual_repair"] = answer
    for k in [1, 2, 3, 5, 20]:
        answer = path_incidence_family(k); raw_check(answer)
        assert len(answer["vertices"]) == 4*k and len(answer["edges"]) == 7*k-1
        path_records.append({"k": k, "n": 4*k, "m": 7*k-1})
        if k == 2:
            examples["path_family"] = answer
    cycle_records = []
    for n in [3, 4, 5, 6, 7, 10, 18]:
        answer = cycle_incidence_family(n); raw_check(answer)
        assert len(answer["vertices"]) == 4*n and len(answer["edges"]) == 7*n
        assert [len(c["vertices"]) for c in answer["S_components"]] == [n, n]
        cycle_records.append({"cycle_length": n, "vertices": 4*n, "edges": 7*n})
        if n == 6:
            examples["two_length_six_cycles"] = answer
    # Prove the smallest all-S-blue obstruction by complete cross-edge search.
    obstruction = examples["triangle_blocks_actual_repair"]
    T = set(obstruction["T"])
    crosses = [(u, v) for u, v, x in obstruction["edges"] if (u in T) != (v in T)]
    assert len(crosses) == 12
    blue_only_checked = 0
    for bits in itertools.product((0, 1), repeat=len(crosses)):
        R, B = Counter(), Counter()
        for u, v, x0 in obstruction["edges"]:
            x = 1 if u in T and v in T else 0
            R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
        for (u, v), bit in zip(crosses, bits):
            R[u] += 2*bit; R[v] += 2*bit; B[u] -= 2*bit; B[v] -= 2*bit
        assert any(R[u] == R[v] or B[u] == B[v] for u, v, x in obstruction["edges"] if u in T and v in T) or any(
            B[u] == B[v] for u, v, x in obstruction["edges"] if u not in T and v not in T)
        blue_only_checked += 1
    # A nonregular 3/4 core where no permitted T exists; no mother counterclaim.
    blocked_edges = [(u, v) for u in range(3) for v in range(3, 6)]+[(0, 1)]
    eligible = []
    G = nx.Graph(blocked_edges)
    for mask in range(1 << 6):
        T = {v for v in range(6) if mask >> v & 1}
        inside = {v: sum((u in T) == (v in T) for u in G[v]) for v in G}
        if all(inside[v] == 1 for v in T) and all(inside[v] <= 2 and (inside[v] != 2 or G.degree(v) == 4)
                                                for v in set(G)-T):
            eligible.append(mask)
    assert not eligible
    for weights in itertools.product(range(3), repeat=len(blocked_edges)):
        R, B = Counter(), Counter()
        for (u, v), x in zip(blocked_edges, weights):
            R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
        if all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for (u, v), x in zip(blocked_edges, weights)):
            examples["no_partition_but_actual_coloring"] = {
                "vertices": list(range(6)), "edges": [[u, v, x] for (u, v), x in zip(blocked_edges, weights)],
                "red": dict(R), "blue": dict(B), "all_64_partitions_rejected": True,
                "mother_conjecture_proved": False}
            break
    else:
        raise AssertionError("The small no-partition diagnostic needs an actual coloring witness.")
    report = {"local_profiles_compared_to_full_binary_enumeration": profiles,
              "path_profiles": path_profiles, "cycle_profiles": profiles-path_profiles,
              "profiles_satisfying_proved_break_conditions": guards,
              "unsupported_profiles_without_extension": failures,
              "eligible_atlas_partitions": atlas,
              "triangle_block_family": triangle_records, "path_incidence_family": path_records,
              "cycle_incidence_family": cycle_records,
              "all_S_blue_obstruction_cross_assignments": blue_only_checked,
              "no_partition_core_all_subsets_checked": 64, "saved_groups": len(examples),
              "all_checks_passed": True, "elapsed_seconds": round(time.monotonic()-started, 3),
              "mother_conjecture_proved": False, "finite_tests_are_not_universal_proofs": True}
    (OUT/"path_cycle_partition_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (OUT/"path_cycle_partition_witnesses.json").write_text(json.dumps(examples, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
