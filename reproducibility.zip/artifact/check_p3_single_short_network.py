import itertools
import json
import random
import time
from pathlib import Path
import networkx as nx

from check_matching_long_branch_coloring import verify
from p3_single_short_network import color_p3_single_short_network
from subcubic_bip_core_no_three import color_subcubic_core_sparse_three, color_subcubic_core_repaired_sparse_three


def main():
    start = time.monotonic()
    rng = random.Random(20261116)
    algebra = 0
    for a, b, c in itertools.product((0, 2, 4), (0, 2), (0, 2)):
        defect = (a + c - b) % 3
        p = 2 if defect == 0 else 0
        d = (defect + p) % 3
        phi_a = (d + 1) % 3
        x, y = (phi_a - a) % 3, (-c - p) % 3
        assert (b + x + y) % 3 == 1 and (c + p + y) % 3 == 0
        assert (a + x) % 3 in (0, 2)
        algebra += 1
    count, connected, returns, outside_both = 0, 0, 0, 0
    witness = None
    def check(n, pairs, matching, name, require_outside=False):
        nonlocal count, connected, returns, outside_both, witness
        graph, result = color_p3_single_short_network(n, pairs, matching)
        verify(graph, result)
        count += 1
        connected += nx.is_connected(graph)
        returns += sum(path["path"][0] == path["path"][-1] for path in result["long_paths"])
        if nx.is_connected(graph):
            old1 = color_subcubic_core_sparse_three(graph)
            old2 = color_subcubic_core_repaired_sparse_three(graph)
            outside = old1["status"] == old2["status"] == "method_not_applicable"
            if require_outside:
                assert outside
            outside_both += outside
            if witness is None:
                witness = {"name": name,
                           "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                           "red": result["red"], "blue": result["blue"]}
    for n in range(2, 32, 2):
        for trial in range(16):
            ports = [(i, j) for i in range(n) for j in range(4)]
            rng.shuffle(ports)
            pairs = [(ports[2 * k], ports[2 * k + 1], rng.choice((3, 3, 3, 4, 5, 8)))
                     for k in range(2 * n)]
            order = list(range(n)); rng.shuffle(order)
            matching = list(zip(order[::2], order[1::2]))
            check(n, pairs, matching, "random_four_port_network")
    for n in (2, 6, 8, 10, 20):
        if n == 2:
            pairs = [((0, j), (1, j), 3) for j in range(4)]
        else:
            long_graph = nx.random_regular_graph(4, n, seed=n)
            ports = {i: [(i, j) for j in range(4)] for i in range(n)}
            pairs = [(ports[u].pop(), ports[v].pop(), 3) for u, v in long_graph.edges()]
        check(n, pairs, list(zip(range(0, n, 2), range(1, n, 2))),
              "all_long_three_no_original_return", True)
    # A long return at the two a ports and another long ordinary path.
    check(2, [((0, 0), (0, 1), 5001), ((1, 0), (1, 1), 3),
              ((0, 2), (1, 2), 5000), ((0, 3), (1, 3), 3)], [(0, 1)], "long_returns")
    result = {"all_local_offset_states": algebra, "actual_networks_verified": count,
              "connected_networks_verified": connected, "long_return_paths_verified": returns,
              "connected_cases_outside_sparse_and_density_repair": outside_both,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "general_subcubic_conjecture_proved": False,
              "seconds": round(time.monotonic() - start, 3)}
    base = Path(__file__).parent
    (base / "p3_single_short_network_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (base / "p3_single_short_network_witness.json").write_text(json.dumps(witness, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
