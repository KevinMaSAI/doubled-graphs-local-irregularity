"""Actual-copy audit of internally contained bipartite-core short paths."""

import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from subcubic_no_two_threads import color_subcubic_internal_bip_short_threads


def domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3 or all(d == 3 for d in degree.values()):
        return False
    core = graph.subgraph([v for v in graph if degree[v] == 3])
    component, bip = {}, {}
    for i, vertices in enumerate(nx.connected_components(core)):
        value = nx.is_bipartite(core.subgraph(vertices))
        for v in vertices:
            component[v], bip[v] = i, value
    for middle in graph:
        if degree[middle] == 2:
            u, v = graph[middle]
            if degree[u] == degree[v] == 3 and component[u] != component[v] and (bip[u] or bip[v]):
                return False
    return True


def main():
    started = time.monotonic()
    rng = random.Random(20261106)
    cases, short_cases, connected_core_cases, new_cases = 0, 0, 0, 0
    modes, witnesses = set(), {}
    def check(name, graph):
        nonlocal cases, short_cases, connected_core_cases, new_cases
        assert domain(graph)
        result = color_subcubic_internal_bip_short_threads(graph)
        verify(graph, result)
        cases += 1
        has_short = bool(result.get("short_threads"))
        short_cases += has_short
        core = graph.subgraph([v for v in graph if graph.degree(v) == 3])
        connected_core_cases += bool(len(core) and nx.is_connected(core))
        local_new = False
        for item in result.get("retained_components", []):
            kind = item["kind"]
            modes.add(kind)
            local_new |= kind in {"isolated_edge_short_parity", "bipartite_two_short_ports",
                "bipartite_short_and_pendant", "bipartite_short_and_target"}
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "component": item,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        new_cases += local_new
        return result
    atlas_colored, atlas_excluded, uncovered = 0, 0, []
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        result = color_subcubic_internal_bip_short_threads(graph)
        expected = domain(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_colored += 1
        else:
            atlas_excluded += 1
            if max(dict(graph.degree()).values()) <= 3 and not all(d == 3 for _, d in graph.degree()):
                uncovered.append({"graph6": nx.to_graph6_bytes(graph, header=False).decode().strip(),
                                  "edges": list(graph.edges()), "reason": result["reason"]})
    fixtures = [
        ("one_internal_short_pair", 2, [(0, 1, 1), (0, 1, 2), (0, 1, 3)], []),
        ("two_internal_short_pair", 2, [(0, 1, 1), (0, 1, 2), (0, 1, 2)], []),
        ("one_short_same_part", 3, [(0, 1, 1), (1, 2, 1), (0, 2, 2)],
         [(0, 1), (1, 2), (2, 3)]),
        ("short_and_pendant", 3, [(0, 1, 1), (1, 2, 1), (0, 1, 2)],
         [(0, 1), (2, 1), (2, 2)]),
        ("short_and_target", 4, [(0, 1, 1), (1, 2, 1), (2, 3, 1), (3, 0, 1),
         (0, 1, 2), (2, 3, 3)], []),
        ("loop_and_short", 4, [(0, 1, 1), (1, 2, 1), (2, 3, 1), (0, 0, 3), (1, 2, 2)],
         [(3, 1), (3, 2)]),
        ("two_bip_cores_with_internal_shorts", 6,
         [(0, 1, 1), (1, 2, 1), (3, 4, 1), (4, 5, 1), (0, 1, 2), (3, 4, 2), (2, 5, 3)],
         [(0, 1), (2, 2), (3, 3), (5, 1)]),
    ]
    for name, count, threads, pendants in fixtures:
        check(name, expand(count, threads, pendants))
    # Arbitrary connected direct cores, including vertices of core degree
    # three, with every missing incidence filled by a short, long, loop or
    # pendant path. Connectivity of H ensures the new hypothesis.
    bases = [g for g in nx.graph_atlas_g() if 1 <= len(g) <= 7 and nx.is_connected(g)
             and max(dict(g.degree()).values()) <= 3 and not all(d == 3 for _, d in g.degree())]
    random_cases, bip_core_cases = 0, 0
    for index in range(1800):
        if index % 3:
            core = nx.convert_node_labels_to_integers(rng.choice(bases))
        else:
            count = 2 * rng.randrange(2, 20)
            core = nx.random_regular_graph(3, count, seed=rng)
            if not nx.is_connected(core):
                largest = max(nx.connected_components(core), key=len)
                core = nx.convert_node_labels_to_integers(core.subgraph(largest))
            for u, v in rng.sample(list(core.edges()), rng.randrange(1, min(8, core.number_of_edges()) + 1)):
                core.remove_edge(u, v)
                if not nx.is_connected(core):
                    core.add_edge(u, v)
            if all(d == 3 for _, d in core.degree()):
                bridges = {frozenset(edge) for edge in nx.bridges(core)}
                u, v = next(edge for edge in core.edges() if frozenset(edge) not in bridges)
                core.remove_edge(u, v)
        count = len(core)
        threads = [(u, v, 1) for u, v in core.edges()]
        stubs = [v for v in core for _ in range(3 - core.degree(v))]
        rng.shuffle(stubs)
        pendants = []
        while stubs:
            u = stubs.pop()
            if stubs and rng.random() < 0.88:
                v = stubs.pop()
                length = rng.randrange(3, 10) if u == v else rng.choice((2, 2, 2, 3, 4, 6, 9))
                threads.append((u, v, length))
            else:
                pendants.append((u, rng.randrange(1, 11)))
        order = list(range(count))
        rng.shuffle(order)
        check("random_connected_direct_core", expand(count, threads, pendants, order))
        bip_core_cases += nx.is_bipartite(core)
        random_cases += 1
    check("long_path_after_internal_short", expand(3,
        [(0, 1, 1), (1, 2, 1), (0, 1, 2)], [(0, 5001), (2, 1), (2, 5000)]))
    required = {"isolated_edge_short_parity", "bipartite_two_short_ports",
                "bipartite_short_and_pendant", "bipartite_short_and_target", "bipartite_loop"}
    assert required <= modes
    report = {"checks_passed": True, "eligible_atlas_graphs": atlas_colored,
        "inapplicable_atlas_graphs": atlas_excluded, "named_fixtures": len(fixtures),
        "random_connected_core_cases": random_cases, "random_bipartite_core_cases": bip_core_cases,
        "long_cases": 1, "actual_copy_checked_colorings": cases,
        "colorings_with_short_threads": short_cases, "colorings_with_connected_core": connected_core_cases,
        "colorings_using_new_short_repairs": new_cases, "core_modes_observed": sorted(modes),
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Finite implementation checks; the full theorem requires its separate proof."}
    Path(__file__).with_name("subcubic_internal_bip_short_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_internal_bip_short_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).parent.parent.joinpath("work", "short_cross_component_atlas_remaining.json").write_text(
        json.dumps(uncovered, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
