"""Independent structural-domain and actual-copy checks of the forest extension."""

import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import build_core, join_cores
from subcubic_bip_core_no_three import color_subcubic_core_forest_three, color_subcubic_core_no_three
from subcubic_no_two_threads import color_subcubic_adjustable_bip_short_threads


def gallai_other_than_K4(core):
    if len(core) == 4 and core.number_of_edges() == 6:
        return False
    for vertices in nx.biconnected_components(core):
        block = core.subgraph(vertices)
        if len(vertices) == 2:
            continue
        if len(vertices) % 2 == 0 or any(block.degree(v) != 2 for v in block):
            return False
    return True


def independent_domain(graph):
    if max(dict(graph.degree()).values()) > 3:
        return False, []
    roots = {v for v in graph if graph.degree(v) == 3}
    core = graph.subgraph(roots)
    components = list(nx.connected_components(core))
    member = {v: i for i, vertices in enumerate(components) for v in vertices}
    nonroot_components = []
    return_components = set()
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        nonroot_components.append((vertices, attachments))
        if len(attachments) == 2 and attachments[0] == attachments[1]:
            return_components.add(member[attachments[0]])
    safe = set()
    for i, vertices in enumerate(components):
        c = core.subgraph(vertices)
        if i not in return_components and (gallai_other_than_K4(c) or
                (nx.is_bipartite(c) and sum(c.degree(v) == 3 for v in c) <= 2)):
            safe.add(i)
    union = {i: i for i in safe}
    def find(i):
        while union[i] != i:
            i = union[i]
        return i
    links = []
    for vertices, attachments in nonroot_components:
        if len(vertices) != 2 or len(attachments) != 2 or attachments[0] == attachments[1]:
            continue
        i, j = map(member.get, attachments)
        if i in safe and j in safe:
            a, b = find(i), find(j)
            if a == b:
                return False, links + [[i, j]]
            union[a] = b
            links.append([i, j])
    return True, links


def change_some_short_to_three(graph, rng):
    roots = {v for v in graph if graph.degree(v) == 3}
    for vertices in list(nx.connected_components(graph.subgraph(set(graph) - roots))):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        if len(vertices) == 1 and len(attachments) == 2 and attachments[0] != attachments[1] and rng.randrange(2):
            old = next(iter(vertices))
            root = attachments[0]
            new = max(graph) + 1
            graph.remove_edge(root, old)
            graph.add_edges_from(((root, new), (new, old)))
    return graph


def main():
    start = time.monotonic()
    rng = random.Random(20261112)
    count, atlas, outside, mixed, three_total = 0, 0, 0, 0, 0
    safe_three_max, flipped, witnesses = 0, 0, {}
    def check(name, graph):
        nonlocal count, mixed, three_total, safe_three_max, flipped
        expected, links = independent_domain(graph)
        assert expected, (name, links)
        result = color_subcubic_core_forest_three(graph)
        verify(graph, result)
        count += 1
        ordinary_three = sum(len(item["path"]) == 4 and item["path"][0] != item["path"][-1]
                             for item in result.get("threads", []))
        ordinary_short = sum(len(item["path"]) == 3 for item in result.get("threads", []))
        three_total += ordinary_three
        mixed += bool(ordinary_three and ordinary_short)
        safe_three_max = max(safe_three_max, len(result.get("safe_three_component_edges", [])))
        flipped += sum(result.get("safe_core_complements", {}).values())
        for item in result.get("threads", []):
            if len(item["path"]) == 4 and item["path"][0] != item["path"][-1]:
                assert set(item["ports"]) == {0, 2}
        if name.startswith("named_"):
            witnesses[name] = {"edges": [[u, v, w] for (u, v), w in zip(result["edge_order"], result["weights"])],
                "red": result["red"], "blue": result["blue"],
                "safe_three_edges": result.get("safe_three_component_edges"),
                "safe_complements": result.get("safe_core_complements")}
        return result
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected, links = independent_domain(graph)
        result = color_subcubic_core_forest_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas += 1
        else:
            outside += 1
    cores = [core for core in nx.graph_atlas_g() if len(core) and nx.is_connected(core)
             and max(dict(core.degree()).values()) <= 3]
    for i in range(1400):
        graph = join_cores([rng.choice(cores) for _ in range(rng.randrange(2, 10))], rng)
        if graph is None:
            continue
        change_some_short_to_three(graph, rng)
        expected, links = independent_domain(graph)
        result = color_subcubic_core_forest_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("random_mixed_2_3_network", graph)
        else:
            outside += 1
    # A large forest of SAFE odd-cycle modules; fill every unused port by
    # short paths, which may create many cycles independently of the forest.
    tree = nx.balanced_tree(2, 5)
    count_roots = 3 * len(tree)
    threads = [(3 * i + j, 3 * i + (j + 1) % 3, 1) for i in tree for j in range(3)]
    stubs = {i: [3 * i + j for j in range(3)] for i in tree}
    for i, j in tree.edges():
        threads.append((stubs[i].pop(), stubs[j].pop(), 3))
    unused = [v for ports in stubs.values() for v in ports]
    rng.shuffle(unused)
    pendants = []
    while len(unused) >= 2:
        u, v = unused.pop(), unused.pop()
        if u == v:
            pendants.extend(((u, 1), (v, 2)))
        else:
            threads.append((u, v, 2))
    if unused:
        pendants.append((unused.pop(), 7))
    check("named_large_SAFE_forest", expand(count_roots, threads, pendants))
    # A length-three triangle is allowed if a modular component breaks
    # the SAFE-only cycle constraints.
    threads = [(i, (i + 1) % 3, 1) for i in range(3)]
    threads += [(3 + i, 3 + (i + 1) % 3, 1) for i in range(3)]
    threads += [(6 + u, 6 + v, 1) for u, v in nx.complete_graph(4).edges() if (u, v) != (0, 1)]
    threads += [(0, 3, 3), (4, 6, 3), (7, 1, 3), (2, 5, 2)]
    check("named_three_cycle_through_MOD", expand(10, threads, []))
    # Clone kernels with exactly one cross length-three connection. These
    # all extend the previous no-three API. A length-three replacement
    # can itself make a former E obstruction intrinsically adjustable;
    # count actual E exclusions rather than assuming all stay excluded.
    fixtures = [
        {"shape": "claw", "lengths": []},
        {"shape": "double_star", "lengths": [1]},
        {"shape": "theta", "lengths": [1, 3, 3]},
        {"shape": "lollipop_fork", "lengths": [4, 1]},
        {"shape": "barbell", "lengths": [4, 4, 1]},
    ]
    beyond_previous, strict_fixture_names = 0, []
    for record in fixtures:
        core = build_core(record)
        n = len(core)
        stubs = [v for v in core for _ in range(3 - core.degree(v))]
        right = [v + n for v in stubs]
        rng.shuffle(right)
        threads = [(u, v, 1) for u, v in core.edges()] + [(u + n, v + n, 1) for u, v in core.edges()]
        threads += [(u, v, 3 if i == 0 else 2) for i, (u, v) in enumerate(zip(stubs, right))]
        graph = expand(2 * n, threads, [])
        check("named_sparse_clone_" + record["shape"], graph)
        assert color_subcubic_core_no_three(graph)["status"] == "method_not_applicable"
        old = color_subcubic_adjustable_bip_short_threads(graph)
        if old["status"] == "method_not_applicable":
            beyond_previous += 1
            strict_fixture_names.append(record["shape"])
    assert beyond_previous >= 2
    # The known pure-port obstruction is rejected by this API, rather
    # than incorrectly declared an uncolorable graph.
    graph = expand(6, [(0, 1, 3), (1, 2, 3), (2, 0, 3),
                       (3, 4, 3), (4, 5, 3), (5, 3, 3),
                       (0, 3, 2), (1, 4, 2), (2, 5, 2)], [])
    assert not independent_domain(graph)[0]
    assert color_subcubic_core_forest_three(graph)["reason"] == "cycle_in_SAFE_three_connection_multigraph"
    result = {
        "actual_graph_colorings_verified": count, "atlas_eligible": atlas, "outside_scope_checked": outside,
        "graphs_with_both_ordinary_two_and_three": mixed, "ordinary_three_threads_verified": three_total,
        "largest_SAFE_three_forest_edge_count": safe_three_max, "SAFE_core_complements_used": flipped,
        "named_examples_beyond_previous_no_three_and_adjustable_interfaces": beyond_previous,
        "strict_extension_fixture_names": strict_fixture_names,
        "known_template_obstruction_rejected": True, "all_checks_passed": True,
        "mother_conjecture_proved": False, "general_subcubic_conjecture_proved": False,
        "seconds": round(time.monotonic() - start, 3),
        "scope": "All subcubic cores, mixed lengths allowed, provided length-three links between structurally selected SAFE components form a multigraph forest."}
    base = Path(__file__).parent
    (base / "subcubic_core_forest_three_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (base / "subcubic_core_forest_three_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
