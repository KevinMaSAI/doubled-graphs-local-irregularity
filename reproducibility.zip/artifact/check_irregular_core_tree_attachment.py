"""Check core preservation and every actual colored copy after attaching trees."""

import json
from pathlib import Path
import random
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from irregular_core_tree_attachment import attach_trees_to_irregular_core


def test_case(core, roots, matching, trees):
    attachments = {}
    next_node = max(core)+1
    for v, (tree, root) in zip(roots, trees):
        mapping = {w: next_node+i for i, w in enumerate(tree)}
        attachments[v] = (nx.relabel_nodes(tree, mapping), mapping[root])
        next_node += len(tree)
    result = attach_trees_to_irregular_core(core, attachments, matching)
    assert result["status"] == "colored"
    verify(result["graph"], result)
    helpers = set().union(*(set(e) for e in matching))-set(roots)
    for v in core:
        expected_red = 2 if v in roots else int(v in helpers)
        assert result["red"][v] == expected_red
        assert result["blue"][v] == 2*core.degree(v)-int(v in helpers)
    return len(result["graph"]), len(roots), not nx.is_bipartite(result["graph"])


def main():
    started = time.monotonic()
    # Include the two exceptional rooted tree shapes from the underlying port lemma.
    trees = [(nx.empty_graph(1), 0), (nx.path_graph(2), 0),
             (nx.path_graph(3), 0), (nx.path_graph(3), 1),
             (nx.path_graph(5), 2), (nx.star_graph(6), 0),
             (nx.star_graph(6), 1), (nx.path_graph(17), 8)]
    three_arms = nx.Graph([(0, 1), (1, 2), (0, 3), (3, 4), (0, 5), (5, 6)])
    trees.append((three_arms, 0))
    rng = random.Random(2026102775)
    cases = multi = nonbipartite = maximum_n = 0
    for core in nx.graph_atlas_g():
        if len(core) < 2 or not nx.is_connected(core):
            continue
        if any(core.degree(u) == core.degree(v) for u, v in core.edges()):
            continue
        for v in core:
            u = next(iter(core[v]))
            for tree in trees:
                n, count, nonbip = test_case(core, [v], [(v, u)], [tree])
                cases += 1
                nonbipartite += nonbip
                maximum_n = max(maximum_n, n)
        matching = list(nx.max_weight_matching(core, maxcardinality=True))
        if len(matching) < 2:
            continue
        for unused in range(12):
            roots = [e[rng.randrange(2)] for e in matching]
            selected = [rng.choice(trees) for v in roots]
            n, count, nonbip = test_case(core, roots, matching, selected)
            cases += 1
            multi += 1
            nonbipartite += nonbip
            maximum_n = max(maximum_n, n)
    failure = attach_trees_to_irregular_core(nx.cycle_graph(4), {}, [])
    assert failure["status"] == "method_not_applicable"
    result = {"whole_graph_constructions_verified": cases, "multiple_attachments": multi,
              "nonbipartite_final_graphs": nonbipartite, "maximum_vertices": maximum_n,
              "core_counter_formulas_verified": True, "all_checks_passed": True,
              "mother_conjecture_proved": False, "seconds": round(time.monotonic()-started, 3)}
    (Path(__file__).parent/"irregular_core_tree_attachment_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
