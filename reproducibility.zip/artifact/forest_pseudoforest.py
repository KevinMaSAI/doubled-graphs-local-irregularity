"""Partition an indexed multigraph into a forest and a pseudoforest.

Loops and parallel edges are retained as distinct indexed edges.
The general path uses shortest exchange paths in a matroid union.
Every completed augmentation is independently checked for independence.
"""

from collections import deque


def independent(vertices, edges, chosen, pseudoforest=False):
    parent = {v: v for v in vertices}
    cyclic = dict.fromkeys(vertices, False)
    def find(v):
        while parent[v] != v:
            parent[v] = parent[parent[v]]
            v = parent[v]
        return v
    for i in chosen:
        u, v = edges[i]
        a, b = find(u), find(v)
        if a == b:
            if not pseudoforest or cyclic[a]:
                return False
            cyclic[a] = True
        else:
            if pseudoforest and cyclic[a] and cyclic[b]:
                return False
            parent[a] = b
            cyclic[b] = cyclic[a] or cyclic[b]
    return True


def partition(vertices, edges):
    vertices, edges = list(vertices), list(edges)
    chosen = [set(), set()]
    # A maximal spanning forest already suffices for many sparse inputs.
    for i in range(len(edges)):
        if independent(vertices, edges, chosen[0] | {i}):
            chosen[0].add(i)
    chosen[1] = set(range(len(edges))) - chosen[0]
    if independent(vertices, edges, chosen[1], True):
        return {"status": "partitioned", "forest": sorted(chosen[0]),
                "pseudoforest": sorted(chosen[1]), "augmentations": 0}
    chosen = [set(), set()]
    for new in range(len(edges)):
        queue, previous = deque([new]), {new: None}
        terminal = None
        while queue and terminal is None:
            x = queue.popleft()
            for color in (0, 1):
                if x in chosen[color]:
                    continue
                if independent(vertices, edges, chosen[color] | {x}, color == 1):
                    terminal = x, color
                    break
                for y in sorted(chosen[color]):
                    if y not in previous and independent(
                            vertices, edges, (chosen[color] - {y}) | {x}, color == 1):
                        previous[y] = x, color
                        queue.append(y)
        if terminal is None:
            return {"status": "not_partitionable", "failed_edge": new}
        x, color = terminal
        chosen[color].add(x)
        while previous[x] is not None:
            p, color = previous[x]
            chosen[color].remove(x)
            chosen[color].add(p)
            x = p
        assert not chosen[0] & chosen[1]
        assert chosen[0] | chosen[1] == set(range(new + 1))
        assert independent(vertices, edges, chosen[0])
        assert independent(vertices, edges, chosen[1], True)
    return {"status": "partitioned", "forest": sorted(chosen[0]),
            "pseudoforest": sorted(chosen[1]), "augmentations": len(edges)}


def orient_pseudoforest(vertices, edges, chosen):
    """Choose a tail for each edge; no vertex is the tail more than once."""
    assert independent(vertices, edges, chosen, True)
    incident = {v: set() for v in vertices}
    degree = dict.fromkeys(vertices, 0)
    for i in chosen:
        u, v = edges[i]
        incident[u].add(i)
        incident[v].add(i)
        degree[u] += 1
        degree[v] += 1
    left, tail = set(chosen), {}
    queue = deque(v for v in vertices if degree[v] == 1)
    while queue:
        v = queue.popleft()
        candidates = incident[v] & left
        if not candidates:
            continue
        assert degree[v] == 1 and len(candidates) == 1
        i = next(iter(candidates))
        u, w = edges[i]
        other = w if v == u else u
        assert other != v
        tail[i] = v
        left.remove(i)
        degree[v] -= 1
        degree[other] -= 1
        if degree[other] == 1:
            queue.append(other)
    while left:
        first = min(left)
        start = current = edges[first][0]
        while True:
            i = min(incident[current] & left)
            u, v = edges[i]
            tail[i] = current
            left.remove(i)
            current = v if current == u else u
            if current == start:
                break
    assert set(tail) == set(chosen) and len(set(tail.values())) == len(tail)
    return tail


def overfull_vertex_subset(vertices, edges):
    """Return X with e(X)>=2|X| by maximum closure, or an empty list."""
    import networkx as nx
    vertices = list(vertices)
    scale = len(vertices) + 1
    source, sink = object(), object()
    graph = nx.DiGraph()
    nodes = {v: object() for v in vertices}
    positive = scale * len(edges)
    large = positive + (2 * scale - 1) * len(vertices) + 1
    for v in vertices:
        graph.add_edge(nodes[v], sink, capacity=2 * scale - 1)
    for u, v in edges:
        node = object()
        graph.add_edge(source, node, capacity=scale)
        for w in {u, v}:
            graph.add_edge(node, nodes[w], capacity=large)
    graph.add_nodes_from((source, sink))
    value, sides = nx.minimum_cut(graph, source, sink)
    if positive <= value:
        return []
    selected = [v for v in vertices if nodes[v] in sides[0]]
    assert sum(u in selected and v in selected for u, v in edges) >= 2 * len(selected)
    return selected


def spanning_forest_balanced_cotree(vertices, edges):
    """Spanning forest T and balanced orientation of E\\T; max degree four."""
    vertices,edges=list(vertices),list(edges)
    forest=set()
    for j in range(len(edges)):
        if independent(vertices,edges,forest|{j}):forest.add(j)
    cotree=set(range(len(edges)))-forest
    degree=dict.fromkeys(vertices,0);adj={v:[] for v in vertices}
    augmented=list(edges)
    for j in cotree:
        u,v=edges[j];adj[u].append(j);adj[v].append(j)
        degree[u]+=1;degree[v]+=1
    dummy=object();adj[dummy]=[]
    for v in vertices:
        if degree[v]%2:
            j=len(augmented);augmented.append((v,dummy))
            adj[v].append(j);adj[dummy].append(j)
    used=set();tails={}
    for start in list(adj):
        stack=[start]
        while stack:
            current=stack[-1]
            while adj[current] and adj[current][-1] in used:adj[current].pop()
            if not adj[current]:stack.pop();continue
            j=adj[current].pop();used.add(j)
            u,v=augmented[j]
            if j in cotree:tails[j]=current
            stack.append(v if current==u else u)
    assert set(tails)==cotree
    counts={v:sum(t==v for t in tails.values()) for v in vertices}
    assert all(degree[v]//2<=counts[v]<=(degree[v]+1)//2 for v in vertices)
    full_degree=dict.fromkeys(vertices,0)
    for u,v in edges:full_degree[u]+=1;full_degree[v]+=1
    assert all(full_degree[v]<=4 for v in vertices)
    assert all(counts[v]<=2 and (counts[v]<2 or full_degree[v]==4) for v in vertices)
    return {"status":"partitioned","forest":sorted(forest),"cotree":sorted(cotree),
            "tails":tails,"outdegrees":counts}
