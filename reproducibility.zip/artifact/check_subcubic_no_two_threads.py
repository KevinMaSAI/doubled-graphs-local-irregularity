"""Actual-copy and complete-interface checks for the noncubic family."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from independent_branch_coloring import _pendant_word
from subcubic_no_two_threads import color_subcubic_no_two_threads, pendant_feasible
from subcubic_pendant_certificate import TEMPLATES, verify_certificate


def check_pendant_word(port, red, word):
    assert word is not None and word[0] == port
    count = len(word)
    actual_red = [red] + [word[i - 1] + word[i] for i in range(1, count)] + [word[-1]]
    actual_blue = [6 - red] + [4 - value for value in actual_red[1:-1]] + [2 - word[-1]]
    return all((value == 0 or actual_red[i] != actual_red[i + 1])
               and (value == 2 or actual_blue[i] != actual_blue[i + 1])
               for i, value in enumerate(word))


def expand(count, threads, pendants, order=None):
    graph = nx.Graph()
    graph.add_nodes_from(range(count) if order is None else order)
    next_vertex = count
    for u, v, length in threads:
        assert length >= (3 if u == v else 1)
        middle = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + middle + [v]
        for a, b in zip(path, path[1:]):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
    for root, length in pendants:
        extra = list(range(next_vertex, next_vertex + length))
        next_vertex += length
        graph.add_edges_from(zip([root] + extra, extra))
    assert nx.is_connected(graph)
    assert all(graph.degree(v) == 3 for v in range(count))
    return graph


def embed_interface(record, long_length=None):
    name = record["core"]
    count, core_edges, _ = TEMPLATES[name]
    roots, kinds = record["pendant_roots"], record["kinds"]
    marks = [int(v in roots) for v in range(count)]
    degrees = [sum(v in edge for edge in core_edges) for v in range(count)]
    threads = [(u, v, 1) for u, v in core_edges]
    pendants, incoming, outgoing = [], [], []
    next_root = count
    for v in range(count):
        total = 3 - degrees[v] - marks[v]
        for i in range(total):
            helper = next_root
            next_root += 1
            (incoming if i < record["fixed_ordinary_red"][v] // 2 else outgoing).append(helper)
            threads.append((v, helper, 3))
            pendants.extend(((helper, 1), (helper, 1)))
    for v, kind in zip(roots, kinds):
        length = kind if kind < 3 else (long_length if long_length is not None else 3 + v % 7)
        pendants.append((v, length))
    order = incoming + list(range(count)) + outgoing
    return expand(next_root, threads, pendants, order)


def main():
    started = time.monotonic()
    rng = random.Random(20261102)
    certificate = json.loads(Path(__file__).with_name("subcubic_pendant_interfaces.json").read_text(encoding="utf-8"))
    certificate_result = verify_certificate(certificate)
    boundary_checks = 0
    for port in range(3):
        for red in range(port, port + 5):
            for length in range(1, 13):
                expected = pendant_feasible(port, red, min(length, 3))
                if length <= 3:
                    brute = next(((port,) + rest for rest in itertools.product(range(3), repeat=length - 1)
                                  if check_pendant_word(port, red, (port,) + rest)), None)
                    assert (brute is not None) == expected
                word = _pendant_word(length, port, red, 6 - red)
                assert (word is not None) == expected
                if word is not None:
                    assert check_pendant_word(port, red, word)
                boundary_checks += 1
    modes, witnesses, loop_sums, form_modes = set(), {}, set(), set()
    private_rows, cases, maximum_length = 0, 0, 0
    def check(name, graph):
        nonlocal private_rows, cases, maximum_length
        assert max(dict(graph.degree()).values()) <= 3
        assert not all(degree == 3 for v, degree in graph.degree())
        assert not any(graph.degree(v) == 2 and all(graph.degree(w) == 3 for w in graph[v]) for v in graph)
        result = color_subcubic_no_two_threads(graph)
        verify(graph, result)
        cases += 1
        for record in result.get("retained_components", []):
            kind = record["kind"]
            modes.add(kind)
            if "loop_sum" in record:
                loop_sums.add(record["loop_sum"])
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "component": record,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        orient = result.get("orientation_certificate", {})
        private_rows += len(orient.get("private_rows", []))
        for record in orient.get("four_form_certificate", {}).get("components", []):
            form_modes.add(record["kind"])
        for item in result.get("threads", []) + result.get("pendants", []):
            maximum_length = max(maximum_length, len(item["path"]) - 1)
        return result
    atlas_colored, atlas_excluded = 0, {}
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected = (max(dict(graph.degree()).values()) <= 3
                    and not all(degree == 3 for v, degree in graph.degree())
                    and not any(graph.degree(v) == 2 and all(graph.degree(w) == 3 for w in graph[v])
                                for v in graph))
        result = color_subcubic_no_two_threads(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_colored += 1
        else:
            reason = result["reason"]
            atlas_excluded[reason] = atlas_excluded.get(reason, 0) + 1
    fixture_specs = [
        ("one_loop_two_edge_pendant", 1, [(0, 0, 3)], [(0, 2)]),
        ("two_loop_roots_direct", 2, [(0, 1, 1), (0, 0, 3), (1, 1, 3)], []),
        ("loop_root_two_pendants", 2, [(0, 1, 1), (0, 0, 3)], [(1, 1), (1, 2)]),
        ("loop_sum_two", 4, [(0, 0, 3), (0, 3, 1), (1, 3, 3), (2, 3, 3)],
         [(1, 1), (1, 2), (2, 2), (2, 3)]),
        ("two_roots_pendants", 2, [(0, 1, 1)], [(0, 1), (0, 2), (1, 2), (1, 3)]),
        ("parallel_private_variables", 2, [(0, 1, 1), (0, 1, 3), (0, 1, 4)], []),
        ("four_form_closed", 4,
         [(0, 1, 1), (2, 3, 1), (0, 2, 3), (0, 3, 3), (1, 2, 3), (1, 3, 3)], []),
        ("four_form_boundary", 4,
         [(0, 1, 1), (0, 2, 3), (0, 3, 3), (1, 2, 3), (1, 3, 3)], [(2, 1), (3, 2)]),
        ("triangle_with_pendants", 3, [(0, 1, 1), (1, 2, 1), (2, 0, 1)],
         [(0, 1), (1, 2), (2, 3)]),
        ("bipartite_loop", 3, [(0, 1, 1), (1, 2, 1), (0, 0, 3)],
         [(1, 2), (2, 1), (2, 3)]),
        ("bipartite_many_pendants", 3, [(0, 1, 1), (1, 2, 1)],
         [(0, 1), (0, 2), (1, 3), (2, 2), (2, 3)]),
        ("nonbipartite_normal_loop", 4, [(0, 1, 1), (1, 2, 1), (2, 0, 1), (0, 3, 1), (3, 3, 3)],
         [(1, 1), (2, 2)]),
    ]
    for name, count, threads, pendants in fixture_specs:
        check(name, expand(count, threads, pendants))
    # P3 with no attached pendants in its core: two roots can change target
    # residue without changing the already oriented ordinary-path ports.
    threads = [(0, 1, 1), (1, 2, 1)]
    pendants, helper = [], 3
    for root, total in ((0, 2), (1, 1), (2, 2)):
        for _ in range(total):
            threads.append((root, helper, 3))
            pendants.extend(((helper, 1), (helper, 2)))
            helper += 1
    check("bipartite_no_pendant_target_flips", expand(helper, threads, pendants))
    embedded = 0
    for record in certificate["records"]:
        result = check(f"embedded_{embedded}", embed_interface(record))
        assert any(item["kind"] == "small_bipartite_certificate" for item in result["retained_components"])
        embedded += 1
    random_cases, loop_cases, parallel_cases, pendant_cases = 0, 0, 0, 0
    for case in range(800):
        count = 2 * rng.randrange(1, 17)
        for attempt in range(100):
            core = nx.configuration_model([3] * count, seed=rng.randrange(1 << 30))
            if nx.is_connected(core):
                break
        else:
            raise AssertionError("No connected compressed sampled cubic graph.")
        for u, v, key in list(core.edges(keys=True)):
            if rng.random() < .3:
                trial = core.copy()
                trial.remove_edge(u, v, key)
                if nx.is_connected(trial):
                    core = trial
        pendants = [(v, rng.randrange(1, 10)) for v in core for _ in range(3 - core.degree(v))]
        seen, threads = set(), []
        records = list(core.edges())
        for u, v in records:
            identity = frozenset((u, v))
            if u != v and identity not in seen and rng.random() < .6:
                length = 1
                seen.add(identity)
            else:
                length = rng.randrange(3, 10)
            threads.append((u, v, length))
        if not pendants and all(length == 1 for u, v, length in threads):
            u, v, length = threads[0]
            threads[0] = (u, v, 3)
        check(f"random_{case}", expand(count, threads, pendants))
        loop_cases += int(any(u == v for u, v in records))
        parallel_cases += int(len({frozenset((u, v)) for u, v in records}) < len(records))
        pendant_cases += int(bool(pendants))
        random_cases += 1
    check("long_mixed_loop", expand(2, [(0, 1, 1), (0, 0, 5000), (1, 1, 3)], []))
    long_record = next(record for record in certificate["records"]
                       if any(kind == 3 and word[0] == 1
                              for kind, word in zip(record["kinds"], record["pendant_words"])))
    check("long_mixed_pendant", embed_interface(long_record, 5000))
    check("long_parallel_thread", expand(2, [(0, 1, 1), (0, 1, 5000), (0, 1, 3)], []))
    large_pairs = 1000
    threads = []
    for i in range(large_pairs):
        u, v = 2 * i, 2 * i + 1
        threads.extend(((u, v, 1), (u, v, 3), (v, 2 * ((i + 1) % large_pairs), 3)))
    large_result = check("one_thousand_private_pairs", expand(2 * large_pairs, threads, []))
    assert len(large_result["orientation_certificate"]["private_rows"]) == large_pairs
    expected_modes = {"isolated_root_boundary", "isolated_edge_loop", "isolated_edge_oriented",
                      "isolated_edge_pendants", "nonbipartite_offsets", "bipartite_loop",
                      "bipartite_two_pendant_ports", "bipartite_two_unattached_vertices",
                      "small_bipartite_certificate"}
    assert modes == expected_modes, modes
    assert loop_sums == {1, 2, 3} and private_rows > 0
    assert form_modes == {"boundary_tree", "positive_cycle"}
    result = {"certificate": certificate_result, "pendant_boundary_states_checked": boundary_checks,
              "eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs_by_reason": atlas_excluded,
              "named_boundary_fixtures": 13, "all_embedded_finite_interfaces": embedded,
              "random_compressed_cases": random_cases, "random_cases_with_loops": loop_cases,
              "random_cases_with_parallel_threads": parallel_cases, "random_cases_with_pendants": pendant_cases,
              "long_cases": 3, "actual_copy_checked_colorings": cases,
              "large_private_pair_cases": 1,
              "observed_component_modes": sorted(modes), "observed_loop_sums": sorted(loop_sums),
              "private_pair_rows_repaired": private_rows, "four_form_component_modes": sorted(form_modes),
              "maximum_tested_path_length": maximum_length, "checks_passed": True,
              "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
              "scope": "Finite implementation checks; the full family needs its separate structural reduction and universal extension proof."}
    Path(__file__).with_name("subcubic_no_two_threads_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_no_two_threads_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
