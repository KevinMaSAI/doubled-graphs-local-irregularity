"""Explicit all-odd-k construction for complement(C_(2k+1) + chord 0-2)."""

import networkx as nx

from complement_path_lift import lift_complement_edge


BASE_WEIGHTS = {(0, 3): 2, (0, 4): 2, (0, 5): 2,
                (1, 3): 0, (1, 4): 0, (1, 5): 0, (1, 6): 0,
                (2, 4): 0, (2, 5): 2, (2, 6): 0,
                (3, 5): 1, (3, 6): 0, (4, 6): 1}


def graph_family(k):
    if type(k) is not int or k < 3 or k % 2 == 0:
        raise ValueError("k must be an odd integer at least three.")
    missing = nx.cycle_graph(2*k+1)
    missing.add_edge(0, 2)
    return nx.complement(missing)


def color_family(k):
    graph = graph_family(3)
    values = {frozenset(e): x for e, x in BASE_WEIGHTS.items()}
    if type(k) is not int or k < 3 or k % 2 == 0:
        raise ValueError("k must be an odd integer at least three.")
    for unused in range((k-3)//2):
        n = len(graph)
        result = lift_complement_edge(graph, values, n-1, 0, range(n, n+4))
        assert result["status"] == "colored"
        graph = result["graph"]
        values = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
    expected = graph_family(k)
    assert {frozenset(e) for e in graph.edges()} == {frozenset(e) for e in expected.edges()}
    R, B = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    edges = list(graph.edges())
    for u, v in edges:
        x = values[frozenset((u, v))]
        R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
    return {"status": "colored", "graph": graph, "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges], "red": R, "blue": B,
            "parameter_k": k, "mother_conjecture_proved": False}
