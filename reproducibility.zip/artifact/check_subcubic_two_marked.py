"""Independent scope and actual-copy audit of the complete-scope construction.

These finite graph checks do not replace the structural proof and complete
4,256-case interface certificate. No prior subcubic candidate is assumed.
"""
import itertools
import json
import random
import time
from pathlib import Path
import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_core_sparse_three import claw_modules
from check_subcubic_core_forest_three import change_some_short_to_three
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import join_cores
from check_weak_two_marked_tree import build as build_weak_core
from forest_pseudoforest import spanning_forest_balanced_cotree
from subcubic_bip_core_no_three import color_subcubic_two_marked


def random_connected_compression(n,rng):
    tree=nx.empty_graph(n)
    for v in range(1,n):
        parent=rng.choice([u for u in range(v) if tree.degree(u)<3])
        tree.add_edge(parent,v)
    used_direct=set();threads=[]
    choices=(1,1,1,2,2,3,3,4,5,8,13)
    for u,v in tree.edges():
        length=rng.choice(choices)
        threads.append((u,v,length))
        if length==1:used_direct.add(frozenset((u,v)))
    stubs=[v for v in tree for _ in range(3-tree.degree(v))]
    rng.shuffle(stubs);pendants=[]
    while stubs:
        u=stubs.pop()
        if not stubs or rng.randrange(8)==0:
            pendants.append((u,rng.randrange(1,10)));continue
        v=stubs.pop();length=rng.choice(choices)
        if u==v:length=max(length,3)
        elif length==1 and frozenset((u,v)) in used_direct:length=2
        if length==1:used_direct.add(frozenset((u,v)))
        threads.append((u,v,length))
    return expand(n,threads,pendants)


def weak_clone_network(core,flags,rng):
    assert set(core)==set(range(len(core)))
    # Preserve labels: insertion-order relabeling would detach port flags.
    n=len(core);threads=[(u,v,1) for u,v in core.edges()]
    threads += [(u+n,v+n,1) for u,v in core.edges()]
    long=[v for v in core for flag in flags[v] if not flag]
    short=[v for v in core for flag in flags[v] if flag]
    target=[v+n for v in long];rng.shuffle(target)
    threads += [(u,v,3) for u,v in zip(long,target)]
    target=[v+n for v in short];rng.shuffle(target)
    threads += [(u,v,2) for u,v in zip(short,target)]
    return expand(2*n,threads,[])


def main():
    start=time.monotonic();rng=random.Random(20261118);base=Path(__file__).parent
    actual=0;weak_count=0;intrinsic_count=0;loop_count=0;both_lengths=0
    modes=set();control_types=set();weak_marked_reds=set();witnesses={}
    def check(name,graph):
        nonlocal actual,weak_count,intrinsic_count,loop_count,both_lengths
        assert len(graph)!=2 and nx.is_connected(graph)
        assert max(dict(graph.degree()).values())<=3
        result=color_subcubic_two_marked(graph)
        verify(graph,result);actual+=1
        weak_count+=len(result.get("weak_two_marked_components",[]))
        intrinsic_count+=len(result.get("intrinsic_promoted_components",[]))
        for item in result.get("core_reports",[]):
            modes.add(item["kind"])
            if item["kind"]=="two_intrinsic_controls":
                control_types.add(tuple(sorted(token[0] for token in item["controls"])))
        for item in result.get("weak_two_marked_components",[]):
            for v,j in item["marked_ports"]:weak_marked_reds.add(result["red"][v])
        lengths=set()
        for item in result.get("threads",[]):
            path=item["path"]
            if path[0]==path[-1]:loop_count+=1
            else:lengths.add(len(path)-1)
        both_lengths += 2 in lengths and 3 in lengths
        # Independent root-level intrinsic counts and the degree-four bound.
        roots={v for v in graph if graph.degree(v)==3}
        h=graph.subgraph(roots)
        cparts=list(nx.connected_components(h));member={v:i for i,c in enumerate(cparts) for v in c}
        has_short=dict.fromkeys(roots,False);pcount=dict.fromkeys(roots,0);internals={}
        for vertices in nx.connected_components(graph.subgraph(set(graph)-roots)):
            attaches=[v for w in vertices for v in graph[w] if v in roots]
            if len(attaches)==1:pcount[attaches[0]]+=1
            elif len(attaches)==2 and len(vertices)==1 and attaches[0]!=attaches[1]:
                u,v=attaches;has_short[u]=has_short[v]=True
                if member[u]==member[v]:
                    internals[member[u]]=internals.get(member[u],[])+[(u,v)]
        safe_roots={v for item in result.get("core_reports",[]) if item["kind"].startswith("safe_")
                    for v in item["vertices"]}
        Fdegree={i:0 for i in range(len(cparts))}
        for item in result.get("threads",[]):
            path=item["path"]
            if len(path)==4 and path[0]!=path[-1] and path[0] in safe_roots and path[-1] in safe_roots:
                Fdegree[member[path[0]]]+=1;Fdegree[member[path[-1]]]+=1
        assert all(d<=4 for d in Fdegree.values())
        for i,d in Fdegree.items():
            if not d:continue
            c=h.subgraph(cparts[i]);assert nx.is_bipartite(c)
            partition=nx.bipartite.color(c);counts=[0,0]
            for v in c:
                counts[partition[v]]+=pcount[v]+int(not pcount[v] and not has_short[v])
            for u,v in internals.get(i,[]):counts[partition[u]]+=1;counts[partition[v]]+=1
            assert max(counts)<=1
            if d==4:
                assert nx.is_tree(c)
                free=[v for v in c if not pcount[v] and not has_short[v]]
                assert len(free)==2 and partition[free[0]]!=partition[free[1]]
        for v in safe_roots:
            if has_short[v]:assert result["red"][v] in (0,1,3,5,6)
        partition=result.get("three_edge_partition")
        if partition and partition.get("mode")=="balanced_cotree":
            counts={}
            for key,c in partition["mixed_tails"].items():counts[c]=counts.get(c,0)+1
            assert max(counts.values(),default=0)<=2
        if name.startswith("named_") and name not in witnesses:
            witnesses[name]={"edges":[[u,v,x] for (u,v),x in zip(result["edge_order"],result["weights"])],
                             "red":result["red"],"blue":result["blue"],
                             "weak_components":result.get("weak_two_marked_components",[])}
        return result
    atlas=0
    for g in nx.graph_atlas_g():
        if len(g)<3 or not nx.is_connected(g):continue
        if max(dict(g.degree()).values())<=3:
            check("atlas",g);atlas+=1
        else:assert color_subcubic_two_marked(g)["reason"]=="degree_above_three"
    check("named_K1",nx.empty_graph(1))
    for n in range(4,62,2):
        for _ in range(12):
            cubic=nx.random_regular_graph(3,n,seed=rng.randrange(1<<30))
            if nx.is_connected(cubic):check("cubic",cubic)
    raw=0
    for _ in range(1800):
        graph=random_connected_compression(rng.randrange(1,50),rng)
        check("raw_compressed_multigraph",graph);raw+=1
    pool=[g for g in nx.graph_atlas_g() if len(g)>0 and nx.is_connected(g)
          and max(dict(g.degree()).values())<=3]
    module_networks=0
    for _ in range(1800):
        graph=join_cores([rng.choice(pool) for j in range(rng.randrange(2,12))],rng)
        if graph is not None:
            change_some_short_to_three(graph,rng)
            check("module_network",graph);module_networks+=1
    certificate=json.loads((base/"weak_two_marked_interfaces.json").read_text(encoding="utf-8"))
    kernel_networks=0
    for record in certificate["records"]:
        core,flags,marks=build_weak_core(record["left"],record["right"],record["length"])
        graph=weak_clone_network(core,flags,rng)
        check("kernel_clone",graph);kernel_networks+=1
    for n in range(5,30):
        F=nx.random_regular_graph(4,n,seed=n)
        if nx.is_connected(F):check("named_four_regular_claw_"+str(n),claw_modules(F,rng))
    check("named_two_same_core_three_loops",expand(2,[(0,1,1),(0,1,3),(0,1,3)],[]))
    for _ in range(40):
        graph=random_connected_compression(10,rng)
        relabeled=nx.relabel_nodes(graph,{v:("node",v) for v in graph})
        check("tuple_labels",relabeled)
    out={"actual_graph_colorings_verified":actual,"atlas_subcubic_all_colored":atlas,
         "random_raw_compressions":raw,"random_module_networks":module_networks,
         "complete_kernel_clone_networks":kernel_networks,"weak_two_marked_cores_used":weak_count,
         "intrinsic_promotions_used":intrinsic_count,"return_paths_verified":loop_count,
         "graphs_with_both_two_and_three":both_lengths,"component_modes":sorted(modes),
         "intrinsic_control_pairs":sorted(control_types),"weak_marked_root_reds":sorted(weak_marked_reds),
         "all_checks_passed":True,"mother_conjecture_proved":False,
         "scope":"Implementation audit of the new complete-scope subcubic construction. Universal proof requires the structural classification and complete finite certificate.",
         "seconds":round(time.monotonic()-start,3)}
    (base/"subcubic_two_marked_validation.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
    (base/"subcubic_two_marked_witnesses.json").write_text(json.dumps(witnesses,indent=2),encoding="utf-8")
    print(json.dumps(out))


if __name__=="__main__":main()
