"""Dense-graph two-color construction via exact targets and Tutte's f-factor theorem.

Sufficient condition: n >= 8*(n-1-delta)+14, equivalently 8*delta >= 7*n+6.
Both red and blue degrees are distinct at ALL vertices. General mother unsolved.
"""

import networkx as nx


def dense_antitone_plan(graph):
    if (graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph)
            or not len(graph)):
        raise ValueError("A nonempty finite simple graph is required.")
    n = len(graph)
    minimum = min(dict(graph.degree()).values())
    q = n-1-minimum
    if n < 8*q+14:
        return {"status": "method_not_applicable", "reason": "density_bound_not_met",
                "n": n, "missing_degree_bound": q, "required_n": 8*q+14}
    order = sorted(graph, key=lambda v: -graph.degree(v))
    targets = {v: (n-1)//2+i for i, v in enumerate(order)}
    if sum(targets.values()) % 2:
        targets[order[-1]] += 1
    blue = {v: 2*graph.degree(v)-targets[v] for v in graph}
    assert sum(targets.values()) % 2 == 0
    assert all(0 <= targets[v] <= 2*graph.degree(v) for v in graph)
    assert all(targets[u] < targets[v] and blue[u] > blue[v]
               for u, v in zip(order, order[1:]))
    return {"status": "planned", "n": n, "missing_degree_bound": q,
            "vertex_order": order, "targets": targets, "blue_targets": blue,
            "all_vertex_color_counts_distinct": True, "mother_conjecture_proved": False}


def _directed_flow_recovery(graph, plan):
    """Try one balanced out/in split; failure is not an f-factor obstruction."""
    f = plan["targets"]
    odd = [v for v in plan["vertex_order"] if f[v] % 2]
    high_out = set(odd[:len(odd)//2])
    outgoing = {v: f[v]//2+int(v in high_out) for v in graph}
    incoming = {v: f[v]-outgoing[v] for v in graph}
    assert sum(outgoing.values()) == sum(incoming.values())
    flow_graph = nx.DiGraph()
    source, sink = object(), object()
    for v in graph:
        flow_graph.add_edge(source, ("out", v), capacity=outgoing[v])
        flow_graph.add_edge(("in", v), sink, capacity=incoming[v])
    for u, v in graph.edges():
        flow_graph.add_edge(("out", u), ("in", v), capacity=1)
        flow_graph.add_edge(("out", v), ("in", u), capacity=1)
    value, flow = nx.maximum_flow(flow_graph, source, sink)
    if value != sum(outgoing.values()):
        return None
    return [flow.get(("out", u), {}).get(("in", v), 0)
            +flow.get(("out", v), {}).get(("in", u), 0) for u, v in graph.edges()]


def color_dense_antitone(graph, factor_weights=None, timeout_ms=10000):
    plan = dense_antitone_plan(graph)
    if plan["status"] != "planned":
        return plan
    edges = list(graph.edges())
    values = _directed_flow_recovery(graph, plan) if factor_weights is None else None
    recovery = "directed_unit_capacity_flow" if values is not None else "provided_factor"
    if factor_weights is None and values is None:
        import z3
        x = [z3.Int("dense_"+str(i)) for i in range(len(edges))]
        solver = z3.Solver()
        solver.set(timeout=timeout_ms)
        solver.add(*[z3.And(a >= 0, a <= 2) for a in x])
        for v in graph:
            solver.add(z3.Sum([a for e, a in zip(edges, x) if v in e]) == plan["targets"][v])
        answer = solver.check()
        if answer == z3.unknown:
            return {"status": "factor_search_incomplete", "reason": solver.reason_unknown(),
                    "mother_conjecture_proved": False}
        if answer != z3.sat:
            raise RuntimeError("The factor solver reported infeasibility under the theorem's hypotheses.")
        model = solver.model()
        values = [model.eval(a).as_long() for a in x]
        recovery = "integer_factor_search"
    elif factor_weights is not None:
        supplied = {frozenset(e): x for e, x in factor_weights.items()}
        if len(supplied) != len(factor_weights) or set(supplied) != set(map(frozenset, edges)):
            raise ValueError("The factor certificate must supply exactly the original edges.")
        values = [supplied[frozenset(e)] for e in edges]
    if any(type(x) is not int or x not in (0, 1, 2) for x in values):
        raise ValueError("The factor must have integer red-copy counts 0, 1, or 2.")
    R, B = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    for (u, v), x in zip(edges, values):
        R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
    if R != plan["targets"]:
        raise ValueError("The supplied factor does not realize the target degrees.")
    assert B == plan["blue_targets"]
    assert len(set(R.values())) == len(set(B.values())) == len(graph)
    return {"status": "colored", "edge_order": edges, "weights": values,
            "red": R, "blue": B, "plan": plan,
            "recovery": recovery,
            "all_vertex_color_counts_distinct": True, "mother_conjecture_proved": False}
