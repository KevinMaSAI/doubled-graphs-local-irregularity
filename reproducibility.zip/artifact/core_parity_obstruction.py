"""Minimum-degree-three obstruction to an exact max-cut parity template.

Every returned graph HAS a legal doubled-edge two-coloring. The obstruction
concerns an extra template: all S-internal edges blue and red degree odd iff T.
An explicit coloring with exactly one parity exception is returned instead.
"""
from numbers import Integral

import networkx as nx


def core_parity_family(r):
    """Odd r>=3: triangle with three rooted K_{r,r} components on bridges.

    Returns a graph, an explicit maximum cut, and a legal coloring satisfying
    the template except at exactly one original-degree-three vertex.
    """
    if not isinstance(r, Integral) or r < 3 or r % 2 != 1:
        raise ValueError('r must be an odd integer >=3.')
    r = int(r)
    graph = nx.Graph([(0, 1), (1, 2), (2, 0)])
    values = {frozenset((0, 1)): 0, frozenset((1, 2)): 1,
              frozenset((2, 0)): 2}
    in_T = {0: True, 1: True, 2: False}
    modules = []
    next_vertex = 3
    for i in range(3):
        rows = list(range(next_vertex, next_vertex + r))
        cols = list(range(next_vertex + r, next_vertex + 2 * r))
        next_vertex += 2 * r
        root = rows[0]
        graph.add_edge(i, root)
        values[frozenset((i, root))] = 1
        for j, u in enumerate(rows):
            in_T[u] = not in_T[i]
            for k, v in enumerate(cols):
                if i == 0:
                    # Root row mixed, others blue: root total (r+1,r+1).
                    x = int(j == 0)
                elif i == 1:
                    # Complement of the parity-correct low-red construction:
                    # low root (2,2r), hence this root has (2r,2).
                    low = int((j == 0 and k == 0) or (j == 1 and k != 0))
                    x = 2 - low
                else:
                    # Root row blue, nonroot rows mixed in column zero.
                    # Root total (1,2r+1).
                    x = int(j != 0 and k == 0)
                graph.add_edge(u, v)
                values[frozenset((u, v))] = x
        for v in cols:
            in_T[v] = in_T[i]
        modules.append({'center': i, 'root': root, 'rows': rows, 'columns': cols})
    edges = list(graph.edges())
    return {'r': r, 'graph': graph, 'edges': edges,
            'weights': [values[frozenset(e)] for e in edges],
            'T': {v for v, b in in_T.items() if b}, 'modules': modules,
            'maximum_cut_size': 3 * r * r + 5,
            'unique_parity_exception': 1,
            'mother_counterexample': False}
