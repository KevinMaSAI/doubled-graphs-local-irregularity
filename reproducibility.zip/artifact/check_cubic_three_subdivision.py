"""Independent finite checks of signed forms and cubic >=3 subdivisions."""

import itertools
import json
import math
import random
import time
from pathlib import Path

import networkx as nx

from check_cubic_perfect_matching_subdivision import all_perfect_matchings
from check_matching_long_branch_coloring import verify
from cubic_three_subdivision import color_cubic_three_subdivision
from degree_two_pair_orientation import avoid_zero_four_forms, _solve_cycle_coefficients


def verify_forms(rows, result):
    signs = result["signs"]
    assert all(value in (-1, 1) for value in signs.values())
    actual = [sum(coefficient * signs[key] for key, coefficient in row.items()) for row in rows]
    assert actual == result["row_sums"] and all(value != 0 for value in actual)
    for certificate in result["components"]:
        if certificate["kind"] != "positive_cycle":
            continue
        vertices, edges = certificate["cycle_rows"], certificate["cycle_variables"]
        assert len(vertices) == len(edges) >= 2 and len(set(vertices)) == len(vertices)
        product = 1
        for i, key in enumerate(edges):
            product *= rows[vertices[i]][key] * rows[vertices[(i + 1) % len(vertices)]][key]
        assert product == 1


def main():
    started = time.monotonic()
    rng = random.Random(20261031)
    form_modes, form_witnesses, form_cases = set(), {}, 0
    def check_forms(name, rows):
        nonlocal form_cases
        result = avoid_zero_four_forms(rows)
        verify_forms(rows, result)
        form_cases += 1
        for certificate in result["components"]:
            mode = certificate.get("search_kind", certificate["kind"])
            form_modes.add(mode)
            if mode not in form_witnesses:
                form_witnesses[mode] = {"name": name, "rows": rows, "result": result}
        return result
    for bits in itertools.product((-1, 1), repeat=8):
        rows = [{e: bits[e] for e in range(4)}, {e: bits[4 + e] for e in range(4)}]
        check_forms("two_rows_four_parallel_variables", rows)
    base = nx.complete_graph(5)
    records = list(base.edges())
    for pattern in itertools.product((-1, 1), repeat=len(records)):
        rows = [{} for _ in base]
        for key, ((u, v), sign) in enumerate(zip(records, pattern)):
            rows[u][key], rows[v][key] = 1, sign
        check_forms("K5_all_edge_sign_patterns", rows)
    check_forms("single_boundary_row", [{i: 1 if i % 2 else -1 for i in range(4)}])
    for case in range(400):
        count = rng.randrange(2, 61)
        for attempt in range(100):
            multi = nx.configuration_model([4] * count, seed=rng.randrange(1 << 30))
            if not nx.number_of_selfloops(multi):
                break
        else:
            raise AssertionError("No loopless sampled four-regular multigraph.")
        rows, record = [{} for _ in range(count)], list(multi.edges(keys=True))
        for key, (u, v, _) in enumerate(record):
            rows[u][key], rows[v][key] = rng.choice((-1, 1)), rng.choice((-1, 1))
        if case % 2:
            key = rng.randrange(len(record))
            u, v, _ = record[key]
            rows[u][len(record)], rows[v][len(record) + 1] = rows[u].pop(key), rows[v].pop(key)
        check_forms(f"random_four_regular_{case}", rows)
    # Exhaustively compare the cycle DP with all binary assignments. This
    # includes negative cycles and the exact all-zero-constant obstruction.
    cycle_cases, unsatisfiable_cycles = 0, 0
    for count in range(2, 6):
        for b in itertools.product((-1, 1), repeat=count):
            for constants in itertools.product((-2, 0, 2), repeat=count):
                brute = next((values for values in itertools.product((-1, 1), repeat=count)
                              if all(values[i] + b[i] * values[i - 1] + constants[i] != 0
                                     for i in range(count))), None)
                result = _solve_cycle_coefficients([1] * count, b, constants)
                expected = any(constants) or math.prod(b) == 1
                assert (brute is not None) == expected == (result is not None)
                if result is not None:
                    assert all(result[i] + b[i] * result[i - 1] + constants[i] != 0 for i in range(count))
                else:
                    unsatisfiable_cycles += 1
                cycle_cases += 1
    full_cases, matching_cases, adjacent_cases = 0, 0, 0
    component_modes, orientation_modes, closed_search_modes = set(), set(), set()
    witnesses = {}
    maximum_pairs = 0
    def check(name, base, selected, lengths=3):
        nonlocal full_cases, matching_cases, adjacent_cases, maximum_pairs
        result = color_cubic_three_subdivision(base, selected, lengths)
        verify(result["graph"], result)
        direction = result["orientation_certificate"]
        assert {frozenset(edge) for edge in direction["directions"]} == {frozenset(edge) for edge in selected}
        assert len(direction["directions"]) == len(selected)
        indegrees = dict.fromkeys(base, 0)
        for tail, head in direction["directions"]:
            indegrees[head] += 1
        retained = base.copy()
        retained.remove_edges_from(selected)
        actual_pairs = [tuple(vertices) for vertices in nx.connected_components(retained) if len(vertices) == 2]
        assert all(indegrees[u] != indegrees[v] for u, v in actual_pairs)
        assert all(result["offsets"][v] == 2 * indegrees[v] for v in base)
        values = {frozenset(edge): x for edge, x in zip(result["edge_order"], result["weights"])}
        for path in result["replacement_paths"]:
            assert sorted((values[frozenset(path[:2])], values[frozenset(path[-2:])])) == [0, 2]
        maximum_pairs = max(maximum_pairs, len(actual_pairs))
        full_cases += 1
        endpoints = [v for edge in selected for v in edge]
        if len(set(endpoints)) == len(endpoints):
            matching_cases += 1
        else:
            adjacent_cases += 1
        for component in result["retained_components"]:
            component_modes.add(component["kind"])
        for certificate in direction["components"]:
            orientation_modes.add(certificate["kind"])
            if "search_kind" in certificate:
                closed_search_modes.add(certificate["search_kind"])
            mode = certificate.get("search_kind", certificate["kind"])
            if mode not in witnesses:
                witnesses[mode] = {"name": name, "orientation": direction,
                    "selected": selected, "ports": result["ports"],
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    subset_records = []
    for name, base in [
        ("K4", nx.complete_graph(4)), ("triangular_prism", nx.circular_ladder_graph(3)),
        ("K33", nx.complete_bipartite_graph(3, 3)),
    ]:
        records = list(base.edges())
        for mask in range(1, 1 << len(records)):
            selected = [edge for i, edge in enumerate(records) if mask & (1 << i)]
            check(f"{name}_{mask}_all_three", base, selected)
            lengths = {frozenset(edge): 3 + (mask + i) % 5 for i, edge in enumerate(selected)}
            check(f"{name}_{mask}_varying", base, selected, lengths)
        subset_records.append({"base": name, "all_nonempty_subsets": (1 << len(records)) - 1,
                               "length_configurations_per_subset": 2})
    bridged = nx.disjoint_union(nx.complete_graph(4), nx.complete_graph(4))
    bridged.remove_edges_from(((0, 1), (4, 5)))
    bridged.add_edges_from(((0, 8), (8, 1), (4, 9), (9, 5), (8, 9)))
    named = [
        ("K4", nx.complete_graph(4)), ("K33", nx.complete_bipartite_graph(3, 3)),
        ("triangular_prism", nx.circular_ladder_graph(3)), ("Petersen", nx.petersen_graph()),
        ("Heawood", nx.heawood_graph()), ("dodecahedral", nx.dodecahedral_graph()),
        ("Desargues", nx.desargues_graph()), ("Moebius_Kantor", nx.moebius_kantor_graph()),
        ("with_bridge", bridged),
    ]
    closed_matching_cases = 0
    for name, base in named:
        records = list(base.edges())
        for i, matching in enumerate(all_perfect_matchings(base)):
            keep = {frozenset(edge) for edge in matching}
            selected = [edge for edge in records if frozenset(edge) not in keep]
            check(f"{name}_retained_perfect_matching_{i}", base, selected)
            lengths = {frozenset(edge): 3 + j % 5 for j, edge in enumerate(selected)}
            check(f"{name}_retained_perfect_matching_{i}_vary", base, selected, lengths)
            closed_matching_cases += 2
        for i, edge in enumerate(records):
            check(f"{name}_single_{i}", base, [edge])
            check(f"{name}_retain_single_{i}", base, [other for other in records if other != edge])
        check(f"{name}_all", base, records)
        for variant in range(40):
            selected = [edge for edge in records if rng.random() < .5] or records[:1]
            lengths = {frozenset(edge): rng.randrange(3, 10) for edge in selected}
            check(f"{name}_random_{variant}", base, selected, lengths)
    random_cases, disconnected = 0, 0
    for size in (8, 12, 18, 30, 50, 80):
        for variant in range(24):
            base = nx.random_regular_graph(3, size, seed=20261101 + 100 * size + variant)
            if not nx.is_connected(base):
                disconnected += 1
                continue
            records = list(base.edges())
            selected = [edge for edge in records if rng.random() < .5] or records[:1]
            check(f"random_{size}_{variant}", base, selected,
                  {frozenset(edge): rng.randrange(3, 10) for edge in selected})
            random_cases += 1
    large = nx.circular_ladder_graph(500)
    retained = {frozenset((i, i + 500)) for i in range(500)}
    check("five_hundred_paired_rows", large,
          [edge for edge in large.edges() if frozenset(edge) not in retained])
    base = nx.complete_graph(4)
    check("long_single", base, [(0, 1)], 5000)
    check("long_all", base, list(base.edges()), 5000)
    assert form_modes == {"boundary_tree", "positive_fundamental_cycle", "two_negative_fundamental_cycles"}
    assert component_modes == {"isolated_vertex", "isolated_edge_distinct_offsets",
                               "balanced_bipartite_target", "nonbipartite_three_color_target"}
    assert orientation_modes == {"boundary_tree", "positive_cycle"}
    summary = {"signed_four_form_systems_checked": form_cases,
               "exhaustive_cycle_systems_checked": cycle_cases,
               "exactly_unsatisfiable_negative_zero_cycles": unsatisfiable_cycles,
               "generic_orientation_modes": sorted(form_modes), "all_subset_bases": subset_records,
               "retained_perfect_matching_cases": closed_matching_cases,
               "random_connected_cubic_cases": random_cases, "random_disconnected_bases_skipped": disconnected,
               "full_actual_copy_checked_colorings": full_cases, "subdivided_matching_cases": matching_cases,
               "cases_with_adjacent_subdivided_edges": adjacent_cases,
               "retained_component_modes": sorted(component_modes),
               "actual_graph_orientation_modes": sorted(orientation_modes),
               "actual_closed_cycle_search_modes": sorted(closed_search_modes),
               "maximum_simultaneous_isolated_edge_pairs": maximum_pairs,
               "maximum_tested_path_length": 5000, "checks_passed": True,
               "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
               "scope": "Finite independent implementation checks, not a replacement for the general proof."}
    Path(__file__).with_name("cubic_three_subdivision_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("degree_two_pair_orientation_witnesses.json").write_text(
        json.dumps(form_witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("cubic_three_subdivision_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
