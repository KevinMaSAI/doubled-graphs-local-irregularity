"""Independent actual-copy checks, not an exhaustive proof of the family."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from matching_long_branch_coloring import color_matching_long_branches


def verify(graph, result):
    assert result["status"] == "colored"
    assert len(result["edge_order"]) == graph.number_of_edges() == len(result["weights"])
    assert {frozenset(e) for e in result["edge_order"]} == {frozenset(e) for e in graph.edges()}
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for (u, v), value in zip(result["edge_order"], result["weights"]):
        assert value in (0, 1, 2)
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
    assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    assert dict(red.degree()) == result["red"] and dict(blue.degree()) == result["blue"]
    return {item["kind"] for item in result.get("direct_edge_decisions", [])}


def expand(count, threads, pendants):
    graph = nx.Graph()
    graph.add_nodes_from(range(count))
    next_vertex = count
    for u, v, length in threads:
        assert length >= (3 if u == v else 1)
        internal = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + internal + [v]
        for a, b in zip(path, path[1:]):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
    for root, length in pendants:
        internal = list(range(next_vertex, next_vertex + length))
        next_vertex += length
        path = [root] + internal
        graph.add_edges_from(zip(path, path[1:]))
    assert nx.is_connected(graph)
    assert all(graph.degree(v) >= 3 for v in range(count))
    return graph


def main():
    started = time.monotonic()
    rng = random.Random(20261029)
    modes, witnesses = set(), {}
    degree_three_cases = 0
    maximum_degree = 0
    def check(name, graph):
        nonlocal degree_three_cases, maximum_degree
        result = color_matching_long_branches(graph)
        modes.update(verify(graph, result))
        degree_three_cases += int(any(d == 3 for v, d in graph.degree()))
        maximum_degree = max(maximum_degree, max(dict(graph.degree()).values()))
        for item in result.get("direct_edge_decisions", []):
            if item["kind"] not in witnesses:
                witnesses[item["kind"]] = {"name": name, "decision": item,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    atlas_colored, atlas_excluded = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        result = color_matching_long_branches(graph)
        if result["status"] == "colored":
            verify(graph, result)
            atlas_colored += 1
        else:
            assert result["status"] == "method_not_applicable"
            atlas_excluded += 1
    fixtures = [
        ("two_cubic_loop_roots", 2, [(0, 1, 1), (0, 0, 3), (1, 1, 3)], []),
        ("locked_loop_and_degree_four_pendant", 2,
         [(0, 1, 1), (0, 0, 3), (1, 1, 4)], [(1, 2)]),
        ("equal_degree_one_free_each", 2,
         [(0, 1, 1), (0, 0, 3), (1, 1, 3)], [(0, 2), (1, 2)]),
        ("different_degree_one_free_each", 2,
         [(0, 1, 1), (0, 0, 3), (1, 1, 3), (1, 1, 4)], [(0, 2), (1, 2)]),
        ("two_forbidden_values_both_used", 2,
         [(0, 1, 1), (0, 0, 3), (1, 1, 3)], [(0, 2), (0, 2), (1, 2)]),
        ("unmatched_special_loop_pendant", 1, [(0, 0, 3)], [(0, 2)]),
        ("unmatched_loop_to_cubic_pair", 3,
         [(0, 0, 3), (0, 1, 4), (1, 2, 1)], [(1, 1), (2, 2), (2, 2)]),
        ("all_unmatched_zero_ports", 3,
         [(0, 1, 4), (1, 2, 4), (0, 2, 4)], [(0, 1), (1, 2), (2, 3)]),
    ]
    fixture_results = []
    for name, count, threads, pendants in fixtures:
        graph = expand(count, threads, pendants)
        result = check(name, graph)
        fixture_results.append({"name": name, "vertices": len(graph), "edges": graph.number_of_edges(),
                                "decisions": result["direct_edge_decisions"], "passed": True})
    # All bounded local root types on a direct pair; branch degrees may differ.
    local_types = [(loops, free) for loops in range(4) for free in range(5)
                   if 1 + 2 * loops + free >= 3]
    root_pairs = 0
    for (lu, zu), (lv, zv) in itertools.product(local_types, repeat=2):
        threads = [(0, 1, 1)] + [(0, 0, 3 + i % 3) for i in range(lu)]
        threads += [(1, 1, 3 + i % 3) for i in range(lv)]
        pendants = [(0, 1 + i % 3) for i in range(zu)]
        pendants += [(1, 1 + (i + 1) % 3) for i in range(zv)]
        check(f"root_pair_{lu}_{zu}_{lv}_{zv}", expand(2, threads, pendants))
        root_pairs += 1
    # Random compressed multigraphs retain only a matching of actual direct edges.
    random_cases = 700
    loop_cases = 0
    for case in range(random_cases):
        count = rng.randrange(1, 26)
        core = nx.MultiGraph()
        core.add_nodes_from(range(count))
        if count > 1:
            core.add_edges_from((v, rng.randrange(v)) for v in range(1, count))
        for _ in range(rng.randrange(4 * count + 1)):
            core.add_edge(rng.randrange(count), rng.randrange(count))
        records = list(core.edges())
        covered, selected = set(), set()
        order = list(range(len(records)))
        rng.shuffle(order)
        for i in order:
            u, v = records[i]
            if u != v and u not in covered and v not in covered and rng.random() < .8:
                covered.update((u, v))
                selected.add(i)
        threads = [(u, v, 1 if i in selected else rng.randrange(3 if u == v else 4, 10))
                   for i, (u, v) in enumerate(records)]
        pendants = [(v, rng.randrange(1, 8)) for v in core for _ in range(rng.randrange(4))]
        for v in core:
            total = core.degree(v) + sum(root == v for root, _ in pendants)
            pendants += [(v, rng.randrange(1, 8)) for _ in range(max(0, 3 - total))]
        check(f"random_{case}", expand(count, threads, pendants))
        loop_cases += int(any(u == v for u, v, _ in threads))
    patterns = 0
    for base, matching in [
        (nx.complete_graph(4), {(0, 1), (2, 3)}),
        (nx.complete_graph(4), {(0, 1)}),
        (nx.complete_bipartite_graph(3, 3), {(0, 3), (1, 4), (2, 5)}),
    ]:
        variable_edges = base.number_of_edges() - len(matching)
        for pattern in itertools.product((4, 5), repeat=variable_edges):
            values = iter(pattern)
            threads = [(u, v, 1 if (u, v) in matching else next(values)) for u, v in base.edges()]
            check(f"cubic_pattern_{patterns}", expand(len(base), threads, []))
            patterns += 1
    base = nx.complete_graph(30)
    matching = {(i, i + 1) for i in range(0, 30, 2)}
    check("dense_degree_29", expand(30, [
        (u, v, 1 if (u, v) in matching else 4 + (u + v) % 3) for u, v in base.edges()], []))
    check("long_path", expand(2, [(0, 1, 1), (0, 1, 5000), (0, 1, 4)], []))
    expected = {"locked_root_loop_adjustment", "two_choices_equal_degree",
                "two_choices_different_degrees", "three_choices_avoid_two",
                "unmatched_loop_two_edge_pendant"}
    assert modes == expected, modes
    witness_path = Path(__file__).with_name("matching_long_branch_witnesses.json")
    witness_path.write_text(json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {"eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs": atlas_excluded,
               "boundary_fixtures": fixture_results, "local_direct_root_pairs": root_pairs,
               "random_compressed_cases": random_cases, "random_cases_with_loops": loop_cases,
               "all_cubic_short_long_patterns": patterns, "dense_and_long_cases": 2,
               "cases_with_degree_three_branches": degree_three_cases,
               "maximum_tested_degree": maximum_degree, "observed_constructor_modes": sorted(modes),
               "checks_passed": True, "seconds": time.monotonic() - started,
               "scope": "Finite independent actual-copy checks; the general theorem needs its analytical proof.",
               "mother_conjecture_proved": False}
    Path(__file__).with_name("matching_long_branch_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "boundary_fixtures"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
