"""Exact elimination of pendant trees, conditional on a core coloring.

This module does not choose the core edge weights or final core color degrees.
It therefore is not a solver or a proof of the full mother conjecture.
"""
from collections import deque
from numbers import Integral

import networkx as nx

from tree_ports import extend_tree_bridge


def _sumset(l, s, b, leaf_allowed, short_allowed):
    """Minkowski sum of l leaf, s two-vertex, b larger-tree port sets."""
    lo = l * min(leaf_allowed) + s * min(short_allowed)
    hi = l * max(leaf_allowed) + s * max(short_allowed) + 2 * b
    other_width = s * (max(short_allowed) - min(short_allowed)) + 2 * b
    step = 2 if l and leaf_allowed == (0, 2) and other_width == 0 else 1
    return {'minimum': lo, 'maximum': hi, 'step': step}


def _contains(profile, value):
    return profile['minimum'] <= value <= profile['maximum'] and \
        (value - profile['minimum']) % profile['step'] == 0


def attachment_sum_profile(core_degree, leaf_count, two_vertex_count,
                           large_count, final_red):
    """All possible total red contributions from the pendant bridges.

    For a core vertex with internal degree h>=2, l singleton, s two-vertex,
    and b larger rooted-tree components, its final original degree is
    D=h+l+s+b. The returned arithmetic interval is exact, given final_red.
    """
    values = (core_degree, leaf_count, two_vertex_count, large_count, final_red)
    if any(not isinstance(x, Integral) for x in values):
        raise ValueError('Degrees, branch counts and red degree must be integers.')
    h, l, s, b, q = map(int, values)
    if h < 2 or min(l, s, b) < 0:
        raise ValueError('Require core degree >=2 and nonnegative branch counts.')
    D = h + l + s + b
    if not 0 <= q <= 2 * D:
        raise ValueError('The final red degree is outside the physical range.')
    B = 2 * D - q
    leaf = tuple(c for c in range(3)
                 if (c != 0 or B != 2) and
                    (c != 1 or (q != 1 and B != 1)) and
                    (c != 2 or q != 2))
    short = tuple(c for c in range(3)
                  if (c != 0 or B != 4) and (c != 2 or q != 4))
    profile = _sumset(l, s, b, leaf, short)
    base = profile['minimum']
    lo = max(base, q - 2 * h)
    hi = min(profile['maximum'], q)
    step = profile['step']
    lo += (base - lo) % step
    hi -= (hi - base) % step
    return {'minimum': lo, 'maximum': hi, 'step': step,
            'leaf_allowed': leaf, 'two_vertex_allowed': short,
            'final_blue': B, 'original_degree': D}


def core_tree_data(graph):
    """Split a connected cyclic simple graph into its 2-core and rooted trees."""
    if graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph):
        raise ValueError('A simple undirected graph is required.')
    if not graph or not nx.is_connected(graph):
        raise ValueError('A nonempty connected graph is required.')
    degrees = dict(graph.degree())
    pending = deque(v for v, d in degrees.items() if d < 2)
    removed = set()
    while pending:
        v = pending.popleft()
        if v in removed:
            continue
        removed.add(v)
        for w in graph[v]:
            if w not in removed:
                degrees[w] -= 1
                if degrees[w] == 1:
                    pending.append(w)
    core = graph.subgraph(set(graph) - removed).copy()
    if not core:
        raise ValueError('The graph is a tree; use tree_ports for that case.')
    core_vertices = set(core)
    branches = {v: [] for v in core}
    for component in nx.connected_components(graph.subgraph(set(graph) - core_vertices)):
        tree = graph.subgraph(component).copy()
        boundary = [(v, r) for r in component for v in graph[r]
                    if v in core_vertices]
        assert nx.is_tree(tree) and len(boundary) == 1
        v, root = boundary[0]
        kind = 0 if len(tree) == 1 else 1 if len(tree) == 2 else 2
        branches[v].append({'tree': tree, 'root': root, 'bridge': (v, root),
                            'kind': kind})
    counts = {}
    for v in core:
        counts[v] = tuple(sum(t['kind'] == j for t in branches[v]) for j in range(3))
        assert graph.degree(v) == core.degree(v) + len(branches[v])
    return {'core': core, 'core_edges': list(core.edges()),
            'branches': branches, 'counts': counts}


def _choose_ports(branches, counts, profile, total):
    remaining = list(counts)
    residual = total
    chosen = []
    leaf, short = profile['leaf_allowed'], profile['two_vertex_allowed']
    for branch in branches:
        kind = branch['kind']
        remaining[kind] -= 1
        suffix = _sumset(*remaining, leaf, short)
        allowed = leaf if kind == 0 else short if kind == 1 else (0, 1, 2)
        c = next((c for c in allowed if _contains(suffix, residual - c)), None)
        assert c is not None
        chosen.append(c)
        residual -= c
    assert residual == 0
    return chosen


def expand_core_coloring(graph, core_weights, final_red):
    """Expand a prescribed core edge assignment and FINAL core red degrees.

    core_weights follows core_tree_data(graph)['core_edges']. final_red is a
    mapping on core vertices. Success is equivalent to the exact local offset
    profiles and the actual conditional core-edge comparisons being satisfied.
    The expansion uses O(|V|+|E|) time and space after these choices are given.
    """
    data = core_tree_data(graph)
    core, core_edges = data['core'], data['core_edges']
    core_weights = list(core_weights)
    if len(core_weights) != len(core_edges) or \
        any(not isinstance(x, Integral) or x not in (0, 1, 2) for x in core_weights):
        raise ValueError('Require one weight 0,1,2 for every core edge.')
    if any(v not in final_red for v in core):
        raise ValueError('Every core vertex needs its final red degree.')
    core_red = {v: 0 for v in core}
    for (u, v), x in zip(core_edges, core_weights):
        core_red[u] += x
        core_red[v] += x
    profiles, ports = {}, {}
    for v in core:
        profiles[v] = attachment_sum_profile(core.degree(v), *data['counts'][v],
                                              final_red[v])
        offset = final_red[v] - core_red[v]
        if not _contains(profiles[v], offset):
            return {'status': 'incompatible', 'reason': 'attachment_sum', 'vertex': v,
                    'required_offset': offset, 'profile': profiles[v]}
        ports[v] = _choose_ports(data['branches'][v], data['counts'][v],
                                 profiles[v], offset)
    for (u, v), x in zip(core_edges, core_weights):
        if (x > 0 and final_red[u] == final_red[v]) or \
            (x < 2 and profiles[u]['final_blue'] == profiles[v]['final_blue']):
            return {'status': 'incompatible', 'reason': 'core_edge', 'edge': (u, v)}
    edges = list(graph.edges())
    index = {frozenset(e): j for j, e in enumerate(edges)}
    weights = [None] * len(edges)
    for e, x in zip(core_edges, core_weights):
        weights[index[frozenset(e)]] = int(x)
    for v in core:
        for branch, c in zip(data['branches'][v], ports[v]):
            result = extend_tree_bridge(branch['tree'], branch['root'],
                                        int(final_red[v]), profiles[v]['final_blue'], c)
            assert result['status'] == 'extended'
            weights[index[frozenset(branch['bridge'])]] = c
            for e, x in zip(result['edges'], result['weights']):
                weights[index[frozenset(e)]] = x
    assert all(x in (0, 1, 2) for x in weights)
    red = {v: 0 for v in graph}
    for (u, v), x in zip(edges, weights):
        red[u] += x
        red[v] += x
    assert all(red[v] == final_red[v] for v in core)
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    return {'status': 'extended', 'edges': edges, 'weights': weights,
            'red_degrees': red, 'blue_degrees': blue, 'bridge_weights': ports}


def extend_at_core_vertex(graph, vertex, base_weights):
    """Reattach all pendant trees at one vertex, keeping every base edge fixed.

    The base graph is obtained by deleting those pendant-tree vertices, and
    base_weights follows list(base.edges()). The input base coloring must be
    legal. Extension is guaranteed when the number of those trees is at least
    the vertex's degree within the 2-core. Below that threshold, this still
    decides exactly whether keeping this particular base assignment works.
    """
    data = core_tree_data(graph)
    core = data['core']
    if vertex not in core:
        raise ValueError('The specified vertex must belong to the 2-core.')
    branches = data['branches'][vertex]
    deleted = {w for branch in branches for w in branch['tree']}
    base = graph.subgraph(set(graph) - deleted).copy()
    base_edges = list(base.edges())
    base_weights = list(base_weights)
    if len(base_edges) != len(base_weights) or \
        any(not isinstance(x, Integral) or x not in (0, 1, 2) for x in base_weights):
        raise ValueError('Require one weight 0,1,2 for every base edge.')
    R = {v: 0 for v in base}
    for (u, v), x in zip(base_edges, base_weights):
        R[u] += x
        R[v] += x
    B = {v: 2 * base.degree(v) - R[v] for v in base}
    if any((x > 0 and R[u] == R[v]) or (x < 2 and B[u] == B[v])
           for (u, v), x in zip(base_edges, base_weights)):
        raise ValueError('The prescribed base coloring must be legal.')
    D = graph.degree(vertex)
    forbidden = set()
    for (u, v), x in zip(base_edges, base_weights):
        if vertex not in (u, v):
            continue
        w = v if u == vertex else u
        if x > 0:
            forbidden.add(R[w])
        if x < 2:
            forbidden.add(2 * D - B[w])
    t = R[vertex]
    chosen = None
    for q in range(t, t + 2 * len(branches) + 1):
        profile = attachment_sum_profile(core.degree(vertex),
                                          *data['counts'][vertex], q)
        if q not in forbidden and _contains(profile, q - t):
            chosen = (q, profile)
            break
    if chosen is None:
        assert len(branches) < core.degree(vertex)
        return {'status': 'incompatible', 'reason': 'fixed_base_assignment',
                'forbidden_final_red': sorted(forbidden)}
    q, profile = chosen
    ports = _choose_ports(branches, data['counts'][vertex], profile, q - t)
    edges = list(graph.edges())
    index = {frozenset(e): j for j, e in enumerate(edges)}
    weights = [None] * len(edges)
    for e, x in zip(base_edges, base_weights):
        weights[index[frozenset(e)]] = int(x)
    for branch, c in zip(branches, ports):
        result = extend_tree_bridge(branch['tree'], branch['root'], q, 2 * D - q, c)
        assert result['status'] == 'extended'
        weights[index[frozenset(branch['bridge'])]] = c
        for e, x in zip(result['edges'], result['weights']):
            weights[index[frozenset(e)]] = x
    assert all(x in (0, 1, 2) for x in weights)
    red = {v: 0 for v in graph}
    for (u, v), x in zip(edges, weights):
        red[u] += x
        red[v] += x
    blue = {v: 2 * graph.degree(v) - red[v] for v in graph}
    assert red[vertex] == q
    return {'status': 'extended', 'edges': edges, 'weights': weights,
            'red_degrees': red, 'blue_degrees': blue,
            'base_edges': base_edges, 'bridge_weights': ports}
