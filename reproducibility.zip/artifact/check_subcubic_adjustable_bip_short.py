"""Independent domain and actual-copy checks for adjustable bipartite cores."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from subcubic_no_two_threads import color_subcubic_adjustable_bip_short_threads


def independent_domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3 or all(d == 3 for d in degree.values()):
        return False, []
    roots = {v for v in graph if degree[v] == 3}
    if not roots:
        return True, []
    core = graph.subgraph(roots)
    components = list(nx.connected_components(core))
    membership = {v: i for i, vertices in enumerate(components) for v in vertices}
    pendants, loops, shorts = dict.fromkeys(roots, 0), dict.fromkeys(roots, 0), []
    # Use components AFTER REMOVING THE ROOTS, rather than following the
    # constructor's root-started path walks.
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [(v, w) for w in vertices for v in graph[w] if v in roots]
        assert len(attachments) in (1, 2)
        if len(attachments) == 1:
            pendants[attachments[0][0]] += 1
        else:
            u, v = attachments[0][0], attachments[1][0]
            if u == v:
                loops[u] += 1
            elif len(vertices) == 1:
                shorts.append((u, v))
    short_degree = dict.fromkeys(roots, 0)
    internal = dict.fromkeys(roots, 0)
    cross = set()
    for u, v in shorts:
        short_degree[u] += 1
        short_degree[v] += 1
        if membership[u] == membership[v]:
            internal[u] += 1
            internal[v] += 1
        else:
            cross.update((membership[u], membership[v]))
    blocked = []
    for i in cross:
        component = core.subgraph(components[i])
        if not nx.is_bipartite(component) or any(loops[v] for v in component):
            continue
        color = nx.bipartite.color(component)
        count = [0, 0]
        for v in component:
            count[color[v]] += (pendants[v] + internal[v]
                                + int(not pendants[v] and not short_degree[v]))
        if max(count) < 2:
            blocked.append({"vertices": list(component), "intrinsic_control_counts": count})
    return not blocked, blocked


def main():
    started = time.monotonic()
    rng = random.Random(20261107)
    # The intrinsic binary adjustment lemma is checked for every defect
    # and every pair of signs; the universal argument is separate.
    algebra_states = 0
    for c, a, b in itertools.product(range(3), (-1, 1), (-1, 1)):
        assert any((c + a * x + b * y) % 3 == 0 for x, y in itertools.product((0, 2), repeat=2))
        algebra_states += 1
    cases, cross_cases, with_bip_cross = 0, 0, 0
    control_pairs, loop_sums, modes, witnesses = set(), set(), set(), {}
    planned_sizes, unchanged_target_endpoints = set(), 0
    full_core_target_controls, full_core_target_flips = 0, 0
    def check(name, graph):
        nonlocal cases, cross_cases, with_bip_cross, unchanged_target_endpoints
        nonlocal full_core_target_controls, full_core_target_flips
        expected, blocked = independent_domain(graph)
        assert expected, (name, blocked)
        result = color_subcubic_adjustable_bip_short_threads(graph)
        verify(graph, result)
        cases += 1
        roots = {v for v in graph if graph.degree(v) == 3}
        h = graph.subgraph(roots)
        membership = {v: i for i, vertices in enumerate(nx.connected_components(h)) for v in vertices}
        has_cross = False
        targets = result.get("prechosen_short_targets", {})
        for key in result.get("short_threads", []):
            path = result["threads"][key]["path"]
            u, v = path[0], path[-1]
            if membership[u] != membership[v]:
                has_cross = True
                assert result["red"][u] % 3 == targets[u]
                assert result["red"][v] % 3 == targets[v]
                unchanged_target_endpoints += 2
        cross_cases += has_cross
        planned = result.get("adjustable_bipartite_components", [])
        with_bip_cross += bool(planned)
        for item in result.get("retained_components", []):
            kind = item["kind"]
            modes.add(kind)
            if kind.startswith("adjustable_bipartite_"):
                planned_sizes.add(min(3, len(item["vertices"])))
            if kind == "adjustable_bipartite_two_controls":
                pair = tuple(sorted(control[0] for control in item["controls"]))
                control_pairs.add(pair)
                for token in item["controls"]:
                    if token[0] == "target" and h.degree(token[1]) == 3:
                        full_core_target_controls += 1
                        full_core_target_flips += item["target_mod3"][token[1]] == 2
                label = str(pair)
            elif kind == "adjustable_bipartite_loop":
                loop_sums.add(item["loop_sum"])
                label = "loop_sum_" + str(item["loop_sum"])
            else:
                continue
            if label not in witnesses:
                witnesses[label] = {"name": name, "component": item,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    atlas_colored, atlas_excluded = 0, 0
    blocked_small = []
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected, blocked = independent_domain(graph)
        result = color_subcubic_adjustable_bip_short_threads(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_colored += 1
        else:
            atlas_excluded += 1
            if blocked:
                blocked_small.append({"graph6": nx.to_graph6_bytes(graph, header=False).decode().strip(),
                                      "blocked_components": blocked})
    fixtures = []
    # Two pendant controls on an isolated core; every combination of
    # pendant types is independently embedded into an actual full graph.
    for a, b in itertools.product((1, 2, 3), repeat=2):
        fixtures.append(("PP_isolated_core", 4,
            [(1, 2, 1), (2, 3, 1), (3, 1, 1), (0, 1, 2)],
            [(0, a), (0, b), (2, 1), (3, 2)]))
    fixtures.extend([
        ("PS_two_root_core", 5, [(0, 1, 1), (0, 1, 2), (1, 2, 2),
         (2, 3, 1), (3, 4, 1), (4, 2, 1)], [(0, 2), (3, 1), (4, 3)]),
        ("PT_path_core", 6, [(0, 1, 1), (1, 2, 1), (3, 4, 1), (4, 5, 1), (5, 3, 1),
         (0, 3, 2), (2, 4, 3), (2, 5, 4)], [(0, 1), (1, 2)]),
        ("SS_path_core", 6, [(0, 1, 1), (1, 2, 1), (0, 2, 2),
         (3, 4, 1), (4, 5, 1), (5, 3, 1), (0, 3, 2), (2, 4, 3), (1, 5, 3)], []),
        ("ST_path_core", 6, [(0, 1, 1), (1, 2, 1), (0, 1, 2),
         (3, 4, 1), (4, 5, 1), (5, 3, 1), (0, 3, 2), (2, 4, 3), (2, 5, 4)], []),
        ("TT_path_core", 8, [(0, 1, 1), (1, 2, 1),
         (3, 4, 1), (4, 5, 1), (5, 6, 1), (6, 7, 1), (7, 3, 1),
         (1, 3, 2), (0, 4, 3), (0, 5, 4), (2, 6, 3), (2, 7, 5)], []),
        ("TT_full_core_degree_three", 8,
         [(0, 2, 1), (0, 3, 1), (0, 4, 1), (1, 2, 1), (1, 3, 1), (1, 4, 1),
          (5, 6, 1), (6, 7, 1), (7, 5, 1), (2, 5, 2), (3, 6, 2), (4, 7, 2)], []),
        ("loop_K1", 4, [(0, 0, 3), (0, 1, 2), (1, 2, 1), (2, 3, 1), (3, 1, 1)],
         [(2, 1), (3, 2)]),
        ("loop_K2", 5, [(0, 1, 1), (0, 0, 3), (1, 2, 2),
         (2, 3, 1), (3, 4, 1), (4, 2, 1)], [(1, 2), (3, 1), (4, 3)]),
        ("two_good_bipartite_cores", 4,
         [(0, 1, 1), (2, 3, 1), (0, 1, 2), (2, 3, 2), (1, 3, 2)], [(0, 1), (2, 2)]),
    ])
    for name, count, threads, pendants in fixtures:
        check(name, expand(count, threads, pendants))
    # Loop sums depend on the fixed target at the NONBIPARTITE neighbor.
    # Vary root insertion order to cover all three actual target colors.
    for order in itertools.permutations(range(4)):
        check("loop_K1_target_permutations", expand(4, fixtures[-3][2], fixtures[-3][3], order))
    random_cases, disconnected, domain_rejected = 0, 0, 0
    while random_cases < 1800:
        count, threads, pendants, stubs = 0, [], [], []
        for _ in range(rng.randrange(2, 9)):
            kind = rng.choice(("star", "star", "cycle_even", "cycle_odd", "loop", "PP"))
            if kind == "star":
                local_count, direct, local_p = 4, [(0, 1), (0, 2), (0, 3)], [(1, 1), (2, 2)]
                local_loops = []
            elif kind.startswith("cycle"):
                local_count = rng.choice((4, 6, 8)) if kind == "cycle_even" else rng.choice((3, 5, 7))
                direct = [(v, (v + 1) % local_count) for v in range(local_count)]
                local_p = [(0, rng.randrange(1, 5)), (2, rng.randrange(1, 5))] if kind == "cycle_even" else []
                local_loops = []
            elif kind == "loop":
                local_count, direct, local_p, local_loops = 1, [], [], [(0, 0, rng.randrange(3, 10))]
            else:
                local_count, direct, local_p, local_loops = 1, [], [(0, 1), (0, 2)], []
            degrees = [sum(v in edge for edge in direct) for v in range(local_count)]
            for root, length in local_p:
                degrees[root] += 1
                pendants.append((count + root, length))
            for u, v, length in local_loops:
                degrees[u] += 2
                threads.append((count + u, count + v, length))
            threads.extend((count + u, count + v, 1) for u, v in direct)
            stubs.extend(count + v for v in range(local_count) for _ in range(3 - degrees[v]))
            count += local_count
        rng.shuffle(stubs)
        while stubs:
            u = stubs.pop()
            if stubs:
                v = stubs.pop()
                length = rng.randrange(3, 10) if u == v else rng.choice((2, 2, 2, 3, 4, 7))
                threads.append((u, v, length))
            else:
                pendants.append((u, rng.randrange(1, 8)))
        compressed = nx.Graph()
        compressed.add_nodes_from(range(count))
        compressed.add_edges_from((u, v) for u, v, _ in threads)
        if not nx.is_connected(compressed):
            disconnected += 1
            continue
        order = list(range(count))
        rng.shuffle(order)
        graph = expand(count, threads, pendants, order)
        if not independent_domain(graph)[0]:
            domain_rejected += 1
            continue
        check("random_good_core_network", graph)
        random_cases += 1
    check("long_loop_with_bipartite_cross", expand(2, [(0, 0, 5000), (0, 1, 2)], [(1, 1), (1, 5001)]))
    expected_pairs = set(itertools.combinations_with_replacement(("pendant", "short", "target"), 2))
    assert control_pairs == expected_pairs, control_pairs
    assert loop_sums == {1, 2, 3}, loop_sums
    assert planned_sizes == {1, 2, 3}
    assert full_core_target_controls >= 2 and full_core_target_flips >= 2
    report = {"checks_passed": True, "binary_defect_states": algebra_states,
        "eligible_atlas_graphs": atlas_colored, "inapplicable_atlas_graphs": atlas_excluded,
        "named_fixtures": len(fixtures), "loop_target_insertion_orders": 24,
        "random_good_core_networks": random_cases, "disconnected_draws_skipped": disconnected,
        "ineligible_random_draws_skipped": domain_rejected, "long_cases": 1,
        "actual_copy_checked_colorings": cases, "colorings_with_cross_short_paths": cross_cases,
        "colorings_with_bipartite_cross_short_paths": with_bip_cross,
        "fixed_cross_short_target_endpoints_checked": unchanged_target_endpoints,
        "full_core_degree_three_target_controls": full_core_target_controls,
        "full_core_degree_three_target_flips": full_core_target_flips,
        "control_pairs_observed": sorted(control_pairs), "loop_sums_observed": sorted(loop_sums),
        "planned_component_size_classes": sorted(planned_sizes), "core_modes_observed": sorted(modes),
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Finite implementation audit; the infinite family requires its separate proof."}
    Path(__file__).with_name("subcubic_adjustable_bip_short_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_adjustable_bip_short_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).parent.parent.joinpath("work", "adjustable_core_atlas_exclusions.json").write_text(
        json.dumps(blocked_small, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
