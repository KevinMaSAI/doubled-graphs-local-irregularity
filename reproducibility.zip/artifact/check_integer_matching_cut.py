"""Cross-check the signed-gap construction and actual, rather than modular, LIR."""

from collections import Counter
import itertools
import json
from pathlib import Path
import random
import time

import networkx as nx

from signed_gap_two import signed_gap_two
from integer_matching_cut import color_integer_matching_cut, cube_extra_cross_edge, phase_barrier_core
from mod4_component_cuts import color_with_mixed_components


OUT = Path(__file__).resolve().parent


def check_rows(rows, answer):
    signs = answer["signs"]
    sums = [sum(c*signs[var] for var, c in row.items()) for row in rows]
    assert sums == answer["row_sums"] and all(abs(a) >= 2 for a in sums)
    cert = answer["certificate"]
    sigma = cert["row_signs"]
    occurrences = {}
    for i, row in enumerate(rows):
        for var, c in row.items():
            occurrences.setdefault(var, []).append((i, c))
    bad, margin, out = {}, [len(row) for row in rows], [0]*len(rows)
    for var, items in occurrences.items():
        assert len(items) <= 2 and signs[var] in (-1, 1)
        if len(items) == 2:
            (u, a), (v, b) = items
            if a*b != sigma[u]*sigma[v]:
                bad[var] = (u, v)
                margin[u] -= 2; margin[v] -= 2
    assert set(cert["bad_positive_endpoint"]) == set(bad)
    for var, u in cert["bad_positive_endpoint"].items():
        assert u in bad[var]
        assert signs[var] == sigma[u]*rows[u][var]
        out[u] += 1
    assert margin == cert["margins"] and out == cert["bad_outdegrees"]
    assert all(margin[i]+2*out[i] == sigma[i]*sums[i] >= 2 for i in range(len(rows)))


def check_graph(answer):
    vertices = answer["vertices"]
    R, B, D = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0), Counter()
    for u, v, x in answer["edges"]:
        D[u] += 1; D[v] += 1
        for copy in range(2):
            target = R if copy < x else B
            target[u] += 1; target[v] += 1
    assert R == answer["red"] and B == answer["blue"]
    for u, v, x in answer["edges"]:
        for copy in range(2):
            target = R if copy < x else B
            assert target[u] != target[v]
    rows = [dict(row) for row in answer["signed_rows"]]
    check_rows(rows, answer["signed_solution"])
    T = set(answer["T"])
    assert all(R[v] % 2 == B[v] % 2 == int(v in T) for v in vertices)
    assert {frozenset((u, v)) for u, v, x in answer["edges"] if x == 1} == set(map(frozenset, answer["mixed_edges"]))
    return D


def encoded_rows(rows, answer):
    return {"rows": [[[var, c] for var, c in row.items()] for row in rows], "solution": answer}


def main():
    started = time.monotonic(); rng = random.Random(2026102801)
    row_cases, modes, flips = 0, Counter(), 0
    saved = {}
    for count in range(4, 9):
        for pattern in itertools.product((-1, 1), repeat=count):
            rows = [{i: 1 for i in range(count)}, {i: c for i, c in enumerate(pattern)}]
            answer = signed_gap_two(rows); check_rows(rows, answer)
            row_cases += 1; flips += answer["certificate"]["local_sign_flips"]
            modes.update(c["kind"] for c in answer["certificate"]["components"])
            if count == 5 and pattern == (1, 1, 1, -1, -1):
                saved["five_term_signed_rows"] = encoded_rows(rows, answer)
    for n in [5, 6, 7, 8, 12, 20]:
        for j in range(25):
            G = nx.complete_graph(n) if n <= 7 else nx.random_regular_graph(4+(j % 3), n, seed=7100+n*100+j)
            edges = list(G.edges())
            rows = [{i: rng.choice((-1, 1)) for i, e in enumerate(edges) if v in e} for v in G]
            if j % 4 == 0:
                var = len(edges)
                for v in G:
                    for _ in range(j % 3):
                        rows[v][var] = rng.choice((-1, 1)); var += 1
            answer = signed_gap_two(rows); check_rows(rows, answer)
            row_cases += 1; flips += answer["certificate"]["local_sign_flips"]
            modes.update(c["kind"] for c in answer["certificate"]["components"])
    boundary_rows = [{i: 1 for i in range(4)}, {i: (-1 if i % 2 else 1) for i in range(2, 6)}]
    answer = signed_gap_two(boundary_rows); check_rows(boundary_rows, answer)
    row_cases += 1; modes.update(c["kind"] for c in answer["certificate"]["components"])
    saved["boundary_signed_rows"] = encoded_rows(boundary_rows, answer)

    # The minimum-four and occurrence-two hypotheses cannot be dropped blindly.
    K4 = nx.complete_graph(4); edges = list(K4.edges())
    three_terms = [{i: (1 if v == e[0] else -1) for i, e in enumerate(edges) if v in e} for v in K4]
    count3 = 0
    for bits in itertools.product((-1, 1), repeat=len(edges)):
        sums = [sum(c*bits[i] for i, c in row.items()) for row in three_terms]
        assert any(abs(a) < 2 for a in sums); count3 += 1
    read_three = [{0: 1, 1: 1, 2: 1, 3: 1, 4: 1},
                  {0: -1, 1: -1, 2: 1, 3: 1, 4: 1},
                  {0: 1, 1: 1, 2: -1, 3: -1, 4: 1}]
    count_read3 = 0
    for bits in itertools.product((-1, 1), repeat=5):
        assert any(abs(sum(c*bits[i] for i, c in row.items())) < 2 for row in read_three)
        count_read3 += 1
    K5_edges = list(nx.complete_graph(5).edges())
    affine_rows = [{i: (1 if v == e[0] else -1) for i, e in enumerate(K5_edges) if v in e}
                   for v in range(5)]
    affine_assignments = 0
    for bits in itertools.product((-1, 1), repeat=len(K5_edges)):
        assert any(abs(1+sum(c*bits[i] for i, c in row.items())) < 2 for row in affine_rows)
        affine_assignments += 1
    for bad in [three_terms, read_three]:
        try:
            signed_gap_two(bad)
        except ValueError:
            pass
        else:
            raise AssertionError("An unsupported signed-form input was accepted.")
    saved["hypothesis_obstructions"] = {
        "three_terms_rows": [[[var, c] for var, c in row.items()] for row in three_terms],
        "three_occurrences_rows": [[[var, c] for var, c in row.items()] for row in read_three],
        "affine_rows": [[[var, c] for var, c in row.items()] for row in affine_rows],
        "affine_constants": [1]*5,
        "scope": "Counterexamples to extensions of the auxiliary signed lemma, not to mother."}

    atlas_inputs, atlas_colored = 0, 0
    for G in nx.graph_atlas_g():
        if not len(G) or not nx.is_connected(G) or min(dict(G.degree()).values()) < 3:
            continue
        degrees = list(dict(G.degree()).values())
        if max(degrees)-min(degrees) > 1:
            continue
        vertices, edges = list(G), list(G.edges())
        for mask in range(1, (1 << len(G))-1):
            T = {v for v in vertices if mask >> v & 1}
            inside = {v: sum((u in T) == (v in T) for u in G[v]) for v in G}
            if any(a > 1 for a in inside.values()) or any(inside[v] != 1 for v in T):
                continue
            atlas_inputs += 1
            answer = color_integer_matching_cut(vertices, edges, T)
            assert answer["status"] == "colored"
            check_graph(answer); atlas_colored += 1
    synthetic = 0
    for k in range(3, 9):
        for extra in [0, 2, 6]:
            n = k+extra+(k % 2)
            S, T = list(range(n)), list(range(n, 2*n))
            edges = [(u, n+(u+j) % n) for u in S for j in range(k-1)]
            edges += [(2*i, 2*i+1) for i in range(n//2)]
            edges += [(n+2*i, n+2*i+1) for i in range(n//2)]
            for amount in [0, n//2, n-1]:
                actual = edges+[(u, n+(u+k-1) % n) for u in range(amount)]
                answer = color_integer_matching_cut(list(range(2*n)), actual, T)
                assert answer["status"] == "colored"
                check_graph(answer); synthetic += 1
    for k in [3, 4, 7]:
        n = k+3+(k+3) % 2
        edges = [(u, n+(u+j) % n) for u in range(n) for j in range(k)]
        edges += [(n+2*i, n+2*i+1) for i in range(n//2)]
        edges += [(0, 1)]
        answer = color_integer_matching_cut(list(range(2*n)), edges, list(range(n, 2*n)))
        assert answer["status"] == "colored"
        check_graph(answer); synthetic += 1

    # Only internal pairs need close degrees; isolated S vertices may be leaves.
    unequal_T = list(range(4, 10))
    unequal_edges = [(s, t) for pair, neighbors in [((4, 5), [0, 1]),
                       ((6, 7), [1, 2]), ((8, 9), [0, 1, 2, 3])]
                     for t in pair for s in neighbors]
    unequal_edges += [(4, 5), (6, 7), (8, 9), (8, 10)]
    unequal = color_integer_matching_cut(list(range(11)), unequal_edges, unequal_T)
    assert unequal["status"] == "colored"
    unequal_d = check_graph(unequal)
    assert min(unequal_d.values()) == 1 and max(unequal_d.values()) == 6
    saved["pairwise_degree_condition_with_a_leaf"] = unequal

    phase_records = []
    for k in [1, 2, 3, 4, 5, 7, 10]:
        answer = phase_barrier_core(k); degrees = check_graph(answer)
        assert len(answer["vertices"]) == 10*k and len(answer["edges"]) == 17*k
        assert Counter(degrees.values()) == Counter({3: 6*k, 4: 4*k})
        G = nx.Graph((u, v) for u, v, x in answer["edges"])
        assert nx.is_connected(G) and not nx.is_bipartite(G)
        modular = color_with_mixed_components(answer["vertices"], [(u, v) for u, v, x in answer["edges"]], answer["mixed_edges"])
        assert (modular["status"] == "mod4_colored") == (k % 2 == 0)
        if k % 2:
            assert modular["obstruction"]["type"] == "phase_cut"
            assert set(modular["obstruction"]["U"]) == set(answer["vertices"])
        phase_records.append({"k": k, "n": 10*k, "m": 17*k, "fixed_mixed_mod4": modular["status"]})
        if k == 1:
            saved["same_mixed_phase_cut_integer_repair"] = {"integer_coloring": answer, "mod4_result": modular}
    cube = cube_extra_cross_edge(); check_graph(cube)
    modular = color_with_mixed_components(cube["vertices"], [(u, v) for u, v, x in cube["edges"]], cube["mixed_edges"])
    assert modular["status"] == "mod4_infeasible_for_fixed_mixed" and modular["obstruction"]["type"] == "forbidden_mixed_edge"
    assert not cube["satisfies_stronger_mod4_condition"]
    saved["same_mixed_forbidden_edge_integer_repair"] = {"integer_coloring": cube, "mod4_result": modular}
    report = {"signed_form_cases": row_cases, "signed_certificate_modes": dict(modes),
              "total_local_sign_flips": flips, "minimum_three_counter_assignments": count3,
              "read_three_counter_assignments": count_read3,
              "affine_counter_assignments": affine_assignments,
              "eligible_atlas_partition_inputs": atlas_inputs, "atlas_colorings_checked": atlas_colored,
              "synthetic_nearregular_graphs_checked": synthetic, "phase_barrier_family": phase_records,
              "pairwise_degree_only_graphs_checked": 1,
              "saved_example_groups": len(saved), "all_checks_passed": True,
              "elapsed_seconds": round(time.monotonic()-started, 3),
              "mother_conjecture_proved": False, "finite_tests_are_not_universal_proofs": True}
    (OUT/"integer_matching_cut_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (OUT/"integer_matching_cut_witnesses.json").write_text(json.dumps(saved, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
