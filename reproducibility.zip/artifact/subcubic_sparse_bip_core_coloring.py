"""LIR2 with sparse bipartite direct cores and freely assignable pure ports.

Every H component is bipartite with at most two H-degree-three vertices.
Original ordinary connections have length 2 or >=4. Original compressed
return paths are excluded; arbitrary pendant lengths and parallel ordinary
paths are allowed. This is a restricted family, not the mother conjecture.
"""

import networkx as nx

from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches
from sparse_bipartite_core import SAFE, safe_sparse_bipartite_core


def color_subcubic_sparse_bip_core(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("The graph must be simple, undirected and loopless.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The graph must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return {"status": "method_not_applicable", "reason": "degree_above_three",
                "mother_conjecture_proved": False}
    roots = [v for v in graph if degree[v] == 3]
    if not roots:
        return color_independent_branches(graph)
    root_set = set(roots)
    core = graph.subgraph(roots).copy()
    components = list(nx.connected_components(core))
    for vertices in components:
        component = core.subgraph(vertices)
        if not nx.is_bipartite(component) or sum(core.degree(v) == 3 for v in vertices) > 2:
            return {"status": "method_not_applicable", "reason": "unsupported_direct_core",
                    "component": list(vertices), "mother_conjecture_proved": False}
    edges = list(graph.edges())
    index = {frozenset(edge): i for i, edge in enumerate(edges)}
    used, threads, pendants = set(), [], []
    for root in roots:
        for neighbor in graph[root]:
            key = index[frozenset((root, neighbor))]
            if key in used:
                continue
            used.add(key)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                key = index[frozenset((current, other))]
                assert key not in used
                used.add(key)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": None})
            else:
                assert current in root_set
                if current == root:
                    return {"status": "method_not_applicable", "reason": "original_return_path",
                            "path": path, "mother_conjecture_proved": False}
                if len(path) == 4:
                    return {"status": "method_not_applicable", "reason": "ordinary_three_edge_thread",
                            "path": path, "mother_conjecture_proved": False}
                threads.append({"path": path, "ports": [None, None]})
    assert len(used) == len(edges)
    free = {v: [] for v in roots}
    for key, item in enumerate(threads):
        path = item["path"]
        if len(path) > 2:
            free[path[0]].append(("ordinary", key, 0))
            free[path[-1]].append(("ordinary", key, 1))
    for key, item in enumerate(pendants):
        free[item["path"][0]].append(("pendant", key, 0))
    assert all(len(free[v]) == 3 - core.degree(v) for v in roots)
    direct_values, root_red, reports = {}, {}, []
    for vertices in components:
        component = core.subgraph(vertices)
        result = safe_sparse_bipartite_core(component)
        assert result["status"] == "weighted"
        for edge, value in zip(result["edge_order"], result["weights"]):
            direct_values[frozenset(edge)] = value
        root_red.update(result["red"])
        for root in component:
            for record, value in zip(free[root], result["boundary_ports"][root]):
                kind, key, end = record
                if kind == "ordinary":
                    threads[key]["ports"][end] = value
                else:
                    pendants[key]["port"] = value
        reports.append({"vertices": list(component), "skeleton": result["skeleton"],
                        "representative_lengths": result["representative_lengths"],
                        "core_chain_reports": result["chain_reports"]})
    root_blue = {v: 6 - root_red[v] for v in roots}
    assert all(root_red[v] in SAFE for v in roots)
    assert all(root_red[u] != root_red[v] for u, v in core.edges())
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            key = index[frozenset((u, v))]
            assert weights[key] is None
            weights[key] = value
    for item in threads:
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            value = direct_values[frozenset((u, v))]
            item["ports"] = [value, value]
            word = [value]
        else:
            assert all(value in (0, 2) for value in item["ports"])
            word = _path_word(len(path) - 1, *item["ports"],
                              root_red[u], root_blue[u], root_red[v], root_blue[v])
        put(path, word)
    for item in pendants:
        path, port = item["path"], item["port"]
        root = path[0]
        assert port in (0, 2)
        put(path, _pendant_word(len(path) - 1, port, root_red[root], root_blue[root]))
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == root_red[v] and blue[v] == root_blue[v] for v in roots)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "threads": threads, "pendants": pendants,
            "core_reports": reports, "root_red": root_red, "mother_conjecture_proved": False}
