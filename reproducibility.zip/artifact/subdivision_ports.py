"""Construct witnesses when every base edge is replaced by a path of length >= 3.

This is an auxiliary arbitrary-degree family, NOT a solver for the mother conjecture.
The proof is the parity-chain argument recorded in the accompanying research notes.
"""
import json
import random
from pathlib import Path

import networkx as nx


def fill_path(length, left_blue_degree, right_red_degree):
    assert length >= 3
    allowed = [set(range(3)) for _ in range(length)]
    allowed[0] = {0}
    allowed[-1] = {2}
    allowed[1].discard(4-left_blue_degree)
    allowed[-2].discard(right_red_degree-2)
    word = [None]*length
    for parity in range(2):
        positions = list(range(parity, length, 2))
        histories = []
        last = {None}
        for pos in positions:
            current = {}
            for color in sorted(allowed[pos]):
                prior = next((c for c in last if c != color), 'missing')
                if prior != 'missing':
                    current[color] = prior
            assert current, (length, allowed, parity, pos)
            histories.append(current)
            last = set(current)
        color = min(last)
        for pos, history in zip(reversed(positions), reversed(histories)):
            word[pos] = color
            color = history[color]
    return word


def construct(base, lengths):
    assert nx.is_connected(base)
    assert not base.is_directed() and not base.is_multigraph()
    assert nx.number_of_selfloops(base) == 0
    roots = {v:i for i,v in enumerate(base)}
    threads = [(roots[u], roots[v], int(lengths[tuple(sorted((u,v)))]))
               for u,v in base.edges()]
    assert all(length >= 3 for u,v,length in threads)
    r = dict.fromkeys(roots.values(), 0)
    b = dict.fromkeys(roots.values(), 0)
    for u,v,length in threads:
        b[u] += 2
        r[v] += 2
    expanded = nx.Graph()
    expanded.add_nodes_from(roots.values())
    weights = {}
    next_vertex = len(roots)
    for u,v,length in threads:
        internal = list(range(next_vertex, next_vertex+length-1))
        next_vertex += length-1
        path = [u]+internal+[v]
        word = fill_path(length, b[u], r[v])
        for a,c,x in zip(path,path[1:],word):
            expanded.add_edge(a,c)
            weights[tuple(sorted((a,c)))] = x
    return expanded, weights


def independent_copy_check(graph, weights):
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for u,v in graph.edges():
        x = weights[tuple(sorted((u,v)))]
        if x not in (0,1,2):
            return False
        for copy in range(2):
            (red if copy < x else blue).add_edge(u,v)
    return (all(red.degree(u) != red.degree(v) for u,v in red.edges())
            and all(blue.degree(u) != blue.degree(v) for u,v in blue.edges()))


def main():
    rng = random.Random(20261026)
    examples = [nx.path_graph(2), nx.complete_graph(4), nx.complete_graph(7),
                nx.complete_bipartite_graph(3,4)]
    for _ in range(80):
        graph = nx.gnp_random_graph(rng.randrange(3,17), rng.uniform(.2,.9),
                                   seed=rng.randrange(1<<30))
        if nx.is_connected(graph):
            examples.append(graph)
    reports = []
    for index,base in enumerate(examples):
        lengths = {tuple(sorted((u,v))):rng.randrange(3,22) for u,v in base.edges()}
        graph,weights = construct(base,lengths)
        assert independent_copy_check(graph,weights)
        reports.append({'index':index,'base_vertices':len(base),
                        'base_edges':base.number_of_edges(),
                        'base_maximum_degree':max(dict(base.degree()).values()),
                        'expanded_vertices':len(graph),'passed':True})
    # Boundary arithmetic does not impose a maximum root degree or path length.
    count = 0
    for length in range(3,70):
        for left in (2,3,4,5,6,7,20,100,1000):
            for right in (2,3,4,5,6,7,20,100,1000):
                word = fill_path(length,left,right)
                assert word[0] == 0 and word[-1] == 2
                assert word[1] != 4-left and word[-2] != right-2
                assert all(word[i] != word[i+2] for i in range(length-2))
                count += 1
    result = {'scope':'finite implementation checks accompanying an infinite-family proof',
              'graph_cases':reports,'boundary_word_cases':count,
              'mother_conjecture_proved':False}
    target = Path(__file__).with_name('subdivision_ports_validation.json')
    target.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'graph_cases':len(reports),'boundary_word_cases':count,
                      'maximum_base_degree':max(x['base_maximum_degree'] for x in reports),
                      'passed':True,'mother_conjecture_proved':False}))


if __name__ == '__main__':
    main()
