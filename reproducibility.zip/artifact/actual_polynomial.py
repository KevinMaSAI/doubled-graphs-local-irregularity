"""Exact leading-coefficient diagnostics for the actual 2-multigraph rules."""
import json
import time
from pathlib import Path

import networkx as nx


def coefficient(g):
    edges = list(g.edges())
    m = len(edges)
    poly = {(0,) * m: 1}
    for i, (u, v) in enumerate(edges):
        delta = g.degree(u) - g.degree(v)
        linear = {}
        for j, (a, b) in enumerate(edges):
            c = int(u in (a, b)) - int(v in (a, b))
            if c:
                linear[j] = c
        factor = {}
        for j, a in linear.items():
            for k, b in linear.items():
                key = tuple(sorted((j, k)))
                factor[key] = factor.get(key, 0) + a * b
        for j, a in linear.items():
            key = tuple(sorted((i, j)))
            factor[key] = factor.get(key, 0) + 2 * delta * a
        if delta:
            factor[(i, i)] = factor.get((i, i), 0) + 2 * delta * delta
        new = {}
        for exponents, value in poly.items():
            for (j, k), c in factor.items():
                if not c or exponents[j] + 1 + int(j == k) > 2 or exponents[k] >= 2:
                    continue
                e = list(exponents)
                e[j] += 1
                e[k] += 1
                e = tuple(e)
                new[e] = new.get(e, 0) + value * c
        poly = {e: c for e, c in new.items() if c}
    return poly.get((2,) * m, 0)


def direct_grid(g):
    import itertools
    edges = list(g.edges())
    m = len(edges)
    acc = 0
    actual_count = 0
    for xs in itertools.product(range(3), repeat=m):
        r = {v: 0 for v in g}
        for (u, v), x in zip(edges, xs):
            r[u] += x
            r[v] += x
        product = 1
        valid = True
        for (u, v), x in zip(edges, xs):
            d = r[u] - r[v]
            delta = g.degree(u) - g.degree(v)
            f = d*d - 2*delta*(2-x)*d + 2*delta*delta*(x-1)*(x-2)
            edge_valid = (x == 0 or d != 0) and (x == 2 or d != 2*delta)
            assert (f != 0) == edge_valid
            valid &= edge_valid
            product *= f
        denominator_inverse_times_2m = (-2) ** xs.count(1)
        acc += product * denominator_inverse_times_2m
        actual_count += int(valid)
    assert acc % (2**m) == 0
    return {'grid_coefficient': acc // (2**m), 'actual_colorings': actual_count}


def main():
    start = time.monotonic()
    results = []
    zeros = []
    for index, g in enumerate(nx.graph_atlas_g()):
        if len(g) < 3 or not nx.is_connected(g) or g.number_of_edges() > 9:
            continue
        c = coefficient(g)
        item = {'atlas': index, 'n': len(g), 'm': g.number_of_edges(), 'coefficient': c}
        if c == 0:
            item['edges'] = list(g.edges())
            item.update(direct_grid(g))
            zeros.append(item)
            print(json.dumps(item), flush=True)
        results.append(item)
        if index % 100 == 0:
            print(json.dumps({'progress': index, 'cases': len(results), 'zeros': len(zeros),
                              'elapsed': time.monotonic() - start}), flush=True)
        if len(zeros) >= 4:
            break
    report = {'scope': 'Finite diagnostics; zero is failure of this coefficient criterion only.',
              'cases': results, 'zero_cases': zeros, 'elapsed': time.monotonic() - start}
    Path(__file__).with_name('actual_polynomial_diagnostic.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'checked': len(results), 'zeros': len(zeros), 'elapsed': report['elapsed']}), flush=True)


if __name__ == '__main__':
    main()
