"""Audit both color branches, the complement identity, and the infinite-family implementation."""

import itertools
import json
from pathlib import Path
import random
import time

import networkx as nx
import z3

from check_matching_long_branch_coloring import verify
from complement_path_lift import lift_complement_edge
from co_cycle_chord_family import color_family, graph_family


def seed_coloring(graph):
    edges = list(graph.edges())
    x = [z3.Int("seed_"+str(i)) for i in range(len(edges))]
    R = {v: z3.Sum([a for e, a in zip(edges, x) if v in e]) for v in graph}
    B = {v: 2*graph.degree(v)-R[v] for v in graph}
    solver = z3.Solver()
    solver.set(timeout=3000)
    solver.add(*[z3.And(a >= 0, a <= 2) for a in x])
    for (u, v), a in zip(edges, x):
        solver.add(z3.Implies(a > 0, R[u] != R[v]), z3.Implies(a < 2, B[u] != B[v]))
    answer = solver.check()
    assert answer == z3.sat, (len(graph), answer)
    model = solver.model()
    return {frozenset(e): model.eval(a).as_long() for e, a in zip(edges, x)}


def main():
    started = time.monotonic()
    rng = random.Random(2026102779)
    seeds = [g for g in nx.graph_atlas_g() if len(g) >= 3 and nx.is_connected(g)
             and max(dict(g.degree()).values()) <= len(g)-3]
    rng.shuffle(seeds)
    actual = red_cases = blue_cases = 0
    for graph in seeds[:100]:
        old_values = seed_coloring(graph)
        for u, v in list(nx.non_edges(graph))[:5]:
            for color in ("red", "blue"):
                result = lift_complement_edge(graph, old_values, u, v,
                                              range(len(graph), len(graph)+4), color)
                if result["status"] != "colored":
                    assert result["reason"] == "chosen_nonedge_lacks_color_contrast"
                    continue
                final = result["graph"]
                verify(final, result)
                before = nx.complement(graph)
                before.remove_edge(u, v)
                before.add_edges_from(zip(result["complement_path"], result["complement_path"][1:]))
                assert {frozenset(e) for e in before.edges()} == {
                    frozenset(e) for e in nx.complement(final).edges()}
                actual += 1
                red_cases += color == "red"
                blue_cases += color == "blue"
    empty = nx.empty_graph(3)
    rejected = lift_complement_edge(empty, {}, 0, 1, range(3, 7))
    assert rejected["status"] == "method_not_applicable"
    assert rejected["reason"] == "chosen_nonedge_lacks_color_contrast"
    cycle = nx.cycle_graph(5)
    cycle_values = {frozenset(e): x for e, x in
                    [((0, 1), 0), ((1, 2), 0), ((2, 3), 1), ((3, 4), 1), ((4, 0), 2)]}
    rejected_cycle = lift_complement_edge(cycle, cycle_values, 0, 3, range(5, 9))
    assert rejected_cycle["status"] == "method_not_applicable"
    assert rejected_cycle["reason"] == "chosen_nonedge_lacks_color_contrast"
    transitive_series = []
    for name, missing in (("K33", nx.complete_bipartite_graph(3, 3)),
                          ("cube", nx.cubical_graph()), ("Petersen", nx.petersen_graph())):
        seed = nx.complement(missing)
        values = seed_coloring(seed)
        R, B = dict.fromkeys(seed, 0), dict.fromkeys(seed, 0)
        for u, v in seed.edges():
            x = values[frozenset((u, v))]
            R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
        u, v = next((u, v) for u, v in missing.edges() if R[u] != R[v] or B[u] != B[v])
        orbit = set()
        target = frozenset(next(iter(missing.edges())))
        mapping = None
        for perm in nx.algorithms.isomorphism.GraphMatcher(missing, missing).isomorphisms_iter():
            image = frozenset((perm[u], perm[v]))
            orbit.add(image)
            if image == target:
                mapping = perm
        assert orbit == {frozenset(e) for e in missing.edges()} and mapping is not None
        values = {frozenset(mapping[w] for w in e): x for e, x in values.items()}
        u, v = tuple(target)
        current = seed
        for step in range(1, 5):
            next_node = max(current)+1
            result = lift_complement_edge(current, values, u, v, range(next_node, next_node+4))
            assert result["status"] == "colored"
            current = result["graph"]
            verify(current, result)
            values = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
            u, v = result["complement_path"][-2:]
        transitive_series.append({"seed": name, "extensions": 4, "new_vertices": len(current),
                                  "seed_connected": nx.is_connected(seed)})
    family, witness = [], None
    for k in (3, 5, 7, 9, 11, 21, 51, 101):
        result = color_family(k)
        graph = result["graph"]
        verify(graph, result)
        assert {v for v, d in graph.degree() if d == 2*k-3} == {0, 2}
        assert all(d in (2*k-3, 2*k-2) for v, d in graph.degree())
        B = set(range(k))
        A = set(graph)-B
        assert max(dict(graph.subgraph(A).degree()).values()) <= k-1
        assert max(dict(graph.subgraph(B).degree()).values()) <= k-2
        record = {"k": k, "vertices": len(graph), "edges": graph.number_of_edges()}
        family.append(record)
        if k == 11:
            witness = {"k": k, "edges": [[u, v, x] for (u, v), x in
                                         zip(result["edge_order"], result["weights"])],
                       "red": result["red"], "blue": result["blue"]}
    # Independent vertex-subset enumeration checks the cardinality statement, not just coloring.
    partition_counts = {}
    for k in (3, 5, 7):
        graph = graph_family(k)
        counts = {}
        for mask in range(1 << len(graph)):
            B = {v for v in graph if mask & (1 << v)}
            A = set(graph)-B
            if any(sum(w in A for w in graph[v]) > k-1 for v in A):
                continue
            if any(sum(w in B for w in graph[v]) > k-2 for v in B):
                continue
            counts[len(B)] = counts.get(len(B), 0)+1
        assert set(counts) == {k}
        partition_counts[k] = counts
    output = {"seed_colorings": min(100, len(seeds)), "actual_lifts_verified": actual,
              "red_contrast_lifts": red_cases, "blue_contrast_lifts": blue_cases,
              "complement_path_identity_verified": True, "old_colors_and_count_increments_verified": True,
              "equal_count_nonedge_rejected_explicitly": True, "family_cases": family,
              "connected_C5_equal_count_interface_rejected": True,
              "edge_transitive_seed_series": transitive_series,
              "all_defective_partitions_enumerated": partition_counts,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "seconds": round(time.monotonic()-started, 3)}
    out = Path(__file__).parent
    (out/"complement_path_lift_validation.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8")
    (out/"co_cycle_chord_witness.json").write_text(json.dumps(witness, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
