"""Exact parity-interval feasibility via a perfect matching gadget.

This chooses actual original-edge weights 0,1,2 with prescribed vertex parity
and degree intervals. It does NOT impose the local irregularity comparisons.
"""

import networkx as nx


def parity_degree_window(graph, lower, upper, parity, obstruction_certificate=False):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if any(set(data) != set(graph) for data in (lower, upper, parity)):
        raise ValueError("Bounds and parity must be specified at every vertex.")
    if any(p not in (0, 1) for p in parity.values()):
        raise ValueError("Parities must be bits.")
    g, f = {}, {}
    for v in graph:
        if not isinstance(lower[v], int) or not isinstance(upper[v], int):
            raise ValueError("Integer degree bounds are required.")
        lo, hi = max(0, lower[v]), min(2 * graph.degree(v), upper[v])
        g[v] = lo + (parity[v] - lo) % 2
        f[v] = hi - (hi - parity[v]) % 2
        if g[v] > f[v]:
            return {"status": "infeasible", "reason": "empty_degree_domain", "vertex": v}

    edges = list(graph.edges())
    gadget = nx.Graph()
    incident = {v: [] for v in graph}
    copies = []
    next_node = 0
    def add_copy(u, v, original_id):
        nonlocal next_node
        a, b = next_node, next_node + 1
        next_node += 2
        gadget.add_edge(a, b)
        incident[u].append(a)
        incident[v].append(b)
        copies.append((u, v, a, b, original_id))
    for edge_id, (u, v) in enumerate(edges):
        for _ in range(2):
            add_copy(u, v, edge_id)
    for v in graph:
        # Selecting a virtual loop subtracts two from the ordinary target f(v).
        for _ in range((f[v] - g[v]) // 2):
            add_copy(v, v, None)
    for v in graph:
        for _ in range(f[v]):
            dummy = next_node
            next_node += 1
            gadget.add_node(dummy)
            gadget.add_edges_from((dummy, port) for port in incident[v])
    matching = nx.max_weight_matching(gadget, maxcardinality=True)
    if 2 * len(matching) != next_node:
        result = {"status": "infeasible", "reason": "no_perfect_matching",
                  "gadget_vertices": next_node, "maximum_matching_size": len(matching)}
        if obstruction_certificate:
            # Gallai-Edmonds extraction. The returned barrier is then checked
            # directly by the elementary odd-component obstruction.
            size = len(matching)
            exposable = set()
            for node in gadget:
                reduced = gadget.subgraph([v for v in gadget if v != node])
                if len(nx.max_weight_matching(reduced, maxcardinality=True)) == size:
                    exposable.add(node)
            barrier = {v for u in exposable for v in gadget[u] if v not in exposable}
            remaining = gadget.subgraph([v for v in gadget if v not in barrier])
            odd_components = [sorted(c) for c in nx.connected_components(remaining) if len(c) % 2]
            assert len(odd_components) > len(barrier)
            result["tutte_barrier"] = {"removed_vertices": sorted(barrier),
                                       "odd_components": odd_components,
                                       "deficiency": len(odd_components) - len(barrier)}
        return result
    partner = {}
    for a, b in matching:
        partner[a], partner[b] = b, a
    weights = [0] * len(edges)
    for u, v, a, b, original_id in copies:
        chosen = partner[a] != b
        assert chosen == (partner[b] != a)
        if chosen and original_id is not None:
            weights[original_id] += 1
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    assert all(g[v] <= red[v] <= f[v] and red[v] % 2 == parity[v] for v in graph)
    return {"status": "feasible", "edge_order": edges, "weights": weights,
            "red": red, "blue": {v: 2 * graph.degree(v) - red[v] for v in graph},
            "gadget_vertices": next_node, "guarantees_local_irregularity": False}
