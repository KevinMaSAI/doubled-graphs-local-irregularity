"""Independent actual-copy audit of the path/cycle-core construction."""

import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from independent_branch_coloring import _path_word
from subcubic_path_cycle_core import color_subcubic_path_cycle_core


def domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return False
    if any(sum(degree[w] == 3 for w in graph[v]) > 2 for v in graph if degree[v] == 3):
        return False
    # An ordinary three-edge branch path has exactly one central edge
    # between degree-two vertices whose other neighbors are DISTINCT roots.
    for u, v in graph.edges():
        if degree[u] == degree[v] == 2:
            a = next(w for w in graph[u] if w != v)
            b = next(w for w in graph[v] if w != u)
            if a != b and degree[a] == degree[b] == 3:
                return False
    return True


def main():
    started = time.monotonic()
    rng = random.Random(20261105)
    free_long_interfaces = 0
    for a in (0, 2):
        for b in (0, 2):
            for ru in range(a, a + 5):
                for rv in range(b, b + 5):
                    for length in range(4, 17):
                        word = _path_word(length, a, b, ru, 6 - ru, rv, 6 - rv)
                        assert word is not None and word[0] == a and word[-1] == b
                        red = [ru] + [x + y for x, y in zip(word, word[1:])] + [rv]
                        blue = [6 - ru] + [4 - x for x in red[1:-1]] + [6 - rv]
                        assert all((x == 0 or red[i] != red[i + 1])
                                   and (x == 2 or blue[i] != blue[i + 1])
                                   for i, x in enumerate(word))
                        free_long_interfaces += 1
    cases, with_short, with_loops = 0, 0, 0
    core_modes, action_modes, witnesses = set(), set(), {}
    def check(name, graph):
        nonlocal cases, with_short, with_loops
        assert domain(graph)
        result = color_subcubic_path_cycle_core(graph)
        verify(graph, result)
        cases += 1
        with_short += any(len(item["path"]) == 3 for item in result.get("threads", []))
        with_loops += any(item["path"][0] == item["path"][-1] for item in result.get("threads", []))
        for item in result.get("core_reports", []):
            core_modes.add((item["kind"], item["parity"]))
        for action in result.get("actions", []):
            kind = action["kind"]
            action_modes.add(kind)
            if kind not in witnesses:
                witnesses[kind] = {"name": name, "action": action,
                    "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        return result
    atlas_colored, atlas_excluded = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        result = color_subcubic_path_cycle_core(graph)
        expected = domain(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            atlas_colored += 1
        else:
            atlas_excluded += 1
    # Every permitted finite core type, both endpoint-loop positions,
    # and both possible ordinary port flips.
    fixtures = [
        ("two_loop_roots", 2, [(0, 1, 1), (0, 0, 3), (1, 1, 3)], []),
        ("one_isolated_loop_short", 2, [(0, 0, 3), (0, 1, 2)], [(1, 1), (1, 2)]),
        ("two_isolated_loops_short", 2, [(0, 0, 3), (1, 1, 3), (0, 1, 2)], []),
        ("path_loop_endpoints", 3,
         [(0, 1, 1), (1, 2, 1), (0, 0, 3), (2, 2, 4)], [(1, 1)]),
    ]
    for length in range(1, 13):
        count = length
        threads = [(v, v + 1, 1) for v in range(count - 1)]
        degree = [sum(v in (a, b) for a, b, _ in threads) for v in range(count)]
        pendants = [(v, 1 + (v + j) % 5) for v in range(count) for j in range(3 - degree[v])]
        fixtures.append(("path_core", count, threads, pendants))
        if count >= 3:
            cycle = [(v, (v + 1) % count, 1) for v in range(count)]
            fixtures.append(("cycle_core", count, cycle, [(v, 1 + v % 5) for v in range(count)]))
    # Cubic prism core with one perfect matching subdivided to length TWO.
    for cycle_length in range(3, 15):
        threads = [(offset + v, offset + (v + 1) % cycle_length, 1)
                   for offset in (0, cycle_length) for v in range(cycle_length)]
        threads.extend((v, v + cycle_length, 2) for v in range(cycle_length))
        fixtures.append(("matching_subdivided_to_two", 2 * cycle_length, threads, []))
    for name, count, threads, pendants in fixtures:
        check(name, expand(count, threads, pendants))
    random_cases, disconnected = 0, 0
    while random_cases < 1400:
        blocks, count, threads = [], 0, []
        for _ in range(rng.randrange(1, 7)):
            size = rng.randrange(1, 9)
            block = list(range(count, count + size))
            count += size
            blocks.append(block)
            threads.extend((u, v, 1) for u, v in zip(block, block[1:]))
            if size >= 3 and rng.random() < 0.5:
                threads.append((block[0], block[-1], 1))
        direct_degree = [sum(v in (u, w) for u, w, _ in threads) for v in range(count)]
        stubs = []
        for v in range(count):
            remaining = 3 - direct_degree[v]
            if remaining >= 2 and rng.random() < 0.4:
                threads.append((v, v, rng.randrange(3, 10)))
                remaining -= 2
            stubs.extend([v] * remaining)
        rng.shuffle(stubs)
        pendants = []
        while stubs:
            u = stubs.pop()
            if stubs and rng.random() < 0.88:
                v = stubs.pop()
                length = rng.choice((2, 2, 4, 5, 7, 9)) if u != v else rng.randrange(3, 10)
                threads.append((u, v, length))
            else:
                pendants.append((u, rng.randrange(1, 10)))
        compressed = nx.Graph()
        compressed.add_nodes_from(range(count))
        compressed.add_edges_from((u, v) for u, v, _ in threads)
        if not nx.is_connected(compressed):
            disconnected += 1
            continue
        order = list(range(count))
        rng.shuffle(order)
        check("random_path_cycle_core", expand(count, threads, pendants, order))
        random_cases += 1
    check("long_loop_with_short", expand(2, [(0, 0, 5001), (0, 1, 2)], [(1, 1), (1, 5000)]))
    assert core_modes == {("path", 0), ("path", 1), ("cycle", 0), ("cycle", 1)}
    assert action_modes == {"ordinary_port_two", "pendant_port_two", "isolated_loop_red_one",
                            "endpoint_loop_red_two", "double_loop_red_four"}, action_modes
    report = {"checks_passed": True, "free_pure_long_interfaces": free_long_interfaces,
        "eligible_atlas_graphs": atlas_colored,
        "inapplicable_atlas_graphs": atlas_excluded, "named_fixtures": len(fixtures),
        "random_cases": random_cases, "disconnected_draws_skipped": disconnected,
        "long_cases": 1, "actual_copy_checked_colorings": cases,
        "colorings_with_short_threads": with_short, "colorings_with_loops": with_loops,
        "core_modes_observed": sorted(core_modes), "actions_observed": sorted(action_modes),
        "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
        "scope": "Finite implementation audit; the full family has a separate constructive proof."}
    Path(__file__).with_name("subcubic_path_cycle_core_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("subcubic_path_cycle_core_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
