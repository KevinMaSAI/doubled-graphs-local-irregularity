"""Actual-copy checks of rooted homogeneous and size-conditioned clique block trees."""

from collections import Counter
import json
from pathlib import Path
import random
import time

import networkx as nx

from check_matching_long_branch_coloring import verify as verify_no_offsets
from check_rooted_clique_interface import verify
from clique_block_tree import color_clique_block_tree
from regular_block_tree import color_regular_block_tree


def attach_clique(graph, root, order):
    fresh = list(range(max(graph, default=-1) + 1, max(graph, default=-1) + order))
    vertices = [root] + fresh
    graph.add_edges_from((u, v) for j, u in enumerate(vertices) for v in vertices[j + 1:])
    return fresh


def main():
    started = time.monotonic()
    rng = random.Random(2026102752)
    checked, without_offsets, strict_extension, equal_adjacent_cuts = 0, 0, 0, 0
    maximum_degree, maximum_block_order, modes = 0, 0, Counter()
    witnesses = {}

    def check(name, graph, root=0, A=0, B=0, target=None):
        nonlocal checked, without_offsets, strict_extension, equal_adjacent_cuts
        nonlocal maximum_degree, maximum_block_order
        target = graph.degree(root) if target is None else target
        result = color_clique_block_tree(graph, root, A, B, target)
        assert result["status"] == "colored", (name, result)
        verify(graph, result, root, A, B, target)
        if A == B == 0:
            verify_no_offsets(graph, result)
            without_offsets += 1
        checked += 1
        modes.update(result["construction_modes"])
        maximum_degree = max(maximum_degree, max(dict(graph.degree()).values()))
        maximum_block_order = max([maximum_block_order] + result["block_orders"])
        cuts = set(nx.articulation_points(graph))
        equal_adjacent_cuts += int(any(u in cuts and v in cuts and graph.degree(u) == graph.degree(v)
                                      for u, v in graph.edges()))
        if A == B == 0 and result["block_orders"] == [4]:
            old = color_regular_block_tree(graph)
            if old["status"] != "colored":
                strict_extension += 1
                if "outside_interval_gluing" not in witnesses:
                    witnesses["outside_interval_gluing"] = {
                        "name": name, "old_reason": old["reason"],
                        "edges": [[u, v, x] for (u, v), x in
                                  zip(result["edge_order"], result["weights"])],
                        "red": result["red"], "blue": result["blue"],
                        "reports": result["assembly_reports"]}
        return result

    check("singleton", nx.empty_graph(1))
    for n in range(4, 14):
        for blocks in (1, 2, 3, 6, 12):
            graph = nx.Graph()
            graph.add_node(0)
            for _ in range(blocks):
                attach_clique(graph, 0, n)
            for root in rng.sample(list(graph), min(3, len(graph))):
                for target in sorted({0, 1, graph.degree(root), 2 * graph.degree(root) - 1,
                                      2 * graph.degree(root)}):
                    check("homogeneous_windmill", graph, root, target=target)
    for trial in range(140):
        n = rng.randrange(4, 11)
        graph = nx.complete_graph(n)
        for _ in range(rng.randrange(1, 24)):
            attach_clique(graph, rng.choice(list(graph)), n)
        root = rng.choice(list(graph))
        A, B = rng.randrange(30), rng.randrange(30)
        B += (A + B) % 2
        target = rng.randrange(2 * graph.degree(root) + 1)
        check("arbitrary_rooted_homogeneous_tree", graph, root, A, B, target)
        check("unrooted_homogeneous_tree", graph)
    # Distinct block orders with child degree >= parent degree.
    for trial in range(100):
        graph = nx.complete_graph(4)
        frontier = [(v, 4) for v in graph if v != 0]
        for _ in range(rng.randrange(1, 18)):
            v, parent_order = frontier.pop(rng.randrange(len(frontier)))
            child_order = parent_order + rng.randrange(3)
            fresh = attach_clique(graph, v, child_order)
            frontier.extend((w, child_order) for w in fresh)
        check("monotone_mixed_blocks", graph)
    # Equal adjacent cut degrees 6 defeat interval separation but are colored.
    graph = nx.complete_graph(4)
    attach_clique(graph, 0, 4)
    attach_clique(graph, 1, 4)
    check("adjacent_equal_degree_six_cuts", graph)
    # Arbitrary tuple labels.
    for trial in range(15):
        graph = nx.complete_graph(4)
        for _ in range(8):
            attach_clique(graph, rng.choice(list(graph)), 4)
        graph = nx.relabel_nodes(graph, {v: ("vertex", v) for v in graph})
        check("tuple_labels", graph, root=("vertex", rng.randrange(4)))
    # The size condition is a method restriction, never an uncolorability claim.
    graph = nx.complete_graph(10)
    left = attach_clique(graph, 0, 4)
    attach_clique(graph, 1, 4)
    rejected = color_clique_block_tree(graph, root=left[0])
    assert rejected["status"] == "method_not_applicable"
    assert rejected["reason"] == "child_clique_degrees_smaller_than_parent_degree"
    assert strict_extension > 0 and equal_adjacent_cuts > 0
    output = {"actual_block_tree_colorings_verified": checked,
              "without_root_offsets": without_offsets,
              "cases_beyond_previous_interval_gluing": strict_extension,
              "graphs_with_equal_degree_adjacent_cuts": equal_adjacent_cuts,
              "maximum_original_degree": maximum_degree,
              "maximum_block_order": maximum_block_order,
              "construction_modes": dict(modes), "explicit_scope_rejection": True,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "scope": "Homogeneous K_n block trees for all n>=4 and root-size-conditioned mixed clique trees.",
              "seconds": round(time.monotonic() - started, 3)}
    path = Path(__file__).parent
    (path / "clique_block_tree_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    (path / "clique_block_tree_witnesses.json").write_text(
        json.dumps(witnesses, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
