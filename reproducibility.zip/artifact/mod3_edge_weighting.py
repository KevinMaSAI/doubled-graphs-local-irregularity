"""Proper 0/1/2 edge sums modulo 3 for suitable three-colorable graphs.

This controls ONE sum, including optional fixed integer vertex offsets.
It is NOT a simultaneous red/blue theorem for arbitrary vertex degrees.
"""

from collections import deque

import networkx as nx


def two_degenerate_coloring(graph):
    degree = dict(graph.degree())
    queue = deque(v for v in graph if degree[v] <= 2)
    removed, order = set(), []
    while queue:
        v = queue.popleft()
        if v in removed:
            continue
        assert degree[v] <= 2
        removed.add(v)
        order.append(v)
        for w in graph[v]:
            if w not in removed:
                degree[w] -= 1
                if degree[w] == 2:
                    queue.append(w)
    if len(order) != len(graph):
        return None
    colors = {}
    for v in reversed(order):
        unavailable = {colors[w] for w in graph[v] if w in colors}
        colors[v] = next(value for value in range(3) if value not in unavailable)
    return colors


def realize_mod3_sums(graph, target):
    """Tree elimination, with one odd closing edge if needed."""
    edges = list(graph.edges())
    values = {frozenset(edge): 0 for edge in edges}
    root = next(iter(graph))
    order, parent, sign = [root], {root: None}, {root: 1}
    for v in order:
        for w in graph[v]:
            if w not in parent:
                parent[w] = v
                sign[w] = -sign[v]
                order.append(w)
    assert len(order) == len(graph)
    remaining = {v: target[v] % 3 for v in graph}
    defect = sum(sign[v] * remaining[v] for v in graph) % 3
    closing = next(((u, v) for u, v in edges if sign[u] == sign[v]), None)
    closing_weight = 0
    if closing is None:
        if defect:
            return {"status": "infeasible_mod3", "alternating_defect": defect}
    else:
        u, v = closing
        coefficient = (sign[u] + sign[v]) % 3
        closing_weight = defect * pow(coefficient, -1, 3) % 3
        values[frozenset(closing)] = closing_weight
        remaining[u] = (remaining[u] - closing_weight) % 3
        remaining[v] = (remaining[v] - closing_weight) % 3
    for v in reversed(order[1:]):
        p = parent[v]
        value = remaining[v] % 3
        values[frozenset((v, p))] = value
        remaining[p] = (remaining[p] - value) % 3
        remaining[v] = 0
    assert remaining[root] % 3 == 0
    sums = dict.fromkeys(graph, 0)
    for u, v in edges:
        value = values[frozenset((u, v))]
        sums[u] += value
        sums[v] += value
    assert all(sums[v] % 3 == target[v] % 3 for v in graph)
    return {"status": "realized", "edge_order": edges,
            "weights": [values[frozenset(edge)] for edge in edges], "sums": sums,
            "closing_edge": closing, "closing_weight": closing_weight,
            "initial_alternating_defect": defect}


def proper_012_with_offsets(graph, offsets=None, coloring=None):
    """Connected bipartite >=3, or a supplied/2-degenerate proper 3-coloring.

    K2 is handled only when its fixed offsets already differ modulo 3.
    An unsupported graph returns method_not_applicable, not uncolorability.
    """
    if (graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph)
            or not len(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    offsets = {v: 0 if offsets is None else offsets[v] for v in graph}
    if any(not isinstance(value, int) for value in offsets.values()):
        raise ValueError("The vertex offsets must be integers.")
    adjustments = []
    if len(graph) == 1:
        target = {v: offsets[v] % 3 for v in graph}
        method = "isolated_vertex"
    elif len(graph) == 2:
        u, v = graph
        if (offsets[u] - offsets[v]) % 3 == 0:
            return {"status": "method_not_applicable", "reason": "K2_equal_offset_residues"}
        target = {v: offsets[v] % 3 for v in graph}
        method = "K2_distinct_offsets"
    elif nx.is_bipartite(graph):
        partition = nx.bipartite.color(graph)
        A = [v for v in graph if partition[v] == 0]
        B = [v for v in graph if partition[v] == 1]
        if len(A) < len(B):
            A, B = B, A
        assert len(A) >= 2
        signed_offset = (sum(offsets[v] for v in A) - sum(offsets[v] for v in B)) % 3
        count = 2 * (signed_offset + len(B)) % 3
        target = {v: 0 for v in A} | {v: 1 for v in B}
        adjustments = A[:count]
        for v in adjustments:
            target[v] = 2
        assert (sum(target[v] - offsets[v] for v in A)
                - sum(target[v] - offsets[v] for v in B)) % 3 == 0
        method = "balanced_bipartite_target"
    else:
        target = two_degenerate_coloring(graph) if coloring is None else dict(coloring)
        if target is None:
            return {"status": "method_not_applicable", "reason": "no_supplied_or_two_degenerate_coloring"}
        if (set(target) != set(graph) or any(value not in (0, 1, 2) for value in target.values())
                or any(target[u] == target[v] for u, v in graph.edges())):
            raise ValueError("The supplied coloring must be a proper 0/1/2 coloring.")
        method = "nonbipartite_three_color_target"
    demand = {v: (target[v] - offsets[v]) % 3 for v in graph}
    result = realize_mod3_sums(graph, demand)
    assert result["status"] == "realized"
    total = {v: result["sums"][v] + offsets[v] for v in graph}
    assert all(total[v] % 3 == target[v] for v in graph)
    assert all(total[u] % 3 != total[v] % 3 for u, v in graph.edges())
    result.update(status="weighted", totals=total, target=target, offsets=offsets,
                  method=method, adjusted_bipartite_vertices=adjustments)
    return result
