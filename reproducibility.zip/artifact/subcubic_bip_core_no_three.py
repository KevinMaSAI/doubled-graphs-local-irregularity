"""Bipartite direct degree-three cores, no ordinary three-edge connection.

All bipartite direct cores are allowed, with unbounded size and fork count.
Ordinary paths have length two or at least four. Compressed return paths,
arbitrary pendant lengths, and parallel ordinary paths are allowed.
The original public API keeps the bipartite-core scope. The additional
color_subcubic_core_no_three API allows arbitrary direct cores, using an
odd-cactus SAFE lemma and the classical degree-list theorem. Both still
exclude ordinary three-edge connections. Neither is the mother conjecture.
Further APIs permit forest, (2,1)-sparse and protected-repair length-three
connections under their stated structural conditions.
The color_subcubic_two_marked API is the newer complete-scope subcubic
construction draft, with independent finite certificates and a separate
universal structural argument; it has not undergone external peer review.
"""

import itertools
from collections import deque

import networkx as nx

from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches
from mod3_edge_weighting import realize_mod3_sums, two_degenerate_coloring
from safe_odd_cactus_core import odd_cactus_cycles, safe_odd_cactus_core
from safe_tree_core import safe_tree_core
from sparse_bipartite_core import SAFE, safe_sparse_bipartite_core
from forest_pseudoforest import partition as partition_three, orient_pseudoforest, overfull_vertex_subset
from strong_marked_safe_core import strong_marked_safe_core
from forest_pseudoforest import spanning_forest_balanced_cotree
from weak_two_marked_tree import weak_two_marked_tree


def bipartite_degree_list_coloring(core, lists):
    """Lists of size >= degree; a slack vertex or a cycle suffices here."""
    assert nx.is_connected(core) and nx.is_bipartite(core)
    assert all(set(lists[v]) <= {0, 1, 2} and len(lists[v]) >= core.degree(v) for v in core)
    slack = next((v for v in core if len(lists[v]) > core.degree(v)), None)
    if slack is not None:
        order, visited = [slack], {slack}
        for v in order:
            for w in core[v]:
                if w not in visited:
                    visited.add(w)
                    order.append(w)
        colors = {}
        for v in reversed(order):
            available = set(lists[v]) - {colors[w] for w in core[v] if w in colors}
            assert available
            colors[v] = min(available)
        return colors, "slack_vertex"
    basis = nx.cycle_basis(core)
    assert basis, "A tree with no slack need not be degree-list colorable."
    cycle = basis[0]
    while True:
        chord = next(((i, j) for i in range(len(cycle)) for j in range(i + 2, len(cycle))
                      if (i, j) != (0, len(cycle) - 1) and core.has_edge(cycle[i], cycle[j])), None)
        if chord is None:
            break
        i, j = chord
        cycle = cycle[i:j + 1]
    assert len(cycle) >= 4 and len(cycle) % 2 == 0
    order, visited = list(cycle), set(cycle)
    for v in order:
        for w in core[v]:
            if w not in visited:
                visited.add(w)
                order.append(w)
    colors = {}
    for v in reversed(order[len(cycle):]):
        available = set(lists[v]) - {colors[w] for w in core[v] if w in colors}
        assert available
        colors[v] = min(available)
    pairs = {}
    for v in cycle:
        available = set(lists[v]) - {colors[w] for w in core[v] if w in colors}
        assert len(available) >= 2
        pairs[v] = set(sorted(available)[:2])
    if all(pairs[v] == pairs[cycle[0]] for v in cycle):
        pair = sorted(pairs[cycle[0]])
        for i, v in enumerate(cycle):
            colors[v] = pair[i % 2]
    else:
        i = next(i for i, v in enumerate(cycle) if pairs[v] != pairs[cycle[i - 1]])
        cycle = cycle[i:] + cycle[:i]
        colors[cycle[0]] = min(pairs[cycle[0]] - pairs[cycle[-1]])
        for previous, v in zip(cycle, cycle[1:]):
            colors[v] = min(pairs[v] - {colors[previous]})
    assert all(colors[v] in lists[v] for v in core)
    assert all(colors[u] != colors[v] for u, v in core.edges())
    return colors, "induced_even_cycle"


def degree_list_coloring(core, lists):
    """Finite list search; existence is supplied by the degree-list theorem.

    No polynomial runtime claim. A slack vertex gives a direct greedy
    construction. Exact iterative search handles the remaining lists.
    """
    slack = next((v for v in core if len(lists[v]) > core.degree(v)), None)
    if slack is not None:
        order, visited, phi = [slack], {slack}, {}
        for v in order:
            for w in core[v]:
                if w not in visited:
                    visited.add(w)
                    order.append(w)
        for v in reversed(order):
            choices = set(lists[v]) - {phi[w] for w in core[v] if w in phi}
            assert choices
            phi[v] = min(choices)
        return phi, "slack_vertex"
    if all(set(lists[v]) == {0, 1, 2} for v in core):
        phi = two_degenerate_coloring(core)
        if phi is not None:
            return phi, "two_degenerate_full_lists"
    phi, stack = {}, []
    def available(v):
        return set(lists[v]) - {phi[w] for w in core[v] if w in phi}
    while len(phi) < len(core):
        v = min((v for v in core if v not in phi), key=lambda v: (len(available(v)), -core.degree(v)))
        stack.append((v, sorted(available(v), reverse=True)))
        while stack:
            v, choices = stack[-1]
            phi.pop(v, None)
            if choices:
                phi[v] = choices.pop()
                if any(w not in phi and not available(w) for w in core[v]):
                    continue
                break
            stack.pop()
        else:
            raise AssertionError("The stated degree-list hypotheses should guarantee a coloring.")
    assert all(phi[v] in lists[v] for v in core)
    assert all(phi[u] != phi[v] for u, v in core.edges())
    return phi, "finite_degree_list_search"


def color_subcubic_bip_core_no_three(graph):
    """The original explicitly bipartite-core public interface."""
    return _color_subcubic_core_no_three(graph, allow_nonbip=False)


def color_subcubic_core_no_three(graph):
    """All subcubic cores; ordinary length three is still excluded."""
    return _color_subcubic_core_no_three(graph, allow_nonbip=True)


def color_subcubic_core_forest_three(graph):
    """Allow length three when its graph between SAFE components is a forest.

    Length-three paths touching a modular component are unrestricted.
    The forest is a MULTIGRAPH; a return to one SAFE component or two
    parallel SAFE--SAFE connections are cycles and outside this API.
    """
    return _color_subcubic_core_no_three(graph, allow_nonbip=True, allow_forest_three=True)


def color_subcubic_core_sparse_three(graph):
    """Allow (2,1)-sparse SAFE-component length-three multigraphs.

    Nonbipartite cores touching ordinary length three are handled modularly.
    On each remaining SAFE core, at most one marked port is mixed, with
    root red one/five. A forest plus pseudoforest decomposition chooses
    those ports globally. This is still a restricted family.
    """
    return _color_subcubic_core_no_three(graph, allow_nonbip=True, allow_sparse_three=True)


def color_subcubic_core_repaired_sparse_three(graph):
    """Promote dense SAFE cores using two protected SAFE short exits."""
    return _color_subcubic_core_no_three(graph, allow_nonbip=True, allow_sparse_three=True,
                                        repair_dense_three=True)


def color_subcubic_two_marked(graph):
    """New complete-scope subcubic construction, subject to the separate proof audit.

    Only short-incident SAFE roots must avoid red two/four. Two marked
    long ports are handled by a complete four-port tree certificate.
    The mother conjecture, which allows arbitrary degrees, is not claimed.
    """
    return _color_subcubic_core_no_three(graph,allow_nonbip=True,allow_sparse_three=True,
                                        full_subcubic=True)


def _color_subcubic_core_no_three(graph, allow_nonbip, allow_forest_three=False,
                                allow_sparse_three=False, repair_dense_three=False,
                                full_subcubic=False):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("A simple loopless undirected graph is required.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The graph must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return {"status": "method_not_applicable", "reason": "degree_above_three",
                "mother_conjecture_proved": False}
    roots = [v for v in graph if degree[v] == 3]
    if not roots:
        return color_independent_branches(graph)
    root_set = set(roots)
    core = graph.subgraph(roots).copy()
    if not allow_nonbip and not nx.is_bipartite(core):
        return {"status": "method_not_applicable", "reason": "nonbipartite_direct_core",
                "mother_conjecture_proved": False}
    edges = list(graph.edges())
    if allow_nonbip and len(graph) == 4 and len(edges) == 6:
        vertices = list(graph)
        table = {(0, 1): 1, (0, 2): 2, (0, 3): 0, (1, 2): 0, (1, 3): 0, (2, 3): 2}
        names = {v: i for i, v in enumerate(vertices)}
        weights = [table[tuple(sorted((names[u], names[v])))] for u, v in edges]
        red = {v: sum(value for edge, value in zip(edges, weights) if v in edge) for v in graph}
        return {"status": "colored", "edge_order": edges, "weights": weights, "red": red,
                "blue": {v: 6 - red[v] for v in graph}, "root_red": red,
                "core_reports": [{"kind": "explicit_K4", "vertices": vertices, "fork_count": 4}],
                "mother_conjecture_proved": False}
    index = {frozenset(edge): i for i, edge in enumerate(edges)}
    used, threads, pendants = set(), [], []
    for root in roots:
        for neighbor in graph[root]:
            key = index[frozenset((root, neighbor))]
            if key in used:
                continue
            used.add(key)
            path, previous, current = [root, neighbor], root, neighbor
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                key = index[frozenset((current, other))]
                assert key not in used
                used.add(key)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": 0})
            else:
                assert current in root_set
                if current != root and len(path) == 4 and not (allow_forest_three or allow_sparse_three):
                    return {"status": "method_not_applicable", "reason": "ordinary_three_edge_thread",
                            "mother_conjecture_proved": False}
                threads.append({"path": path, "ports": [0, 0]})
    assert len(used) == len(edges)
    components = [core.subgraph(vertices).copy() for vertices in nx.connected_components(core)]
    membership = {v: i for i, component in enumerate(components) for v in component}
    free = {v: [] for v in roots}
    loops, short, three, direct = [], [], [], {}
    for i, item in enumerate(threads):
        path = item["path"]
        if len(path) == 2:
            continue
        u, v = path[0], path[-1]
        free[u].append(("thread", i, 0))
        free[v].append(("thread", i, 1))
        if u == v:
            assert len(path) >= 4
            loops.append(i)
        elif len(path) == 3:
            short.append(i)
        elif len(path) == 4:
            three.append(i)
    for i, item in enumerate(pendants):
        free[item["path"][0]].append(("pendant", i, 0))
    assert all(len(free[v]) == 3 - core.degree(v) for v in roots)
    def get_port(slot):
        kind, i, end = slot
        return pendants[i]["port"] if kind == "pendant" else threads[i]["ports"][end]
    def set_port(slot, value):
        kind, i, end = slot
        if kind == "pendant":
            pendants[i]["port"] = value
        else:
            threads[i]["ports"][end] = value
    has_loop = {membership[threads[i]["path"][0]] for i in loops}
    short_degree=dict.fromkeys(roots,0)
    pendant_keys={v:[] for v in roots}
    internal_short={i:[] for i in range(len(components))}
    for key in short:
        u,v=threads[key]["path"][0],threads[key]["path"][-1]
        short_degree[u]+=1;short_degree[v]+=1
        if membership[u]==membership[v]:internal_short[membership[u]].append(key)
    for key,item in enumerate(pendants):pendant_keys[item["path"][0]].append(key)
    intrinsic={}
    if full_subcubic:
        for i,component in enumerate(components):
            if not nx.is_bipartite(component):continue
            colors=nx.bipartite.color(component)
            tokens=[[],[]]
            for v in component:
                tokens[colors[v]].extend(("pendant",key,0) for key in pendant_keys[v])
                if not pendant_keys[v] and not short_degree[v]:
                    tokens[colors[v]].append(("target",v,0))
            for key in internal_short[i]:
                u,v=threads[key]["path"][0],threads[key]["path"][-1]
                tokens[colors[u]].append(("short",key,1))
                tokens[colors[v]].append(("short",key,0))
            intrinsic[i]={"colors":colors,"tokens":tokens}
    three_components={membership[v] for key in three for v in
                      (threads[key]["path"][0],threads[key]["path"][-1])}
    intrinsic_promoted={i for i in three_components if i in intrinsic
                        and max(map(len,intrinsic[i]["tokens"]))>=2}
    promoted_nonbip_three = {membership[v] for key in three for v in
                            (threads[key]["path"][0], threads[key]["path"][-1])
                            if not nx.is_bipartite(components[membership[v]])}
    safe_ids, root_red, reports = set(), {}, []
    for i, component in enumerate(components):
        if (i in has_loop or (allow_sparse_three and i in promoted_nonbip_three)
                or (full_subcubic and i in intrinsic_promoted)):
            continue
        if nx.is_tree(component):
            weighted = safe_tree_core(component)
        elif allow_nonbip and odd_cactus_cycles(component) is not None:
            weighted = safe_odd_cactus_core(component)
        elif nx.is_bipartite(component) and sum(core.degree(v) == 3 for v in component) <= 2:
            weighted = safe_sparse_bipartite_core(component)
        else:
            continue
        assert weighted["status"] == "weighted"
        safe_ids.add(i)
        for edge, value in zip(weighted["edge_order"], weighted["weights"]):
            direct[frozenset(edge)] = value
        root_red.update(weighted["red"])
        for v in component:
            for slot, value in zip(free[v], weighted["boundary_ports"][v]):
                set_port(slot, value)
        report_kind = ("safe_" + weighted["skeleton"] if allow_nonbip else
                       "safe_tree" if nx.is_tree(component) else "safe_sparse_bipartite")
        reports.append({"kind": report_kind,
                        "vertices": list(component), "fork_count": sum(core.degree(v) == 3 for v in component)})
    # Color complementation flips EVERY port at one SAFE component and
    # keeps all its red degrees in SAFE. Solve the forest's XOR equations
    # before imposing any modular short-boundary lists.
    safe_three_edges, complements = [], {i: 0 for i in safe_ids}
    mixed_three, three_partition, density_repairs = set(), None, []
    weak_marked_reports=[]
    if allow_sparse_three:
        protected = set()
        while True:
            keys = [key for key in three if membership[threads[key]["path"][0]] in safe_ids
                    and membership[threads[key]["path"][-1]] in safe_ids]
            component_edges = [(membership[threads[key]["path"][0]], membership[threads[key]["path"][-1]])
                               for key in keys]
            three_partition = (spanning_forest_balanced_cotree(safe_ids,component_edges)
                               if full_subcubic else partition_three(safe_ids, component_edges))
            if three_partition["status"] == "partitioned":
                break
            if not repair_dense_three:
                return {"status": "method_not_applicable", "reason": "SAFE_three_multigraph_not_2_1_sparse",
                        "mother_conjecture_proved": False}
            dense = overfull_vertex_subset(safe_ids, component_edges)
            assert dense
            selected = None
            for c in dense:
                if c in protected or not nx.is_bipartite(components[c]):
                    continue
                exits = []
                for key in short:
                    path = threads[key]["path"]
                    u, v = membership[path[0]], membership[path[-1]]
                    if u == c and v in safe_ids and v != c:
                        exits.append((key, v))
                    if v == c and u in safe_ids and u != c:
                        exits.append((key, u))
                if len(exits) >= 2:
                    selected = c, exits[:2]
                    break
            if selected is None:
                return {"status": "method_not_applicable", "reason": "dense_three_repair_unavailable",
                        "density_repairs": density_repairs, "dense_SAFE_components": dense,
                        "mother_conjecture_proved": False}
            c, exits = selected
            assert any(c in edge for edge in component_edges)
            safe_ids.remove(c)
            complements.pop(c)
            protected.update(other for key, other in exits)
            density_repairs.append({"component": c, "vertices": list(components[c]),
                                    "protected_short_exits": [key for key, other in exits],
                                    "protected_SAFE_neighbors": [other for key, other in exits]})
            reports = [r for r in reports if set(r["vertices"]) != set(components[c])]
        tails = (three_partition["tails"] if full_subcubic else
                 orient_pseudoforest(safe_ids, component_edges, three_partition["pseudoforest"]))
        marked_specs={}
        for j,component_id in tails.items():
            key=keys[j];path=threads[key]["path"]
            end=0 if membership[path[0]]==component_id else 1
            root=path[0 if end==0 else -1]
            marked_specs.setdefault(component_id,[]).append((key,root,("thread",key,end)))
        for component_id,specs in marked_specs.items():
            component = components[component_id]
            if len(specs)==1:
                key,root,slot=specs[0]
                weighted=strong_marked_safe_core(component,root)
                assert weighted["status"]=="weighted" and weighted["red"][root] in (1,5)
            else:
                assert full_subcubic and len(specs)==2
                flags={v:[record[0]=="thread" and record[1] in short for record in free[v]]
                       for v in component}
                assert all(record[0]=="thread" for v in component for record in free[v])
                marks=[(v,free[v].index(record)) for key,v,record in specs]
                weighted=weak_two_marked_tree(component,flags,marks)
                assert all(weighted["red"][v]!=3 for v,j in marks)
                weak_marked_reports.append({"vertices":list(component),"marked_ports":marks,
                                            "kernel_key":weighted["kernel_key"]})
            for edge, value in zip(weighted["edge_order"], weighted["weights"]):
                direct[frozenset(edge)] = value
            root_red.update(weighted["red"])
            for v in component:
                ordered = (([slot]+[s for s in free[v] if s!=slot]) if len(specs)==1 and v==root
                           else free[v])
                assert len(ordered) == len(free[v])
                for record, value in zip(ordered, weighted["boundary_ports"][v]):
                    set_port(record, value)
            mixed_three.update(key for key,v,record in specs)
        if full_subcubic:
            three_partition={"forest_threads":[keys[j] for j in three_partition["forest"]],
                             "cotree_threads":[keys[j] for j in three_partition["cotree"]],
                             "mixed_tails":{keys[j]:c for j,c in tails.items()},
                             "mode":"balanced_cotree"}
        else:
            three_partition = {"forest_threads": [keys[j] for j in three_partition["forest"]],
                               "pseudoforest_threads": [keys[j] for j in three_partition["pseudoforest"]],
                               "mixed_tails": {keys[j]: c for j, c in tails.items()}}
    if allow_forest_three or allow_sparse_three:
        forest = nx.Graph()
        forest.add_nodes_from(safe_ids)
        parent = {i: i for i in safe_ids}
        def representative(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i
        for key in three:
            item = threads[key]
            u, v = item["path"][0], item["path"][-1]
            cu, cv = membership[u], membership[v]
            if cu not in safe_ids or cv not in safe_ids:
                continue
            safe_three_edges.append([cu, cv])
            if key in mixed_three:
                continue
            ru, rv = representative(cu), representative(cv)
            if ru == rv:
                return {"status": "method_not_applicable",
                        "reason": "cycle_in_SAFE_three_connection_multigraph",
                        "mother_conjecture_proved": False}
            parent[ru] = rv
            a, b = item["ports"]
            assert a in (0, 2) and b in (0, 2)
            parity = 1 ^ (a // 2) ^ (b // 2)
            forest.add_edge(cu, cv, parity=parity)
        visited = set()
        for start in forest:
            if start in visited:
                continue
            order = [start]
            visited.add(start)
            for i in order:
                for j in forest[i]:
                    if j in visited:
                        continue
                    visited.add(j)
                    complements[j] = complements[i] ^ forest[i][j]["parity"]
                    order.append(j)
        for i, flip in complements.items():
            if not flip:
                continue
            component = components[i]
            for u, v in component.edges():
                edge = frozenset((u, v))
                direct[edge] = 2 - direct[edge]
            for v in component:
                root_red[v] = 6 - root_red[v]
                for slot in free[v]:
                    set_port(slot, 2 - get_port(slot))
        for key in three:
            item = threads[key]
            u, v = item["path"][0], item["path"][-1]
            su, sv = membership[u] in safe_ids, membership[v] in safe_ids
            if su and not sv:
                item["ports"][1] = 2 - item["ports"][0]
            elif sv and not su:
                item["ports"][0] = 2 - item["ports"][1]
            elif not su and not sv:
                item["ports"] = [0, 2]
            if key in mixed_three:
                assert sorted(item["ports"]) in ([0, 1], [1, 2])
                mixed_end = item["ports"].index(1)
                mixed_root = item["path"][0 if mixed_end == 0 else -1]
                assert root_red[mixed_root]!=3
                if not full_subcubic:assert root_red[mixed_root] in (1,5)
            else:
                assert set(item["ports"]) == {0, 2}
    boundary = {i: [] for i in range(len(components)) if i not in safe_ids}
    for key in short:
        item = threads[key]
        u, v = item["path"][0], item["path"][-1]
        cu, cv = membership[u], membership[v]
        if cu not in safe_ids and cv in safe_ids:
            boundary[cu].append((u, ("thread", key, 0), item["ports"][1]))
        if cv not in safe_ids and cu in safe_ids:
            boundary[cv].append((v, ("thread", key, 1), item["ports"][0]))
    plans, phi_all = {}, {}
    for i, component in enumerate(components):
        if i in safe_ids:
            continue
        restrictions = boundary[i]
        lists = {v: {0, 1, 2} for v in component}
        for v, slot, a in restrictions:
            assert a in (0, 2)
            lists[v].discard((2 + a) % 3)
        assert all(len(lists[v]) >= core.degree(v) for v in component)
        if not nx.is_bipartite(component):
            # A Gallai subcubic component other than K4 is an odd cactus.
            # Without a return path it was absorbed by the SAFE stage.
            # With a return path its low-degree root gives list slack.
            assert (i in has_loop or odd_cactus_cycles(component) is None
                    or (allow_sparse_three and i in promoted_nonbip_three))
            if allow_sparse_three and i in promoted_nonbip_three:
                assert any(len(lists[v]) > core.degree(v) for v in component)
            phi, coloring_mode = degree_list_coloring(component, lists)
            plans[i] = {"kind": "nonbipartite_degree_lists", "phi": phi,
                        "list_coloring_mode": coloring_mode}
            phi_all.update(phi)
            continue
        parts_by_node = nx.bipartite.color(component)
        parts = ([v for v in component if parts_by_node[v] == 0],
                 [v for v in component if parts_by_node[v] == 1])
        local_loop = next((key for key in loops if membership[threads[key]["path"][0]] == i), None)
        if len(restrictions) >= 2:
            phi, coloring_mode = bipartite_degree_list_coloring(component, lists)
            plan = {"kind": "two_safe_boundary_ports", "controls": [slot for v, slot, a in restrictions[:2]],
                    "list_coloring_mode": coloring_mode}
        else:
            if local_loop is not None:
                loop_root = threads[local_loop]["path"][0]
                B = parts[parts_by_node[loop_root]]
                A = parts[1 - parts_by_node[loop_root]]
                plan = {"kind": "one_loop_control", "loop": local_loop}
            elif full_subcubic and i in intrinsic and max(map(len,intrinsic[i]["tokens"]))>=2:
                info=intrinsic[i]
                side=next(s for s in (0,1) if len(info["tokens"][s])>=2)
                A=[v for v in component if info["colors"][v]==side]
                B=[v for v in component if info["colors"][v]!=side]
                plan={"kind":"two_intrinsic_controls","controls":info["tokens"][side][:2],
                      "intrinsic_control_counts":[len(t) for t in info["tokens"]]}
            else:
                side = next(side for side in (0, 1)
                            if sum(core.degree(v) == 3 for v in parts[side]) >= 2)
                A, B = parts[side], parts[1 - side]
                plan = {"kind": "two_full_core_targets",
                        "controls": [v for v in A if core.degree(v) == 3][:2]}
            t = 1
            if restrictions and restrictions[0][0] in B:
                t = 1 if restrictions[0][2] == 0 else 2
            phi = {v: 0 for v in A} | {v: t for v in B}
            plan.update({"zero_part": A, "nonzero": t})
        assert all(phi[u] != phi[v] for u, v in component.edges())
        assert all(phi[v] != (2 + a) % 3 for v, slot, a in restrictions)
        plan["phi"] = phi
        plans[i] = plan
        phi_all.update(phi)
    # All short-incident target residues are now FROZEN.
    for key in short:
        item = threads[key]
        ends = (item["path"][0], item["path"][-1])
        for end, v in enumerate(ends):
            other = ends[1 - end]
            if membership[v] not in safe_ids and membership[other] not in safe_ids:
                item["ports"][end] = 2 * int(phi_all[other] == 2)
    for key in loops:
        threads[key]["ports"] = [0, 2]
    for item in pendants:
        v, length = item["path"][0], len(item["path"]) - 1
        if membership[v] not in safe_ids:
            phi = phi_all[v]
            item["port"] = 2 * int((length == 1 and phi == 1) or (length == 2 and phi == 2))
    frozen_short_targets = {v: phi_all[v] for key in short for v in
                            (threads[key]["path"][0], threads[key]["path"][-1]) if v in phi_all}
    for i, plan in plans.items():
        component = components[i]
        phi = dict(plan["phi"])
        partition = nx.bipartite.color(component) if nx.is_bipartite(component) else None
        def offsets():
            return {v: sum(get_port(slot) for slot in free[v]) for v in component}
        def balanced():
            c = offsets()
            return sum((1 if partition[v] else -1) * (phi[v] - c[v]) for v in component) % 3 == 0
        selected = None
        if plan["kind"] == "nonbipartite_degree_lists":
            selected = "not_required"
        elif plan["kind"] == "two_safe_boundary_ports":
            for bits in itertools.product((0, 2), repeat=2):
                for slot, value in zip(plan["controls"], bits):
                    set_port(slot, value)
                if balanced():
                    selected = list(bits)
                    break
        elif plan["kind"] == "one_loop_control":
            for pair in ([0, 1], [0, 2], [1, 2]):
                threads[plan["loop"]]["ports"] = list(pair)
                if balanced():
                    selected = list(pair)
                    break
        elif plan["kind"]=="two_intrinsic_controls":
            for bits in itertools.product((0,2),repeat=2):
                phi=dict(plan["phi"])
                for (kind,key,end),bit in zip(plan["controls"],bits):
                    if kind=="target":
                        assert not short_degree[key] and not pendant_keys[key]
                        phi[key]=0 if bit==0 else 3-plan["nonzero"]
                    elif kind=="pendant":
                        pendants[key]["port"]=bit
                    else:
                        assert kind=="short"
                        path=threads[key]["path"]
                        opposite=path[-1 if end==0 else 0]
                        assert phi[opposite]==0
                        threads[key]["ports"][end]=bit
                if balanced():
                    selected=list(bits);break
        else:
            assert plan["kind"] == "two_full_core_targets"
            for count in range(3):
                phi = dict(plan["phi"])
                for v in plan["controls"][:count]:
                    assert core.degree(v) == 3 and not free[v]
                    phi[v] = 3 - plan["nonzero"]
                if balanced():
                    selected = count
                    break
        assert selected is not None
        assert partition is None or balanced(), (i, plan)
        assert all(phi[u] != phi[v] for u, v in component.edges())
        assert all(phi[v] == frozen_short_targets[v] for v in component if v in frozen_short_targets)
        c = offsets()
        weighted = realize_mod3_sums(component, {v: (phi[v] - c[v]) % 3 for v in component})
        assert weighted["status"] == "realized"
        for edge, value in zip(weighted["edge_order"], weighted["weights"]):
            direct[frozenset(edge)] = value
        for v in component:
            root_red[v] = c[v] + weighted["sums"][v]
            assert root_red[v] % 3 == phi[v]
        reports.append({"kind": plan["kind"], "vertices": list(component),
                        "fork_count": sum(core.degree(v) == 3 for v in component),
                        "safe_short_boundary_count": len(boundary[i]),
                        "target_mod3": phi, "selected": selected,
                        "list_coloring_mode": plan.get("list_coloring_mode"),
                        "controls":plan.get("controls"),
                        "intrinsic_control_counts":plan.get("intrinsic_control_counts")})
    root_blue = {v: 6 - root_red[v] for v in roots}
    assert all(root_red[u] != root_red[v] for u, v in core.edges())
    assert all(root_red[v] in SAFE for v in roots if membership[v] in safe_ids and short_degree[v])
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1, (path, word)
        for u, v, value in zip(path, path[1:], word):
            key = index[frozenset((u, v))]
            assert weights[key] is None
            weights[key] = value
    for item in threads:
        path = item["path"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            value = direct[frozenset((u, v))]
            item["ports"] = [value, value]
            word = [value]
        else:
            word = _path_word(len(path) - 1, *item["ports"],
                              root_red[u], root_blue[u], root_red[v], root_blue[v])
        put(path, word)
    for item in pendants:
        v = item["path"][0]
        put(item["path"], _pendant_word(len(item["path"]) - 1, item["port"], root_red[v], root_blue[v]))
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        assert value in (0, 1, 2)
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == root_red[v] for v in roots)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "threads": threads, "pendants": pendants,
            "core_reports": reports, "root_red": root_red,
            "frozen_short_targets": frozen_short_targets,
            "safe_three_component_edges": safe_three_edges, "safe_core_complements": complements,
            "three_edge_partition": three_partition, "mixed_three_threads": sorted(mixed_three),
            "promoted_nonbip_three_components": sorted(promoted_nonbip_three) if allow_sparse_three else [],
            "density_repairs": density_repairs,
            "intrinsic_promoted_components":sorted(intrinsic_promoted) if full_subcubic else [],
            "weak_two_marked_components":weak_marked_reports,
            "mother_conjecture_proved": False}
