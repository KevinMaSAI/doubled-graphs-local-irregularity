"""Read-twice signed forms with at least four terms have simultaneous gap two.

Every coefficient is +/-1, every variable occurs in at most two different
rows, and the forms are homogeneous. This is not an arbitrary graph LIR solver.
"""


def _path(u, v, parent, edge, depth):
    left, right, le, re = [u], [v], [], []
    while depth[u] > depth[v]:
        le.append(edge[u]); u = parent[u]; left.append(u)
    while depth[v] > depth[u]:
        re.append(edge[v]); v = parent[v]; right.append(v)
    while u != v:
        le.append(edge[u]); re.append(edge[v])
        u, v = parent[u], parent[v]; left.append(u); right.append(v)
    return left+list(reversed(right[:-1])), le+list(reversed(re))


def signed_gap_two(rows):
    rows = [dict(row) for row in rows]
    occurrences = {}
    for i, row in enumerate(rows):
        if len(row) < 4 or any(type(c) is not int or c not in (-1, 1) for c in row.values()):
            raise ValueError("Each row needs at least four distinct variables with coefficients +/-1.")
        for var, coefficient in row.items():
            occurrences.setdefault(var, []).append((i, coefficient))
    if any(len(items) > 2 for items in occurrences.values()):
        raise ValueError("Each variable may occur in at most two rows.")
    internal, adjacency = {}, [[] for _ in rows]
    for var, items in occurrences.items():
        if len(items) == 2:
            (u, a), (v, b) = items
            assert u != v
            internal[var] = (u, v, a*b)
            adjacency[u].append((v, var)); adjacency[v].append((u, var))
    sigma, flips = [1]*len(rows), 0
    while True:
        vertex = next((v for v in range(len(rows))
                       if sum(1 if internal[e][2] == sigma[v]*sigma[u] else -1
                              for u, e in adjacency[v]) < 0), None)
        if vertex is None:
            break
        sigma[vertex] *= -1; flips += 1
        assert flips <= len(internal)
    bad, bad_adjacency, signs = {}, [[] for _ in rows], {}
    for var, items in occurrences.items():
        if len(items) == 1:
            v, c = items[0]; signs[var] = sigma[v]*c
        else:
            u, v, tau = internal[var]
            if tau == sigma[u]*sigma[v]:
                signs[var] = sigma[u]*rows[u][var]
            else:
                bad[var] = (u, v)
                bad_adjacency[u].append((v, var)); bad_adjacency[v].append((u, var))
    margin = [len(rows[v])-2*len(bad_adjacency[v]) for v in range(len(rows))]
    assert all(a >= 0 for a in margin)
    critical = {v for v, a in enumerate(margin) if a < 2}
    assert all(len(bad_adjacency[v]) >= 2 for v in critical)
    positive, components, seen = {}, [], set()
    for start in range(len(rows)):
        if start in seen:
            continue
        group, seen = [start], seen | {start}
        for v in group:
            for u, e in bad_adjacency[v]:
                if u not in seen:
                    seen.add(u); group.append(u)
        root = next((v for v in group if v not in critical), None)
        if root is not None:
            order, parent = [root], {root: None}
            for v in order:
                for u, e in bad_adjacency[v]:
                    if u not in parent:
                        parent[u] = v; order.append(u); positive[e] = u
            components.append({"kind": "root_tree", "vertices": group, "root": root})
        else:
            order, parent, parent_edge, depth = [start], {start: None}, {}, {start: 0}
            for v in order:
                for u, e in bad_adjacency[v]:
                    if u not in parent:
                        parent[u] = v; parent_edge[u] = e; depth[u] = depth[v]+1; order.append(u)
            tree_edges = set(parent_edge.values())
            group_set = set(group)
            chord = next(e for e, (u, v) in bad.items() if u in group_set and e not in tree_edges)
            u, v = bad[chord]
            cycle_v, cycle_e = _path(u, v, parent, parent_edge, depth)
            cycle_e.append(chord)
            assert len(cycle_v) == len(cycle_e) >= 2
            for i, e in enumerate(cycle_e):
                positive[e] = cycle_v[i]
            order, parent = list(cycle_v), {v: None for v in cycle_v}
            for v in order:
                for u, e in bad_adjacency[v]:
                    if u not in parent:
                        parent[u] = v; order.append(u); positive[e] = u
            components.append({"kind": "cycle_and_trees", "vertices": group,
                               "cycle_rows": cycle_v, "cycle_variables": cycle_e})
        for v in group:
            for u, e in bad_adjacency[v]:
                positive.setdefault(e, v)
    out = [0]*len(rows)
    for e, v in positive.items():
        assert v in bad[e]
        signs[e] = sigma[v]*rows[v][e]; out[v] += 1
    sums = [sum(c*signs[e] for e, c in row.items()) for row in rows]
    assert set(signs) == set(occurrences) and all(x in (-1, 1) for x in signs.values())
    assert all(sigma[v]*sums[v] == margin[v]+2*out[v] >= 2 for v in range(len(rows)))
    return {"signs": signs, "row_sums": sums,
            "certificate": {"row_signs": sigma, "margins": margin, "bad_positive_endpoint": positive,
                            "bad_outdegrees": out, "critical_rows": sorted(critical),
                            "local_sign_flips": flips, "components": components},
            "mother_conjecture_proved": False}
