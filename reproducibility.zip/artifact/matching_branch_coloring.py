"""LIR2 with branch degrees >=4 and a matching of direct branch edges.

All remaining paths, compressed loops and pendant paths may have arbitrary
legal lengths. This does not cover degree-three branches or a general direct
branch core, and is NOT a solver for the full mother conjecture.
"""

import networkx as nx

from independent_branch_coloring import _path_word, _pendant_word, color_independent_branches


def color_matching_branches(graph):
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("The input must be a simple loopless undirected graph.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("K2 is excluded.")
    degree = dict(graph.degree())
    branches = [v for v in graph if degree[v] >= 3]
    if not branches:
        return color_independent_branches(graph)
    if any(degree[v] == 3 for v in branches):
        return {"status": "method_not_applicable", "reason": "degree_three_branch",
                "mother_conjecture_proved": False}
    branch_set = set(branches)
    if any(sum(w in branch_set for w in graph[v]) > 1 for v in branches):
        return {"status": "method_not_applicable", "reason": "direct_branch_edges_not_a_matching",
                "mother_conjecture_proved": False}
    edges = list(graph.edges())
    edge_id = {frozenset(e): i for i, e in enumerate(edges)}
    used, threads, pendants = set(), [], []
    for root in branches:
        for neighbor in graph[root]:
            first_id = edge_id[frozenset((root, neighbor))]
            if first_id in used:
                continue
            path, previous, current = [root, neighbor], root, neighbor
            used.add(first_id)
            while degree[current] == 2:
                other = next(v for v in graph[current] if v != previous)
                index = edge_id[frozenset((current, other))]
                assert index not in used
                used.add(index)
                path.append(other)
                previous, current = current, other
            if degree[current] == 1:
                pendants.append({"path": path, "port": None})
            else:
                assert current in branch_set
                threads.append({"path": path, "ports": None, "orientation": None})
    assert len(used) == len(edges)

    compressed = nx.MultiGraph()
    compressed.add_nodes_from(branches)
    for i, item in enumerate(threads):
        path = item["path"]
        compressed.add_edge(path[0], path[-1], key=("thread", i))
    for i, item in enumerate(pendants):
        placeholder = object()
        compressed.add_edge(item["path"][0], placeholder, key=("pendant", i))
    augmented = compressed.copy()
    dummy = object()
    for i, v in enumerate([v for v in compressed if compressed.degree(v) % 2]):
        augmented.add_edge(v, dummy, key=("auxiliary", i))
    outgoing = dict.fromkeys(branches, 0)
    incoming_direct = dict.fromkeys(branches, 0)
    outgoing_candidates = {v: [] for v in branches}
    for component in nx.connected_components(augmented):
        subgraph = augmented.subgraph(component)
        if not subgraph.number_of_edges():
            continue
        for tail, head, key in nx.eulerian_circuit(subgraph, keys=True):
            if key[0] == "auxiliary":
                continue
            if tail in branch_set:
                outgoing[tail] += 1
            i = key[1]
            if key[0] == "pendant":
                root = pendants[i]["path"][0]
                pendants[i]["port"] = int(tail == root)
                if tail == root:
                    outgoing_candidates[root].append(("pendant", i, 0))
                continue
            item = threads[i]
            path = item["path"]
            u, v = path[0], path[-1]
            item["orientation"] = [tail, head]
            if len(path) == 2:
                item["ports"] = [1, 1]
                incoming_direct[head] += 1
            else:
                item["ports"] = [1, 0] if (tail, head) == (u, v) else [0, 1]
                end = 0 if item["ports"][0] == 1 else 1
                outgoing_candidates[tail].append(("thread", i, end))
    assert all(abs(2 * outgoing[v] - degree[v]) <= 1 for v in branches)
    assert all(incoming_direct[v] in (0, 1) for v in branches)

    def root_totals():
        result = dict.fromkeys(branches, 0)
        for item in threads:
            path, pair = item["path"], item["ports"]
            result[path[0]] += pair[0]
            result[path[-1]] += pair[1]
        for item in pendants:
            result[item["path"][0]] += item["port"]
        return result
    initial_red = root_totals()
    initial_blue = {v: 2 * degree[v] - initial_red[v] for v in branches}
    assert all(initial_red[v] == outgoing[v] + incoming_direct[v] for v in branches)
    repairs = []
    for item in threads:
        if len(item["path"]) != 2:
            continue
        u, v = item["path"]
        red_tie = initial_red[u] == initial_red[v]
        blue_tie = initial_blue[u] == initial_blue[v]
        if not red_tie and not blue_tie:
            repairs.append({"edge": [u, v], "kind": "keep_mixed"})
        elif red_tie and not blue_tie:
            item["ports"] = [0, 0]
            repairs.append({"edge": [u, v], "kind": "blue_only"})
        elif blue_tie and not red_tie:
            item["ports"] = [2, 2]
            repairs.append({"edge": [u, v], "kind": "red_only"})
        else:
            assert degree[u] == degree[v] and degree[u] % 2 and degree[u] >= 5
            tail, head = item["orientation"]
            k = (degree[tail] - 1) // 2
            assert initial_red[tail] == initial_red[head] == k + 1
            assert len(outgoing_candidates[tail]) == k
            candidates = outgoing_candidates[tail]
            kind, index, end = next((candidate for candidate in candidates if candidate[0] == "pendant"), candidates[0])
            if kind == "thread":
                chosen = threads[index]
                assert chosen["ports"][end] == 1
                chosen["ports"][end] = 2
                repairs.append({"edge": [u, v], "kind": "increase_nondirect_port",
                                "vertex": tail, "path": chosen["path"]})
            else:
                chosen = pendants[index]
                assert chosen["port"] == 1
                chosen["port"] = 0
                repairs.append({"edge": [u, v], "kind": "decrease_pendant_port",
                                "vertex": tail, "path": chosen["path"]})
    final_red = root_totals()
    final_blue = {v: 2 * degree[v] - final_red[v] for v in branches}
    assert all(final_red[v] >= 2 and final_blue[v] >= 5 for v in branches)
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value
    for item in threads:
        path, pair = item["path"], item["ports"]
        u, v = path[0], path[-1]
        if len(path) == 2:
            assert pair[0] == pair[1]
            value = pair[0]
            assert (value == 0 or final_red[u] != final_red[v]) and (value == 2 or final_blue[u] != final_blue[v])
            word = [value]
        else:
            assert sorted(pair) in ([0, 1], [0, 2])
            for vertex, port in zip((u, v), pair):
                if port == 2:
                    assert final_red[vertex] >= 4
            word = _path_word(len(path) - 1, *pair, final_red[u], final_blue[u], final_red[v], final_blue[v])
            if word is None:
                raise AssertionError(("thread", path, pair, final_red[u], final_blue[u], final_red[v], final_blue[v]))
        put(path, word)
    for item in pendants:
        path, first = item["path"], item["port"]
        assert first in (0, 1)
        root = path[0]
        word = _pendant_word(len(path) - 1, first, final_red[root], final_blue[root])
        if word is None:
            raise AssertionError(("pendant", path, first, final_red[root], final_blue[root]))
        put(path, word)
    assert all(value in (0, 1, 2) for value in weights)
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == final_red[v] and blue[v] == final_blue[v] for v in branches)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "root_outdegrees": outgoing,
            "initial_root_red": initial_red, "initial_root_blue": initial_blue,
            "direct_edge_repairs": repairs, "threads": threads, "pendants": pendants,
            "mother_conjecture_proved": False}
