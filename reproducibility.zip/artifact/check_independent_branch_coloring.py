"""Independent actual-copy checks for the independent-branch theorem."""

import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from independent_branch_coloring import color_independent_branches


def actual_check(graph, result):
    assert result["status"] == "colored"
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for (u, v), value in zip(result["edge_order"], result["weights"]):
        assert value in (0, 1, 2)
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
    assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    assert dict(red.degree()) == result["red"]
    assert dict(blue.degree()) == result["blue"]


def expand(branches, threads, pendants):
    graph = nx.Graph()
    graph.add_nodes_from(range(branches))
    next_vertex = branches
    for u, v, length in threads:
        assert length >= (3 if u == v else 2)
        internal = list(range(next_vertex, next_vertex + length - 1))
        next_vertex += length - 1
        path = [u] + internal + [v]
        graph.add_edges_from(zip(path, path[1:]))
    for u, length in pendants:
        internal = list(range(next_vertex, next_vertex + length))
        next_vertex += length
        path = [u] + internal
        graph.add_edges_from(zip(path, path[1:]))
    assert all(graph.degree(v) >= 3 for v in range(branches))
    assert nx.is_connected(graph)
    return graph


def main():
    started = time.monotonic()
    rng = random.Random(20261027)
    atlas_cases, excluded = 0, 0
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        eligible = not any(graph.degree(u) >= 3 and graph.degree(v) >= 3 for u, v in graph.edges())
        result = color_independent_branches(graph)
        if eligible:
            actual_check(graph, result)
            atlas_cases += 1
        else:
            assert result["status"] == "method_not_applicable"
            excluded += 1
    tree_cases = 0
    for n in range(3, 13):
        for graph in nx.nonisomorphic_trees(n):
            if any(graph.degree(u) >= 3 and graph.degree(v) >= 3 for u, v in graph.edges()):
                continue
            actual_check(graph, color_independent_branches(graph))
            tree_cases += 1

    fixture_specs = [
        ("two_special_loops_short", 2, [(0, 0, 3), (1, 1, 4), (0, 1, 2)], []),
        ("special_loop_short_to_tree_root", 2, [(0, 0, 3), (0, 1, 2)], [(1, 1), (1, 2)]),
        ("special_loop_two_edge_pendant", 1, [(0, 0, 3)], [(0, 2)]),
        ("two_special_loops_long", 2, [(0, 0, 3), (1, 1, 5), (0, 1, 3)], []),
        ("multiple_loops", 1, [(0, 0, 3), (0, 0, 6), (0, 0, 7)], []),
        ("triangle_long_C3_pendant", 3, [(0, 1, 3), (0, 2, 4), (1, 2, 5)], [(0, 1), (1, 2), (2, 1)]),
        ("triangle_long_short_to_A", 3, [(0, 1, 3), (0, 2, 4), (1, 2, 5), (0, 2, 2)], [(0, 1), (1, 2)]),
        ("triangle_long_short_to_B", 3, [(0, 1, 4), (0, 2, 5), (1, 2, 3), (1, 2, 2)], [(0, 1), (1, 2)]),
        ("C_C_long", 4, [(u, v, 3) for u, v in nx.complete_graph(4).edges()], []),
        ("C_C_short", 4, [(u, v, 2 if (u, v) == (2, 3) else 3) for u, v in nx.complete_graph(4).edges()], []),
        ("C_high_loop", 3, [(0, 1, 3), (0, 2, 3), (1, 2, 3), (2, 2, 3)], [(0, 1), (1, 1)]),
        ("C3_mixed_to_special_A", 4, [(0, 1, 3), (0, 2, 3), (1, 2, 3), (2, 3, 3), (3, 3, 3)], [(0, 1), (1, 1)]),
    ]
    fixture_records = []
    fix_kinds, C_degrees = set(), set()
    loop_cases = 0
    for name, count, threads, pendants in fixture_specs:
        graph = expand(count, threads, pendants)
        result = color_independent_branches(graph)
        actual_check(graph, result)
        fix_kinds.update(fix["kind"] for fix in result["exceptional_fixes"])
        C_degrees.update(graph.degree(v) for v, group in result["groups"].items() if group == "C")
        fixture_records.append({"name": name, "vertices": len(graph), "edges": graph.number_of_edges(),
                                "fixes": result["exceptional_fixes"], "passed": True})
        if name in ("two_special_loops_short", "special_loop_two_edge_pendant"):
            witness = {"name": name, "vertices": len(graph),
                       "edges": [[u, v, x] for (u, v), x in zip(result["edge_order"], result["weights"])],
                       "groups": result["groups"], "red": result["red"], "blue": result["blue"],
                       "fixes": result["exceptional_fixes"]}
            Path(__file__).with_name(name + "_coloring.json").write_text(
                json.dumps(witness, ensure_ascii=False, indent=2), encoding="utf-8")

    random_cases, maximum_degree = 0, 0
    for case in range(600):
        count = rng.randrange(1, 25)
        core = nx.MultiGraph()
        core.add_nodes_from(range(count))
        if count > 1:
            core.add_edges_from((v, rng.randrange(v)) for v in range(1, count))
        for _ in range(rng.randrange(4 * count + 1)):
            core.add_edge(rng.randrange(count), rng.randrange(count))
        pendants = [(v, rng.randrange(1, 11)) for v in core for _ in range(rng.randrange(3))]
        number_pendants = {v: sum(root == v for root, _ in pendants) for v in core}
        for v in core:
            for _ in range(max(0, 3 - core.degree(v) - number_pendants[v])):
                pendants.append((v, rng.randrange(1, 11)))
        threads = [(u, v, rng.randrange(3 if u == v else 2, 12)) for u, v in core.edges()]
        graph = expand(count, threads, pendants)
        result = color_independent_branches(graph)
        actual_check(graph, result)
        fix_kinds.update(fix["kind"] for fix in result["exceptional_fixes"])
        C_degrees.update(graph.degree(v) for v, group in result["groups"].items() if group == "C")
        maximum_degree = max(maximum_degree, max(dict(graph.degree()).values()))
        loop_cases += int(any(u == v for u, v, _ in threads))
        random_cases += 1
    # All choices of lengths two or three on K4; this is an implementation
    # check of every short/long pattern, not an infinite-scope argument.
    patterns = 0
    for lengths in itertools.product((2, 3), repeat=6):
        graph = expand(4, [(u, v, length) for (u, v), length in zip(nx.complete_graph(4).edges(), lengths)], [])
        actual_check(graph, color_independent_branches(graph))
        patterns += 1
    # High degree and long paths without recursion or search.
    count = 36
    dense = expand(count, [(u, v, 2 + (u + v) % 4) for u, v in nx.complete_graph(count).edges()], [])
    actual_check(dense, color_independent_branches(dense))
    maximum_degree = max(maximum_degree, max(dict(dense.degree()).values()))
    long_graph = expand(1, [(0, 0, 5000)], [(0, 1), (0, 5000)])
    actual_check(long_graph, color_independent_branches(long_graph))
    assert fix_kinds == {"loop_short_thread", "loop_two_edge_pendant"}
    assert 3 in C_degrees and any(degree >= 4 for degree in C_degrees)
    result = {"eligible_atlas_graphs": atlas_cases, "inapplicable_atlas_graphs": excluded,
              "eligible_nonisomorphic_trees": tree_cases, "boundary_fixtures": fixture_records,
              "random_compressed_multigraph_cases": random_cases, "random_cases_with_loops": loop_cases,
              "K4_short_long_patterns": patterns, "maximum_tested_degree": maximum_degree,
              "dense_and_long_cases": 2, "covered_fix_kinds": sorted(fix_kinds),
              "C_degrees_observed": sorted(C_degrees), "checks_passed": True,
              "seconds": time.monotonic() - started,
              "scope": "Independent finite copy checks; infinite scope rests on the proof note.",
              "mother_conjecture_proved": False}
    Path(__file__).with_name("independent_branch_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "boundary_fixtures"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
