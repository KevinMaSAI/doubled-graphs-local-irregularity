"""Free pure ports on an arbitrary subcubic TREE direct core.

All actual root degrees are three. The supplied tree has degree at most
three; its missing incidences are free private ports, not prescribed ones.
The three finite interface types close under rooted-tree induction.
"""

import itertools

import networkx as nx

SAFE = (0, 1, 3, 5, 6)
STATES = {(x, r) for x in range(3) for r in SAFE if x <= r <= x + 4}
TYPES = {
    "L": {(x, x + 2 * k) for x in range(3) for k in range(3) if x + 2 * k in SAFE},
    "O": {(x, r) for x, r in STATES if r % 2},
    "A": STATES,
}


def safe_tree_core(core):
    if core.is_directed() or core.is_multigraph() or nx.number_of_selfloops(core):
        raise ValueError("A simple undirected tree is required.")
    if not len(core) or not nx.is_tree(core) or max(dict(core.degree()).values()) > 3:
        return {"status": "method_not_applicable", "reason": "not_subcubic_tree",
                "mother_conjecture_proved": False}
    root = next(v for v in core if core.degree(v) <= 1)
    order, parent = [root], {root: None}
    children = {v: [] for v in core}
    for v in order:
        for w in core[v]:
            if w != parent[v]:
                assert w not in parent
                parent[w] = v
                children[v].append(w)
                order.append(w)
    possible, kind = {}, {}
    for v in reversed(order):
        child = children[v]
        assert len(child) <= 2
        records = {}
        for x in range(3):
            child_domains = [sorted(possible[w]) for w in child]
            for choices in itertools.product(*child_domains):
                for ports in itertools.product((0, 2), repeat=2 - len(child)):
                    red = x + sum(y for y, s in choices) + sum(ports)
                    if red in SAFE and all(s != red for y, s in choices):
                        records.setdefault((x, red), (choices, ports))
        expected = ("L" if not child else "O" if any(kind[w] == "L" for w in child) else "A")
        assert set(records) == TYPES[expected], (v, expected, set(records))
        possible[v], kind[v] = records, expected
    initial = next(state for state in sorted(possible[root]) if state[0] == 0)
    pending, values = [(root, initial)], {}
    boundary, red = {v: [] for v in core}, {}
    boundary[root].append(0)  # The virtual incoming edge is a REAL free port.
    while pending:
        v, state = pending.pop()
        x, red[v] = state
        choices, ports = possible[v][state]
        boundary[v].extend(ports)
        for w, child_state in zip(children[v], choices):
            values[frozenset((v, w))] = child_state[0]
            pending.append((w, child_state))
    edges = list(core.edges())
    weights = [values[frozenset(edge)] for edge in edges]
    assert all(len(boundary[v]) == 3 - core.degree(v) for v in core)
    assert all(red[v] in SAFE and red[v] == sum(boundary[v]) + sum(
        values[frozenset((v, w))] for w in core[v]) for v in core)
    assert all(red[u] != red[v] for u, v in edges)
    return {"status": "weighted", "edge_order": edges, "weights": weights,
            "boundary_ports": boundary, "red": red, "root": root,
            "interface_types": kind, "skeleton": "arbitrary_tree",
            "mother_conjecture_proved": False}
