"""Orient degree-two nonadjacent pairs to have distinct indegrees.

The input graph is simple and loopless, the prescribed pairs are disjoint,
and both vertices in every pair have degree two. A signed four-variable
lemma coordinates the orientations. This is not a full LIR2 solver.
"""

import networkx as nx


def _tree_path(u, v, parent, parent_edge, depth):
    left_v, right_v, left_e, right_e = [u], [v], [], []
    while depth[u] > depth[v]:
        left_e.append(parent_edge[u])
        u = parent[u]
        left_v.append(u)
    while depth[v] > depth[u]:
        right_e.append(parent_edge[v])
        v = parent[v]
        right_v.append(v)
    while u != v:
        left_e.append(parent_edge[u])
        right_e.append(parent_edge[v])
        u, v = parent[u], parent[v]
        left_v.append(u)
        right_v.append(v)
    return left_v + list(reversed(right_v[:-1])), left_e + list(reversed(right_e))


def _cycle_from_edges(graph, selected):
    adjacency = {}
    for u, v, key in graph.edges(keys=True):
        if key in selected:
            adjacency.setdefault(u, []).append((v, key))
            adjacency.setdefault(v, []).append((u, key))
    assert adjacency and all(len(items) == 2 for items in adjacency.values())
    start = next(iter(adjacency))
    vertices, edges, current, previous_edge = [], [], start, None
    while True:
        vertices.append(current)
        other, key = next(item for item in adjacency[current] if item[1] != previous_edge)
        edges.append(key)
        current, previous_edge = other, key
        if current == start:
            break
    assert len(edges) == len(selected) and len(vertices) == len(adjacency)
    return vertices, edges


def _positive_cycle(graph, tau):
    """Amortized linear search: prior negative tree paths are edge-disjoint."""
    root = next(iter(graph))
    order, parent, parent_edge, depth = [root], {root: None}, {}, {root: 0}
    for u in order:
        for v, keyed in graph[u].items():
            if v not in parent:
                key = next(iter(keyed))
                parent[v], parent_edge[v], depth[v] = u, key, depth[u] + 1
                order.append(v)
    assert len(order) == len(graph)
    tree_edges = set(parent_edge.values())
    owner, fundamental = {}, {}
    for u, v, key in graph.edges(keys=True):
        if key in tree_edges:
            continue
        vertices, path_edges = _tree_path(u, v, parent, parent_edge, depth)
        cycle_edges = path_edges + [key]
        product = 1
        for edge in cycle_edges:
            product *= tau[edge]
        if product == 1:
            return vertices, cycle_edges, "positive_fundamental_cycle"
        old = next((owner[edge] for edge in path_edges if edge in owner), None)
        if old is not None:
            selected = set(cycle_edges) ^ fundamental[old]
            vertices, cycle_edges = _cycle_from_edges(graph, selected)
            product = 1
            for edge in cycle_edges:
                product *= tau[edge]
            assert product == 1
            return vertices, cycle_edges, "two_negative_fundamental_cycles"
        fundamental[key] = set(cycle_edges)
        for edge in path_edges:
            owner[edge] = key
    raise AssertionError("A finite loopless four-regular component cannot be a cactus.")


def _solve_cycle_coefficients(a, b, constants):
    """Exact two-state DP for a_i*y_i+b_i*y_(i-1)+C_i != 0."""
    count = len(a)
    assert count == len(b) == len(constants) and count >= 2
    for seed in (1, -1):
        previous, histories = {seed}, []
        for i in range(count):
            current = {}
            for value in ((seed,) if i == count - 1 else (1, -1)):
                candidates = [old for old in previous if a[i] * value + b[i] * old + constants[i] != 0]
                if candidates:
                    current[value] = candidates[0]
            if not current:
                break
            histories.append(current)
            previous = set(current)
        else:
            result, value = [None] * count, seed
            for i in reversed(range(count)):
                result[i] = value
                value = histories[i][value]
            assert value == seed
            return result
    return None


def avoid_zero_four_forms(rows):
    """Four DISTINCT signed variables per row; variable occurrences <=2.

    Returns a sign for each variable such that every row sum is nonzero.
    The proof uses boundary-rooted trees or a positive signed cycle.
    """
    rows = [dict(row) for row in rows]
    occurrences = {}
    for i, row in enumerate(rows):
        if len(row) != 4 or any(value not in (-1, 1) for value in row.values()):
            raise ValueError("Each row must contain four distinct variables with coefficients +/-1.")
        for key, coefficient in row.items():
            if key is None:
                raise ValueError("Variable identifiers must not be None.")
            occurrences.setdefault(key, []).append((i, coefficient))
    if any(len(items) > 2 for items in occurrences.values()):
        raise ValueError("A variable may occur in at most two rows.")
    graph = nx.MultiGraph()
    graph.add_nodes_from(range(len(rows)))
    boundaries, tau = {i: [] for i in graph}, {}
    for key, items in occurrences.items():
        if len(items) == 1:
            boundaries[items[0][0]].append(key)
        else:
            (u, first), (v, second) = items
            assert u != v
            graph.add_edge(u, v, key=key)
            tau[key] = first * second
    values, certificates = dict.fromkeys(occurrences, 1), []
    def choose_one(row, key):
        constant = sum(coefficient * values[edge] for edge, coefficient in rows[row].items() if edge != key)
        assert values[key] is None
        values[key] = next(value for value in (1, -1) if constant + rows[row][key] * value != 0)
    for vertices in nx.connected_components(graph):
        subgraph = graph.subgraph(vertices)
        boundary_root = next((v for v in vertices if boundaries[v]), None)
        if boundary_root is not None:
            root_key = boundaries[boundary_root][0]
            order, parent, parent_edge = [boundary_root], {boundary_root: None}, {}
            for u in order:
                for v, keyed in subgraph[u].items():
                    if v not in parent:
                        parent[v], parent_edge[v] = u, next(iter(keyed))
                        order.append(v)
            selected = set(parent_edge.values()) | {root_key}
            for key in selected:
                values[key] = None
            for v in reversed(order[1:]):
                choose_one(v, parent_edge[v])
            choose_one(boundary_root, root_key)
            certificates.append({"kind": "boundary_tree", "rows": list(vertices), "root": boundary_root})
        else:
            assert all(subgraph.degree(v) == 4 for v in subgraph)
            cycle_v, cycle_e, search_kind = _positive_cycle(subgraph, tau)
            order, parent, parent_edge = list(cycle_v), {v: None for v in cycle_v}, {}
            for u in order:
                for v, keyed in subgraph[u].items():
                    if v not in parent:
                        parent[v], parent_edge[v] = u, next(iter(keyed))
                        order.append(v)
            selected = set(cycle_e) | set(parent_edge.values())
            for key in selected:
                values[key] = None
            for v in reversed(order[len(cycle_v):]):
                choose_one(v, parent_edge[v])
            cycle_set = set(cycle_e)
            constants = [sum(coefficient * values[key] for key, coefficient in rows[v].items()
                             if key not in cycle_set) for v in cycle_v]
            assert all(value in (-2, 0, 2) for value in constants)
            a = [rows[v][cycle_e[i]] for i, v in enumerate(cycle_v)]
            b = [rows[v][cycle_e[i - 1]] for i, v in enumerate(cycle_v)]
            signs = _solve_cycle_coefficients(a, b, constants)
            assert signs is not None
            for key, sign in zip(cycle_e, signs):
                values[key] = sign
            certificates.append({"kind": "positive_cycle", "rows": list(vertices),
                                 "cycle_rows": cycle_v, "cycle_variables": cycle_e,
                                 "cycle_constants": constants, "search_kind": search_kind})
    sums = [sum(coefficient * values[key] for key, coefficient in row.items()) for row in rows]
    assert all(value in (-1, 1) for value in values.values()) and all(value != 0 for value in sums)
    return {"signs": values, "row_sums": sums, "components": certificates}


def orient_distinct_degree_two_pairs(graph, pairs):
    """Pairs are disjoint degree-two vertices NONADJACENT in graph."""
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("The orientation graph must be simple, loopless and undirected.")
    pairs = [tuple(pair) for pair in pairs]
    membership = {}
    for i, pair in enumerate(pairs):
        if (len(pair) != 2 or pair[0] == pair[1]
                or any(v not in graph or graph.degree(v) != 2 or v in membership for v in pair)
                or graph.has_edge(*pair)):
            raise ValueError("Pairs must be disjoint nonadjacent degree-two vertices.")
        membership[pair[0]], membership[pair[1]] = (i, 1), (i, -1)
    edges = list(graph.edges())
    rows = [{} for pair in pairs]
    for key, (u, v) in enumerate(edges):
        for vertex, delta in ((u, -1), (v, 1)):
            if vertex in membership:
                row, epsilon = membership[vertex]
                rows[row][key] = epsilon * delta
    result = avoid_zero_four_forms(rows)
    signs = {key: result["signs"].get(key, 1) for key in range(len(edges))}
    directions = [(u, v) if signs[key] == 1 else (v, u) for key, (u, v) in enumerate(edges)]
    indegree = dict.fromkeys(graph, 0)
    for tail, head in directions:
        indegree[head] += 1
    assert all(indegree[u] != indegree[v] for u, v in pairs)
    assert all(value == 2 * (indegree[u] - indegree[v])
               for (u, v), value in zip(pairs, result["row_sums"]))
    return {"edge_order": edges, "directions": directions, "indegree": indegree,
            "paired_vertices": pairs, "signed_rows": rows, **result, "signs": signs}
