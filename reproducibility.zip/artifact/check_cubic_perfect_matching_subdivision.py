"""Actual-copy validation of cubic perfect-matching subdivisions."""

import json
import time
from pathlib import Path

import networkx as nx

from cubic_perfect_matching_subdivision import color_cubic_perfect_matching_subdivision
from check_matching_long_branch_coloring import verify


def all_perfect_matchings(graph):
    def search(remaining, pairs):
        if not remaining:
            yield pairs
            return
        u = min(remaining)
        for v in graph[u]:
            if v in remaining:
                yield from search(remaining - {u, v}, pairs + [(u, v)])
    yield from search(set(graph), [])


def main():
    started = time.monotonic()
    bridged = nx.disjoint_union(nx.complete_graph(4), nx.complete_graph(4))
    bridged.remove_edges_from(((0, 1), (4, 5)))
    bridged.add_edges_from(((0, 8), (8, 1), (4, 9), (9, 5), (8, 9)))
    fixtures = [
        ("K4", nx.complete_graph(4)),
        ("K33", nx.complete_bipartite_graph(3, 3)),
        ("triangular_prism", nx.circular_ladder_graph(3)),
        ("Petersen", nx.petersen_graph()),
        ("Heawood", nx.heawood_graph()),
        ("dodecahedral", nx.dodecahedral_graph()),
        ("Desargues", nx.desargues_graph()),
        ("Moebius_Kantor", nx.moebius_kantor_graph()),
        ("cubic_graph_with_bridge", bridged),
    ]
    counts, checked, longest = [], 0, 0
    example = None
    for name, base in fixtures:
        matchings = list(all_perfect_matchings(base))
        assert matchings
        for index, matching in enumerate(matchings):
            for variant in range(4):
                lengths = {frozenset(edge): 4 if variant == 0 else 4 + (j + variant) % (variant + 2)
                           for j, edge in enumerate(matching)}
                result = color_cubic_perfect_matching_subdivision(base, matching, lengths)
                verify(result["graph"], result)
                values = {frozenset(edge): value for edge, value in zip(result["edge_order"], result["weights"])}
                assert all(values[frozenset(path[:2])] == values[frozenset(path[-2:])] == 0
                           for path in result["replacement_paths"])
                longest = max(longest, max(lengths.values()))
                checked += 1
                if example is None:
                    example = {"base": name, "matching": matching,
                               "edges": [[u, v, value] for (u, v), value in zip(result["edge_order"], result["weights"])],
                               "red": result["red"], "blue": result["blue"],
                               "replacement_paths": result["replacement_paths"]}
        counts.append({"base": name, "vertices": len(base), "perfect_matchings": len(matchings)})
    matching = next(all_perfect_matchings(nx.complete_graph(4)))
    result = color_cubic_perfect_matching_subdivision(nx.complete_graph(4), matching, 5000)
    verify(result["graph"], result)
    checked += 1
    longest = 5000
    summary = {"bases": counts, "actual_copy_checked_colorings": checked,
               "maximum_tested_path_length": longest, "checks_passed": True,
               "seconds": time.monotonic() - started, "mother_conjecture_proved": False,
               "scope": "All perfect matchings of these finite bases, not a substitute for the general proof."}
    Path(__file__).with_name("cubic_perfect_matching_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(__file__).with_name("cubic_perfect_matching_K4_example.json").write_text(
        json.dumps(example, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
