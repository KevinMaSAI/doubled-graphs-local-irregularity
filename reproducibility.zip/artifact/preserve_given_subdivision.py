"""Preserve a GIVEN legal doubled-edge coloring under simultaneous subdivision.

For a mixed selected edge, an endpoint is exceptional exactly when R=B=1
or R=B=3. Required length is 4 plus the number of exceptional endpoints.
This conditional extension does not find the initial coloring for general G.
"""

import networkx as nx

from independent_branch_coloring import _path_word


def extend_given_doubled_coloring(base, weight_by_edge, lengths):
    if base.is_directed() or base.is_multigraph() or nx.number_of_selfloops(base):
        raise ValueError("The base must be simple, undirected and loopless.")
    if not len(base) or not nx.is_connected(base):
        raise ValueError("The base must be nonempty and connected.")
    base_edges = list(base.edges())
    identifiers = {frozenset(edge) for edge in base_edges}
    if set(weight_by_edge) != identifiers or any(x not in (0, 1, 2) for x in weight_by_edge.values()):
        raise ValueError("Supply one original-edge red weight 0/1/2 for every base edge.")
    if not set(lengths) <= identifiers or any(not isinstance(n, int) or n < 4 for n in lengths.values()):
        raise ValueError("Selected base edges need integer path lengths at least four.")
    red = dict.fromkeys(base, 0)
    for u, v in base_edges:
        value = weight_by_edge[frozenset((u, v))]
        red[u] += value
        red[v] += value
    blue = {v: 2 * base.degree(v) - red[v] for v in base}
    if not all((weight_by_edge[frozenset((u, v))] == 0 or red[u] != red[v])
               and (weight_by_edge[frozenset((u, v))] == 2 or blue[u] != blue[v])
               for u, v in base_edges):
        raise ValueError("The supplied base coloring is not locally irregular.")
    graph = nx.Graph()
    graph.add_nodes_from(base)
    next_vertex, expanded_weights, paths = 0, {}, []
    for u, v in base_edges:
        key = frozenset((u, v))
        value = weight_by_edge[key]
        if key not in lengths:
            path, word = [u, v], [value]
        else:
            length = lengths[key]
            exceptional = sum(red[w] == blue[w] and red[w] in (1, 3) for w in (u, v)) if value == 1 else 0
            required = 4 + exceptional
            if length < required:
                return {"status": "method_not_applicable", "reason": "fixed_interface_not_extendible",
                        "edge": [u, v], "initial_weight": value,
                        "endpoint_counts": [[red[u], blue[u]], [red[v], blue[v]]],
                        "specified_length": length, "minimum_length_at_least_four": required,
                        "mother_conjecture_proved": False}
            middle = []
            for _ in range(length - 1):
                while next_vertex in graph:
                    next_vertex += 1
                middle.append(next_vertex)
                graph.add_node(next_vertex)
                next_vertex += 1
            path = [u] + middle + [v]
            word = _path_word(length, value, value, red[u], blue[u], red[v], blue[v])
            assert word is not None
            paths.append({"path": path, "initial_weight": value, "required_length": required})
        for a, b, x in zip(path, path[1:], word):
            assert not graph.has_edge(a, b)
            graph.add_edge(a, b)
            expanded_weights[frozenset((a, b))] = x
    edge_order = list(graph.edges())
    weights = [expanded_weights[frozenset(edge)] for edge in edge_order]
    actual_red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edge_order, weights):
        actual_red[u] += value
        actual_red[v] += value
    actual_blue = {v: 2 * graph.degree(v) - actual_red[v] for v in graph}
    assert all(actual_red[v] == red[v] and actual_blue[v] == blue[v] for v in base)
    assert all((value == 0 or actual_red[u] != actual_red[v])
               and (value == 2 or actual_blue[u] != actual_blue[v])
               for (u, v), value in zip(edge_order, weights))
    return {"status": "colored", "graph": graph, "edge_order": edge_order, "weights": weights,
            "red": actual_red, "blue": actual_blue, "initial_red": red, "initial_blue": blue,
            "subdivision_paths": paths, "mother_conjecture_proved": False}
