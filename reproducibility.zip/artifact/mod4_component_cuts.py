"""Exact fixed-mixed-set mod4 criterion using components and cut certificates.

The cut certificate concerns the prescribed mixed set and the extra mod4
condition. It is not a counterexample to ordinary locally irregular coloring.
"""

from mod4_fixed_mixed import solve_binary


def _components(vertices, adjacency):
    index, groups, parents, orders = {}, [], {}, []
    for root in vertices:
        if root in index:
            continue
        j = len(groups); group = [root]; index[root] = j; parents[root] = None
        for v in group:
            for u in adjacency[v]:
                if u not in index:
                    index[u] = j; parents[u] = v; group.append(u)
        groups.append(group); orders.append(group)
    return index, groups, parents, orders


def color_with_mixed_components(vertices, edges, mixed_edges, red_offsets=None, blue_offsets=None):
    vertices, edges, mixed_edges = list(vertices), [tuple(e) for e in edges], [tuple(e) for e in mixed_edges]
    V = set(vertices)
    if not vertices or len(V) != len(vertices):
        raise ValueError("A nonempty list of distinct vertices is required.")
    keys = [frozenset(e) for e in edges]
    if any(len(e) != 2 or len(k) != 2 or not k <= V for e, k in zip(edges, keys)) or len(set(keys)) != len(keys):
        raise ValueError("A simple undirected edge inventory is required.")
    M = {frozenset(e) for e in mixed_edges}
    if len(M) != len(mixed_edges) or not M <= set(keys):
        raise ValueError("Supply a set of existing mixed edges.")
    A = dict.fromkeys(vertices, 0) if red_offsets is None else dict(red_offsets)
    B0 = dict.fromkeys(vertices, 0) if blue_offsets is None else dict(blue_offsets)
    if set(A) != V or set(B0) != V or any(type(A[v]) is not int or type(B0[v]) is not int
            or min(A[v], B0[v]) < 0 or (A[v]+B0[v]) % 2 for v in vertices):
        raise ValueError("Physical nonnegative offsets with even total are required.")
    degree, md = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    for (u, v), key in zip(edges, keys):
        degree[u] += 1; degree[v] += 1
        if key in M:
            md[u] += 1; md[v] += 1
    D = {v: degree[v]+(A[v]+B0[v])//2 for v in vertices}
    p = {v: (A[v]+md[v]) % 2 for v in vertices}
    h = {v: ((A[v]+md[v])//2) % 2 for v in vertices}
    common = {"vertices": vertices, "original_edges": [list(e) for e in edges],
              "mixed_edges": [list(e) for e, k in zip(edges, keys) if k in M],
              "red_offsets": A, "blue_offsets": B0, "total_degree": D, "parity": p,
              "half_offset": h, "external_boundary_edges_checked": False,
              "mother_conjecture_proved": False}

    def reject(obstruction, **extra):
        return {"status": "mod4_infeasible_for_fixed_mixed", "obstruction": obstruction, **common, **extra}

    H, K = {v: [] for v in vertices}, {v: [] for v in vertices}
    forced = []
    for i, ((u, v), key) in enumerate(zip(edges, keys)):
        if p[u] == p[v] and (D[u]-D[v]) % 2:
            if key in M:
                return reject({"type": "forbidden_mixed_edge", "edge_index": i})
            forced.append(i)
        else:
            if key not in M:
                K[u].append(v); K[v].append(u)
            if p[u] == p[v]:
                H[u].append(v); H[v].append(u)
    # H contains exactly the edges requiring opposite half-residue bits.
    c, hi, hg, hp = {}, {}, [], {}
    for root in vertices:
        if root in c:
            continue
        j = len(hg); group = [root]; c[root] = 0; hi[root] = j; hp[root] = None
        for v in group:
            for u in H[v]:
                if u not in c:
                    c[u] = 1-c[v]; hi[u] = j; hp[u] = v; group.append(u)
                elif c[u] == c[v]:
                    chain, cur = [], u
                    while cur is not None:
                        chain.append(cur); cur = hp[cur]
                    lookup = {w: z for z, w in enumerate(chain)}
                    other, cur = [], v
                    while cur not in lookup:
                        other.append(cur); cur = hp[cur]
                    cycle = chain[:lookup[cur]+1]+list(reversed(other))+[u]
                    assert (len(cycle)-1) % 2 == 1
                    return reject({"type": "odd_cycle_in_H", "cycle_vertices": cycle})
        hg.append(group)
    ki, kg, kp, orders = _components(vertices, K)
    masks, rhs = [0]*len(kg), [0]*len(kg)
    for v in vertices:
        j = ki[v]; masks[j] ^= 1 << hi[v]; rhs[j] ^= h[v] ^ c[v]
    for i in forced:
        u, v = edges[i]
        if ki[u] != ki[v]:
            for j in (ki[u], ki[v]):
                masks[j] ^= (1 << hi[u]) ^ (1 << hi[v]); rhs[j] ^= c[u] ^ c[v]
    rows = list(zip(masks, rhs))
    answer = solve_binary(rows, len(hg))
    phase = {"H_components": hg, "H_colors": c, "K_components": kg,
             "forced_even_edge_indices": forced,
             "rows": [{"variables": [i for i in range(len(hg)) if mask >> i & 1], "rhs": b}
                      for mask, b in rows], **answer}
    if not answer["consistent"]:
        U = {v for j in answer["xor_rows"] for v in kg[j]}
        lam = set(U)
        boundary_forced = []
        for i in forced:
            u, v = edges[i]
            if (u in U) != (v in U):
                lam.symmetric_difference_update((u, v)); boundary_forced.append(i)
        assert all(len(lam & set(group)) % 2 == 0 for group in hg)
        assert (sum(h[v] for v in U)+sum(c[v] for v in lam)) % 2 == 1
        boundary = [i for i, (u, v) in enumerate(edges) if (u in U) != (v in U)]
        assert all(keys[i] in M or i in forced for i in boundary)
        return reject({"type": "phase_cut", "U": [v for v in vertices if v in U],
                       "lambda_vertices": [v for v in vertices if v in lam],
                       "boundary_edge_indices": boundary,
                       "boundary_forced_edge_indices": boundary_forced}, phase_certificate=phase)
    t = {v: c[v] ^ answer["solution"][hi[v]] for v in vertices}
    z, residual = {}, {v: h[v] ^ t[v] for v in vertices}
    for i in forced:
        u, v = edges[i]; z[i] = t[u] ^ t[v]
        residual[u] ^= z[i]; residual[v] ^= z[i]
    selected = set()
    index = {key: i for i, key in enumerate(keys)}
    for order in orders:
        for v in reversed(order[1:]):
            if residual[v]:
                i = index[frozenset((v, kp[v]))]
                selected.add(i); residual[kp[v]] ^= 1
        assert residual[order[0]] == 0
    values = [1 if key in M else 2*z[i] if i in z else 2*int(i in selected)
              for i, key in enumerate(keys)]
    R, B = dict(A), dict(B0)
    for (u, v), x in zip(edges, values):
        for copy in range(2):
            target = R if copy < x else B
            target[u] += 1; target[v] += 1
    assert all(R[v] % 4 == p[v]+2*t[v] for v in vertices)
    assert all((x == 0 or (R[u]-R[v]) % 4) and (x == 2 or (B[u]-B[v]) % 4)
               for (u, v), x in zip(edges, values))
    return {"status": "mod4_colored", "edges": [[u, v, x] for (u, v), x in zip(edges, values)],
            "red": R, "blue": B, "phase_certificate": phase, **common}
