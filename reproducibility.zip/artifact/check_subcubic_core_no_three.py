"""Independent checks of the full-core/no-ordinary-three restricted theorem."""

import copy
import itertools
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from check_subcubic_no_two_threads import expand
from check_subcubic_sparse_bip_core import join_cores, verify_core
from safe_cactus_certificate import verify_certificate
from safe_odd_cactus_core import odd_cactus_cycles, safe_odd_cactus_core
from subcubic_bip_core_no_three import color_subcubic_core_no_three, degree_list_coloring


def independent_domain(graph):
    degree = dict(graph.degree())
    if max(degree.values()) > 3:
        return False
    roots = {v for v in graph if degree[v] == 3}
    for vertices in nx.connected_components(graph.subgraph(set(graph) - roots)):
        attachments = [v for w in vertices for v in graph[w] if v in roots]
        if len(vertices) == 2 and len(attachments) == 2 and attachments[0] != attachments[1]:
            return False
    return True


def random_odd_cactus(rng, blocks):
    graph = nx.empty_graph(1)
    for _ in range(blocks):
        candidates = [v for v in graph if graph.degree(v) < 3]
        root = rng.choice(candidates)
        n = len(graph)
        graph.add_edge(root, n)
        if rng.randrange(3):
            size = rng.choice((3, 5, 7, 9, 11, 31))
            graph.add_edges_from((n + i, n + (i + 1) % size) for i in range(size))
    return graph


def is_gallai(graph):
    return all(len(vertices) == 2 or graph.subgraph(vertices).number_of_edges()
               == len(vertices) * (len(vertices) - 1) // 2 or
               (len(vertices) % 2 and all(graph.subgraph(vertices).degree(v) == 2 for v in vertices))
               for vertices in nx.biconnected_components(graph))


def main():
    start = time.monotonic()
    rng = random.Random(20261111)
    base = Path(__file__).parent
    certificate = json.loads((base / "safe_cactus_interfaces.json").read_text(encoding="utf-8"))
    certificate_check = verify_certificate(certificate)
    mutations = []
    value = copy.deepcopy(certificate)
    value["local_records"].pop()
    mutations.append(value)
    value = copy.deepcopy(certificate)
    value["letter_matrices"]["F"][0] ^= 1
    mutations.append(value)
    value = copy.deepcopy(certificate)
    value["even_product_layers"]["six"].pop()
    mutations.append(value)
    value = copy.deepcopy(certificate)
    value["types"]["C"].append([1, 1])
    mutations.append(value)
    for value in mutations:
        try:
            verify_certificate(value)
        except AssertionError:
            pass
        else:
            raise AssertionError("A damaged complete certificate was accepted.")
    auxiliary_count, interface_types, cycle_lengths = 0, set(), set()
    def check_auxiliary(graph):
        nonlocal auxiliary_count
        result = safe_odd_cactus_core(graph)
        verify_core(graph, result)
        auxiliary_count += 1
        interface_types.update(result["interface_types"].values())
        cycle_lengths.update(result["cycle_lengths"])
    for graph in nx.graph_atlas_g():
        if len(graph) and nx.is_connected(graph) and odd_cactus_cycles(graph) is not None:
            check_auxiliary(graph)
    cactus_pool = [random_odd_cactus(rng, rng.randrange(2, 24)) for _ in range(300)]
    for graph in cactus_pool:
        check_auxiliary(graph)
    long_cycle = nx.cycle_graph(5001)
    check_auxiliary(long_cycle)
    list_count, list_modes = 0, set()
    for graph in nx.graph_atlas_g():
        if (not len(graph) or not nx.is_connected(graph) or max(dict(graph.degree()).values()) > 3
                or is_gallai(graph)):
            continue
        vertices = list(graph)
        domains = [list(itertools.combinations(range(3), graph.degree(v))) for v in vertices]
        for lists in itertools.product(*domains):
            assigned = {v: set(choices) for v, choices in zip(vertices, lists)}
            phi, mode = degree_list_coloring(graph, assigned)
            assert all(phi[v] in assigned[v] for v in graph)
            assert all(phi[u] != phi[v] for u, v in graph.edges())
            list_count += 1
            list_modes.add(mode)
    actual_count, eligible, outside, nonbip_core_graphs = 0, 0, 0, 0
    modes, list_constructor_modes, witness = {}, set(), {}
    safe_nonbip_mix, max_forks, short_count, max_return = 0, 0, 0, 0
    def check(name, graph):
        nonlocal actual_count, nonbip_core_graphs, safe_nonbip_mix, max_forks, short_count, max_return
        assert independent_domain(graph), name
        result = color_subcubic_core_no_three(graph)
        verify(graph, result)
        actual_count += 1
        core = graph.subgraph({v for v in graph if graph.degree(v) == 3})
        nonbip_core_graphs += not nx.is_bipartite(core)
        local_kinds = {report["kind"] for report in result.get("core_reports", [])}
        safe_nonbip_mix += ("safe_odd_cactus" in local_kinds and "nonbipartite_degree_lists" in local_kinds)
        for report in result.get("core_reports", []):
            kind = report["kind"]
            modes[kind] = modes.get(kind, 0) + 1
            max_forks = max(max_forks, report["fork_count"])
            if report.get("list_coloring_mode"):
                list_constructor_modes.add(report["list_coloring_mode"])
            key = kind + ":" + str(report.get("selected"))
            if key not in witness:
                witness[key] = {"name": name, "component": report,
                    "edges": [[u, v, w] for (u, v), w in zip(result["edge_order"], result["weights"])],
                    "red": result["red"], "blue": result["blue"]}
        for item in result.get("threads", []):
            short_count += len(item["path"]) == 3
            if item["path"][0] == item["path"][-1]:
                max_return = max(max_return, len(item["path"]) - 1)
        return result
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        expected = independent_domain(graph)
        result = color_subcubic_core_no_three(graph)
        assert (result["status"] == "colored") == expected
        if expected:
            check("atlas", graph)
            eligible += 1
        else:
            outside += 1
    check("K1", nx.empty_graph(1))
    # Every connected small direct core, completed by real pendant edges.
    small_cores = []
    for core in nx.graph_atlas_g():
        if not len(core) or not nx.is_connected(core) or max(dict(core.degree()).values()) > 3:
            continue
        small_cores.append(core)
        pendants = [(v, 1) for v in core for _ in range(3 - core.degree(v))]
        check("all_small_cores_with_leaves", expand(len(core), [(u, v, 1) for u, v in core.edges()], pendants))
    pool = small_cores + cactus_pool[:100]
    for i in range(2000):
        graph = join_cores([rng.choice(pool) for _ in range(rng.randrange(2, 9))],
                           rng, all_short=(i % 2 == 0))
        if graph is not None:
            check("mixed_core_network", graph)
    for n in range(4, 82, 2):
        for trial in range(3):
            graph = nx.random_regular_graph(3, n, seed=rng.randrange(1 << 30))
            if nx.is_connected(graph):
                check("cubic_direct_core", graph)
    # A nonbipartite Gallai direct core WITH an original return path is
    # deliberately left in the modular stage; its loop root supplies slack.
    for n in (3, 5, 7, 9):
        for length in range(3, 10):
            for boundary in range(4):
                count = n + 1
                threads = [(i, (i + 1) % n, 1) for i in range(n)]
                threads.extend(((0, n, 1), (n, n, length)))
                pendants = []
                for v in range(1, n):
                    if v < boundary + 1:
                        threads.append((v, count, 2))
                        pendants.extend(((count, 1), (count, 2)))
                        count += 1
                    else:
                        pendants.append((v, 1 + v % 4))
                check("odd_Gallai_core_with_original_loop", expand(count, threads, pendants))
    # Force mixed SAFE odd-cactus / non-Gallai components and arbitrarily
    # many odd cycle blocks, rather than relying on random occurrence.
    diamond = nx.complete_graph(4)
    diamond.remove_edge(0, 1)
    graph = join_cores([nx.cycle_graph(3), diamond, nx.cycle_graph(5), diamond], rng, all_short=True)
    assert graph is not None
    check("SAFE_odd_cycles_and_non_Gallai_cores", graph)
    tree = random_odd_cactus(rng, 80)
    graph = join_cores([tree, tree], rng, all_short=True)
    assert graph is not None
    check("many_odd_blocks_all_short", graph)
    result = {
        "finite_certificate": certificate_check, "damaged_certificates_rejected": len(mutations),
        "auxiliary_odd_cactus_cores_verified": auxiliary_count,
        "all_six_rooted_types_observed": sorted(interface_types),
        "odd_cycle_lengths_observed": sorted(cycle_lengths),
        "all_small_non_Gallai_degree_lists_checked": list_count, "list_search_modes": sorted(list_modes),
        "actual_graph_colorings_verified": actual_count, "atlas_eligible": eligible,
        "atlas_outside_scope": outside, "graphs_with_nonbipartite_direct_core": nonbip_core_graphs,
        "component_modes": modes, "modular_list_modes": sorted(list_constructor_modes),
        "graphs_with_both_SAFE_odd_cactus_and_nonbip_MOD": safe_nonbip_mix,
        "largest_direct_core_fork_count": max_forks, "short_threads_verified": short_count,
        "largest_original_return_length": max_return, "all_checks_passed": True,
        "mother_conjecture_proved": False, "general_subcubic_conjecture_proved": False,
        "seconds": round(time.monotonic() - start, 3),
        "scope": "Arbitrary direct core, no ordinary length-three connection; original loops and pendants allowed. Infinite range requires the accompanying structural proof."}
    (base / "subcubic_core_no_three_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (base / "subcubic_core_no_three_witnesses.json").write_text(
        json.dumps(witness, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
