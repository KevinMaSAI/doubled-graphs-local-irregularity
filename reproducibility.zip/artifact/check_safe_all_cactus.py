"""Independent complete certificate, marked interface and actual-copy checks."""

import copy
import json
import random
import time
from pathlib import Path

import networkx as nx

from check_matching_long_branch_coloring import verify
from safe_all_cactus_certificate import verify_all_cactus_certificate
from safe_odd_cactus_core import safe_cactus_core, safe_odd_cactus_core


def independent_cactus(graph):
    if (not len(graph) or not nx.is_connected(graph) or max(dict(graph.degree()).values()) > 3):
        return False
    basis = nx.cycle_basis(graph)
    return sum(map(len, basis)) == len({v for cycle in basis for v in cycle})


def verify_auxiliary(core, result, marked=None, incoming=0, nonbalanced=False):
    assert result["status"] == "weighted"
    graph = core.copy()
    edges, values = list(result["edge_order"]), list(result["weights"])
    red = dict.fromkeys(core, 0)
    for edge, value in zip(edges, values):
        assert value in (0, 1, 2)
        for v in edge:
            red[v] += value
    assert {frozenset(e) for e in edges} == {frozenset(e) for e in core.edges()}
    for v in core:
        ports = result["boundary_ports"][v]
        assert len(ports) == 3 - core.degree(v)
        for i, value in enumerate(ports):
            if marked == v and i == 0:
                assert value == incoming
            else:
                assert value in (0, 2)
            red[v] += value
            leaf = object()
            graph.add_edge(v, leaf)
            edges.append((v, leaf))
            values.append(value)
            if value == 1:
                # A mixed marked port with root red one cannot end in
                # a leaf. The real pendant word (1,1) works for all odd R.
                end = object()
                graph.add_edge(leaf, end)
                edges.append((leaf, end))
                values.append(1)
        assert red[v] in (0, 1, 3, 5, 6) and red[v] == result["red"][v]
    if marked is not None and nonbalanced:
        assert red[marked] != 3
    assert all(red[u] != red[v] for u, v in core.edges())
    actual_red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, values):
        actual_red[u] += value
        actual_red[v] += value
    assert all(actual_red[v] == red[v] for v in core)
    verify(graph, {"status": "colored", "edge_order": edges, "weights": values,
                   "red": actual_red, "blue": {v: 2 * graph.degree(v) - actual_red[v] for v in graph}})


def main():
    start = time.monotonic()
    base = Path(__file__).parent
    data = json.loads((base / "safe_all_cactus_interfaces.json").read_text(encoding="utf-8"))
    certificate = verify_all_cactus_certificate(data)
    bad = copy.deepcopy(data)
    bad["odd_product_layers"]["seven"].pop()
    try:
        verify_all_cactus_certificate(bad)
    except AssertionError:
        pass
    else:
        raise AssertionError("A missing layer matrix was accepted.")
    rng = random.Random(20261113)
    pool = [g for g in nx.graph_atlas_g() if independent_cactus(g)]
    for k in range(120):
        graph = nx.empty_graph(1)
        for _ in range(rng.randrange(2, 14)):
            root = rng.choice([v for v in graph if graph.degree(v) < 3])
            n = len(graph)
            graph.add_edge(root, n)
            if rng.randrange(3):
                size = rng.choice((3, 4, 5, 6, 7, 8, 10, 31, 32))
                graph.add_edges_from((n + i, n + (i + 1) % size) for i in range(size))
        pool.append(graph)
    count, marked_checks, bip_marked, exact_three = 0, 0, 0, 0
    types, lengths, examples = set(), set(), {}
    for core in pool:
        result = safe_cactus_core(core)
        verify_auxiliary(core, result, marked=result["marked_vertex"])
        count += 1
        types.update(result["interface_types"].values())
        lengths.update(result["cycle_lengths"])
        old = safe_odd_cactus_core(core)
        all_odd = all(len(cycle) % 2 for cycle in nx.cycle_basis(core))
        assert (old["status"] == "weighted") == all_odd
        marks = [v for v in core if core.degree(v) <= 2]
        if len(core) > 12:
            marks = rng.sample(marks, min(4, len(marks)))
        for v in marks:
            for incoming in (0, 2):
                weighted = safe_cactus_core(core, v, incoming, forbid_balanced=True)
                verify_auxiliary(core, weighted, v, incoming, True)
                marked_checks += 1
            weighted = safe_cactus_core(core, v, 1, marked_red=3)
            verify_auxiliary(core, weighted, v, 1)
            exact_three += 1
            if nx.is_bipartite(core):
                weighted = safe_cactus_core(core, v, 1, forbid_balanced=True)
                verify_auxiliary(core, weighted, v, 1, True)
                bip_marked += 1
                assert weighted["marked_red"] in (1, 5)
            elif safe_cactus_core(core, v, 1, forbid_balanced=True)["status"] != "weighted":
                examples.setdefault("nonbipartite_mixed_requires_three",
                                    {"edges": list(core.edges()), "marked_vertex": v})
    for n in (1000, 1001):
        core = nx.cycle_graph(n)
        weighted = safe_cactus_core(core, 0, 1, forbid_balanced=(n % 2 == 0), marked_red=3 if n % 2 else None)
        verify_auxiliary(core, weighted, 0, 1, n % 2 == 0)
    result = {"finite_certificate": certificate, "auxiliary_cactus_cores": count,
              "pure_marked_nonbalanced_interfaces": marked_checks,
              "mixed_marked_exact_three_interfaces": exact_three,
              "bipartite_mixed_marked_red_one_or_five": bip_marked,
              "all_six_types_observed": sorted(types), "cycle_lengths": sorted(lengths),
              "long_cycles_checked": [1000, 1001], "old_odd_scope_preserved": True,
              "damaged_extended_certificate_rejected": True, "examples": examples,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "seconds": round(time.monotonic() - start, 3)}
    (base / "safe_all_cactus_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
