"""Construct LIR2 when all vertices of degree >=3 form an independent set.

Arbitrary degrees, compressed loops, leaves and paths of length two are allowed.
This is a restricted-family constructor, NOT a solver for the mother conjecture.
No SAT, matching oracle or previously unconfirmed subcubic proof is used.
"""

import networkx as nx


def _path_word(length, first, last, left_red, left_blue, right_red, right_blue):
    if length < 2:
        raise ValueError("This interface needs at least two edges.")
    allowed = [set(range(3)) for _ in range(length)]
    allowed[0], allowed[-1] = {first}, {last}
    if first:
        allowed[1].discard(left_red - first)
    if first < 2:
        allowed[1].discard(4 - first - left_blue)
    if last:
        allowed[-2].discard(right_red - last)
    if last < 2:
        allowed[-2].discard(4 - last - right_blue)
    word = [None] * length
    for parity in (0, 1):
        positions = list(range(parity, length, 2))
        previous, histories = {None}, []
        for position in positions:
            current = {}
            for value in sorted(allowed[position]):
                predecessors = [old for old in previous if old != value]
                if predecessors:
                    current[value] = predecessors[0]
            if not current:
                return None
            histories.append(current)
            previous = set(current)
        value = min(previous)
        for position, history in zip(reversed(positions), reversed(histories)):
            word[position] = value
            value = history[value]
    return word


def _pendant_word(length, first, red, blue):
    if length == 1:
        return [first] if ((first == 0 or red != first) and
                           (first == 2 or blue != 2 - first)) else None
    for last in range(3):
        word = _path_word(length, first, last, red, blue, last, 2 - last)
        if word is not None:
            return word
    return None


def color_independent_branches(graph):
    """Return actual original-edge weights for the precisely stated family.

    Connected, nonempty, simple, loopless input; K2 is excluded. If adjacent
    vertices both have degree >=3, return method_not_applicable, not a claim
    that the graph is uncolorable. Weights follow edge_order.
    """
    if graph.is_directed() or graph.is_multigraph() or nx.number_of_selfloops(graph):
        raise ValueError("The input must be a simple loopless undirected graph.")
    if not len(graph) or not nx.is_connected(graph):
        raise ValueError("The input must be nonempty and connected.")
    if len(graph) == 2:
        raise ValueError("The isolated K2 is excluded.")
    edges = list(graph.edges())
    edge_id = {frozenset(e): i for i, e in enumerate(edges)}
    degree = dict(graph.degree())
    branches = [v for v in graph if degree[v] >= 3]
    if any(degree[u] >= 3 and degree[v] >= 3 for u, v in edges):
        return {"status": "method_not_applicable", "reason": "adjacent_branch_vertices",
                "mother_conjecture_proved": False}
    weights = [None] * len(edges)
    def put(path, word):
        assert word is not None and len(word) == len(path) - 1
        for u, v, value in zip(path, path[1:], word):
            index = edge_id[frozenset((u, v))]
            assert weights[index] is None
            weights[index] = value

    threads, pendants = [], []
    groups, final_red, final_blue, fixes = {}, {}, {}, []
    if not branches:
        if not edges:
            return {"status": "colored", "edge_order": edges, "weights": [],
                    "red": {v: 0 for v in graph}, "blue": {v: 0 for v in graph},
                    "groups": {}, "mother_conjecture_proved": False}
        is_path = any(degree[v] == 1 for v in graph)
        start = next(v for v in graph if degree[v] == 1) if is_path else next(iter(graph))
        path, previous, current = [start], None, start
        while True:
            choices = [v for v in graph[current] if v != previous]
            if not choices:
                break
            other = choices[0]
            path.append(other)
            if other == start:
                break
            previous, current = current, other
        length = len(path) - 1
        if is_path:
            word = [0, 0] if length == 2 else _path_word(length, 0, 2, 0, 2, 2, 0)
        else:
            position_graph = nx.Graph()
            position_graph.add_nodes_from(range(length))
            position_graph.add_edges_from((i, (i + 2) % length) for i in range(length))
            colors = {}
            for i in range(length):
                used_colors = {colors[j] for j in position_graph[i] if j in colors}
                colors[i] = next(value for value in range(3) if value not in used_colors)
            word = [colors[i] for i in range(length)]
        put(path, word)
    else:
        used = set()
        for root in branches:
            for neighbor in graph[root]:
                first_id = edge_id[frozenset((root, neighbor))]
                if first_id in used:
                    continue
                path, previous, current = [root, neighbor], root, neighbor
                used.add(first_id)
                while degree[current] == 2:
                    other = next(v for v in graph[current] if v != previous)
                    index = edge_id[frozenset((current, other))]
                    assert index not in used
                    used.add(index)
                    path.append(other)
                    previous, current = current, other
                if degree[current] == 1:
                    pendants.append({"path": path, "port": None})
                else:
                    assert degree[current] >= 3 and len(path) >= 3
                    threads.append({"path": path, "ports": None})
        assert len(used) == len(edges)

        long_graph = nx.Graph()
        long_graph.add_nodes_from(branches)
        for item in threads:
            path = item["path"]
            if path[0] != path[-1] and len(path) - 1 >= 3:
                long_graph.add_edge(path[0], path[-1])
        A, B = set(), set()
        for v in branches:
            if not any(w in A for w in long_graph[v]):
                A.add(v)
        for v in branches:
            if v not in A and not any(w in B for w in long_graph[v]):
                B.add(v)
        C = set(branches) - A - B
        groups = {v: "A" if v in A else "B" if v in B else "C" for v in branches}
        assert all(any(w in A for w in long_graph[v]) and any(w in B for w in long_graph[v]) for v in C)

        inside = nx.MultiGraph()
        inside.add_nodes_from(C)
        loops = dict.fromkeys(branches, 0)
        free_increase, free_decrease = {}, {}
        for index, item in enumerate(threads):
            path = item["path"]
            u, v = path[0], path[-1]
            length = len(path) - 1
            if u == v:
                loops[u] += 1
                item["ports"] = [0, 2]
            elif u in C and v in C:
                inside.add_edge(u, v, key=("original", index))
            else:
                ports = [0 if x in A else 2 if x in B else 1 for x in (u, v)]
                if length == 2:
                    for end, (x, other) in enumerate(((u, v), (v, u))):
                        if x in C and degree[x] == 3:
                            ports[end] = 2 if other in A else 0
                item["ports"] = ports
                if length >= 3:
                    for end, (x, other) in enumerate(((u, v), (v, u))):
                        if x in C and other in A:
                            free_increase[x] = (index, end)
                        elif x in C and other in B:
                            free_decrease[x] = (index, end)
        dummy = object()
        for index, v in enumerate([v for v in C if inside.degree(v) % 2]):
            inside.add_edge(v, dummy, key=("auxiliary", index))
        for component in nx.connected_components(inside):
            subgraph = inside.subgraph(component)
            if not subgraph.number_of_edges():
                continue
            for tail, head, key in nx.eulerian_circuit(subgraph, keys=True):
                if key[0] != "original":
                    continue
                item = threads[key[1]]
                u, v = item["path"][0], item["path"][-1]
                item["ports"] = [0, 2] if (tail, head) == (u, v) else [2, 0]
        for item in pendants:
            root = item["path"][0]
            item["port"] = 0 if root in A else 2 if root in B else 1

        def root_totals():
            totals = dict.fromkeys(branches, 0)
            for item in threads:
                path, pair = item["path"], item["ports"]
                totals[path[0]] += pair[0]
                totals[path[-1]] += pair[1]
            for item in pendants:
                totals[item["path"][0]] += item["port"]
            return totals
        initial = root_totals()
        for v in C:
            difference = degree[v] - initial[v]
            assert difference in (-1, 0, 1)
            if not difference:
                continue
            index, end = (free_increase if difference == 1 else free_decrease)[v]
            chosen = threads[index]
            assert chosen["ports"][end] == 1
            chosen["ports"][end] += difference
        after_correction = root_totals()
        assert all(after_correction[v] == degree[v] for v in C)

        special = {v for v in branches if degree[v] == 3 and loops[v] == 1}
        for item in threads:
            path = item["path"]
            u, v = path[0], path[-1]
            if len(path) == 3 and u != v and u in A and v in A:
                candidates = [end for end, x in enumerate((u, v)) if x in special]
                if candidates:
                    end = candidates[0]
                    assert item["ports"] == [0, 0]
                    item["ports"][end] = 2
                    fixes.append({"kind": "loop_short_thread", "vertex": (u, v)[end]})
        for item in pendants:
            root = item["path"][0]
            if root in special and len(item["path"]) == 3:
                assert root in A and item["port"] == 0
                item["port"] = 1
                fixes.append({"kind": "loop_two_edge_pendant", "vertex": root})
        final_red = root_totals()
        final_blue = {v: 2 * degree[v] - final_red[v] for v in branches}
        for item in threads:
            path, (a, b) = item["path"], item["ports"]
            u, v = path[0], path[-1]
            word = _path_word(len(path) - 1, a, b, final_red[u], final_blue[u], final_red[v], final_blue[v])
            if word is None:
                raise AssertionError(("thread_interface", path, a, b, final_red[u], final_blue[u], final_red[v], final_blue[v]))
            put(path, word)
        for item in pendants:
            path, first = item["path"], item["port"]
            root = path[0]
            word = _pendant_word(len(path) - 1, first, final_red[root], final_blue[root])
            if word is None:
                raise AssertionError(("pendant_interface", path, first, final_red[root], final_blue[root]))
            put(path, word)
    assert all(value in (0, 1, 2) for value in weights)
    red = dict.fromkeys(graph, 0)
    for (u, v), value in zip(edges, weights):
        red[u] += value
        red[v] += value
    blue = {v: 2 * degree[v] - red[v] for v in graph}
    assert all(red[v] == final_red[v] and blue[v] == final_blue[v] for v in final_red)
    assert all((value == 0 or red[u] != red[v]) and (value == 2 or blue[u] != blue[v])
               for (u, v), value in zip(edges, weights))
    return {"status": "colored", "edge_order": edges, "weights": weights,
            "red": red, "blue": blue, "groups": groups, "threads": threads,
            "pendants": pendants, "exceptional_fixes": fixes,
            "mother_conjecture_proved": False}
