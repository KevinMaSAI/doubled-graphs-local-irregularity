"""Exact GF(2) criterion for mod-four LIR with a prescribed mixed-edge set.

Only standard-library modules are used. Infeasibility concerns this extra
congruence condition and this fixed mixed set, never the mother conjecture.
"""


def solve_binary(rows, variables):
    """Return a solution or indices whose row XOR is the contradiction 0=1."""
    basis = {}
    for i, (mask, rhs) in enumerate(rows):
        provenance = 1 << i
        while mask:
            p = mask.bit_length()-1
            if p not in basis:
                basis[p] = (mask, rhs, provenance)
                break
            other, value, origins = basis[p]
            mask ^= other; rhs ^= value; provenance ^= origins
        if not mask and rhs:
            indices = [j for j in range(len(rows)) if provenance >> j & 1]
            lhs, value = 0, 0
            for j in indices:
                lhs ^= rows[j][0]; value ^= rows[j][1]
            assert lhs == 0 and value == 1
            return {"consistent": False, "xor_rows": indices}
    solution = 0
    for p in sorted(basis):
        mask, rhs, _ = basis[p]
        value = rhs ^ ((mask & solution).bit_count() % 2)
        solution |= value << p
    assert all((mask & solution).bit_count() % 2 == rhs for mask, rhs in rows)
    return {"consistent": True, "solution": [solution >> i & 1 for i in range(variables)]}


def solve_mod4_with_mixed(vertices, edges, mixed_edges, red_offsets=None, blue_offsets=None):
    vertices, edges, mixed_edges = list(vertices), [tuple(e) for e in edges], list(mixed_edges)
    if len(set(vertices)) != len(vertices):
        raise ValueError("Vertex identifiers must be distinct.")
    V = set(vertices)
    keys = [frozenset(e) for e in edges]
    if any(len(e) != 2 or len(k) != 2 or not k <= V for e, k in zip(edges, keys)) or len(set(keys)) != len(keys):
        raise ValueError("A simple undirected edge inventory is required.")
    mixed_list = [frozenset(e) for e in mixed_edges]
    M = set(mixed_list)
    if len(M) != len(mixed_list) or not M <= set(keys):
        raise ValueError("The mixed set must list distinct existing edges.")
    A = dict.fromkeys(vertices, 0) if red_offsets is None else dict(red_offsets)
    B0 = dict.fromkeys(vertices, 0) if blue_offsets is None else dict(blue_offsets)
    if (set(A) != V or set(B0) != V or any(type(A[v]) is not int or type(B0[v]) is not int
            or min(A[v], B0[v]) < 0 or (A[v]+B0[v]) % 2 for v in vertices)):
        raise ValueError("Offsets must be physical nonnegative integer contributions of even total.")
    degree, mdegree = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    for (u, v), key in zip(edges, keys):
        degree[u] += 1; degree[v] += 1
        if key in M:
            mdegree[u] += 1; mdegree[v] += 1
    D = {v: degree[v]+(A[v]+B0[v])//2 for v in vertices}
    p = {v: (A[v]+mdegree[v]) % 2 for v in vertices}
    h = {v: ((A[v]+mdegree[v])//2) % 2 for v in vertices}
    variables = [["vertex_bit", v] for v in vertices]
    t = {v: i for i, v in enumerate(vertices)}
    z = {}
    for i, key in enumerate(keys):
        if key not in M:
            z[i] = len(variables); variables.append(["even_edge_bit", i])
    original, descriptions = [], []

    def equation(indices, rhs, kind, context):
        mask = 0
        for j in indices:
            mask ^= 1 << j
        original.append((mask, rhs))
        descriptions.append({"variables": [j for j in range(len(variables)) if mask >> j & 1],
                             "rhs": rhs, "kind": kind, "context": context})

    for v in vertices:
        equation([t[v]]+[z[i] for i, e in enumerate(edges) if i in z and v in e],
                 h[v], "vertex_residue", v)
    for i, (u, v) in enumerate(edges):
        if p[u] != p[v]:
            continue
        if (D[u]-D[v]) % 2 == 0:
            equation([t[u], t[v]], 1, "equal_degree_parity", i)
        elif keys[i] in M:
            equation([], 1, "forbidden_mixed_edge", i)
        else:
            equation([z[i], t[u], t[v]], 0, "forced_even_edge_color", i)
    answer = solve_binary(original, len(variables))
    matrix = {"variable_order": variables, "rows": descriptions, **answer}
    common = {"vertices": vertices, "original_edges": [list(e) for e in edges],
              "mixed_edges": [list(e) for e, k in zip(edges, keys) if k in M],
              "red_offsets": A, "blue_offsets": B0, "total_degree": D,
              "parity": p, "matrix_certificate": matrix,
              "external_boundary_edges_checked": False, "mother_conjecture_proved": False}
    if not answer["consistent"]:
        return {"status": "mod4_infeasible_for_fixed_mixed", **common}
    bits = answer["solution"]
    values = [1 if key in M else 2*bits[z[i]] for i, key in enumerate(keys)]
    R, B = dict(A), dict(B0)
    for (u, v), x in zip(edges, values):
        for copy in range(2):
            color = R if copy < x else B
            color[u] += 1; color[v] += 1
    assert all(R[v] % 4 == p[v]+2*bits[t[v]] and R[v]+B[v] == 2*D[v] for v in vertices)
    assert all((x == 0 or (R[u]-R[v]) % 4 != 0) and (x == 2 or (B[u]-B[v]) % 4 != 0)
               for (u, v), x in zip(edges, values))
    return {"status": "mod4_colored", "edges": [[u, v, x] for (u, v), x in zip(edges, values)],
            "red": R, "blue": B, **common}
