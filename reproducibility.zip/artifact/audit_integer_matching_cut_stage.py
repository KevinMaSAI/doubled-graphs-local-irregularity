"""Independent stdlib audit. No imports of construction code or solvers."""

import ast
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT
SCRIPTS = ["signed_gap_two.py", "integer_matching_cut.py", "check_integer_matching_cut.py",
           "mod4_component_cuts.py", "mod4_fixed_mixed.py"]
DOCS = ["符号和间隙与配对分割的整数构造_20261028.md", "UPDATE_20261028.md"]
RECORDS = ["integer_matching_cut_validation.json", "integer_matching_cut_witnesses.json"]
for name in SCRIPTS:
    ast.parse((OUT/name).read_text(encoding="utf-8"), filename=name)
links = 0
for name in DOCS:
    content = (OUT/name).read_text(encoding="utf-8")
    assert not any(ord(c) < 32 and c not in "\n\r\t" for c in content)
    assert len(re.findall(r"(?<!\\)\$", content)) % 2 == 0
    for target in re.findall(r"\]\(([^)]+)\)", content):
        if target.startswith(("http:", "https:", "#")):
            continue
        assert (OUT/target).is_file(), (name, target)
        links += 1


def components(vertices, edges):
    adj = {v: set() for v in vertices}
    for u, v in edges:
        adj[u].add(v); adj[v].add(u)
    groups, seen = [], set()
    for root in vertices:
        if root in seen:
            continue
        group = {root}; order = [root]; seen.add(root)
        for v in order:
            for u in adj[v]-seen:
                seen.add(u); group.add(u); order.append(u)
        groups.append(group)
    return groups


row_count = 0


def signed_audit(encoded_rows, solution):
    global row_count
    rows = [dict(row) for row in encoded_rows]
    signs = {int(e): y for e, y in solution["signs"].items()}
    cert = solution["certificate"]; sigma = cert["row_signs"]
    assert len(sigma) == len(rows) and all(s in (-1, 1) for s in sigma)
    occ = {}
    for i, row in enumerate(rows):
        assert len(row) >= 4 and all(c in (-1, 1) for c in row.values())
        for e, c in row.items():
            occ.setdefault(e, []).append((i, c))
    assert set(signs) == set(occ) and all(y in (-1, 1) for y in signs.values())
    assert all(1 <= len(items) <= 2 for items in occ.values())
    bad, internal_good = {}, [0]*len(rows)
    margin = [len(row) for row in rows]
    for e, items in occ.items():
        if len(items) == 1:
            v, c = items[0]
            assert sigma[v]*c*signs[e] == 1
        else:
            (u, a), (v, b) = items
            assert u != v
            if a*b == sigma[u]*sigma[v]:
                internal_good[u] += 1; internal_good[v] += 1
                assert sigma[u]*a*signs[e] == sigma[v]*b*signs[e] == 1
            else:
                bad[e] = (u, v); margin[u] -= 2; margin[v] -= 2
    baddegree = Counter(v for endpoints in bad.values() for v in endpoints)
    assert all(internal_good[v] >= baddegree[v] for v in range(len(rows)))
    pos = {int(e): v for e, v in cert["bad_positive_endpoint"].items()}
    assert set(pos) == set(bad)
    out = Counter()
    for e, v in pos.items():
        assert v in bad[e] and sigma[v]*rows[v][e]*signs[e] == 1
        out[v] += 1
    critical = {v for v, m in enumerate(margin) if m < 2}
    assert critical == set(cert["critical_rows"])
    assert all(baddegree[v] >= 2 and out[v] >= 1 for v in critical)
    assert margin == cert["margins"] and [out[v] for v in range(len(rows))] == cert["bad_outdegrees"]
    groups = components(range(len(rows)), bad.values())
    assert {frozenset(g) for g in groups} == {frozenset(c["vertices"]) for c in cert["components"]}
    for c in cert["components"]:
        group = set(c["vertices"])
        if c["kind"] == "root_tree":
            assert c["root"] in group-critical
        else:
            assert c["kind"] == "cycle_and_trees" and group <= critical
            cycle, edges = c["cycle_rows"], c["cycle_variables"]
            assert len(set(cycle)) == len(cycle) == len(edges) >= 2 and len(set(edges)) == len(edges)
            for i, e in enumerate(edges):
                assert set(bad[e]) == {cycle[i], cycle[(i+1) % len(cycle)]} and pos[e] == cycle[i]
    sums = [sum(c*signs[e] for e, c in row.items()) for row in rows]
    assert sums == solution["row_sums"]
    assert all(sigma[v]*sums[v] == margin[v]+2*out[v] >= 2 for v in range(len(rows)))
    assert solution["mother_conjecture_proved"] is False
    row_count += len(rows)


def raw_graph(data):
    V = set(data["vertices"]); T = set(data["T"])
    assert len(V) == len(data["vertices"]) and T <= V
    E, D, R, B, inside = {}, Counter(), Counter(), Counter(), Counter()
    for u, v, x in data["edges"]:
        key = frozenset((u, v))
        assert len(key) == 2 and key <= V and key not in E and x in (0, 1, 2)
        E[key] = x; D[u] += 1; D[v] += 1
        if (u in T) == (v in T):
            inside[u] += 1; inside[v] += 1
            assert x == int(u in T)
        else:
            assert x in (0, 2)
        for copy in range(2):
            C = R if copy < x else B
            C[u] += 1; C[v] += 1
    assert all(inside[v] <= 1 and (v not in T or inside[v] == 1) for v in V)
    pairs = [(u, v) for u, v, x in data["edges"] if (u in T) == (v in T)]
    assert pairs == [tuple(p) for p in data["paired_edges"]]
    assert all(min(D[u], D[v]) >= 3 and abs(D[u]-D[v]) <= 1 for u, v in pairs)
    assert {int(v): r for v, r in data["red"].items()} == {v: R[v] for v in V}
    assert {int(v): b for v, b in data["blue"].items()} == {v: B[v] for v in V}
    assert all(R[v]+B[v] == 2*D[v] and R[v] % 2 == B[v] % 2 == int(v in T) for v in V)
    for u, v, x in data["edges"]:
        for copy in range(2):
            C = R if copy < x else B
            assert C[u] != C[v]
    rows = [{i: (1 if u in (a, b) else -1)
             for i, (a, b, x) in enumerate(data["edges"])
             if (a in T) != (b in T) and (u in (a, b) or v in (a, b))}
            for u, v in pairs]
    assert rows == [dict(row) for row in data["signed_rows"]]
    signed_audit(data["signed_rows"], data["signed_solution"])
    for (u, v), total in zip(pairs, data["signed_solution"]["row_sums"]):
        assert R[u]-R[v] == D[u]-D[v]+total and B[u]-B[v] == D[u]-D[v]-total
    M = {key for key, x in E.items() if x == 1}
    assert M == set(map(frozenset, data["mixed_edges"]))
    modular = all((x == 0 or (R[u]-R[v]) % 4) and (x == 2 or (B[u]-B[v]) % 4)
                  for u, v, x in data["edges"])
    assert bool(modular) == data["satisfies_stronger_mod4_condition"]
    assert data["new_vertices_added"] == data["new_edges_added"] == 0
    assert data["mother_conjecture_proved"] is False
    return V, E, D, R, B, M


report = json.loads((OUT/RECORDS[0]).read_text(encoding="utf-8"))
assert report["all_checks_passed"] and report["mother_conjecture_proved"] is False
assert report["signed_form_cases"] == 647 and report["eligible_atlas_partition_inputs"] == 31
assert report["atlas_colorings_checked"] == 31 and report["synthetic_nearregular_graphs_checked"] == 57
assert report["pairwise_degree_only_graphs_checked"] == 1
assert all((r["fixed_mixed_mod4"] == "mod4_colored") == (r["k"] % 2 == 0)
           and r["n"] == 10*r["k"] and r["m"] == 17*r["k"] for r in report["phase_barrier_family"])
w = json.loads((OUT/RECORDS[1]).read_text(encoding="utf-8"))
assert len(w) == report["saved_example_groups"] == 6
for key in ["five_term_signed_rows", "boundary_signed_rows"]:
    signed_audit(w[key]["rows"], w[key]["solution"])
ob = w["hypothesis_obstructions"]; counter_counts = []
for key, arity, frequency, constants in [
        ("three_terms_rows", 3, 2, [0]*4),
        ("three_occurrences_rows", 5, 3, [0]*3),
        ("affine_rows", 4, 2, ob["affine_constants"])]:
    rows = [dict(row) for row in ob[key]]; occ = Counter(e for row in rows for e in row)
    assert all(len(row) == arity for row in rows) and max(occ.values()) == frequency
    assert len(rows) == len(constants)
    variables = sorted(occ); count = 0
    for values in itertools.product((-1, 1), repeat=len(variables)):
        assign = dict(zip(variables, values))
        assert any(abs(a+sum(c*assign[e] for e, c in row.items())) < 2
                   for row, a in zip(rows, constants))
        count += 1
    counter_counts.append(count)
assert counter_counts == [64, 32, 1024]
whole_edges, whole_graphs = 0, 0
for key in ["same_mixed_phase_cut_integer_repair", "same_mixed_forbidden_edge_integer_repair"]:
    pair = w[key]; actual = pair["integer_coloring"]; mod = pair["mod4_result"]
    V, E, D, R, B, M = raw_graph(actual)
    assert V == set(mod["vertices"]) and set(E) == set(map(frozenset, mod["original_edges"]))
    assert M == set(map(frozenset, mod["mixed_edges"]))
    assert all(a == 0 for a in list(mod["red_offsets"].values())+list(mod["blue_offsets"].values()))
    assert mod["status"] == "mod4_infeasible_for_fixed_mixed"
    md = Counter(v for e in M for v in e); p = {v: md[v] % 2 for v in V}
    if "phase_cut" in key:
        assert actual["parameter"] == 1 and V == set(range(10))
        base = [(v, (v+1) % 4) for v in range(4)]+[(0, 2), (1, 3)]
        expected = {frozenset((v, 4+i)) for i, edge in enumerate(base) for v in edge}
        expected |= set(map(frozenset, [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)]))
        assert set(E) == expected and len(E) == 17 and Counter(D.values()) == Counter({3: 6, 4: 4})
        assert M == set(map(frozenset, [(4, 5), (6, 7), (8, 9)]))
        H = {e for e in E for u, v in [tuple(e)] if p[u] == p[v] and (D[u]-D[v]) % 2 == 0}
        L = {e for e in E for u, v in [tuple(e)] if p[u] == p[v] and (D[u]-D[v]) % 2}
        assert not L and len(H) == 5 and Counter(v for e in H for v in e) == Counter({v: 1 for v in V})
        assert len(components(actual["vertices"], [tuple(e) for e in set(E)-M])) == 1
        cert = mod["phase_certificate"]
        assert not cert["consistent"] and cert["rows"] == [{"variables": [], "rhs": 1}]
        assert mod["obstruction"]["type"] == "phase_cut" and set(mod["obstruction"]["U"]) == V
        assert set(mod["obstruction"]["lambda_vertices"]) == V
        colors = {int(v): c for v, c in cert["H_colors"].items()}
        assert all(colors[u] != colors[v] for e in H for u, v in [tuple(e)]) and sum(colors.values()) % 2 == 1
        assert any(abs(R[u]-R[v]) == 4 for e in H for u, v in [tuple(e)])
    else:
        expected = {frozenset((u, v)) for u in range(8) for v in range(u+1, 8) if u ^ v in (1, 2, 4)}
        expected.add(frozenset((0, 3)))
        assert V == set(range(8)) and set(E) == expected and len(E) == 13
        obstruction = mod["obstruction"]; assert obstruction["type"] == "forbidden_mixed_edge"
        u, v = mod["original_edges"][obstruction["edge_index"]]
        assert frozenset((u, v)) == frozenset((2, 3)) and frozenset((u, v)) in M
        assert p[u] == p[v] == 1 and (D[u]-D[v]) % 2
        assert abs(R[u]-R[v]) == 4 and abs(B[u]-B[v]) == 6
    assert not actual["satisfies_stronger_mod4_condition"]
    whole_graphs += 1; whole_edges += len(E)
V, E, D, R, B, M = raw_graph(w["pairwise_degree_condition_with_a_leaf"])
assert min(D.values()) == 1 and max(D.values()) == 6 and D[10] == 1
assert len(V) == 11 and len(E) == 20
whole_graphs += 1; whole_edges += len(E)
inventory = {}
for name in SCRIPTS+DOCS+RECORDS:
    path = OUT/name
    inventory[name] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
audit = {"syntax_checks_including_two_older_dependencies": len(SCRIPTS),
         "documents_checked": len(DOCS), "local_links_checked": links,
         "independently_checked_saved_signed_rows": row_count,
         "exhaustive_auxiliary_counterexample_assignments": counter_counts,
         "raw_whole_original_graphs_checked": whole_graphs,
         "raw_original_edges_checked": whole_edges, "raw_actual_copies_checked": 2*whole_edges,
         "same_mixed_set_mod4_forbidden_edge_but_integer_colored": True,
         "same_mixed_set_mod4_global_phase_cut_but_integer_colored": True,
         "pairwise_degree_conditions_and_leaf_instance_verified": True,
         "portable_release_paths_checked": True, "all_checks_passed": True,
         "external_peer_review": False, "lean_formalization": False,
         "mother_conjecture_proved": False,
         "independent_auditor": {"relative_to_project": "artifact/audit_integer_matching_cut_stage.py",
                                "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
         "files": inventory}
# Report on stdout; preserve all archived input bytes.
print(json.dumps({k: v for k, v in audit.items() if k not in ("files", "independent_auditor")}, ensure_ascii=False, indent=2))
