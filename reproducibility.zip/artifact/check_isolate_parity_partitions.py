"""Check isolate constructions and scope-specific negative certificates."""

from collections import Counter
import itertools
import json
from pathlib import Path
import time

import networkx as nx

from isolate_parity_partitions import (color_protected_isolates, color_independent_given_join,
    color_independent_even_components, independent_cross_join, protected_path_family,
    bridge_parity_barrier_family, odd_independent_side_family)

OUT = Path(__file__).resolve().parent


def raw_check(answer):
    V = answer["vertices"]; T = set(answer["T"])
    R, B, D, E = Counter(), Counter(), Counter(), set()
    for u, v, x in answer["edges"]:
        e = frozenset((u, v)); assert len(e) == 2 and e not in E and x in (0, 1, 2); E.add(e)
        D[u] += 1; D[v] += 1
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert {v: R[v] for v in V} == answer["red"] and {v: B[v] for v in V} == answer["blue"]
    for u, v, x in answer["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    assert set(map(frozenset, answer["mixed_edges"])) == {frozenset((u, v)) for u, v, x in answer["edges"] if x == 1}
    reverse = answer["method"] == "independent_T_reverse_parity"
    assert all(R[v] % 2 == B[v] % 2 == int((v not in T) if reverse else (v in T)) for v in V)
    assert answer["new_vertices_added"] == answer["new_edges_added"] == 0
    return D


def brute_fixed_mixed(V, E, mixed):
    fixed = set(map(frozenset, mixed)); pure = [i for i, e in enumerate(E) if frozenset(e) not in fixed]
    for bits in itertools.product((0, 1), repeat=len(pure)):
        values = [1]*len(E)
        for i, b in zip(pure, bits):
            values[i] = 2*b
        R, B = Counter(), Counter()
        for (u, v), x in zip(E, values):
            R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
        if all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v]) for (u, v), x in zip(E, values)):
            return True
    return False


def check_protected_negative(answer):
    E = [tuple(e) for e in answer["original_edges"]]; T = set(answer["T"])
    I = {v for v in T if not any(u in T for e in E if v in e for u in e if u != v)}
    assert I == set(answer["I"])
    P = set(answer["protected_S_vertices"])
    expected = [i for i, (u, v) in enumerate(E) if (u in I and v not in T and v not in P) or (
        v in I and u not in T and u not in P)]
    assert expected == answer["allowed_edge_indices"]
    U = set(answer["parity_certificate"]["odd_component"])
    assert len(U & I) % 2 == 1
    assert all((u in U) == (v in U) for i in expected for u, v in [E[i]])


def main():
    started = time.monotonic(); saved = {}; atlas = Counter(); exact = Counter(); brute_domains = 0
    for G in nx.graph_atlas_g():
        if not len(G) or not nx.is_connected(G) or any(d not in (3, 4) for v, d in G.degree()):
            continue
        V, E = list(G), list(G.edges())
        for mask in range(1, 1 << len(V)):
            T = {v for v in V if mask >> v & 1}
            inside = {v: sum((u in T) == (v in T) for u in G[v]) for v in G}
            if any(inside[v] > 1 for v in T) or any(inside[v] > 2 or inside[v] == 2 and G.degree(v) != 4 for v in set(V)-T):
                continue
            answer = color_protected_isolates(V, E, T); atlas[answer["status"]] += 1
            if answer["status"] == "colored":
                raw_check(answer)
                if any(inside[v] == 0 for v in T):
                    atlas["colored_with_T_isolates"] += 1
            else:
                assert answer["status"] == "no_protected_parity_join"; check_protected_negative(answer)
            if any(inside[v] for v in T) or len(V) > 6:
                continue
            cross = [i for i, (u, v) in enumerate(E) if (u in T) != (v in T)]
            for bits in itertools.product((0, 1), repeat=len(cross)):
                mixed = [E[i] for i, b in zip(cross, bits) if b]
                md = Counter(v for e in mixed for v in e)
                if any(md[v] % 2 != int(v in T) for v in V):
                    continue
                result = color_independent_given_join(V, E, T, mixed); exact[result["status"]] += 1
                possible = brute_fixed_mixed(V, E, mixed); brute_domains += 1
                assert (result["status"] == "colored") == possible
                if possible:
                    raw_check(result)
                else:
                    assert result["status"] == "no_extension_for_this_cross_mixed_set"
    protected_records = []
    for t in [1, 3, 5, 9]:
        for r in [0, 1, 2, 4]:
            answer = protected_path_family(t, r); D = raw_check(answer)
            assert len(answer["vertices"]) == 5*t+4*r and len(answer["edges"]) == 9*t+7*r-1
            assert len(answer["I"]) == 2*t
            assert Counter(D.values()) == Counter({3: 2*t+2*r+2, 4: 3*t+2*r-2})
            protected_records.append({"t": t, "r": r, "vertices": len(D), "edges": len(answer["edges"])})
            if t == 3 and r == 2:
                saved["both_T_pairs_and_isolates"] = answer
    barrier_records = []
    for t in [1, 2, 3, 5]:
        answer = bridge_parity_barrier_family(t); D = raw_check(answer)
        assert len(D) == 30*t+10 and len(answer["edges"]) == 45*t+18
        assert Counter(D.values()) == Counter({3: 30*t+4, 4: 6})
        cross = nx.Graph((u, v) for u, v, x in answer["edges"] if (u in answer["T"]) != (v in answer["T"]))
        assert nx.is_connected(cross)
        forced = answer["opposite_pattern_obstruction"]["conflicting_S_pair"]
        N = set(answer["opposite_pattern_parity_join"]["indices"])
        for v in forced:
            incident = [i for i, (u, w, x) in enumerate(answer["edges"]) if i in N and v in (u, w)]
            assert len(incident) == 2
            for u in cross[v]:
                H = cross.copy(); H.remove_edge(u, v)
                C = nx.node_connected_component(H, u)
                assert (v not in C) and len(C & set(answer["T"])) % 2 == 1
        opposite = color_independent_given_join(answer["vertices"], [(u, v) for u, v, x in answer["edges"]], answer["T"],
                                               [answer["edges"][i][:2] for i in sorted(N)])
        assert opposite["status"] == "no_extension_for_this_cross_mixed_set"
        barrier_records.append({"t": t, "vertices": len(D), "edges": len(answer["edges"])})
        if t == 1:
            saved["even_T_bridge_barrier_repaired_by_reverse_parity"] = answer
    odd_records = []
    for q in [3, 5, 7, 11]:
        answer = odd_independent_side_family(q); raw_check(answer)
        assert len(answer["vertices"]) == 3*q and len(answer["edges"]) == 6*q-1
        joined = independent_cross_join(answer["vertices"], [(u, v) for u, v, x in answer["edges"]], answer["T"])
        assert joined["status"] == "infeasible" and len(joined["odd_targets"]) % 2
        odd_records.append({"q": q, "vertices": 3*q, "edges": 6*q-1})
        if q == 3:
            saved["odd_T_reverse_parity"] = answer
    # Minimal fixed-cross-M saturation failure, and repair on the SAME graph.
    V = list(range(5)); T = [3, 4]
    E = [(u, v) for u in range(5) for v in range(u+1, 5) if (u, v) != (3, 4)]
    all_cross = [(u, v) for u, v in E if (u in T) != (v in T)]
    bad = color_independent_given_join(V, E, T, all_cross)
    assert bad["status"] == "no_extension_for_this_cross_mixed_set"
    assert not brute_fixed_mixed(V, E, all_cross)
    good = color_independent_given_join(V, E, T, [(0, 3), (0, 4)]); raw_check(good)
    saved["same_graph_fixed_join_obstruction_and_repair"] = {"bad": bad, "good": good}
    # An odd protected component is a precise scope-specific negative certificate.
    E0 = [(u, v) for u in range(3) for v in range(3, 6)]+[(0, 1)]
    no_join = color_protected_isolates(list(range(6)), E0, [3, 4, 5])
    assert no_join["status"] == "no_protected_parity_join"; check_protected_negative(no_join)
    saved["odd_protected_component"] = no_join
    report = {"eligible_atlas_partition_outcomes": dict(atlas),
              "exact_fixed_join_outcomes": dict(exact), "fixed_join_domains_compared_to_full_binary_assignments": brute_domains,
              "protected_path_family": protected_records, "bridge_barrier_family": barrier_records,
              "odd_independent_side_family": odd_records, "saved_groups": len(saved),
              "all_checks_passed": True, "elapsed_seconds": round(time.monotonic()-started, 3),
              "mother_conjecture_proved": False, "finite_tests_are_not_universal_proofs": True}
    (OUT/"isolate_parity_partitions_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (OUT/"isolate_parity_partitions_witnesses.json").write_text(json.dumps(saved, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
