"""Actual LIR for a supplied subquartic path/cycle versus paired partition.

S-induced degree <=2, all S-induced degree-two vertices have ordinary degree4,
T induces a matching covering all of T, and all ordinary degrees are3 or4.
No universal existence of such a partition is asserted.
"""

import itertools

from signed_gap_two import signed_gap_two


def solve_two_cnf(variable_count, clauses):
    """Literal (i,b) means variable i equals b. Iterative Kosaraju."""
    adjacency = [[] for _ in range(2*variable_count)]
    reverse = [[] for _ in adjacency]
    for clause in clauses:
        if not clause:
            return None
        if len(clause) > 2:
            raise ValueError("Only clauses of size at most two are supported.")
        (i, a), (j, b) = (list(clause)*2)[:2] if len(clause) == 1 else clause
        for u, v in [(2*i+(1-a), 2*j+b), (2*j+(1-b), 2*i+a)]:
            adjacency[u].append(v); reverse[v].append(u)
    seen, order = set(), []
    for root in range(len(adjacency)):
        if root in seen:
            continue
        seen.add(root); stack = [(root, 0)]
        while stack:
            v, pointer = stack[-1]
            if pointer == len(adjacency[v]):
                order.append(v); stack.pop(); continue
            u = adjacency[v][pointer]; stack[-1] = (v, pointer+1)
            if u not in seen:
                seen.add(u); stack.append((u, 0))
    component = [-1]*len(adjacency); count = 0
    for root in reversed(order):
        if component[root] != -1:
            continue
        component[root] = count; stack = [root]
        for v in stack:
            for u in reverse[v]:
                if component[u] == -1:
                    component[u] = count; stack.append(u)
        count += 1
    if any(component[2*i] == component[2*i+1] for i in range(variable_count)):
        return None
    values = [int(component[2*i+1] > component[2*i]) for i in range(variable_count)]
    assert all(any(values[i] == b for i, b in clause) for clause in clauses)
    return values


def selected_break_indices(n, cycle, degree_sequence):
    if cycle:
        if n % 2:
            return [0]
        return [0, 3] if n % 4 == 2 else []
    return [0] if n % 2 == 0 and degree_sequence[0] == degree_sequence[-1] else []


def complete_component(degrees, crossing_red_counts, cycle=False):
    """Return pure internal edges for one profile; failure is profile-specific."""
    degrees, red = list(degrees), list(crossing_red_counts)
    n = len(degrees); m = n if cycle else n-1
    if not n or len(red) != n or (cycle and n < 3):
        raise ValueError("Use a nonempty path, or a simple cycle of length >=3.")
    if any(d not in (3, 4) for d in degrees):
        raise ValueError("Ordinary degrees must be three or four.")
    internal = [2 if cycle or 0 < i < n-1 else int(n > 1) for i in range(n)]
    if any(a == 2 and d != 4 for a, d in zip(internal, degrees)):
        raise ValueError("Internal degree-two S vertices must have ordinary degree four.")
    if any(type(s) is not int or not 0 <= s <= d-a for s, d, a in zip(red, degrees, internal)):
        raise ValueError("A crossing red count lies outside its capacity.")
    clauses = []
    for i in range(m):
        j = (i+1) % n
        previous = (i-1) % m if cycle else i-1 if i > 0 else None
        following = (i+1) % m if cycle else i+1 if i+1 < m else None
        variables = [v for v in (previous, following) if v is not None]
        if degrees[i] != degrees[j]:
            variables.append(i)
        variables = list(dict.fromkeys(variables))
        assert len(variables) <= 2
        for bits in itertools.product((0, 1), repeat=len(variables)):
            choice = dict(zip(variables, bits))
            delta = red[i]-red[j]+choice.get(previous, 0)-choice.get(following, 0)
            valid = delta != 0 if degrees[i] == degrees[j] else (
                delta != 0 if choice[i] else degrees[i]-degrees[j]-delta != 0)
            if not valid:
                clauses.append([[v, 1-choice[v]] for v in variables])
    values = solve_two_cnf(m, clauses)
    result = {"degrees": degrees, "crossing_red_counts": red, "cycle": cycle,
              "clauses": clauses, "selected_break_indices": selected_break_indices(n, cycle, degrees)}
    if values is None:
        return dict(result, status="no_extension_for_this_profile")
    q = list(red)
    for i, z in enumerate(values):
        q[i] += z; q[(i+1) % n] += z
    for i, z in enumerate(values):
        j = (i+1) % n
        assert q[i] != q[j] if z else degrees[i]-q[i] != degrees[j]-q[j]
    return dict(result, status="extended", internal_bits=values, half_red=q)


def color_path_cycle_partition(vertices, edges, T):
    vertices, edges, T = list(vertices), [tuple(e) for e in edges], set(T)
    V = set(vertices)
    if not vertices or len(V) != len(vertices) or not T <= V:
        raise ValueError("Use distinct vertices and a subset T.")
    adjacency, inventory = {v: [] for v in vertices}, set()
    for u, v in edges:
        key = frozenset((u, v))
        if len(key) != 2 or not key <= V or key in inventory:
            raise ValueError("A simple graph is required.")
        inventory.add(key); adjacency[u].append(v); adjacency[v].append(u)
    degree = {v: len(adjacency[v]) for v in vertices}
    inside = {v: [u for u in adjacency[v] if (u in T) == (v in T)] for v in vertices}
    if any(d not in (3, 4) for d in degree.values()) or any(len(inside[v]) != 1 for v in T) or any(
            len(inside[v]) > 2 or len(inside[v]) == 2 and degree[v] != 4 for v in V-T):
        return {"status": "not_applicable", "mother_conjecture_proved": False,
                "reason": "Need degrees3/4, T covered by induced matching, S paths/cycles with degree4 interiors."}
    groups, seen, selected = [], set(), []
    for start in vertices:
        if start in T or start in seen:
            continue
        group, seen = [start], seen | {start}
        for v in group:
            for u in inside[v]:
                if u not in seen:
                    seen.add(u); group.append(u)
        cycle = all(len(inside[v]) == 2 for v in group)
        root = group[0] if cycle else next(v for v in group if len(inside[v]) <= 1)
        order, previous = [root], None
        while True:
            nxt = next((u for u in inside[order[-1]] if u != previous and u != root), None)
            if nxt is None:
                break
            previous = order[-1]; order.append(nxt)
        assert set(order) == set(group) and len(order) == len(group)
        indices = selected_break_indices(len(order), cycle, [degree[v] for v in order])
        selected += [(order[i], order[(i+1) % len(order)]) for i in indices]
        groups.append({"vertices": order, "cycle": cycle})
    assert len({v for e in selected for v in e}) == 2*len(selected)
    T_pairs = [(u, v) for u, v in edges if u in T and v in T]
    row_pairs = T_pairs+selected
    cross = [i for i, (u, v) in enumerate(edges) if (u in T) != (v in T)]
    rows = [{i: (1 if u in edges[i] else -1) for i in cross if u in edges[i] or v in edges[i]}
            for u, v in row_pairs]
    assert all(len(row) >= 4 for row in rows)
    signed = signed_gap_two(rows)
    assert set(signed["signs"]) == set(cross)
    values = {i: 1+signed["signs"][i] for i in cross}
    values.update({i: 1 for i, (u, v) in enumerate(edges) if u in T and v in T})
    cross_red = {v: sum(values[i]//2 for i in cross if v in edges[i]) for v in vertices}
    edge_index = {frozenset(e): i for i, e in enumerate(edges)}
    for group in groups:
        order = group["vertices"]
        extension = complete_component([degree[v] for v in order], [cross_red[v] for v in order], group["cycle"])
        assert extension["status"] == "extended", (group, extension)
        for i, z in enumerate(extension["internal_bits"]):
            values[edge_index[frozenset((order[i], order[(i+1) % len(order)]))]] = 2*z
        group["extension"] = extension
    assert set(values) == set(range(len(edges)))
    R, B = dict.fromkeys(vertices, 0), dict.fromkeys(vertices, 0)
    for i, (u, v) in enumerate(edges):
        x = values[i]
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert all(R[v] % 2 == B[v] % 2 == int(v in T) for v in vertices)
    assert all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v])
               for i, (u, v) in enumerate(edges) for x in [values[i]])
    return {"status": "colored", "vertices": vertices, "T": [v for v in vertices if v in T],
            "edges": [[u, v, values[i]] for i, (u, v) in enumerate(edges)], "red": R, "blue": B,
            "mixed_edges": [list(e) for e in T_pairs], "selected_S_edges": [list(e) for e in selected],
            "row_pairs": [list(e) for e in row_pairs], "signed_rows": [list(row.items()) for row in rows],
            "signed_solution": signed, "S_components": groups,
            "new_vertices_added": 0, "new_edges_added": 0, "mother_conjecture_proved": False}


def triangle_block_family(t):
    """2t S-triangles joined through 3t paired K2,2 blocks; n12t,m21t."""
    if type(t) is not int or t < 1:
        raise ValueError("A positive integer t is required.")
    triangle_count = 2*t
    base = [(0, 1)]*3 if t == 1 else (
        [(v, (v+1) % triangle_count) for v in range(triangle_count)]
        +[(v, v+t) for v in range(t)])
    ports = [0]*triangle_count; pairs = []
    for u, v in base:
        pairs.append((3*u+ports[u], 3*v+ports[v])); ports[u] += 1; ports[v] += 1
    assert all(a == 3 for a in ports)
    edges = [(3*v+i, 3*v+(i+1) % 3) for v in range(triangle_count) for i in range(3)]
    for i, (u, v) in enumerate(pairs):
        a, b = 6*t+2*i, 6*t+2*i+1
        edges += [(u, a), (u, b), (v, a), (v, b), (a, b)]
    answer = color_path_cycle_partition(list(range(12*t)), edges, list(range(6*t, 12*t)))
    assert answer["status"] == "colored"
    answer.update({"family": "triangle_block_family", "parameter": t,
                   "all_S_edges_blue_is_impossible_for_same_mixed_set": True,
                   "blue_only_obstruction": {"required_cross_degree_one_vertices": 3*t,
                                             "maximum_independent_vertices_in_S": 2*t}})
    return answer


def path_incidence_family(k):
    if type(k) is not int or k < 1:
        raise ValueError("A positive integer k is required.")
    n = 2*k
    edges = [(v, v+1) for v in range(n-1)]
    edges += [(v, n+j) for v in range(n) for j in (v, (v-1) % n)]
    edges += [(n+2*i, n+2*i+1) for i in range(k)]
    answer = color_path_cycle_partition(list(range(2*n)), edges, list(range(n, 2*n)))
    assert answer["status"] == "colored"
    answer.update({"family": "path_incidence_family", "parameter": k})
    return answer


def cycle_incidence_family(n):
    if type(n) is not int or n < 3:
        raise ValueError("A cycle length at least three is required.")
    N = 2*n
    edges = [(start+i, start+(i+1) % n) for start in (0, n) for i in range(n)]
    edges += [(v, N+j) for v in range(N) for j in (v, (v-1) % N)]
    edges += [(N+2*i, N+2*i+1) for i in range(n)]
    answer = color_path_cycle_partition(list(range(2*N)), edges, list(range(N, 2*N)))
    assert answer["status"] == "colored"
    answer.update({"family": "cycle_incidence_family", "cycle_length": n})
    return answer
