"""Standalone exact checker for the finite part of the path induction proof.

Python standard library only. Does not import the path constructor or a solver.
Each local relation is rebuilt by counting actual red/blue edge copies on a
small path with its attached tree. Arbitrary larger trees use the proved tree
port lemma; this checker is not a proof of the full mother conjecture.
"""
import itertools
import json
from pathlib import Path


TYPES = ('bare', 'leaf', 'two', 'large')
STATES = [(p, D, r) for D in (2, 3) for p in range(3)
          for r in range(p, p + (3 if D == 2 else 5))]
INDEX = {s: i for i, s in enumerate(STATES)}


def local_by_edge_copies(kind, p, R, B):
    # 7 is an infinity class. Pick a physical representative without changing
    # any comparison to an internal color count (which is at most 6).
    if R == 7 and B != 7 and (R + B) % 2:
        R = 8
    if B == 7 and R != 7 and (R + B) % 2:
        B = 8
    branch_size = {'bare': 0, 'leaf': 1, 'two': 2, 'large': 3}[kind]
    mask = 0
    for q in range(3):
        for branch in itertools.product(range(3), repeat=branch_size):
            edges = [(0, 1, p), (1, 2, q)]
            if branch_size:
                shape = [(1, 3)] + [(j, j + 1) for j in range(3, 2 + branch_size)]
                edges.extend((u, v, x) for (u, v), x in zip(shape, branch))
            red, blue = [0] * 6, [0] * 6
            red_edges, blue_edges = [], []
            for u, v, x in edges:
                for copy in range(2):
                    degrees, copies = (red, red_edges) if copy < x else (blue, blue_edges)
                    degrees[u] += 1
                    degrees[v] += 1
                    copies.append((u, v))
            red[0] += R - p
            blue[0] += B - (2 - p)
            legal_red = all((u, v) == (1, 2) or red[u] != red[v] for u, v in red_edges)
            legal_blue = all((u, v) == (1, 2) or blue[u] != blue[v] for u, v in blue_edges)
            if legal_red and legal_blue:
                D = 2 if branch_size == 0 else 3
                mask |= 1 << INDEX[(q, D, red[1])]
    return mask


def verify():
    certificate = json.loads(Path(__file__).with_name('decorated_path_certificate.json').read_text())
    assert certificate['states'] == [list(s) for s in STATES]
    levels = certificate['lower_signature_levels']
    assert [len(a) for a in levels] == [30, 19, 7, 3]
    ends = [(p, R, B) for p in range(3) for R in range(8) for B in range(8)
            if R >= p and B >= 2 - p and
            (R == 7 or B == 7 or (R + B) % 2 == 0)]
    initial = {(kind, e): local_by_edge_copies(kind, *e)
               for kind in TYPES for e in ends}
    rows = {kind: [local_by_edge_copies(kind, p, r, 2 * D - r)
                   for p, D, r in STATES] for kind in TYPES}

    def image(mask, kind):
        result = 0
        for i, row in enumerate(rows[kind]):
            if mask >> i & 1:
                result |= row
        return result

    assert all(any(mask & m == m for m in levels[0]) for mask in initial.values())
    transitions = 0
    for before, after in zip(levels, levels[1:]):
        for m in before:
            for kind in TYPES:
                value = image(m, kind)
                assert any(value & n == n for n in after)
                transitions += 1
    full = {}
    for kind in TYPES:
        full[kind] = 0
        for p in range(3):
            full[kind] |= initial[(kind, (p, 7, 7))]
    for m in levels[-1]:
        assert all(image(m, kind) == full[kind] for kind in TYPES)
    for mask in full.values():
        assert any(mask & m == m for m in levels[-1])
        for p, R, B in ends:
            assert any(mask >> i & 1 and outgoing == p and
                       (p == 0 or r != R) and (p == 2 or 2 * D - r != B)
                       for i, (outgoing, D, r) in enumerate(STATES))
    return {'verified': True, 'states': len(STATES), 'endpoint_classes': len(ends),
            'initial_cases': len(initial), 'transition_rows': sum(map(len, rows.values())),
            'coverage_transitions': transitions, 'saturation_cases': 4 * len(levels[-1]),
            'infinite_step': 'Monotonicity, saturation and induction, as stated in the note.',
            'mother_conjecture_proved': False}


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
