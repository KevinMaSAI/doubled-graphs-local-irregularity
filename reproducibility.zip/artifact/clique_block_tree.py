"""Root-offset construction for clique block trees with an explicit size condition.

Every block has order >=4. Away from the chosen root, the sum of child-block
degrees at a cut must be >= the parent-block degree. Homogeneous K_n block
trees (any fixed n>=4) automatically satisfy this, for every chosen root.
This is not a theorem for all block graphs, let alone arbitrary graphs.
"""

from collections import Counter, deque

import networkx as nx

from rooted_clique_interface import color_rooted_clique


def color_clique_block_tree(graph, root=None, red_offset=0, blue_offset=0, root_red=None):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    root = next(iter(graph)) if root is None else root
    if root not in graph:
        raise ValueError("The root must be a graph vertex.")
    A, B = red_offset, blue_offset
    target = graph.degree(root) if root_red is None else root_red
    if (type(A) is not int or type(B) is not int or A < 0 or B < 0
            or (A + B) % 2 or type(target) is not int
            or not 0 <= target <= 2 * graph.degree(root)):
        raise ValueError("The root offsets and internal red target must be feasible.")
    blocks = [list(vertices) for vertices in nx.biconnected_components(graph)]
    for vertices in blocks:
        n = len(vertices)
        if n < 4 or graph.subgraph(vertices).number_of_edges() != n * (n - 1) // 2:
            return {"status": "method_not_applicable",
                    "reason": "a_block_is_not_a_clique_of_order_at_least_four"}
    incidence = nx.Graph()
    incidence.add_nodes_from((0, v) for v in graph)
    for i, vertices in enumerate(blocks):
        incidence.add_edges_from(((1, i), (0, v)) for v in vertices)
    assert nx.is_tree(incidence)
    parent, order = {(0, root): None}, []
    queue = deque([(0, root)])
    while queue:
        node = queue.popleft()
        order.append(node)
        for nxt in incidence[node]:
            if nxt not in parent:
                parent[nxt] = node
                queue.append(nxt)
    children = {v: [] for v in graph}
    for i in range(len(blocks)):
        children[parent[(1, i)][1]].append(i)
    for v in graph:
        if v == root or not children[v]:
            continue
        p = parent[(0, v)][1]
        h = len(blocks[p]) - 1
        L = sum(len(blocks[i]) - 1 for i in children[v])
        if L < h:
            return {"status": "method_not_applicable",
                    "reason": "child_clique_degrees_smaller_than_parent_degree",
                    "vertex": v, "parent_degree": h, "child_degree_sum": L}
    current = nx.Graph()
    current.add_node(root)
    red, blue = {root: A}, {root: B}
    values, reports, modes = {}, [], Counter()

    def add_children(v, indices, amount):
        L = sum(len(blocks[i]) - 1 for i in indices)
        final_red, final_blue = red[v] + amount, blue[v] + 2 * L - amount
        remaining = amount
        for i in indices:
            vertices = [v] + [w for w in blocks[i] if w != v]
            n, r = len(vertices), len(vertices) - 1
            s = min(2 * r, remaining)
            remaining -= s
            local = color_rooted_clique(n, final_red - s,
                                       final_blue - (2 * r - s), s)
            modes.update(local["construction_modes"])
            assert all(w not in current for w in vertices[1:])
            for j, w in enumerate(vertices[1:], 1):
                current.add_node(w)
                red[w], blue[w] = local["red"][j], local["blue"][j]
            for (j, k), x in zip(local["edge_order"], local["weights"]):
                a, b = vertices[j], vertices[k]
                assert not current.has_edge(a, b)
                current.add_edge(a, b)
                values[frozenset((a, b))] = x
        assert remaining == 0
        red[v], blue[v] = final_red, final_blue
        reports.append({"vertex": v, "child_blocks": len(indices),
                        "added_degree": L, "chosen_red_contribution": amount})

    add_children(root, children[root], target)
    for kind, v in order:
        if kind != 0 or v == root or not children[v]:
            continue
        h = current.degree(v)
        assert h == len(blocks[parent[(0, v)][1]]) - 1
        L = sum(len(blocks[i]) - 1 for i in children[v])
        assert L >= h
        forbidden = set()
        for w in current[v]:
            x = values[frozenset((v, w))]
            if x > 0:
                forbidden.add(red[w] - red[v])
            if x < 2:
                forbidden.add(blue[v] + 2 * L - blue[w])
        amount = next(s for s in range(2 * h + 1) if s not in forbidden)
        add_children(v, children[v], amount)
        reports[-1]["parent_degree"] = h
        reports[-1]["forbidden_contributions"] = sorted(forbidden)
    assert set(current) == set(graph) and current.number_of_edges() == graph.number_of_edges()
    assert red[root] == A + target and blue[root] == B + 2 * graph.degree(root) - target
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for u, v in graph.edges() for x in [values[frozenset((u, v))]])
    edges = list(graph.edges())
    return {"status": "colored", "edge_order": edges,
            "weights": [values[frozenset(edge)] for edge in edges],
            "red": red, "blue": blue, "root": root,
            "root_internal_red": target, "root_offsets": [A, B],
            "assembly_reports": reports, "construction_modes": dict(modes),
            "block_orders": sorted({len(vertices) for vertices in blocks}),
            "mother_conjecture_proved": False}
