"""Attach arbitrary rooted trees to a locally irregular core using a matching.

The core's ordinary adjacent degrees must already differ. One disjoint matching
edge connects each attachment root to a distinct core vertex with no attachment.
This condition is essential to this constructor, not claimed for every graph.
"""

import networkx as nx

from tree_ports import extend_tree_bridge


def attach_trees_to_irregular_core(core, attachments, matching):
    if (core.is_directed() or core.is_multigraph() or len(core) < 2
            or nx.number_of_selfloops(core) or not nx.is_connected(core)):
        raise ValueError("A connected simple core with an edge is required.")
    if any(core.degree(u) == core.degree(v) for u, v in core.edges()):
        return {"status": "method_not_applicable", "reason": "core_not_ordinarily_locally_irregular"}
    S = set(attachments)
    if not S <= set(core):
        raise ValueError("Every attachment root must be in the core.")
    used, matching_keys, covered = set(), set(), set()
    for u, v in matching:
        if (not core.has_edge(u, v) or u in used or v in used
                or (u in S) == (v in S)):
            raise ValueError("A disjoint matching from all roots to nonroots is required.")
        used.update((u, v))
        matching_keys.add(frozenset((u, v)))
        covered.add(u if u in S else v)
    if covered != S:
        raise ValueError("The matching must cover every attachment root exactly once.")
    graph = core.copy()
    values = {frozenset(e): int(frozenset(e) in matching_keys) for e in core.edges()}
    for v, (tree, root) in attachments.items():
        if (tree.is_directed() or tree.is_multigraph() or root not in tree
                or nx.number_of_selfloops(tree) or not nx.is_tree(tree)
                or set(tree) & set(graph)):
            raise ValueError("Disjoint simple rooted trees are required.")
        # These parent counts already include its mixed old matching edge and bridge.
        colored = extend_tree_bridge(tree, root, 2, 2*core.degree(v), bridge_red=1)
        assert colored["status"] == "extended"
        graph.update(tree)
        graph.add_edge(v, root)
        values[frozenset((v, root))] = 1
        values.update(zip(map(frozenset, colored["edges"]), colored["weights"]))
    edges = list(graph.edges())
    red, blue = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    for u, v in edges:
        x = values[frozenset((u, v))]
        red[u] += x; red[v] += x; blue[u] += 2-x; blue[v] += 2-x
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for u, v in edges for x in [values[frozenset((u, v))]])
    return {"status": "colored", "graph": graph, "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges], "red": red, "blue": blue,
            "mother_conjecture_proved": False}
