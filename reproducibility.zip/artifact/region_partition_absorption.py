"""Simultaneous high-degree absorbers with arbitrary inside boundary vertices.

Every edge outside the specified induced regions is supplied and preserved.
A proper coloring of the UNION of high vertices protects inter-region edges.
Explicit minimum-degree and palette hypotheses remain essential.
"""

import networkx as nx

from chromatic_degree_factor import color_from_factor, color_with_degree_factor


def partition_absorption_plan(graph, regions, coloring, given_weights, palette_size=None):
    if (graph.is_directed() or graph.is_multigraph() or not len(graph)
            or nx.number_of_selfloops(graph) or not nx.is_connected(graph)):
        raise ValueError("A nonempty connected simple graph is required.")
    parts = [set(part) for part in regions]
    if not parts or any(not part or not part <= set(graph) for part in parts):
        raise ValueError("The regions must be nonempty vertex subsets.")
    owner = {}
    for i, part in enumerate(parts):
        if any(v in owner for v in part) or not nx.is_connected(graph.subgraph(part)):
            raise ValueError("Regions must be disjoint and each induce a connected graph.")
        owner.update({v: i for v in part})
    high = set(owner)
    if set(coloring) != high or any(coloring[u] == coloring[v]
                                   for u, v in graph.subgraph(high).edges()):
        raise ValueError("A proper coloring of the entire high-vertex graph is required.")
    values = {frozenset(e): x for e, x in given_weights.items()}
    required = {frozenset((u, v)) for u, v in graph.edges()
                if u not in owner or v not in owner or owner[u] != owner[v]}
    if (len(values) != len(given_weights) or set(values) != required
            or any(type(x) is not int or not 0 <= x <= 2 for x in values.values())):
        raise ValueError("Supply exactly all noninternal-region edges with 0/1/2 weights.")
    low = set(graph) - high
    outside_red, outside_blue = dict.fromkeys(low, 0), dict.fromkeys(low, 0)
    A, B = dict.fromkeys(high, 0), dict.fromkeys(high, 0)
    ports = {v: [] for v in high}
    for u, v in graph.edges():
        identity = frozenset((u, v))
        if identity not in values:
            continue
        x = values[identity]
        for w in (u, v):
            if w in high:
                A[w] += x
                B[w] += 2 - x
            else:
                outside_red[w] += x
                outside_blue[w] += 2 - x
        if (u in high) != (v in high):
            h, l = (u, v) if u in high else (v, u)
            ports[h].append((l, x))
    for u, v in graph.subgraph(low).edges():
        x = values[frozenset((u, v))]
        if ((x > 0 and outside_red[u] == outside_red[v])
                or (x < 2 and outside_blue[u] == outside_blue[v])):
            raise ValueError("The given low-low edges are not already locally irregular.")
    forbidden_count = {v: sum(1 + int(x == 1) for l, x in ports[v]) for v in high}
    classes = {}
    for value in coloring.values():
        if value not in classes:
            classes[value] = len(classes)
    base = {v: classes[coloring[v]] for v in high}
    c = len(classes)
    if palette_size is None:
        copies = {j: 1 + max(forbidden_count[v] for v in high if base[v] == j)
                  for j in range(c)}
        groups = {}
        next_label = 0
        for j in range(c):
            groups[j] = list(range(next_label, next_label + copies[j]))
            next_label += copies[j]
        C = max(2, next_label)
        candidates = {v: groups[base[v]] for v in high}
    else:
        C = palette_size
        if (type(C) is not int or C < 2
                or any(type(x) is not int or not 0 <= x < C for x in coloring.values())):
            raise ValueError("An explicit palette uses integer labels 0..C-1.")
        copies = None
        candidates = {v: [coloring[v]] for v in high}
    p, q = 2 * C, 2 * C + 1
    bound = 8 * C * (2 * C + 1) - 7
    degrees = [min(dict(graph.subgraph(part).degree()).values()) for part in parts]
    if any(d < bound for d in degrees):
        return {"status": "method_not_applicable", "reason": "region_minimum_degree_too_small",
                "region_minimum_degrees": degrees, "required": bound, "palette_size": C}
    labels = {}
    for v in high:
        labels[v] = next((j for j in candidates[v] if all(
            (x == 0 or outside_red[l] % p not in {2*j % p, (2*j+1) % p})
            and (x == 2 or outside_blue[l] % q not in {2*j % q, (2*j-1) % q})
            for l, x in ports[v])), None)
        if labels[v] is None:
            return {"status": "method_not_applicable",
                    "reason": "explicit_boundary_label_conflicts", "vertex": v}
    assert all(labels[u] != labels[v] for u, v in graph.subgraph(high).edges())
    return {"status": "planned", "regions": [list(part) for part in parts],
            "coloring": labels, "base_colors": base, "palette_size": C,
            "class_copy_counts": copies, "maximum_low_boundary_color_count":
                max(forbidden_count.values(), default=0),
            "red_offsets": A, "blue_offsets": B, "given_weights": values,
            "outside_red": outside_red, "outside_blue": outside_blue,
            "required_minimum_degree": bound}


def complete_region_partition(graph, regions, coloring, given_weights, factors=None,
                               palette_size=None, timeout_ms=10000):
    plan = partition_absorption_plan(graph, regions, coloring, given_weights, palette_size)
    if plan["status"] != "planned":
        return plan
    if factors is not None and len(factors) != len(plan["regions"]):
        raise ValueError("Provide one factor certificate for each region.")
    values = dict(plan["given_weights"])
    for i, part in enumerate(plan["regions"]):
        inner = graph.subgraph(part)
        labels = {v: plan["coloring"][v] for v in inner}
        A = {v: plan["red_offsets"][v] for v in inner}
        B = {v: plan["blue_offsets"][v] for v in inner}
        if factors is None:
            local = color_with_degree_factor(
                inner, labels, A, B, timeout_ms=timeout_ms, palette_size=plan["palette_size"])
        else:
            local = color_from_factor(inner, labels, factors[i], A, B,
                                      palette_size=plan["palette_size"])
        if local["status"] != "colored":
            return {"status": "factor_search_incomplete", "region": i,
                    "reason": local.get("reason", local["status"])}
        values.update(zip(map(frozenset, local["edge_order"]), local["weights"]))
    edges = list(graph.edges())
    red, blue = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    for u, v in edges:
        x = values[frozenset((u, v))]
        red[u] += x
        red[v] += x
        blue[u] += 2 - x
        blue[v] += 2 - x
    assert all(red[v] == plan["outside_red"][v] and blue[v] == plan["outside_blue"][v]
               for v in graph if v in plan["outside_red"])
    assert all((x == 0 or red[u] != red[v]) and (x == 2 or blue[u] != blue[v])
               for u, v in edges for x in [values[frozenset((u, v))]])
    return {"status": "colored", "edge_order": edges,
            "weights": [values[frozenset(e)] for e in edges],
            "red": red, "blue": blue, "partition_plan": plan,
            "all_given_colors_preserved": True, "mother_conjecture_proved": False}
