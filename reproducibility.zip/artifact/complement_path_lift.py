"""Lift a coloring across a four-vertex subdivision in the COMPLEMENT.

Requires an existing legal coloring, maximum original degree at most n-3,
and a chosen nonedge whose endpoints have different counts in a chosen color.
The theorem is conditional, not an arbitrary-graph mother-conjecture solver.
"""

import networkx as nx


def _counts(graph, values):
    R, B = dict.fromkeys(graph, 0), dict.fromkeys(graph, 0)
    for u, v in graph.edges():
        x = values[frozenset((u, v))]
        R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x
    return R, B


def lift_complement_edge(graph, weights, u, v, new_vertices, contrast_color=None):
    if (graph.is_multigraph() or graph.is_directed() or nx.number_of_selfloops(graph)
            or len(graph) < 3):
        raise ValueError("A simple undirected graph on at least three vertices is required.")
    if u not in graph or v not in graph or u == v or graph.has_edge(u, v):
        raise ValueError("Choose a nonedge with two distinct existing endpoints.")
    new_vertices = list(new_vertices)
    if len(new_vertices) != 4 or len(set(new_vertices)) != 4 or set(new_vertices) & set(graph):
        raise ValueError("Four distinct fresh vertex identifiers are required.")
    values = {frozenset(edge): x for edge, x in weights.items()}
    if (len(values) != len(weights) or set(values) != {frozenset(e) for e in graph.edges()}
            or any(type(x) is not int or x not in (0, 1, 2) for x in values.values())):
        raise ValueError("Supply exactly the old edges and integer red-copy counts.")
    R, B = _counts(graph, values)
    if any((x > 0 and R[s] == R[t]) or (x < 2 and B[s] == B[t])
           for s, t in graph.edges() for x in [values[frozenset((s, t))]]):
        raise ValueError("The supplied old coloring must already be legal.")
    n = len(graph)
    if max(dict(graph.degree()).values()) > n-3:
        return {"status": "method_not_applicable", "reason": "old_maximum_degree_exceeds_n_minus_3"}
    if contrast_color is None:
        contrast_color = "blue" if B[u] != B[v] else "red"
    if contrast_color not in ("red", "blue"):
        raise ValueError("contrast_color must be red or blue.")
    counter = R if contrast_color == "red" else B
    if counter[u] == counter[v]:
        return {"status": "method_not_applicable", "reason": "chosen_nonedge_lacks_color_contrast"}
    a, b, c, d = new_vertices
    added = {frozenset((u, v)): 0, frozenset((a, c)): 1,
             frozenset((b, d)): 2, frozenset((a, d)): 0}
    for w in graph:
        if w != u:
            added[frozenset((w, a))] = 0
        if w != v:
            added[frozenset((w, d))] = 0
        added[frozenset((w, b))] = 2
        added[frozenset((w, c))] = 2
    if contrast_color == "red":
        added = {e: 2-x for e, x in added.items()}
    final = graph.copy()
    final.add_nodes_from(new_vertices)
    final.add_edges_from(tuple(e) for e in added)
    all_values = dict(values)
    all_values.update(added)
    final_R, final_B = _counts(final, all_values)
    assert all(final_R[w] == R[w]+4 and final_B[w] == B[w]+4 for w in graph)
    assert all(all_values[e] == x for e, x in values.items())
    assert all((x == 0 or final_R[s] != final_R[t]) and
               (x == 2 or final_B[s] != final_B[t])
               for s, t in final.edges() for x in [all_values[frozenset((s, t))]])
    path = [u, a, b, c, d, v]
    assert all(not final.has_edge(s, t) and
               (final_R[s] != final_R[t] or final_B[s] != final_B[t])
               for s, t in zip(path, path[1:]))
    assert max(dict(final.degree()).values()) <= len(final)-3
    edge_order = list(final.edges())
    return {"status": "colored", "graph": final, "edge_order": edge_order,
            "weights": [all_values[frozenset(e)] for e in edge_order],
            "red": final_R, "blue": final_B, "complement_path": path,
            "contrast_color": contrast_color, "old_counts_increased_by_four": True,
            "old_colors_preserved": True, "mother_conjecture_proved": False}
