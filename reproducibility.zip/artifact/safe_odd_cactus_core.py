"""Free pure ports on a subcubic cactus whose cycle blocks are all odd.

The six rooted relations are certified by a finite 9-state matrix closure.
The graph may have arbitrarily many odd blocks and arbitrarily long odd
cycles. Ports are PRIVATE FREE variables, not prescribed boundary data.
The new safe_cactus_core API accepts both cycle parities and one specified
private port. The original odd-only public API retains its scope.
"""

import itertools

import networkx as nx

from safe_tree_core import SAFE, STATES, TYPES

C_TYPES = dict(TYPES) | {
    "C": {(0, 0), (0, 1), (1, 3), (2, 5), (2, 6)},
    "D": {(0, 0), (0, 1), (0, 3), (1, 3), (2, 3), (2, 5), (2, 6)},
    "E": {(0, 0), (0, 1), (1, 1), (1, 3), (1, 5), (2, 5), (2, 6)},
}


def odd_cactus_cycles(core):
    """Return ordered cycle blocks, or None outside the exact scope."""
    return cactus_cycles(core, odd_only=True)


def cactus_cycles(core, odd_only=False):
    """Cycles of a subcubic cactus; optionally retain the old odd scope."""
    if core.is_directed() or core.is_multigraph() or nx.number_of_selfloops(core):
        return None
    if not len(core) or not nx.is_connected(core) or max(dict(core.degree()).values()) > 3:
        return None
    cycles = []
    for vertices in nx.biconnected_components(core):
        if len(vertices) == 2:
            continue
        block = core.subgraph(vertices)
        if (odd_only and len(vertices) % 2 == 0) or any(block.degree(v) != 2 for v in block):
            return None
        start = next(iter(block))
        order, previous, current = [start], None, start
        while True:
            other = next(v for v in block[current] if v != previous)
            if other == start:
                break
            order.append(other)
            previous, current = current, other
        assert len(order) == len(block)
        cycles.append(order)
    assert sum(map(len, cycles)) == len({v for cycle in cycles for v in cycle})
    return cycles


def safe_odd_cactus_core(core):
    cycles = odd_cactus_cycles(core)
    if cycles is None:
        return {"status": "method_not_applicable", "reason": "not_subcubic_odd_cactus",
                "mother_conjecture_proved": False}
    return _safe_cactus_core(core, cycles)


def safe_cactus_core(core, marked_vertex=None, marked_value=0, marked_red=None,
                     forbid_balanced=False):
    """All cycle parities; one actual private port can be prescribed.

    The marked port is boundary_ports[marked_vertex][0]. Other private
    ports remain free and pure. With a bipartite cactus, marked_value=1
    and forbid_balanced=True always succeeds (marked root red 1 or 5).
    General cacti may have only red 3 for a mixed marked port.
    """
    cycles = cactus_cycles(core)
    if cycles is None:
        return {"status": "method_not_applicable", "reason": "not_subcubic_cactus",
                "mother_conjecture_proved": False}
    if marked_value not in (0, 1, 2):
        raise ValueError("The marked value must be zero, one or two.")
    if marked_vertex is not None and (marked_vertex not in core or core.degree(marked_vertex) > 2):
        raise ValueError("The marked vertex must have an available private port.")
    return _safe_cactus_core(core, cycles, marked_vertex, marked_value, marked_red, forbid_balanced)


def _safe_cactus_core(core, cycles, marked_vertex=None, marked_value=0,
                      marked_red=None, forbid_balanced=False):
    by_vertex = {v: cycle for cycle in cycles for v in cycle}
    root = (next(v for v in core if core.degree(v) <= 2)
            if marked_vertex is None else marked_vertex)
    units, owner = [], {}
    def add_unit(v, p):
        if v in by_vertex:
            cycle = by_vertex[v]
            k = cycle.index(v)
            order = cycle[k:] + cycle[:k]
        else:
            order = [v]
        index = len(units)
        assert all(w not in owner for w in order)
        owner.update({w: index for w in order})
        units.append({"anchor": v, "parent": p, "order": order, "children": []})
        return index
    add_unit(root, None)
    for i, unit in enumerate(units):
        local = set(unit["order"])
        for v in unit["order"]:
            for w in core[v]:
                if w in local or (v == unit["anchor"] and w == unit["parent"]):
                    continue
                assert w not in owner
                child = add_unit(w, v)
                unit["children"].append((v, w, child))
        if len(unit["order"]) > 1:
            assert all(v != unit["anchor"] for v, w, child in unit["children"])
            assert len({v for v, w, child in unit["children"]}) == len(unit["children"])
        else:
            assert len(unit["children"]) <= 2
    assert set(owner) == set(core)
    possible, kinds = {}, {}
    def cycle_witness(unit, incoming, anchor_red):
        order = unit["order"]
        children = {v: child for v, w, child in unit["children"]}
        for first in range(3):
            last = anchor_red - incoming - first
            if last not in (0, 1, 2):
                continue
            current, histories = {(first, anchor_red)}, []
            for v in order[1:]:
                following = {}
                options = ([(p, s, (p, s)) for p, s in sorted(possible[children[v]])]
                           if v in children else [(0, None, None), (2, None, None)])
                for old in sorted(current):
                    x, old_red = old
                    for z in range(3):
                        for p, child_red, child_state in options:
                            r = x + z + p
                            if r in SAFE and r != old_red and r != child_red:
                                following.setdefault((z, r), (old, p, child_state))
                if not following:
                    break
                histories.append(following)
                current = set(following)
            if len(histories) != len(order) - 1:
                continue
            candidates = [state for state in sorted(current) if state[0] == last and state[1] != anchor_red]
            if not candidates:
                continue
            state = candidates[0]
            edge_trace, extras = [state], []
            for history in reversed(histories):
                old, p, child_state = history[state]
                extras.append((p, child_state))
                edge_trace.append(old)
                state = old
            edge_trace.reverse()
            extras.reverse()
            word = [state[0] for state in edge_trace]
            reds = [anchor_red] + [state[1] for state in edge_trace[1:]]
            assert len(word) == len(order) and len(reds) == len(order)
            return {"word": word, "reds": reds, "extras": extras}
        return None
    for i in reversed(range(len(units))):
        unit = units[i]
        records = {}
        if len(unit["order"]) == 1:
            children = unit["children"]
            domains = [sorted(possible[child]) for v, w, child in children]
            for x in range(3):
                for choices in itertools.product(*domains):
                    for ports in itertools.product((0, 2), repeat=2 - len(children)):
                        r = x + sum(y for y, s in choices) + sum(ports)
                        if r in SAFE and all(r != s for y, s in choices):
                            records.setdefault((x, r), {"choices": choices, "ports": ports})
        else:
            for x, r in sorted(STATES):
                witness = cycle_witness(unit, x, r)
                if witness is not None:
                    records[(x, r)] = witness
        kind = next((name for name, states in C_TYPES.items() if set(records) == states), None)
        assert kind is not None, (unit["order"], sorted(records))
        possible[i], kinds[i] = records, kind
    candidates = [state for state in sorted(possible[0]) if state[0] == marked_value
                  and (marked_red is None or state[1] == marked_red)
                  and (not forbid_balanced or state[1] != 3)]
    if not candidates:
        return {"status": "method_not_applicable", "reason": "requested_marked_state_not_available",
                "root_type": kinds[0], "available_states": sorted(possible[0]),
                "mother_conjecture_proved": False}
    initial = candidates[0]
    boundary, red, values = {v: [] for v in core}, {}, {}
    boundary[root].append(marked_value)
    pending = [(0, initial)]
    while pending:
        i, state = pending.pop()
        unit, witness = units[i], possible[i][state]
        red[unit["anchor"]] = state[1]
        if len(unit["order"]) == 1:
            v = unit["anchor"]
            boundary[v].extend(witness["ports"])
            for (v, w, child), child_state in zip(unit["children"], witness["choices"]):
                values[frozenset((v, w))] = child_state[0]
                pending.append((child, child_state))
        else:
            order, word = unit["order"], witness["word"]
            for u, v, weight in zip(order, order[1:] + order[:1], word):
                values[frozenset((u, v))] = weight
            children = {v: (w, child) for v, w, child in unit["children"]}
            for v, r, (p, child_state) in zip(order[1:], witness["reds"][1:], witness["extras"]):
                red[v] = r
                if v in children:
                    w, child = children[v]
                    assert p == child_state[0]
                    values[frozenset((v, w))] = p
                    pending.append((child, child_state))
                else:
                    boundary[v].append(p)
    edges = list(core.edges())
    weights = [values[frozenset(edge)] for edge in edges]
    assert all(len(boundary[v]) == 3 - core.degree(v) for v in core)
    assert all(red[v] in SAFE and red[v] == sum(boundary[v]) + sum(
        values[frozenset((v, w))] for w in core[v]) for v in core)
    assert all(red[u] != red[v] for u, v in edges)
    return {"status": "weighted", "edge_order": edges, "weights": weights,
            "boundary_ports": boundary, "red": red, "interface_types": kinds,
            "cycle_lengths": [len(cycle) for cycle in cycles],
            "skeleton": "odd_cactus" if all(len(cycle) % 2 for cycle in cycles) else "cactus",
            "marked_vertex": root, "marked_value": marked_value, "marked_red": red[root],
            "mother_conjecture_proved": False}
