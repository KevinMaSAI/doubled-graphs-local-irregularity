"""Actual-copy checks and the all-h fixed-color threshold obstruction."""

import json
from pathlib import Path
import random
import time

import networkx as nx

from check_matching_long_branch_coloring import verify
from clique_block_tree import color_clique_block_tree
from clique_bouquet_extension import extend_by_clique_bouquet, color_core_with_clique_bouquets
from rooted_clique_interface import color_rooted_clique


def old_sharp_example(h):
    even = list(range(0, 2 * h - 1, 2))
    odd = list(range(1, 2 * h - 1, 2))
    pairs = []
    for row in (even, odd):
        end = len(row) if len(row) % 2 == 0 else len(row) - 3
        pairs.extend((row[j + 1], row[j]) for j in range(0, end, 2))
        if len(row) % 2:
            pairs.extend([(row[-2], row[-3]), (row[-1], row[-2])])
    assert len(pairs) == h and all(a == b + 2 for a, b in pairs)
    assert {x for pair in pairs for x in pair} == set(range(2 * h - 1))
    graph = nx.complete_graph(h + 1)
    values = {frozenset(edge): 1 for edge in graph.edges()}
    next_label = h + 1
    for v, (a, b) in enumerate(pairs, 1):
        vertices = [v] + list(range(next_label, next_label + h))
        next_label += h
        local = color_rooted_clique(h + 1, h, h, a)
        assert local["red"][0] == h + a and local["blue"][0] == 3 * h - 2 - b
        for (i, j), x in zip(local["edge_order"], local["weights"]):
            u, w = vertices[i], vertices[j]
            graph.add_edge(u, w)
            values[frozenset((u, w))] = x
    edges = list(graph.edges())
    red = dict.fromkeys(graph, 0)
    for u, v in edges:
        x = values[frozenset((u, v))]
        red[u] += x
        red[v] += x
    result = {"status": "colored", "edge_order": edges,
              "weights": [values[frozenset(e)] for e in edges], "red": red,
              "blue": {v: 2 * graph.degree(v) - red[v] for v in graph}}
    verify(graph, result)
    return graph, result, pairs


def main():
    started = time.monotonic()
    rng = random.Random(2026102753)
    extensions, arbitrary_cores, threshold_obstructions, repairs = 0, 0, 0, 0
    maximum_core_degree, maximum_final_degree = 0, 0
    for core in nx.graph_atlas_g():
        if not len(core) or not nx.is_connected(core):
            continue
        orders = {v: [4] * ((core.degree(v) + 2) // 3) for v in core}
        graph, result = color_core_with_clique_bouquets(core, orders)
        verify(graph, result)
        assert all(x == 1 for e, x in zip(result["edge_order"], result["weights"]) if core.has_edge(*e))
        arbitrary_cores += 1
    for trial in range(160):
        n = rng.randrange(3, 45)
        core = nx.random_labeled_tree(n, seed=rng.randrange(10 ** 9))
        for u in core:
            for v in range(u + 1, n):
                if rng.random() < 0.13:
                    core.add_edge(u, v)
        maximum_core_degree = max(maximum_core_degree, max(dict(core.degree()).values()))
        orders = {}
        for v in core:
            row, capacity = [], 0
            while capacity < core.degree(v):
                size = rng.randrange(4, 10)
                row.append(size)
                capacity += size - 1
            orders[v] = row
        graph, result = color_core_with_clique_bouquets(core, orders)
        verify(graph, result)
        arbitrary_cores += 1
        root = rng.choice(list(graph))
        h = graph.degree(root)
        extended, new = extend_by_clique_bouquet(graph, result, root, [h + 1 if h >= 3 else 4])
        verify(extended, new)
        before = dict(zip(map(frozenset, result["edge_order"]), result["weights"]))
        assert all(before[frozenset(e)] == x for e, x in zip(new["edge_order"], new["weights"])
                   if graph.has_edge(*e))
        maximum_final_degree = max(maximum_final_degree, max(dict(extended.degree()).values()))
        extensions += 1
    for h in range(4, 26):
        graph, old, pairs = old_sharp_example(h)
        assert graph.degree(0) == h and old["red"][0] == old["blue"][0] == h
        for s in range(2 * h - 1):
            R, B = h + s, 3 * h - 2 - s
            assert any(R == old["red"][v] or B == old["blue"][v] for v in graph[0])
        threshold_obstructions += 1
        unused, rejected = extend_by_clique_bouquet(graph, old, 0, [h])
        assert unused is None and rejected["reason"] == "added_clique_capacity_smaller_than_old_degree"
        fresh = list(range(max(graph) + 1, max(graph) + h))
        vertices = [0] + fresh
        full = graph.copy()
        full.add_edges_from((u, v) for j, u in enumerate(vertices) for v in vertices[j + 1:])
        repaired = color_clique_block_tree(full, root=0)
        verify(full, repaired)
        old_weights = dict(zip(map(frozenset, old["edge_order"]), old["weights"]))
        assert any(old_weights[frozenset(e)] != x for e, x in
                   zip(repaired["edge_order"], repaired["weights"]) if graph.has_edge(*e))
        repairs += 1
        extended, preserved = extend_by_clique_bouquet(graph, old, 0, [h + 1])
        verify(extended, preserved)
        extensions += 1
    output = {"arbitrary_unknown_core_constructions_verified": arbitrary_cores,
              "given_coloring_extensions_verified": extensions,
              "all_h_threshold_obstructions_verified": threshold_obstructions,
              "explicit_recolored_repairs_verified": repairs,
              "maximum_random_core_degree": maximum_core_degree,
              "maximum_random_extension_degree": maximum_final_degree,
              "all_checks_passed": True, "mother_conjecture_proved": False,
              "scope": "Capacity conditions are required; the all-h obstructions concern only preserving a specified old coloring.",
              "seconds": round(time.monotonic() - started, 3)}
    path = Path(__file__).parent
    (path / "clique_bouquet_extension_validation.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
