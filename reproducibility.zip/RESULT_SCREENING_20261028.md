# Screening ledger, 28 October 2026

| Candidate | Decision | Reason and containment |
|---|---|---|
| Signed-gap/paired-partition note | Retain as E1 | Complete self-contained proof; arbitrary paired degrees. Even-row nonvanishing alone was already weaker. |
| Path/cycle-side note | Retain as E2 | Extends the degree-three/four graph application of E1 to longer internal components; does not replace its arbitrary-degree version. |
| Isolated-side parity note | Retain exact and protected claims as E3 | Fixed interface and mixed paired/isolated-side guarantees are absent from E4. |
| Even-component parity swap | Fold into a corollary | E4 with no odd components includes this existence theorem. |
| Odd-component root-port note | Retain as E4 | Arbitrary maximum degree and odd components, with explicit required port certificate. |
| Biased maximum-cut decomposition | Supporting lemma | Elementary proof locates remaining isolated-side gap; no standalone novelty claim. |
| Bipartite/root-pairing examples | Method comparisons only | Bipartite colourability already follows from the cited literature. |
| Partial component-DP work | Exclude at cutoff | No completed written theorem/finished stage record at 10:25:33; finite code success alone does not promote a theorem. |

Proof review checks: the signed graph has no loops and critical bad degrees are at
least two; each chosen crossing variable appears in at most two rows; odd five-term
rows exclude both forbidden even-path endpoint values; binary relation cycles include
the four-cycle/two-parallel-relation case; additional mixed edges avoid protected
endpoints and paired T vertices; the exact independent-side criterion compares actual
integer degrees; root ports of unrestricted odd size are allowed only for internally
isolated roots; larger nonisolated crossing capacity needs a qualified supplied port
set rather than an unjustified parity-only assertion.

This is a mathematical and artifact-selection review, not an exhaustive novelty
survey or an independent peer review. The unrestricted conjecture remains unproved.
