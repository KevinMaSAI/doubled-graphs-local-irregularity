# Doubled graphs: expanded English preprint and reproducible artifact

**Author:** Qiyuan Ma, Shanghai Jiao Tong University.  
**ORCID:** https://orcid.org/0009-0000-9532-0821.
**Contact:** [mqyqwerty@sjtu.edu.cn](mailto:mqyqwerty@sjtu.edu.cn).  
**Date:** 28 October 2026. **Local revision:** 1.1.1.  
**Title:** Locally Irregular Two-Edge-Colourings of Doubled Graphs: Constructions, Extensions, and Obstructions.

This local research preprint contains the full A1 proof, the retained A2–A9 constructions,
B1–B4 tools and C1–C5 strategy obstructions, and completed main-task results after 17:00
China Standard Time through the source snapshot at **20:31:04 on 27 October 2026**.
The two screenshot conditions are Theorem D1 and Theorem D3 in the coverage ledger.
Revision 1.1.1 additionally includes the four completed notes E1--E4 frozen at
10:25:33 China Standard Time on 28 October 2026: signed gaps, paired and path/cycle
partitions, protected/fixed parity joins, and arbitrary-degree odd-component root ports.
The unrestricted mother conjecture remains unproved. Later results, including the component-dynamic-programming note completed after that
cutoff, lie outside this fixed snapshot. Historical priority and external peer review are not claimed.

## Read the paper

- `paper.pdf`: compiled English manuscript, including its complete proof and certificate appendices.
- `manuscript/main.tex`: editable main source; all section files are in the same directory.
- `COVERAGE.md`: map from every retained inventory group to English proofs, code and certificates.
- `PROOF_DEPENDENCIES.md`: classical dependencies and exactly where finite certificates enter.
- `references.bib`: editable bibliography; the TeX source also has a self-contained bibliography.

## Check complete finite proof data without third-party packages

From the extracted archive, with Python 3.10 or later, run:

```text
python -I -B verify.py
```

Do not use `-O`. This requires no network, NetworkX, solver, Lean, account or service.
It verifies all A1 certificate domains, independently recomputes its local two-mark kernel,
verifies all 836 clique bases and the decorated-path saturation domain, checks submitted
graph witnesses by actual copy-degree counting, and recalculates the documented finite
obstructions and arithmetic identities. It additionally executes the four portable E1--E4 standard-library auditors, which
recount 972 actual copies and rederive saved rows, truth tables, parity cuts and
strategy obstructions without importing the constructors or solvers. It also checks
the immutable release manifest if present.
Use `--output validation/my_certificate_run.json` to save a new report. Original release reports
are in `validation/`; they are excluded from immutable checksums so local reruns are permitted.

## Run constructive implementation tests

Use Python 3.12 or later (NetworkX 3.7 excludes Python 3.14.1), then:

```text
python -m pip install -r requirements.txt
python -B run_checks.py
```

The runner copies the released code and data to a uniquely named directory under
`validation/constructor_workspace_*`, executes the constructor checks there, and keeps
bounded logs in `validation/constructor_logs/`. It preserves released witnesses and certificates.
Constructor workspaces are not part of the distributed archive or immutable manifest.
Some high-degree witness recovery uses Z3; a timeout is reported as unfinished, never UNSAT.
Explicit submitted witnesses and complete certificate verification do not need that search.

`construct.py` is the A1 graph constructor. Run `python construct.py --help` for its JSON interface.
`check_constructor.py` independently audits full subcubic constructions. Other family-specific
constructors and scope gates are in `artifact/`, paired with their `check_*.py` scripts.
`extra_checks.py` checks tree candidates, target matching/factor tools, tree elimination,
energy cleanup, universal-vertex preservation, parity-radius families and algebraic identities.

## Build the PDF

With a standard TeX distribution run `pdflatex main.tex` twice from `manuscript/`,
or run `tectonic main.tex`. No shell escape or bibliography processor is needed.
The local release was built with Tectonic; the standard Latin Modern and AMS fonts are embedded.

## Provenance and status

`provenance/original_source/` is the complete frozen source snapshot with hashes in
`provenance/source_manifest.json`. The earlier Chinese notes are provenance, not a
substitute for the English proofs. `provenance/original_notes/` preserves the same note-only view.
Some original notes record intermediate scopes; the final English statements and
`COVERAGE.md` determine the claims of this release. Original research diagnostics are
distinct from new release checks. `provenance/additional_research_code/` retains the
unmodified coefficient modules used for the supplemental formula checks. Their released
copies only relocate CLI report paths; `check_balanced_subdivision.py` also accepts
the archive's `artifact` directory name as its output location. Mathematical algorithms
are unchanged by these portability edits.

Extensive AI assistance is disclosed in the paper and `AI_ASSISTANCE.md`. No external
independent review or formal verification is claimed. Existing matching/factor/degree-list
results and interpolation tools are explicitly attributed; these are not all new theorems.
No upload, repository deposit, DOI reservation or journal submission has been performed.
The author selected CC BY 4.0 for the manuscript/documentation/certificates and MIT for Python code; see `LICENSES.md` and `LICENSES/`.

The 28 October source snapshot is separately frozen in
`provenance/updates_20261028/`; the previous source snapshot and all
previous mathematical code/certificates remain preserved. `CHANGES_20261028.md`
and `RESULT_SCREENING_20261028.md` explain selection and containment.

The final content review is in `FINAL_CONTENT_AUDIT.md`. `audit_content.py`
is run by `verify.py` and adds independent endpoint and documentation checks.
