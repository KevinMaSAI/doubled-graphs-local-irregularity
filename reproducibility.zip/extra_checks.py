"""Independent small-instance checks for the general tools, not a universal proof."""
from pathlib import Path
from itertools import product
from collections import defaultdict
import json
import random
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'artifact'))
import networkx as nx


def counts(g, xs, red_offsets=None, blue_offsets=None):
    r={v:(red_offsets or {}).get(v,0) for v in g}
    b={v:(blue_offsets or {}).get(v,0) for v in g}
    es=list(g.edges())
    assert len(es)==len(xs)
    for (u,v),x in zip(es,xs):
        assert x in (0,1,2)
        for w in (u,v):r[w]+=x;b[w]+=2-x
    psi=sum(x*(r[u]==r[v])+(2-x)*(b[u]==b[v]) for (u,v),x in zip(es,xs))
    return r,b,psi


def tree_checks():
    from tree_ports import tree_port_witnesses
    exact=0;witnesses=0
    for n in range(1,8):
        trees=[nx.empty_graph(1)] if n==1 else nx.nonisomorphic_trees(n)
        for g in trees:
            es=list(g.edges());assignments=[]
            for xs in product(range(3),repeat=len(es)):
                r,b,_=counts(g,xs);assignments.append((xs,r,b))
            for root in g:
                result=tree_port_witnesses(g,root)
                for c in range(3):
                    allowed=set()
                    for xs,r,b in assignments:
                        R=dict(r);B=dict(b);R[root]+=c;B[root]+=2-c
                        if all((x==0 or R[u]!=R[v]) and (x==2 or B[u]!=B[v])
                               for (u,v),x in zip(es,xs)):allowed.add(r[root])
                    for p,xs in result['ports'][c].items():
                        rr,bb,psi=counts(g,xs,{root:c},{root:2-c})
                        assert psi==0 and rr[root]-c==p and p in allowed
                        witnesses+=1
                    if n==1:assert allowed=={0}
                    elif n==2:assert allowed==({0} if c==0 else {2} if c==2 else {0,1,2})
                    elif c==1:assert len(allowed)>=3
                    else:assert len(allowed)>=2
                    exact+=1
    return {'exact_root_port_domains':exact,'returned_witnesses_checked':witnesses}


def target_checks():
    from fixed_degree_coloring import minimum_conflicts_at_red_degrees,coloring_with_red_degrees,degree_exchange_toward
    from target_obstructions import coloring_target_certificate
    cases=0;exchanges=0
    rng=random.Random(2026102742)
    graphs=[nx.empty_graph(1),nx.path_graph(2),nx.path_graph(3),nx.path_graph(4),
            nx.cycle_graph(3),nx.cycle_graph(4),nx.complete_graph(4)]
    for g in graphs:
        nodes=list(g);es=list(g.edges());D={};sources={}
        for xs in product(range(3),repeat=len(es)):
            r,b,psi=counts(g,xs);q=tuple(r[v] for v in nodes)
            D[q]=min(D.get(q,2*len(es)+1),psi);sources[q]=xs
        for q,expected in D.items():
            targets=dict(zip(nodes,q))
            answer=minimum_conflicts_at_red_degrees(g,targets)
            assert answer['status']=='optimal' and answer['minimum_bad_copies']==expected
            assert counts(g,answer['weights'])[2]==expected
            legal=coloring_with_red_degrees(g,targets)
            assert (legal['status']=='feasible')==(expected==0)
            cert=coloring_target_certificate(g,targets)
            assert (cert['status']=='integer_feasible')==(expected==0)
            cases+=1
        pairs=list(D)
        for unused in range(30):
            q=rng.choice(pairs);r=rng.choice(pairs)
            differing=[v for v,a,b in zip(nodes,q,r) if a!=b]
            if not differing:continue
            v=rng.choice(differing)
            ans=degree_exchange_toward(g,sources[q],sources[r],v)
            Q,_,_=counts(g,ans['weights']);R,_,_=counts(g,ans['opposite_weights'])
            assert sum(abs(Q[v]-r[i]) for i,v in enumerate(nodes))==sum(abs(q[i]-r[i]) for i in range(len(nodes)))-2
            assert all(Q[v]+R[v]==q[i]+r[i] for i,v in enumerate(nodes))
            exchanges+=1
    return {'fixed_target_optima_and_factor_criteria':cases,'two_sided_degree_exchanges':exchanges}


def reduction_checks():
    from core_tree_boundary import attachment_sum_profile
    from high_degree_cleanup import remove_extreme_bad_colors
    from universal_vertex_extension import extend_universal_vertex
    profiles=0;cleanup=0;universals=0
    for h in range(2,5):
        for l,s,b in product(range(3),repeat=3):
            D=h+l+s+b
            for q in range(2*D+1):
                B=2*D-q
                L=[c for c in range(3) if (c!=0 or B!=2) and (c!=1 or(q!=1 and B!=1)) and(c!=2 or q!=2)]
                S=[c for c in range(3) if(c!=0 or B!=4) and(c!=2 or q!=4)]
                possible={0}
                for choices in [L]*l+[S]*s+[list(range(3))]*b:
                    possible={a+c for a in possible for c in choices}
                possible={a for a in possible if q-2*h<=a<=q}
                prof=attachment_sum_profile(h,l,s,b,q)
                returned=set(range(prof['minimum'],prof['maximum']+1,prof['step']))
                assert possible==returned
                profiles+=1
    for g in [nx.path_graph(3),nx.path_graph(4),nx.cycle_graph(3),nx.complete_graph(4)]:
        for xs in product(range(3),repeat=g.number_of_edges()):
            ans=remove_extreme_bad_colors(g,xs)
            r,b,_=counts(g,ans['weights'])
            for (u,v),x in zip(g.edges(),ans['weights']):
                if x and r[u]==r[v]:assert 2<=r[u]<=max(g.degree(u),g.degree(v))
                if x<2 and b[u]==b[v]:assert 2<=b[u]<=max(g.degree(u),g.degree(v))
            cleanup+=1
    bases=[nx.empty_graph(1),nx.empty_graph(3),nx.path_graph(2),nx.path_graph(3),nx.star_graph(3),
           nx.cycle_graph(3),nx.complete_graph(4),nx.disjoint_union(nx.path_graph(2),nx.empty_graph(1))]
    for h in bases:
        oldedges=list(h.edges());small=set()
        for C in nx.connected_components(h):
            if len(C)==2:small.update(frozenset(e) for e in h.subgraph(C).edges())
        selectable=[e for e in oldedges if frozenset(e) not in small]
        for xs in product(range(3),repeat=len(selectable)):
            byedge=dict(zip(map(frozenset,selectable),xs))
            old=[None if frozenset(e) in small else byedge[frozenset(e)] for e in oldedges]
            large=h.copy();large.remove_edges_from([e for e in oldedges if frozenset(e) in small])
            checkxs=[byedge[frozenset(e)] for e in large.edges()]
            if counts(large,checkxs)[2]:continue
            z=max(h,default=-1)+1;g=h.copy();g.add_node(z);g.add_edges_from((z,v) for v in h)
            if len(g)==2:continue
            ans=extend_universal_vertex(g,z,old)
            assert counts(g,ans['weights'])[2]==0
            actual=dict(zip(map(frozenset,g.edges()),ans['weights']))
            assert all(a is None or actual[frozenset(e)]==a for e,a in zip(oldedges,old))
            universals+=1
    return {'exact_branch_sum_profiles':profiles,'cleanup_all_assignments':cleanup,
            'preserved_universal_vertex_extensions':universals}


def radius_checks():
    from parity_repair_obstruction import repair_obstruction
    total=0
    for c in (2,4,6,8,10):
        for k in range(1,5):
            d=repair_obstruction(c,k);g=d['graph'];es=list(g.edges())
            x=[d['parity_repaired_coloring'][tuple(sorted(e))] for e in es]
            r,b,psi=counts(g,x)
            assert psi==0 and all(r[v]%2==d['parity'][v] for v in g)
            assert max(abs(r[v]-d['target'][v]) for v in g)==2*((c+3)//4)
            y=[d['free_coloring'][tuple(sorted(e))] for e in es]
            assert counts(g,y)[2]==0
            total+=1
    return {'explicit_unbounded_radius_family_cases':total}


def algebra_checks():
    from parity_certificate import predicted_parameter_coefficient,exact_parameter_coefficient
    cases=0
    for g in [nx.path_graph(3),nx.path_graph(4),nx.cycle_graph(3),nx.star_graph(3),nx.complete_graph(4)]:
        edges=list(g.edges())
        for mask in range(1<<len(edges)):
            S=[i for i in range(len(edges)) if mask>>i&1]
            assert exact_parameter_coefficient(g,S)%2==predicted_parameter_coefficient(g,S)
            cases+=1
    return {'exact_free_parameter_minor_identities':cases}


def main():
    assert __debug__
    started=time.monotonic()
    report={}
    for name,fn in [('trees',tree_checks),('targets',target_checks),('reductions',reduction_checks),
                    ('radius',radius_checks),('algebra',algebra_checks)]:
        report[name]=fn();print(json.dumps({name:report[name]}),flush=True)
    report.update(all_checks_passed=True,mother_conjecture_proved=False,seconds=round(time.monotonic()-started,3))
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
