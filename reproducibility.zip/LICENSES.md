# Licence scopes — author-confirmed release

Copyright (c) 2026 Qiyuan Ma.

| Material | Licence |
|---|---|
| Manuscript PDF and TeX, original documentation, original research notes, bibliography and finite certificate/witness data (JSON) | Creative Commons Attribution 4.0 International, SPDX `CC-BY-4.0` |
| All original Python source files, including copies preserved for provenance | MIT, SPDX `MIT` |

The licences apply by material type, not as two simultaneous licences on every file.
Full texts are in `LICENSES/CC-BY-4.0.txt` and `LICENSES/MIT.txt`.
The author explicitly approved these scopes on 27 October 2026.
Historical licence-status statements in frozen earlier notes describe the earlier local drafts;
this file states the grant for this release. Referenced third-party publications and
unbundled dependencies retain their respective rights and licences.
No Zenodo upload, publication, or DOI reservation is implied by this licence grant.
