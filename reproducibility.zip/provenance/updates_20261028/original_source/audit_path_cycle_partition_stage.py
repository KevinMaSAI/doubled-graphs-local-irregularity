"""Independent finite certificate audit, stdlib only, no author imports."""

import ast
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT/"outputs"
COMPAT = Path(r"C:\Users\马\Documents\Codex\2026-10-26\for-every-connected-graph-g-which\outputs\mother_conjecture")
assert COMPAT.resolve() == OUT.resolve()
SCRIPTS = ["path_cycle_partition.py", "check_path_cycle_partition.py", "signed_gap_two.py"]
DOCS = ["三四度核心中路径与圈侧的整数补色_20261028.md", "README.md"]
RECORDS = ["path_cycle_partition_validation.json", "path_cycle_partition_witnesses.json"]
for name in SCRIPTS:
    ast.parse((OUT/name).read_text(encoding="utf-8"), filename=name)
links = 0
for name in DOCS:
    content = (OUT/name).read_text(encoding="utf-8")
    assert not any(ord(c) < 32 and c not in "\n\r\t" for c in content)
    assert len(re.findall(r"(?<!\\)\$", content)) % 2 == 0
    for target in re.findall(r"\]\(([^)]+)\)", content):
        if target.startswith(("http:", "https:", "#")):
            continue
        assert (OUT/target).is_file(), (name, target)
        links += 1
report = json.loads((OUT/RECORDS[0]).read_text(encoding="utf-8"))
assert report["all_checks_passed"] and report["mother_conjecture_proved"] is False
assert report["local_profiles_compared_to_full_binary_enumeration"] == 15757
assert report["profiles_satisfying_proved_break_conditions"] == 13536
assert report["eligible_atlas_partitions"] == 45
assert report["unsupported_profiles_without_extension"] == 181
w = json.loads((OUT/RECORDS[1]).read_text(encoding="utf-8"))
assert len(w) == report["saved_groups"] == 6
component_tables = signed_rows = 0


def raw(data):
    V = set(data["vertices"]); E = {}; D, R, B = Counter(), Counter(), Counter()
    for u, v, x in data["edges"]:
        key = frozenset((u, v))
        assert len(key) == 2 and key <= V and key not in E and type(x) is int and x in (0, 1, 2)
        E[key] = x; D[u] += 1; D[v] += 1
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert {int(v): r for v, r in data["red"].items()} == {v: R[v] for v in V}
    assert {int(v): b for v, b in data["blue"].items()} == {v: B[v] for v in V}
    for u, v, x in data["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    assert data["mother_conjecture_proved"] is False
    return V, E, D, R, B


def conditional(data):
    global component_tables, signed_rows
    V, E, D, R, B = raw(data); T = set(data["T"]); S = V-T
    assert all(d in (3, 4) for d in D.values())
    inside = Counter(v for e in E if e <= T or e <= S for v in e)
    assert all(inside[v] == 1 for v in T)
    assert all(inside[v] <= 2 and (inside[v] != 2 or D[v] == 4) for v in S)
    M = {e for e, x in E.items() if x == 1}
    assert M == {e for e in E if e <= T} == set(map(frozenset, data["mixed_edges"]))
    assert all(R[v] % 2 == B[v] % 2 == int(v in T) for v in V)
    selected = list(map(tuple, data["selected_S_edges"]))
    assert len({v for e in selected for v in e}) == 2*len(selected)
    assert all(frozenset(e) in E and set(e) <= S for e in selected)
    pairs = [tuple(e) for e in data["row_pairs"]]
    assert {frozenset(e) for e in pairs} == M | set(map(frozenset, selected))
    cross = [i for i, (u, v, x) in enumerate(data["edges"]) if (u in T) != (v in T)]
    rows = [{i: (1 if u in data["edges"][i][:2] else -1) for i in cross
             if u in data["edges"][i][:2] or v in data["edges"][i][:2]} for u, v in pairs]
    assert rows == [dict(row) for row in data["signed_rows"]]
    occ = Counter(e for row in rows for e in row)
    assert set(occ) == set(cross) and max(occ.values()) <= 2 and all(len(row) >= 4 for row in rows)
    solution = data["signed_solution"]; signs = {int(e): y for e, y in solution["signs"].items()}
    assert set(signs) == set(cross) and all(y in (-1, 1) for y in signs.values())
    assert all(data["edges"][i][2] == 1+signs[i] for i in cross)
    sums = [sum(c*signs[i] for i, c in row.items()) for row in rows]
    assert sums == solution["row_sums"] and all(abs(s) >= 2 for s in sums)
    signed_rows += len(rows)
    visited = set(); expected_selected = set()
    for comp in data["S_components"]:
        order = comp["vertices"]; n = len(order); cycle = comp["cycle"]; ext = comp["extension"]
        assert not visited & set(order) and set(order) <= S; visited.update(order)
        m = n if cycle else n-1
        edges = [frozenset((order[i], order[(i+1) % n])) for i in range(m)]
        assert all(e in E and E[e] in (0, 2) for e in edges)
        assert sum(inside[v] for v in order) == 2*m
        degrees = [D[v] for v in order]
        cross_s = [sum(x//2 for e, x in E.items() if v in e and not(e <= S or e <= T)) for v in order]
        assert degrees == ext["degrees"] and cross_s == ext["crossing_red_counts"] and cycle == ext["cycle"]
        choices = ([0] if n % 2 else [0, 3] if n % 4 == 2 else []) if cycle else (
            [0] if n % 2 == 0 and degrees[0] == degrees[-1] else [])
        assert choices == ext["selected_break_indices"]
        expected_selected.update(edges[i] for i in choices)
        for bits in itertools.product((0, 1), repeat=m):
            r = [2*s for s in cross_s]
            for i, bit in enumerate(bits):
                r[i] += 2*bit; r[(i+1) % n] += 2*bit
            b = [2*d-a for d, a in zip(degrees, r)]
            actual_legal = all(r[i] != r[(i+1) % n] if bit else b[i] != b[(i+1) % n]
                               for i, bit in enumerate(bits))
            formula_legal = all(any(bits[i] == value for i, value in clause) for clause in ext["clauses"])
            assert actual_legal == formula_legal
            component_tables += 1
        assert ext["status"] == "extended"
        assert [E[e]//2 for e in edges] == ext["internal_bits"]
        assert all(any(ext["internal_bits"][i] == value for i, value in clause) for clause in ext["clauses"])
    assert visited == S and expected_selected == set(map(frozenset, selected))
    assert data["new_vertices_added"] == data["new_edges_added"] == 0
    return V, E, D, R, B


colored = ["K5_minus_edge_with_path_S", "triangle_blocks_actual_repair", "path_family", "two_length_six_cycles"]
whole_edges = 0
for key in colored:
    V, E, D, R, B = conditional(w[key]); whole_edges += len(E)
    if key == "K5_minus_edge_with_path_S":
        assert V == set(range(5)) and set(E) == {frozenset((u, v)) for u in range(5) for v in range(u+1, 5)
                                                if (u, v) != (0, 1)}
    if key == "triangle_blocks_actual_repair":
        expected = {frozenset((start+i, start+(i+1) % 3)) for start in (0, 3) for i in range(3)}
        for i in range(3):
            u, v, a, b = i, i+3, 6+2*i, 7+2*i
            expected |= set(map(frozenset, [(u, a), (u, b), (v, a), (v, b), (a, b)]))
        assert V == set(range(12)) and set(E) == expected and len(E) == 21
        assert w[key]["blue_only_obstruction"] == {"required_cross_degree_one_vertices": 3,
                                                   "maximum_independent_vertices_in_S": 2}
    if key == "path_family":
        expected = set(map(frozenset, [(0, 1), (1, 2), (2, 3), (4, 5), (6, 7)]))
        expected |= {frozenset((v, 4+j)) for v in range(4) for j in (v, (v-1) % 4)}
        assert V == set(range(8)) and set(E) == expected
    if key == "two_length_six_cycles":
        assert V == set(range(24)) and len(E) == 42
        assert [len(c["vertices"]) for c in w[key]["S_components"]] == [6, 6]
        assert len(w[key]["selected_S_edges"]) == 4

data = w["no_partition_but_actual_coloring"]; V, E, D, R, B = raw(data)
assert V == set(range(6)) and set(E) == {frozenset((u, v)) for u in range(3) for v in range(3, 6)} | {frozenset((0, 1))}
for mask in range(64):
    T = {v for v in V if mask >> v & 1}; S = V-T
    inside = Counter(v for e in E if e <= S or e <= T for v in e)
    assert not (all(inside[v] == 1 for v in T) and all(inside[v] <= 2 and (inside[v] != 2 or D[v] == 4) for v in S))
whole_edges += len(E)
obstruction_assignments = 0
data = w["triangle_blocks_actual_repair"]; T = set(data["T"])
cross = [(u, v) for u, v, x in data["edges"] if (u in T) != (v in T)]
for bits in itertools.product((0, 1), repeat=len(cross)):
    weights = {frozenset(e): 2*bit for e, bit in zip(cross, bits)}
    R, B = Counter(), Counter(); all_edges = []
    for u, v, old in data["edges"]:
        x = weights.get(frozenset((u, v)), int(u in T and v in T))
        R[u] += x; R[v] += x; B[u] += 2-x; B[v] += 2-x; all_edges.append((u, v, x))
    assert not all((x == 0 or R[u] != R[v]) and (x == 2 or B[u] != B[v]) for u, v, x in all_edges)
    obstruction_assignments += 1
negative_profile_assignments = 0
for p in w["local_obstruction_profiles"]:
    n = len(p["degrees"]); m = n if p["cycle"] else n-1
    for bits in itertools.product((0, 1), repeat=m):
        assert not all(any(bits[i] == value for i, value in clause) for clause in p["clauses"])
        negative_profile_assignments += 1
assert obstruction_assignments == 4096 and negative_profile_assignments == 16
inventory = {}
for name in SCRIPTS+DOCS+RECORDS:
    path = OUT/name
    inventory[name] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
audit = {"syntax_checks_including_unchanged_signed_dependency": len(SCRIPTS),
         "documents_checked": len(DOCS), "local_links_checked": links,
         "raw_whole_graphs_checked": 5, "raw_original_edges_checked": whole_edges,
         "raw_actual_copies_checked": 2*whole_edges, "saved_signed_rows_recounted": signed_rows,
         "component_truth_table_assignments_rederived": component_tables,
         "all_S_blue_obstruction_assignments_rechecked": obstruction_assignments,
         "no_partition_core_subsets_rechecked": 64,
         "negative_profile_assignments_rechecked": negative_profile_assignments,
         "same_mixed_set_and_original_graph_verified": True,
         "compatibility_junction_points_to_D": True, "all_checks_passed": True,
         "mother_conjecture_proved": False, "external_peer_review": False, "lean_formalization": False,
         "independent_auditor": {"relative_to_project": "work/audit_path_cycle_partition_stage.py",
                                "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
         "files": inventory}
(OUT/"path_cycle_partition_stage_manifest.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({k: v for k, v in audit.items() if k not in ("files", "independent_auditor")}, ensure_ascii=False, indent=2))
