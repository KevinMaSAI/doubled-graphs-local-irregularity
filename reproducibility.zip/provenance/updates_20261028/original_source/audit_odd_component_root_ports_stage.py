"""Independent stdlib-only inspection of root ports, palettes, cuts and copies."""

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT/"outputs"
COMPAT = Path(r"C:\Users\马\Documents\Codex\2026-10-26\for-every-connected-graph-g-which\outputs\mother_conjecture")
assert COMPAT.resolve() == OUT.resolve()
SCRIPTS = ["odd_component_root_ports.py", "check_odd_component_root_ports.py"]
DOCS = ["奇分量根端口的接合与无界度数构造_20261028.md", "README.md"]
RECORDS = ["odd_component_root_ports_validation.json", "odd_component_root_ports_witnesses.json"]
for name in SCRIPTS:
    ast.parse((OUT/name).read_text(encoding="utf-8"), filename=name)
links = 0
for name in DOCS:
    content = (OUT/name).read_text(encoding="utf-8")
    assert not any(ord(c) < 32 and c not in "\n\r\t" for c in content)
    assert len(re.findall(r"(?<!\\)\$", content)) % 2 == 0
    for target in re.findall(r"\]\(([^)]+)\)", content):
        if target.startswith(("http:", "https:", "#")):
            continue
        assert (OUT/target).is_file(), (name, target)
        links += 1
report = json.loads((OUT/RECORDS[0]).read_text(encoding="utf-8"))
assert report["all_checks_passed"] and report["mother_conjecture_proved"] is False
assert report["degree_profile_checks"] == {"path_colorings": 1830, "degree_profiles": 1059,
    "cycle_colorings": 2823, "cycle_root_phase_checks": 3813,
    "inadmissible_root_rejections": 464, "isolated_root_colorings": 5}
assert report["fixed_root_atlas_outcomes"] == {"colored": 373, "no_parity_join_for_these_roots": 354}
w = json.loads((OUT/RECORDS[1]).read_text(encoding="utf-8"))
assert len(w) == report["saved_groups"] == 5


def components(vertices, edges):
    adj = {v: set() for v in vertices}
    for u, v in edges:
        adj[u].add(v); adj[v].add(u)
    seen, groups = set(), []
    for root in vertices:
        if root in seen:
            continue
        order, seen = [root], seen | {root}
        for v in order:
            for u in adj[v]-seen:
                seen.add(u); order.append(u)
        groups.append(set(order))
    return groups


def raw(data):
    V = set(data["vertices"]); T = set(data["T"]); E = {}; D, R, B = Counter(), Counter(), Counter()
    for u, v, x in data["edges"]:
        e = frozenset((u, v))
        assert len(e) == 2 and e <= V and e not in E and type(x) is int and x in (0, 1, 2)
        E[e] = x; D[u] += 1; D[v] += 1
        for copy in range(2):
            counts = R if copy < x else B
            counts[u] += 1; counts[v] += 1
    assert {int(v): a for v, a in data["red"].items()} == {v: R[v] for v in V}
    assert {int(v): a for v, a in data["blue"].items()} == {v: B[v] for v in V}
    for u, v, x in data["edges"]:
        for copy in range(2):
            counts = R if copy < x else B
            assert counts[u] != counts[v]
    assert all(R[v] % 2 == B[v] % 2 == int(v not in T) for v in V)
    assert data["mother_conjecture_proved"] is False
    return V, E, D, R, B


palette_vertices = phase_edges = 0


def root_certificate(data):
    global palette_vertices, phase_edges
    V, E, D, red, blue = raw(data); T = set(data["T"]); S = V-T; roots = set(data["roots"])
    assert not any(e <= T for e in E)
    internal = {e for e in E if e <= S}; cross = set(E)-internal
    sd = Counter(v for e in internal for v in e); cd = Counter(v for e in cross for v in e)
    assert all(sd[v] <= 2 and (not sd[v] or cd[v] >= 2) for v in S)
    assert all(abs(D[u]-D[v]) <= 1 for e in internal for u, v in [tuple(e)])
    N = set(map(frozenset, data["mixed_port_edges"]))
    M = {e for e, x in E.items() if x == 1}
    assert M == set(map(frozenset, data["mixed_edges"])) and N <= cross
    assert all(len(e & roots) == len(e & T) == 1 for e in N)
    assert M & cross == N
    md = Counter(v for e in N for v in e)
    assert all(md[v] % 2 == 1 for v in roots) and all(md[v] % 2 == 0 for v in T)
    assert all(not md[v] for v in S-roots)
    insideM = M & internal
    assert Counter(v for e in insideM for v in e) == Counter({v: 1 for v in S-roots})
    assert all(x == 0 for e, x in E.items() if e in internal-insideM)
    assert dict(data["S_red_targets"]) == {v: red[v] for v in S}
    assert all(red[v] in (1, 5) for v in S-roots)
    assert all((md[v] in (1, 3) and red[v] == 3) if sd[v] else red[v] == md[v] for v in roots)
    for e in internal:
        u, v = tuple(e)
        if e & roots:
            assert E[e] == 0 and blue[u] != blue[v]
            phase_edges += 1
        else:
            assert abs(red[u]-red[v]) == 4 and blue[u] != blue[v]
    visited = set()
    for c in data["S_components"]:
        order = c["vertices"]; n = len(order)
        assert not visited & set(order); visited.update(order)
        expected = {frozenset((order[i], order[(i+1) % n])) for i in range(n if c["cycle"] else n-1)}
        assert {e for e in internal if e <= set(order)} == expected
        assert sum(sd[v] for v in order) == 2*len(expected)
        chosen = set(order) & roots
        assert len(chosen) == n % 2
        if n % 2:
            root = next(iter(chosen)); assert c["chosen_root"] == root
            j = order.index(root)
            if c["cycle"]:
                a, b = order[(j-1) % n], order[(j+1) % n]
                assert not (D[a] == D[b] and abs(D[a]-D[root]) == 1)
            else:
                assert j % 2 == 0
        else:
            assert c["chosen_root"] is None
    assert visited == S
    assert data["new_vertices_added"] == data["new_edges_added"] == 0
    palette_vertices += len(S)
    return V, E, D, red, blue


keys = ["bridge_family_with_two_odd_triangles", "unbounded_degrees_and_leaves",
        "three_ports_at_nonisolated_path_roots", "pairing_fails_but_branching_ports_work"]
edge_count = 0
for key in keys:
    V, E, D, R, B = root_certificate(w[key]); edge_count += len(E)
bridge = w[keys[0]]; V, E, D, R, B = raw(bridge); T = set(bridge["T"])
assert len(V) == 40 and len(E) == 63 and Counter(D.values()) == Counter({3: 34, 4: 6})
odd_components = [c for c in bridge["S_components"] if len(c["vertices"]) % 2]
assert len(odd_components) == 2 and all(c["cycle"] and len(c["vertices"]) == 3 for c in odd_components)
u, center, v = bridge["root_pair"]
assert center in T and set(map(frozenset, bridge["mixed_port_edges"])) == {frozenset((u, center)), frozenset((v, center))}
C = {e for e in E for a, b in [tuple(e)] if (a in T) != (b in T)}
assert len(components(list(V), [tuple(e) for e in C])) == 1
odd_cuts = 0
for s in bridge["bridge_S_vertices"]:
    incident = [e for e in C if s in e]
    assert len(incident) == 2
    for edge in incident:
        a = next(iter(edge-{s}))
        U = next(group for group in components(list(V), [tuple(e) for e in C-{edge}]) if a in group)
        assert s not in U and len(U & T) % 2
        assert {e for e in C for a, b in [tuple(e)] if (a in U) != (b in U)} == {edge}
        odd_cuts += 1
a, b = bridge["forced_S_pair"]
assert frozenset((a, b)) in E and D[a] == D[b] == 3
assert {e for e in set(E)-C if a in e or b in e} == {frozenset((a, b))}
high = w[keys[1]]; Vh, Eh, Dh, Rh, Bh = raw(high)
assert len(Vh) == 19 and len(Eh) == 82 and min(Dh.values()) == 1 and max(Dh.values()) == 12
assert sum(d == 1 for d in Dh.values()) == 2
paths = w[keys[2]]; Vp, Ep, Dp, Rp, Bp = raw(paths)
assert len(Vp) == 13 and len(Ep) == 30 and set(paths["roots"]) == {2, 7}
assert all(sum(v in e for e in paths["mixed_port_edges"]) == 3 and Rp[v] == 3 for v in paths["roots"])
assert all(Rp[v] == 5 for v in [1, 3, 6, 8])
branch = w[keys[3]]; Vb, Eb, Db, Rb, Bb = raw(branch); T = set(branch["T"]); roots = set(branch["roots"])
assert len(Vb) == 19 and len(Eb) == 30 and len(roots) == 10
Q = set()
for center in T:
    neighbors = {v for e in Eb if center in e for v in e if v in roots}
    Q |= {frozenset((u, v)) for u in neighbors for v in neighbors if u != v}
deleted = set(branch["root_pairing_tutte_barrier"]["deleted_roots"])
groups = components(sorted(roots-deleted), [tuple(e) for e in Q if not e & deleted])
assert len(groups) == 3 > len(deleted) == 1 and all(len(c) == 3 for c in groups)
assert {frozenset(c) for c in groups} == set(map(frozenset, branch["root_pairing_tutte_barrier"]["odd_components"]))
assert sum(0 in e for e in branch["mixed_port_edges"]) == 3
gap = w["even_component_transport_gap"]; actual = gap["actual_coloring"]
Vg, Eg, Dg, Rg, Bg = raw(actual); edge_count += len(Eg)
assert len(Vg) == 7 and len(Eg) == 7
negative = gap["root_only_negative"]; roots = set(negative["roots"]); T = set(negative["T"])
indexed = [tuple(e) for e in negative["original_edges"]]
assert set(map(frozenset, indexed)) == set(Eg) and roots == {0, 1}
allowed = [i for i, (u, v) in enumerate(indexed) if (u in roots and v in T) or (v in roots and u in T)]
assert allowed == negative["allowed_edge_indices"]
U = set(negative["odd_root_component"])
assert len(U & roots) % 2 and all((u in U) == (v in U) for i in allowed for u, v in [indexed[i]])
full_cross = [tuple(e) for e in Eg for u, v in [tuple(e)] if (u in T) != (v in T)]
assert len(components(sorted(Vg), full_cross)) == 1 and len(roots) % 2 == 0
assert any(x == 1 and bool(e & ({2, 3})) and bool(e & T) for e, x in Eg.items())
inventory = {}
for name in SCRIPTS+DOCS+RECORDS:
    path = OUT/name
    inventory[name] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
audit = {"syntax_checks": len(SCRIPTS), "documents_checked": len(DOCS), "local_links_checked": links,
         "raw_whole_graphs_checked": 5, "raw_original_edges_checked": edge_count,
         "raw_actual_copies_checked": 2*edge_count,
         "root_palette_vertices_rederived": palette_vertices, "root_adjacent_blue_edges_checked": phase_edges,
         "bridge_half_odd_cut_certificates_rederived": odd_cuts,
         "root_pairing_barrier_odd_components": len(groups),
         "fixed_root_negative_cut_and_even_component_repair_verified": True,
         "unbounded_degree_and_leaf_example_verified": True,
         "compatibility_junction_points_to_D": True, "all_checks_passed": True,
         "mother_conjecture_proved": False, "external_peer_review": False, "lean_formalization": False,
         "independent_auditor": {"relative_to_project": "work/audit_odd_component_root_ports_stage.py",
                                "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, "files": inventory}
(OUT/"odd_component_root_ports_stage_manifest.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({k: v for k, v in audit.items() if k not in ("files", "independent_auditor")}, ensure_ascii=False, indent=2))
