"""Search structured families for a failure of the coefficient criterion only."""
import itertools
import json
import time
from pathlib import Path

import networkx as nx

from coefficient_frontier import coefficient


def theta(lengths):
    g = nx.Graph()
    next_vertex = 2
    for length in lengths:
        path = [0] + list(range(next_vertex, next_vertex+length-1)) + [1]
        next_vertex += length-1
        g.add_edges_from(zip(path, path[1:]))
    return g


def barbell(p, q, length):
    g = nx.Graph()
    left = list(range(p))
    g.add_edges_from(zip(left, left[1:]+left[:1]))
    path = [0] + list(range(p, p+length))
    g.add_edges_from(zip(path, path[1:]))
    root = path[-1]
    right = [root] + list(range(root+1, root+q))
    g.add_edges_from(zip(right, right[1:]+right[:1]))
    return g


def cycle_arms(k, length):
    g = nx.Graph()
    centers = [i*(length+1) for i in range(k)]
    for i, u in enumerate(centers):
        g.add_edge(u, centers[(i+1) % k])
        path = list(range(u, u+length+1))
        g.add_edges_from(zip(path, path[1:]))
    return g


def cases():
    for lengths in itertools.combinations_with_replacement(range(1, 11), 3):
        if lengths[1] == 1 or sum(lengths) > 24:
            continue
        yield ('theta', lengths, theta(lengths))
    for p in range(3, 9):
        for q in range(p, 9):
            for length in range(1, 9):
                yield ('barbell', (p, q, length), barbell(p, q, length))
    for k in range(3, 16):
        for length in range(1, 7):
            yield ('cycle_arms', (k, length), cycle_arms(k, length))


def main():
    start = time.monotonic()
    counts = {}
    zeros = []
    report = {'scope': 'Bounded structured diagnostics, not a universal coloring result.'}
    for family, args, g in cases():
        c = coefficient(g)
        counts[family] = counts.get(family, 0) + 1
        if not c:
            m = g.number_of_edges()
            item = {'family': family, 'args': args, 'n': len(g), 'edges': list(g.edges()),
                    'canonical_coefficient': c,
                    'parameter_all_1': coefficient(g, [1]*m),
                    'parameter_all_minus1': coefficient(g, [-1]*m)}
            zeros.append(item)
            print(json.dumps(item), flush=True)
        if zeros or time.monotonic()-start > 60:
            break
    report.update(counts=counts, zeros=zeros, elapsed=time.monotonic()-start)
    Path('work/structured_coefficient_diagnostic.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'zeros'}), flush=True)


if __name__ == '__main__':
    main()
