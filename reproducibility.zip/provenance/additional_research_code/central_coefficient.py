"""Exact coefficient diagnostic for a stronger Nullstellensatz approach."""
import json
import time
from pathlib import Path

import networkx as nx


def coefficient(g):
    edges=list(g.edges())
    m=len(edges)
    polynomial={(0,)*m:1}
    for u,v in edges:
        factor=[]
        for j,(a,b) in enumerate(edges):
            c=int(u in (a,b))-int(v in (a,b))
            if c:
                factor.append((j,c))
        new={}
        for exponent,value in polynomial.items():
            for j,c in factor:
                if exponent[j]>=2:
                    continue
                e=list(exponent)
                e[j]+=1
                e=tuple(e)
                new[e]=new.get(e,0)+c*value
        polynomial={e:c for e,c in new.items() if c}
    total=sum(value*polynomial.get(tuple(2-x for x in exponent),0)
              for exponent,value in polynomial.items())
    return {'coefficient':(-1)**m*total,'retained_terms':len(polynomial)}


def main():
    start=time.monotonic()
    cases={
        'P4':nx.path_graph(4),
        'P6':nx.path_graph(6),
        'C3':nx.cycle_graph(3),
        'C4':nx.cycle_graph(4),
        'C5':nx.cycle_graph(5),
        'C6':nx.cycle_graph(6),
        'K4':nx.complete_graph(4),
        'K5':nx.complete_graph(5),
        'K2_3':nx.complete_bipartite_graph(2,3),
        'K3_3':nx.complete_bipartite_graph(3,3),
        'diamond':nx.complete_graph(4),
    }
    cases['diamond'].remove_edge(0,1)
    results=[]
    for name,g in cases.items():
        item={'name':name,'n':len(g),'m':g.number_of_edges(),**coefficient(g)}
        results.append(item)
        print(json.dumps(item),flush=True)
    Path('work/central_coefficient_diagnostic.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps({'elapsed_seconds':time.monotonic()-start}),flush=True)


if __name__=='__main__':
    main()
