"""Exact coefficient extraction, eliminating variables at their last use."""
import argparse
import json
import time
from pathlib import Path

import networkx as nx


def quadratic_factors(g, parameters=None):
    edges = list(g.edges())
    factors = []
    for i, (u, v) in enumerate(edges):
        delta = g.degree(u) - g.degree(v)
        t = 2 * delta if parameters is None else parameters[i]
        d = {j: int(u in edge) - int(v in edge) for j, edge in enumerate(edges)}
        d = {j: c for j, c in d.items() if c}
        f = {}
        for j, a in d.items():
            for k, b in d.items():
                pair = tuple(sorted((j, k)))
                f[pair] = f.get(pair, 0) + a*b
        for j, a in d.items():
            pair = tuple(sorted((i, j)))
            f[pair] = f.get(pair, 0) + t*a
        f[(i, i)] = f.get((i, i), 0) + t*delta
        factors.append({pair: c for pair, c in f.items() if c})
    return factors


def extract(factors):
    if any(not f for f in factors):
        return 0
    last = {}
    for i, f in enumerate(factors):
        for pair in f:
            for j in pair:
                last[j] = i
    active = []
    poly = {(): 1}
    for i, f in enumerate(factors):
        variables = sorted(set(active) | {j for pair in f for j in pair})
        position = {j: k for k, j in enumerate(variables)}
        staying = [j for j in variables if last[j] != i]
        leaving_positions = [position[j] for j in variables if last[j] == i]
        staying_positions = [position[j] for j in staying]
        old_positions = [position[j] for j in active]
        terms = [(position[j], position[k], c) for (j, k), c in f.items()]
        new = {}
        for e, value in poly.items():
            full = [0] * len(variables)
            for old_index, new_index in enumerate(old_positions):
                full[new_index] = e[old_index]
            for j, k, c in terms:
                if full[j] + 1 + int(j == k) > 2 or full[k] >= 2:
                    continue
                result = full.copy()
                result[j] += 1
                result[k] += 1
                if any(result[p] != 2 for p in leaving_positions):
                    continue
                key = tuple(result[p] for p in staying_positions)
                new[key] = new.get(key, 0) + value*c
        poly = {e: c for e, c in new.items() if c}
        active = staying
    return poly.get((), 0)


def coefficient(g, parameters=None):
    return extract(quadratic_factors(g, parameters))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--max-n', type=int, default=14)
    args = ap.parse_args()
    start = time.monotonic()
    checked = 0
    first_zero = None
    for n in range(3, args.max_n+1):
        count = 0
        for index, g in enumerate(nx.nonisomorphic_trees(n)):
            c = coefficient(g)
            checked += 1
            count += 1
            if not c:
                first_zero = {'n': n, 'tree_index': index, 'edges': list(g.edges()),
                              'parameters_1': coefficient(g, [1]*g.number_of_edges()),
                              'parameters_minus1': coefficient(g, [-1]*g.number_of_edges())}
                print(json.dumps({'zero': first_zero}), flush=True)
                break
        print(json.dumps({'n': n, 'checked_at_n': count, 'total': checked,
                          'elapsed': time.monotonic()-start}), flush=True)
        if first_zero:
            break
    report = {'scope': 'Finite coefficient-strategy diagnostic, not a coloring theorem.',
              'checked': checked, 'first_zero': first_zero,
              'elapsed': time.monotonic()-start}
    Path('work/tree_actual_coefficient_diagnostic.json').write_text(json.dumps(report, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
