"""GF(2) principal-minor certificates for the multiaffine coefficient polynomial."""
import itertools
import json
import time
from pathlib import Path

import networkx as nx

from coefficient_frontier import coefficient, extract, quadratic_factors


def det2(matrix):
    a = [[x % 2 for x in row] for row in matrix]
    n = len(a)
    for j in range(n):
        pivot = next((i for i in range(j, n) if a[i][j]), None)
        if pivot is None:
            return 0
        a[j], a[pivot] = a[pivot], a[j]
        for i in range(j+1, n):
            if a[i][j]:
                a[i] = [x ^ y for x, y in zip(a[i], a[j])]
    return 1


def matrices(g):
    edges = list(g.edges())
    adjacency = [[int(i != j and bool(set(e) & set(f)))
                  for j, f in enumerate(edges)] for i, e in enumerate(edges)]
    laplacian = [row.copy() for row in adjacency]
    for i, row in enumerate(adjacency):
        laplacian[i][i] = sum(row) % 2
    return adjacency, laplacian


def minor(a, indices):
    return [[a[i][j] for j in indices] for i in indices]


def predicted_parameter_coefficient(g, subset):
    adjacency, laplacian = matrices(g)
    complement = [i for i in range(len(adjacency)) if i not in subset]
    return det2(minor(laplacian, subset)) * det2(minor(adjacency, complement))


def exact_parameter_coefficient(g, subset):
    m = g.number_of_edges()
    zero = quadratic_factors(g, [0]*m)
    one = quadratic_factors(g, [1]*m)
    factors = []
    for i in range(m):
        if i in subset:
            keys = set(zero[i]) | set(one[i])
            factors.append({key: one[i].get(key, 0)-zero[i].get(key, 0)
                            for key in keys if one[i].get(key, 0) != zero[i].get(key, 0)})
        else:
            factors.append(zero[i])
    return extract(factors)


def main():
    start = time.monotonic()
    cases = [('P3', nx.path_graph(3)), ('P4', nx.path_graph(4)),
             ('P6', nx.path_graph(6)), ('C3', nx.cycle_graph(3)),
             ('K4', nx.complete_graph(4)), ('star3', nx.star_graph(3)),
             ('H7', nx.Graph([(0,1),(0,4),(1,2),(1,4),(2,3),(4,5),(5,6)])),
             ('atlas574', nx.graph_atlas_g()[574])]
    reports = []
    for name, g in cases:
        m = g.number_of_edges()
        odd_subsets = []
        for bits in range(1 << m):
            subset = [i for i in range(m) if bits & (1 << i)]
            predicted = predicted_parameter_coefficient(g, subset)
            actual = exact_parameter_coefficient(g, subset) % 2
            assert predicted == actual, (name, subset, predicted, actual)
            if predicted:
                odd_subsets.append(subset)
        reports.append({'graph': name, 'm': m, 'parameter_coefficients_checked': 1 << m,
                        'odd_coefficients': len(odd_subsets),
                        'first_odd_subset': next(iter(odd_subsets), None),
                        'canonical_coefficient': coefficient(g)})
        print(json.dumps(reports[-1]), flush=True)
    report = {'scope': 'Independent finite formula validation; theorem follows from algebraic proof.',
              'graphs': reports, 'elapsed': time.monotonic()-start}
    Path('work/parity_certificate_validation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
