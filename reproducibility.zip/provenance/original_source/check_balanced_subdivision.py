"""Independent copy-count checks for the balanced-port construction."""

import itertools
import json
import random
import sys
import time
from pathlib import Path

import networkx as nx

OUTPUTS = Path(__file__).resolve().parent
if OUTPUTS.name != "outputs":
    OUTPUTS = OUTPUTS.parent / "outputs"
sys.path.insert(0, str(OUTPUTS))
from balanced_subdivision import (balanced_halfedge_ports, color_partial_subdivision,
                                  extend_by_subdivision_paths, fill_balanced_path)


def check_ports(graph):
    result = balanced_halfedge_ports(graph)
    totals = {v: 0 for v in graph}
    for (u, v, _), (a, b) in zip(result["edge_order"], result["ports"]):
        assert a in (0, 1, 2) and b in (0, 1, 2) and a != b
        totals[u] += a
        totals[v] += b
    assert totals == dict(graph.degree())
    ones = {v: 0 for v in graph}
    for (u, v, _), (a, b) in zip(result["edge_order"], result["ports"]):
        ones[u] += int(a == 1)
        ones[v] += int(b == 1)
    assert all(ones[v] == graph.degree(v) % 2 for v in graph)


def check_copy_graph(graph, weights, root_degrees):
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for u, v in graph.edges():
        value = weights[tuple(sorted((u, v)))]
        assert value in (0, 1, 2)
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
    assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    assert nx.is_connected(graph)
    assert nx.number_of_selfloops(graph) == 0
    for v, expected in root_degrees.items():
        assert graph.degree(v) == expected
        assert red.degree(v) == blue.degree(v) == expected


def check_extension(base, old_weights, connector, lengths):
    graph, weights, certificate = extend_by_subdivision_paths(base, old_weights, connector, lengths)
    labels = {v: i for i, v in enumerate(base)}
    for (u, v), old in zip(base.edges(), old_weights):
        new = weights[tuple(sorted((labels[u], labels[v])))]
        assert new == (1 if old is None else old)
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(graph)
    blue.add_nodes_from(graph)
    for u, v in graph.edges():
        value = weights[tuple(sorted((u, v)))]
        for copy in range(2):
            (red if copy < value else blue).add_edge(u, v)
    assert all(red.degree(u) != red.degree(v) for u, v in red.edges())
    assert all(blue.degree(u) != blue.degree(v) for u, v in blue.edges())
    assert all(red.degree(v) == count for v, count in certificate["root_red"].items())
    assert all(blue.degree(v) == count for v, count in certificate["root_blue"].items())
    assert nx.is_connected(graph) and nx.number_of_selfloops(graph) == 0


def regular_connector(nodes, degree):
    result = nx.MultiGraph()
    result.add_nodes_from(nodes)
    n = len(nodes)
    if n == 1:
        assert degree % 2 == 0
        result.add_edges_from([(nodes[0], nodes[0])] * (degree // 2))
    elif n == 2:
        result.add_edges_from([(nodes[0], nodes[1])] * degree)
    else:
        for _ in range(degree // 2):
            result.add_edges_from((nodes[i], nodes[(i + 1) % n]) for i in range(n))
        if degree % 2:
            assert n % 2 == 0
            result.add_edges_from((nodes[i], nodes[i + 1]) for i in range(0, n, 2))
    assert all(d == degree for _, d in result.degree())
    return result


def check_path(length, a, b, left, right):
    word = fill_balanced_path(length, a, b, left, right)
    red, blue = nx.MultiGraph(), nx.MultiGraph()
    red.add_nodes_from(range(length + 1))
    blue.add_nodes_from(range(length + 1))
    for i, value in enumerate(word):
        for copy in range(2):
            (red if copy < value else blue).add_edge(i, i + 1)
    rd = {v: red.degree(v) for v in range(length + 1)}
    bd = {v: blue.degree(v) for v in range(length + 1)}
    # These are fixed external counts, not comparisons of external edges.
    rd[0], bd[0] = left, left
    rd[length], bd[length] = right, right
    assert word[0] == a and word[-1] == b
    assert all(rd[u] != rd[v] for u, v in red.edges())
    assert all(bd[u] != bd[v] for u, v in blue.edges())


def main():
    started = time.monotonic()
    port_cases = 0
    separated_pair_cases = 0
    for n, multiplicities in ((1, range(5)), (2, range(4)), (3, range(3)), (4, range(2))):
        kinds = list(itertools.combinations_with_replacement(range(n), 2))
        for counts in itertools.product(multiplicities, repeat=len(kinds)):
            graph = nx.MultiGraph()
            graph.add_nodes_from(range(n))
            for edge, count in zip(kinds, counts):
                graph.add_edges_from([edge] * count)
            if any(d == 1 for _, d in graph.degree()):
                continue
            check_ports(graph)
            port_cases += 1
            for u, v in itertools.combinations(graph, 2):
                if graph.degree(u) == 0 or graph.degree(v) == 0 or graph.degree(u) % 2 != graph.degree(v) % 2:
                    continue
                result = balanced_halfedge_ports(graph, [(u, v)])
                totals = dict.fromkeys(graph, 0)
                for (a, b, _), (left, right) in zip(result["edge_order"], result["ports"]):
                    assert left != right
                    totals[a] += left
                    totals[b] += right
                assert all(totals[w] == graph.degree(w) for w in graph if w not in (u, v))
                assert sorted((abs(totals[u] - graph.degree(u)), abs(totals[v] - graph.degree(v)))) == [0, 1]
                separated_pair_cases += 1

    path_cases = 0
    for length in list(range(2, 25)) + [100, 1000]:
        for left, right in itertools.product((4, 5, 6, 9, 1000), repeat=2):
            for a, b in itertools.permutations(range(3), 2):
                check_path(length, a, b, left, right)
                path_cases += 1

    rng = random.Random(20261027)
    graph_cases = []
    bases = []
    for n in range(5, 23):
        bases.append(nx.complete_graph(n))
        for degree in (4, 5, 6):
            if degree < n and n * degree % 2 == 0:
                bases.append(nx.random_regular_graph(degree, n, seed=rng.randrange(1 << 30)))
    for _ in range(70):
        n = rng.randrange(5, 25)
        graph = nx.MultiGraph(nx.random_regular_graph(4, n, seed=rng.randrange(1 << 30)))
        for _ in range(rng.randrange(n + 1)):
            graph.add_edge(rng.randrange(n), rng.randrange(n))
        bases.append(graph)
    loop_graph = nx.MultiGraph()
    loop_graph.add_edges_from([(0, 0), (0, 0)])
    bases.append(loop_graph)
    loop_pair = nx.MultiGraph()
    loop_pair.add_edges_from([(0, 0), (1, 1), (0, 1), (0, 1), (0, 1)])
    bases.append(loop_pair)
    for index, base in enumerate(bases):
        assert nx.is_connected(base) and min(dict(base.degree()).values()) >= 4
        records = list(base.edges(keys=True)) if base.is_multigraph() else list(base.edges())
        lengths = [rng.randrange(2 if e[0] != e[1] else 3, 12) for e in records]
        graph, weights, certificate = color_partial_subdivision(base, lengths)
        check_copy_graph(graph, weights, certificate["root_degrees"])
        graph_cases.append({"base_vertices": len(base), "base_edges": base.number_of_edges(),
                            "base_min_degree": min(dict(base.degree()).values()),
                            "base_max_degree": max(dict(base.degree()).values()),
                            "expanded_vertices": len(graph), "has_loops": nx.number_of_selfloops(base) > 0,
                            "has_length_two": 2 in lengths, "passed": True})

    # Direct edges really are present. They are not silently subdivided.
    partial_cases = 0
    for a, b in ((4, 5), (4, 6), (5, 8), (8, 11)):
        base = nx.complete_bipartite_graph(a, b)
        for variant in range(8):
            retained = {(u, v) for u in range(a // 2) for v in range(a, a + b // 2)}
            lengths = [1 if (u, v) in retained else rng.randrange(2, 12)
                       for u, v in base.edges()]
            graph, weights, certificate = color_partial_subdivision(base, lengths)
            check_copy_graph(graph, weights, certificate["root_degrees"])
            assert any(item["length"] == 1 for item in certificate["threads"])
            partial_cases += 1
            if a == 4 and b == 6 and variant == 0:
                example = {"base_edges": list(base.edges()), "lengths": lengths,
                           "expanded_edges": [[u, v, weights[(u, v)]] for u, v in sorted(graph.edges())],
                           "certificate": certificate}
                (OUTPUTS / "balanced_subdivision_example.json").write_text(
                    json.dumps(example, ensure_ascii=False, indent=2), encoding="utf-8")

    extension_cases = 0
    extension_K2_pairs = 0
    for atlas in nx.graph_atlas_g():
        if len(atlas) == 0 or len(atlas) > 5 or atlas.number_of_edges() > 6:
            continue
        edges = list(atlas.edges())
        k2_edges = set()
        for component in nx.connected_components(atlas):
            if len(component) == 2:
                u, v = tuple(component)
                if atlas.has_edge(u, v):
                    k2_edges.add(frozenset((u, v)))
        positions = [i for i, e in enumerate(edges) if frozenset(e) not in k2_edges]
        legal = 0
        for values in itertools.product(range(3), repeat=len(positions)):
            old = [None] * len(edges)
            for i, value in zip(positions, values):
                old[i] = value
            red = dict.fromkeys(atlas, 0)
            for (u, v), value in zip(edges, old):
                if value is not None:
                    red[u] += value
                    red[v] += value
            blue = {v: 2 * atlas.degree(v) - red[v] for v in atlas}
            if any(value is not None and ((value > 0 and red[u] == red[v]) or (value < 2 and blue[u] == blue[v]))
                   for (u, v), value in zip(edges, old)):
                continue
            for degree in ((4, 5, 6) if len(atlas) % 2 == 0 else (4, 6)):
                connector = regular_connector(list(atlas), degree)
                lengths = [rng.randrange(3 if u == v else 2, 9) for u, v, _ in connector.edges(keys=True)]
                check_extension(atlas, old, connector, lengths)
                extension_cases += 1
                extension_K2_pairs += len(k2_edges)
            legal += 1
            if legal == 8:
                break
    for pair_count in (1, 2, 5, 10, 21):
        base = nx.Graph()
        base.add_edges_from((2 * i, 2 * i + 1) for i in range(pair_count))
        for degree in (4, 5, 6):
            connector = regular_connector(list(base), degree)
            lengths = [rng.randrange(2, 9) for _ in connector.edges()]
            check_extension(base, [None] * pair_count, connector, lengths)
            extension_cases += 1
            extension_K2_pairs += pair_count
    # Different connector degrees are permitted on distinct base components.
    base = nx.Graph([(0, 1), (1, 2), (2, 0), (3, 4)])
    base.add_node(5)
    old_map = {frozenset((0, 1)): 0, frozenset((1, 2)): 1, frozenset((2, 0)): 2,
               frozenset((3, 4)): None}
    old = [old_map[frozenset(e)] for e in base.edges()]
    connector = nx.MultiGraph([(0, 3), (0, 4), (0, 5), (0, 5),
                               (1, 3), (1, 4), (1, 5), (1, 5),
                               (2, 3), (2, 4), (2, 5), (2, 5), (3, 4)])
    assert dict(connector.degree()) == {0: 4, 3: 4, 4: 4, 5: 6, 1: 4, 2: 4}
    check_extension(base, old, connector, [2 + i % 4 for i in range(connector.number_of_edges())])
    extension_cases += 1
    extension_K2_pairs += 1

    rejected = []
    for name, action in (
        ("degree_one_port_graph", lambda: balanced_halfedge_ports(nx.star_graph(3))),
        ("retained_regular_edges", lambda: color_partial_subdivision(nx.complete_graph(5), [1] * 10)),
    ):
        try:
            action()
        except ValueError:
            rejected.append(name)
        else:
            raise AssertionError(name)
    # Exercise the selected-degree-one validation without an earlier failed gate.
    base = nx.complete_bipartite_graph(4, 5)
    try:
        color_partial_subdivision(base, [3] + [1] * 19)
    except ValueError as error:
        assert "at least two" in str(error)
        rejected.append("selected_degree_one")
    else:
        raise AssertionError("selected_degree_one")

    result = {"port_graph_cases": port_cases, "separated_pair_port_cases": separated_pair_cases,
              "path_boundary_cases": path_cases,
              "full_subdivision_graph_cases": len(graph_cases), "partial_subdivision_graph_cases": partial_cases,
              "preserved_coloring_extension_cases": extension_cases,
              "filled_K2_components_across_extension_cases": extension_K2_pairs,
              "maximum_tested_base_degree": max(r["base_max_degree"] for r in graph_cases),
              "implementation_checks_passed": True, "rejected_inputs": rejected,
              "seconds": time.monotonic() - started,
              "scope": "Finite independent implementation checks. Infinite scope rests on the proof in the note.",
              "mother_conjecture_proved": False}
    (OUTPUTS / "balanced_subdivision_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
