#!/usr/bin/env python3
"""Construct and recount a locally irregular two-colouring of a doubled subcubic graph."""
import argparse,json,sys
from pathlib import Path
from collections import Counter
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'artifact'))

def recount(graph,result):
    if result.get('status')!='colored':raise RuntimeError('The constructor did not return a colouring.')
    edges=result['edge_order'];weights=result['weights']
    assert len(edges)==len(weights)==graph.number_of_edges()
    assert Counter(map(frozenset,edges))==Counter(map(frozenset,graph.edges()))
    red=dict.fromkeys(graph,0);blue=dict.fromkeys(graph,0)
    for (u,v),x in zip(edges,weights):
        assert type(x)==int and x in (0,1,2)
        red[u]+=x;red[v]+=x;blue[u]+=2-x;blue[v]+=2-x
    for (u,v),x in zip(edges,weights):
        for _ in range(x):assert red[u]!=red[v]
        for _ in range(2-x):assert blue[u]!=blue[v]
    assert red==result['red'] and blue==result['blue']
    return red,blue

def from_input(data):
    import networkx as nx
    vertices=data['vertices'];edges=data['edges']
    if not vertices or any(type(v)!=int for v in vertices) or len(set(vertices))!=len(vertices):
        raise ValueError('vertices must be a nonempty list of distinct integers')
    keys=[]
    for edge in edges:
        if len(edge)!=2 or any(type(v)!=int or v not in vertices for v in edge) or edge[0]==edge[1]:
            raise ValueError('Every edge must join two distinct listed integer vertices')
        keys.append(frozenset(edge))
    if len(set(keys))!=len(keys):raise ValueError('Duplicate edges are not allowed')
    g=nx.Graph();g.add_nodes_from(vertices);g.add_edges_from(edges)
    if not nx.is_connected(g):raise ValueError('The graph must be connected')
    if len(g)==2:raise ValueError('K2 is excluded')
    if max(dict(g.degree()).values())>3:raise ValueError('Maximum degree must be at most three')
    return g

def main():
    if not __debug__:raise SystemExit('Do not run the constructor/recount with -O.')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path)
    p.add_argument('--output',type=Path);args=p.parse_args()
    try:
        from subcubic_bip_core_no_three import color_subcubic_two_marked
        g=from_input(json.loads(args.input.read_text(encoding='utf-8')))
        result=color_subcubic_two_marked(g);red,blue=recount(g,result)
    except ModuleNotFoundError as e:
        raise SystemExit('Install the optional constructor dependency: python -m pip install -r requirements.txt') from e
    except (ValueError,KeyError,TypeError) as e:raise SystemExit(str(e)) from e
    report={'scope':'finite connected simple subcubic graphs other than K2',
            'status':'locally_irregular_two_colouring_recounted',
            'vertices':[{'vertex':v,'red_degree':red[v],'blue_degree':blue[v]} for v in g],
            'edges':[{'endpoints':[u,v],'red_copies':x,'blue_copies':2-x}
                     for (u,v),x in zip(result['edge_order'],result['weights'])],
            'arbitrary_degree_mother_conjecture_proved':False}
    text=json.dumps(report,indent=2)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text,encoding='utf-8')
    print(text,end='')

if __name__=='__main__':main()
